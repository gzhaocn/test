package com.walmart.mobile.checkout.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.walmart.mobile.checkout.annotation.PrivilegeInfo;
import com.walmart.mobile.checkout.bo.Page;
import com.walmart.mobile.checkout.bo.StoreOrder;
import com.walmart.mobile.checkout.domain.delivery.Delivery;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.exception.handler.ResultBody;
import com.walmart.mobile.checkout.service.DeliveryService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Controller
@RequestMapping("/delivery")
public class DeliveryController {

	@Autowired
	private DeliveryService deliveryService;

	@ApiOperation(value = "getDeliveryByOrderId", notes = "通过订单号获取运单")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -905, message = "非法用户"),
			@ApiResponse(code = -906, message = "运单正在创建中") })
	@RequestMapping(value = "/detail/order", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	@PrivilegeInfo
	public ResponseEntity<ResultBody> getDeliveryByOrderId(@RequestBody StoreOrder storeOrder) throws GlobalErrorInfoException {
		Delivery delivery = deliveryService.getDeliveryByOrderId(storeOrder);
		deliveryService.checkUser(delivery.getUserId());
		ResultBody result = new ResultBody(delivery);
		return new ResponseEntity<>(result, HttpStatus.OK);
	}

	@ApiOperation(value = "getDeliveryListByUserId", notes = "获取当前用户的运单列表")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功") })
	@RequestMapping(value = "/list/user", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	@PrivilegeInfo
	public ResponseEntity<ResultBody> getDeliveryListByUserId(@RequestBody Page page) throws GlobalErrorInfoException {
		return new ResponseEntity<>(new ResultBody(deliveryService.getDeliveryListByUserId(page)), HttpStatus.OK);
	}

	// @ApiOperation(value = "getDeliveryOrderByUserId", notes =
	// "获取当前用户的未打包的运单")
	// @ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0,
	// message = "成功"), @ApiResponse(code = -900, message = "没有找到可以打包的运单") })
	// @RequestMapping(value = "/detail/user/{storeId}", method =
	// RequestMethod.POST)
	// @ResponseStatus(HttpStatus.OK)
	// @ResponseBody
	// @PrivilegeInfo
	// public ResponseEntity<ResultBody>
	// getDeliveryOrderByUserId(@PathVariable("storeId") Integer storeId) throws
	// GlobalErrorInfoException {
	// return new ResponseEntity<>(new
	// ResultBody(deliveryService.getDeliveryByUserId(storeId)), HttpStatus.OK);
	// }

	// @ApiOperation(value = "packageDelivery", notes = "运单打包")
	// @ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0,
	// message = "成功"), @ApiResponse(code = -900, message = "没有找到可以打包的运单"),
	// @ApiResponse(code = -902, message = "运单打包失败"), @ApiResponse(code = -905,
	// message = "非法用户"),
	// @ApiResponse(code = -908, message = "box被其他用户使用,result字段包含无效的boxid列表"),
	// @ApiResponse(code = -909, message = "插入box信息失败"),
	// @ApiResponse(code = -910, message = "更新box信息失败") })
	// @RequestMapping(value = "/package", method = RequestMethod.POST)
	// @ResponseStatus(HttpStatus.OK)
	// @ResponseBody
	// @PrivilegeInfo
	// public ResponseEntity<ResultBody> packageDelivery(@RequestBody BindBox
	// bindBox) throws GlobalErrorInfoException {
	// deliveryService.checkBoxId(bindBox.getStoreId(),
	// bindBox.getDeliveryBoxList());
	// Delivery delivery =
	// deliveryService.getDeliveryWithoutLine(bindBox.getDeliveryId(), true);
	// deliveryService.checkUser(delivery.getUserId());
	// deliveryService.checkOp(delivery, DeliveryConstant.TO_BE_PACKAGE);
	// deliveryService.packageDelivery(bindBox, delivery);
	// return new ResponseEntity<>(new ResultBody(), HttpStatus.OK);
	// }
}
