package com.walmart.mobile.checkout.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.walmart.mobile.checkout.bo.OpenBody;
import com.walmart.mobile.checkout.bo.OpenParam;
import com.walmart.mobile.checkout.domain.delivery.Delivery;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.exception.handler.ResultBody;
import com.walmart.mobile.checkout.service.DeliveryOpenService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Controller
@RequestMapping("/delivery/open")
public class DeliveryOpenController {

	@Autowired
	private DeliveryOpenService deliveryOpenService;

	@ApiOperation(value = "getDeliveryByOrderId", notes = "通过订单号获取运单")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -906, message = "运单正在创建中"),
			@ApiResponse(response = ResultBody.class, code = -911, message = "签名不通过"),
			@ApiResponse(response = ResultBody.class, code = -912, message = "签名加密算法不存在") })
	@RequestMapping(value = "/detail/order", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResponseEntity<ResultBody> getDeliveryByOrderId(@RequestBody OpenParam<OpenBody> openParam) throws GlobalErrorInfoException {
		openParam.checkSum();
		Delivery delivery = deliveryOpenService.getDeliveryByDeliveryId(openParam.getBody());
		ResultBody result = new ResultBody(delivery);
		return new ResponseEntity<>(result, HttpStatus.OK);
	}

	@ApiOperation(value = "getDeliveryListByStore", notes = "获取当前用户的运单列表")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"),
			@ApiResponse(response = ResultBody.class, code = -911, message = "签名不通过"),
			@ApiResponse(response = ResultBody.class, code = -912, message = "签名加密算法不存在") })
	@RequestMapping(value = "/list/store", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResponseEntity<ResultBody> getDeliveryListByStore(@RequestBody OpenParam<OpenBody> openParam) throws GlobalErrorInfoException {
		openParam.checkSum();
		return new ResponseEntity<>(new ResultBody(deliveryOpenService.getDeliveryListByStore(openParam.getBody())), HttpStatus.OK);
	}

	// @ApiOperation(value = "packageDelivery", notes = "运单已发货")
	// @ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0,
	// message = "成功,result中有成功的记录数"),
	// @ApiResponse(response = ResultBody.class, code = -911, message =
	// "签名不通过"),
	// @ApiResponse(response = ResultBody.class, code = -912, message =
	// "签名加密算法不存在") })
	// @RequestMapping(value = "/package", method = RequestMethod.POST)
	// @ResponseStatus(HttpStatus.OK)
	// @ResponseBody
	// public ResponseEntity<ResultBody> packageDelivery(@RequestBody
	// OpenParam<OpenBody> openParam) throws GlobalErrorInfoException {
	// openParam.checkSum();
	// return new ResponseEntity<>(new
	// ResultBody(deliveryOpenService.packageDelivery(openParam.getBody())),
	// HttpStatus.OK);
	// }

	@ApiOperation(value = "sendDelivery", notes = "运单已发货")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功,result中有成功的记录数"),
			@ApiResponse(response = ResultBody.class, code = -911, message = "签名不通过"),
			@ApiResponse(response = ResultBody.class, code = -912, message = "签名加密算法不存在") })
	@RequestMapping(value = "/send", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResponseEntity<ResultBody> sendDelivery(@RequestBody OpenParam<OpenBody> openParam) throws GlobalErrorInfoException {
		openParam.checkSum();
		return new ResponseEntity<>(new ResultBody(deliveryOpenService.sendDelivery(openParam.getBody())), HttpStatus.OK);
	}

	@ApiOperation(value = "signDelivery", notes = "运单已签收")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功,result中有成功的记录数"),
			@ApiResponse(response = ResultBody.class, code = -911, message = "签名不通过"),
			@ApiResponse(response = ResultBody.class, code = -912, message = "签名加密算法不存在") })
	@RequestMapping(value = "/sign", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResponseEntity<ResultBody> signDelivery(@RequestBody OpenParam<OpenBody> openParam) throws GlobalErrorInfoException {
		openParam.checkSum();
		return new ResponseEntity<>(new ResultBody(deliveryOpenService.signDelivery(openParam.getBody())), HttpStatus.OK);
	}

}
