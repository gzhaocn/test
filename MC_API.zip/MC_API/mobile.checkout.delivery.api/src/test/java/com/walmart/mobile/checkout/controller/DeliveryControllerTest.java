package com.walmart.mobile.checkout.controller;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import javax.servlet.http.Cookie;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.config.MainConfig;
import com.walmart.mobile.checkout.exception.handler.ResultBody;
import com.walmart.mobile.checkout.utils.PropertyUtils;

@RunWith(SpringRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { MainConfig.class })
public class DeliveryControllerTest {

	protected MockMvc mockMVC;

	@Autowired
	private WebApplicationContext wac;

	@Before
	public void before() {
		mockMVC = MockMvcBuilders.webAppContextSetup(wac).build();
		System.out.println(wac + "  " + mockMVC);
		MockitoAnnotations.initMocks(this);
	}

	// @Test
	// public void packageDeliveryTest() throws Exception {
	// String requestJson =
	// PropertyUtils.getConfigValue("delivery.packageDelivery");
	// String restUrl = "/delivery/package";
	// execute(restUrl, requestJson);
	// }

	@Test
	public void getDeliveryOrderByOrderIdTest() throws Exception {
		String requestJson = PropertyUtils.getConfigValue("delivery.getDeliveryOrderByOrderId");
		String restUrl = "/delivery/detail/order";
		execute(restUrl, requestJson);
	}

	// @Test
	// public void getDeliveryOrderByUserIdTest() throws Exception {
	// String requestJson = "";
	// String restUrl = "/delivery/detail/user/1059";
	// execute(restUrl, requestJson);
	// }

	@Test
	public void getDeliveryListByUserIdTest() throws Exception {
		String requestJson = PropertyUtils.getConfigValue("delivery.getDeliveryListByUserId");
		String restUrl = "/delivery/list/user";
		execute(restUrl, requestJson);
	}

	private void execute(String restUrl, String requestJson) throws Exception {
		String responseString = mockMVC
				.perform(MockMvcRequestBuilders.post(restUrl).contentType(MediaType.APPLICATION_JSON).cookie(cookies()).content(requestJson))
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
		ResultBody resultBody = JSONObject.parseObject(responseString, ResultBody.class);
		// Assert.assertEquals(resultBody.getCode(), "0");
	}

	private Cookie[] cookies() {
		Cookie[] cookies = new Cookie[3];
		cookies[0] = new Cookie("dagId", "001");
		cookies[1] = new Cookie("token", "7be2cf2f42614d8e901f25d2119e5846");
		cookies[2] = new Cookie("appType", "6");
		return cookies;
	}

}
