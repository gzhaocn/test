USE [MobileCheckout]
GO

/****** Object:  Table [dbo].[order_shipping_line]    Script Date: 2018/2/2 18:36:09 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[order_shipping_line](
	[order_id] [varchar](21) NOT NULL,
	[product_id] [bigint] NOT NULL,
	[cart_item_id] [bigint] NOT NULL,
	[upc] [bigint] NOT NULL,
	[item_type] [int] NOT NULL,
	[price_with_tax] [decimal](10, 2) NOT NULL,
	[order_quantity] [int] NULL,
	[thumbnail_url] [varchar](200) NULL,
	[desc_online] [varchar](200) NULL,
	[was_price] [decimal](10, 2) NULL,
	[price_without_tax] [decimal](10, 2) NULL,
	[tax_rate] [decimal](5, 4) NULL,
	[unit_cost] [decimal](12, 4) NULL,
	[return_by] [datetime] NULL,
	[gp_discount] [decimal](10, 2) NULL,
	[store_id] [int] NULL,
	[report_code] [int] NULL,
	[department] [int] NULL,
	[pos_desc_online] [varchar](200) NULL,
	[item_number] [bigint] NULL,
 CONSTRAINT [PK__order_shipping__022945F602BBB999] PRIMARY KEY CLUSTERED 
(
	[order_id] ASC,
	[product_id] ASC,
	[cart_item_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

