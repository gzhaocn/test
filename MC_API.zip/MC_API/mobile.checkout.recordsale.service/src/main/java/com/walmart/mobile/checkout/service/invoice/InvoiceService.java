package com.walmart.mobile.checkout.service.invoice;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.bo.invoice.InvoiceData;
import com.walmart.mobile.checkout.bo.invoice.InvoiceInfo;
import com.walmart.mobile.checkout.bo.invoice.InvoiceItemInfo;
import com.walmart.mobile.checkout.bo.invoice.InvoiceMainInfo;
import com.walmart.mobile.checkout.bo.invoice.InvoiceTitleInfo;
import com.walmart.mobile.checkout.bo.invoice.InvoiceUserInfo;
import com.walmart.mobile.checkout.bo.order.OrderBo;
import com.walmart.mobile.checkout.bo.order.OrderLineBo;
import com.walmart.mobile.checkout.domain.refund.Refund;
import com.walmart.mobile.checkout.utils.DateUtil;

@Service
public class InvoiceService {

	private static final Integer WEIGHT_TYPE = 1;

	@Value("${invoice.store.test}")
	private String invoiceStoreTest;
	
	@Value("${invoice.platformNo}")
	private String platformNo;

	public String sendInvoiceInfo(OrderBo orderBo, String applyKey, String tcNumber, List<Refund> refundList) {
		InvoiceInfo invoiceInfo = new InvoiceInfo();
		InvoiceData invoiceData = new InvoiceData();
		// 设置invoiceMainInfo
		InvoiceMainInfo invoiceMainInfo = new InvoiceMainInfo();
		invoiceMainInfo.setGroupFlag("Walmart");
		if ("1".equals(invoiceStoreTest)) {
			invoiceMainInfo.setStoreCode("HO");
		} else {
			invoiceMainInfo.setStoreCode(orderBo.getStoreId() + "");
		}

		/** invoiceMainInfo.setMiAccount("MI207045");//开发   
		 * invoiceMainInfo.setMiAccount("MI170429"); //之前生产* /
		 */
		invoiceMainInfo.setMiAccount("");
		invoiceMainInfo.setPosNo(tcNumber);
		invoiceMainInfo.setPosDate(DateUtil.dateToString(orderBo.getPaidTime(), DateUtil.PATTERN_YYYYMMDD));
		invoiceMainInfo.setAmountWithTax(orderBo.getAmount().toString());
		invoiceMainInfo.setInvoiceType("ce");
		invoiceMainInfo.setRemark(orderBo.getOrderId());
		invoiceMainInfo.setOuterDiscountWithTax(orderBo.getPaymentCouponFee().toString());
		invoiceMainInfo.setEmail(orderBo.getInvoiceEmail());
		invoiceData.getMain().add(invoiceMainInfo);
		// 设置invoiceItemInfo List
		List<OrderLineBo> list = orderBo.getOrderLineBoList();

		Map<String, Integer> refundMap = buildRefundMap(refundList);
		List<Integer> refundAllList = new ArrayList<>();

		for (OrderLineBo orderLineBo : list) {
			String orderLineKey = orderLineBo.getOrderId() + orderLineBo.getCartItemId() + orderLineBo.getProductId();
			Integer returnQuantity = null;
			if (!refundMap.isEmpty()) {
				returnQuantity = refundMap.get(orderLineKey);
			}
			int invoiceQuantity = orderLineBo.getOrderQuantity() - (returnQuantity == null ? 0 : returnQuantity);
			if (invoiceQuantity <= 0) {
				refundAllList.add(invoiceQuantity);
				continue;
			}
			InvoiceItemInfo invoiceItemInfo = new InvoiceItemInfo();
			invoiceItemInfo.setItemName(orderLineBo.getPosDescOnline());
			invoiceItemInfo.setQuantity(String.valueOf(invoiceQuantity));

			if (WEIGHT_TYPE == orderLineBo.getItemType()) {
				invoiceItemInfo.setAmountWithTax(orderLineBo.getItemAmount());
				invoiceItemInfo.setUnitPrice(orderLineBo.getItemAmount());
			} else {
				invoiceItemInfo.setAmountWithTax(orderLineBo.getPriceWithTax()
						.multiply(new BigDecimal(invoiceQuantity)));
				invoiceItemInfo.setUnitPrice(orderLineBo.getPriceWithTax());
			}
			invoiceItemInfo.setOuterDiscountWithTax(new BigDecimal(invoiceQuantity).multiply(
					orderLineBo.getGpDiscount()).divide(new BigDecimal(orderLineBo.getOrderQuantity()), 2,
					BigDecimal.ROUND_HALF_UP));

			invoiceItemInfo.setVolunCode("H" + orderLineBo.getUpc());
			invoiceItemInfo.setTaxRate(orderLineBo.getTaxRate().multiply(new BigDecimal(100)).intValue());
			invoiceMainInfo.getDetails().add(invoiceItemInfo);
		}

		if (CollectionUtils.isNotEmpty(refundAllList) && list.size() == refundAllList.size()) {
			return StringUtils.EMPTY;
		}

		// 设置invoiceTitleInfo
		InvoiceTitleInfo title = new InvoiceTitleInfo();
		title.setName(orderBo.getInvoiceTitle());
		title.setTaxerId(orderBo.getTaxCode());
		invoiceData.getTitle().add(title);
		// 设置invoiceTitleInfo
		InvoiceUserInfo user = new InvoiceUserInfo();
		user.setMobilePhone(orderBo.getMobilePhone());
		user.setUserId(platformNo);
		invoiceData.getUser().add(user);

		invoiceInfo.setRequestData(invoiceData);
		invoiceInfo.setAppKey(applyKey);
		return JSONObject.toJSONString(invoiceInfo);
	}

	private Map<String, Integer> buildRefundMap(List<Refund> refundList) {
		Map<String, Integer> refundMap = new HashMap<>(16);
		if (CollectionUtils.isNotEmpty(refundList)) {
			refundList.forEach(refund -> {
				String orderId = refund.getOrderId();
				Long cartItemId = refund.getCartItemId();
				Long productId = refund.getProductId();
				String key = orderId + cartItemId + productId;
				if (refundMap.containsKey(key)) {
					refundMap.put(key, refund.getReturnQuantity() + refundMap.get(key));
				} else {
					refundMap.put(key, refund.getReturnQuantity());
				}
			});
		}
		return refundMap;
	}
}
