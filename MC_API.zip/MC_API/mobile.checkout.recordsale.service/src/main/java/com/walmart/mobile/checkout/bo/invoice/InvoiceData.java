package com.walmart.mobile.checkout.bo.invoice;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class InvoiceData implements Serializable {

	private static final long serialVersionUID = 6272975997549157392L;

	private List<InvoiceMainInfo> main = new ArrayList<>();
	private List<InvoiceTitleInfo> title = new ArrayList<>();

	private List<InvoiceUserInfo> user = new ArrayList<>();

	public List<InvoiceTitleInfo> getTitle() {
		return title;
	}

	public void setTitle(List<InvoiceTitleInfo> title) {
		this.title = title;
	}

	public List<InvoiceUserInfo> getUser() {
		return user;
	}

	public void setUser(List<InvoiceUserInfo> user) {
		this.user = user;
	};

	public List<InvoiceMainInfo> getMain() {
		return main;
	}

	public void setMain(List<InvoiceMainInfo> main) {
		this.main = main;
	}

}
