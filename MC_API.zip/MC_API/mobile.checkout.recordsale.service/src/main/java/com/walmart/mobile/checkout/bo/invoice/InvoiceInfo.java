package com.walmart.mobile.checkout.bo.invoice;

import java.io.Serializable;

public class InvoiceInfo implements Serializable {

	private static final long serialVersionUID = 6272975997549157392L;

	private InvoiceData requestData;

	private String appKey;

	public InvoiceData getRequestData() {
		return requestData;
	}

	public void setRequestData(InvoiceData requestData) {
		this.requestData = requestData;
	}

	public String getAppKey() {
		return appKey;
	}

	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}

}
