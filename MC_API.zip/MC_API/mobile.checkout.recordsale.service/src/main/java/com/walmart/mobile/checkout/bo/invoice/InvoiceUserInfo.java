package com.walmart.mobile.checkout.bo.invoice;

import java.io.Serializable;

public class InvoiceUserInfo implements Serializable {

	private static final long serialVersionUID = -9034787818727071530L;

	private String mobilePhone;

	private String userId;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getMobilePhone() {
		return mobilePhone;
	}

	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}

}
