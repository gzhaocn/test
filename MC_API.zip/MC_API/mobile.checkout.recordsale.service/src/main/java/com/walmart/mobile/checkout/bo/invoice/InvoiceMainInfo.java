package com.walmart.mobile.checkout.bo.invoice;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class InvoiceMainInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5389067370048347607L;

	// 约定参数
	private String groupFlag;

	// 门店代码
	private String storeCode;

	// 小票订单号tcNumber
	private String posNo;

	// 小票日期
	private String posDate;

	// 开票名称 不需要填充
	private String itemeName;

	// 商品总金额
	private String amountWithTax;
	// 折扣金额
	private String outerDiscountWithTax;

	// 发票类型[M], c:普票 ce:普电票 s:专票 //ce
	private String invoiceType;
	// [O]
	private String miAccount;

	private String saleCheckId;

	// 订单号 orderId
	private String remark;

	private String cashierName;

	private String checkerName;

	private String invoicerName;

	private String originInvoiceNo;

	private String originInvoiceCode;

	private String email;

	private List<InvoiceItemInfo> details = new ArrayList<>();

	public List<InvoiceItemInfo> getDetails() {
		return details;
	}

	public void setDetails(List<InvoiceItemInfo> details) {
		this.details = details;
	}

	public String getGroupFlag() {
		return groupFlag;
	}

	public void setGroupFlag(String groupFlag) {
		this.groupFlag = groupFlag;
	}

	public String getStoreCode() {
		return storeCode;
	}

	public void setStoreCode(String storeCode) {
		this.storeCode = storeCode;
	}

	public String getPosNo() {
		return posNo;
	}

	public void setPosNo(String posNo) {
		this.posNo = posNo;
	}

	public String getPosDate() {
		return posDate;
	}

	public void setPosDate(String posDate) {
		this.posDate = posDate;
	}

	public String getItemeName() {
		return itemeName;
	}

	public void setItemeName(String itemeName) {
		this.itemeName = itemeName;
	}

	public String getAmountWithTax() {
		return amountWithTax;
	}

	public void setAmountWithTax(String amountWithTax) {
		this.amountWithTax = amountWithTax;
	}

	public String getOuterDiscountWithTax() {
		return outerDiscountWithTax;
	}

	public void setOuterDiscountWithTax(String outerDiscountWithTax) {
		this.outerDiscountWithTax = outerDiscountWithTax;
	}

	public String getInvoiceType() {
		return invoiceType;
	}

	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}

	public String getMiAccount() {
		return miAccount;
	}

	public void setMiAccount(String miAccount) {
		this.miAccount = miAccount;
	}

	public String getSaleCheckId() {
		return saleCheckId;
	}

	public void setSaleCheckId(String saleCheckId) {
		this.saleCheckId = saleCheckId;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getCashierName() {
		return cashierName;
	}

	public void setCashierName(String cashierName) {
		this.cashierName = cashierName;
	}

	public String getCheckerName() {
		return checkerName;
	}

	public void setCheckerName(String checkerName) {
		this.checkerName = checkerName;
	}

	public String getInvoicerName() {
		return invoicerName;
	}

	public void setInvoicerName(String invoicerName) {
		this.invoicerName = invoicerName;
	}

	public String getOriginInvoiceNo() {
		return originInvoiceNo;
	}

	public void setOriginInvoiceNo(String originInvoiceNo) {
		this.originInvoiceNo = originInvoiceNo;
	}

	public String getOriginInvoiceCode() {
		return originInvoiceCode;
	}

	public void setOriginInvoiceCode(String originInvoiceCode) {
		this.originInvoiceCode = originInvoiceCode;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
