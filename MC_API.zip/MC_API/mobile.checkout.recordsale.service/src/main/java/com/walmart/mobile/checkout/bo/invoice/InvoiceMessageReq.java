package com.walmart.mobile.checkout.bo.invoice;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
 *
 */
@ApiModel(description = "invoice Message")
public class InvoiceMessageReq implements Serializable {

	private static final long serialVersionUID = 4131472891358275455L;

	@ApiModelProperty(value = "订单号")
	@JsonProperty(value = "orderId")
	private String orderId;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

}
