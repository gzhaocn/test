package com.walmart.mobile.checkout.bo.invoice;

import java.io.Serializable;

public class InvoiceTitleInfo implements Serializable {

	private static final long serialVersionUID = -2119102412547329880L;

	// "公司/个人", [M] 发票抬头
	private String name;

	private String taxerId;

	private String bankName;

	private String bankAccount;
	private String companyAddr;
	private String companyPhone;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTaxerId() {
		return taxerId;
	}

	public void setTaxerId(String taxerId) {
		this.taxerId = taxerId;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankAccount() {
		return bankAccount;
	}

	public void setBankAccount(String bankAccount) {
		this.bankAccount = bankAccount;
	}

	public String getCompanyAddr() {
		return companyAddr;
	}

	public void setCompanyAddr(String companyAddr) {
		this.companyAddr = companyAddr;
	}

	public String getCompanyPhone() {
		return companyPhone;
	}

	public void setCompanyPhone(String companyPhone) {
		this.companyPhone = companyPhone;
	}

}
