package com.walmart.mobile.checkout.bo.invoice;

import java.io.Serializable;
import java.math.BigDecimal;

public class InvoiceItemInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4860733132177605733L;

	// 明细名称
	private String itemName;

	// 数量
	private String quantity;

	// 单价
	private BigDecimal unitPrice;

	// 明细直接折扣
	private BigDecimal outerDiscountWithTax;

	// 明细编号 upc
	private String volunCode;

	// 商品总金额
	private BigDecimal amountWithTax;
	// 税率", [M]，整数（17）[O] //整数
	private Integer taxRate;

	// 商品货物税收分类编码",[O]不用填充
	private String itemCode;

	// 条形码
	private String barCode;

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public BigDecimal getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(BigDecimal unitPrice) {
		this.unitPrice = unitPrice;
	}


	public String getVolunCode() {
		return volunCode;
	}

	public void setVolunCode(String volunCode) {
		this.volunCode = volunCode;
	}

	public BigDecimal getAmountWithTax() {
		return amountWithTax;
	}

	public void setAmountWithTax(BigDecimal amountWithTax) {
		this.amountWithTax = amountWithTax;
	}

	public Integer getTaxRate() {
		return taxRate;
	}

	public void setTaxRate(Integer taxRate) {
		this.taxRate = taxRate;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public String getBarCode() {
		return barCode;
	}

	public void setBarCode(String barCode) {
		this.barCode = barCode;
	}

	public BigDecimal getOuterDiscountWithTax() {
		return outerDiscountWithTax;
	}

	public void setOuterDiscountWithTax(BigDecimal outerDiscountWithTax) {
		this.outerDiscountWithTax = outerDiscountWithTax;
	}

}
