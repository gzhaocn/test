package com.walmart.mobile.checkout.bo;

import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "门店参数模型")
public class OpenBody {

	@ApiModelProperty(value = "门店")
	private Integer storeId;

	@ApiModelProperty(value = "运单号")
	private String deliveryId;

	@ApiModelProperty(value = "运单状态 : 参考DeliveryConstant类")
	private Integer status;

	@ApiModelProperty(value = "运单操作人")
	private String updateBy;

	@ApiModelProperty(value = "运单列表")
	private List<String> deliveryList;

	public String getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public String getDeliveryId() {
		return deliveryId;
	}

	public void setDeliveryId(String deliveryId) {
		this.deliveryId = deliveryId;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public List<String> getDeliveryList() {
		return deliveryList;
	}

	public void setDeliveryList(List<String> deliveryList) {
		this.deliveryList = deliveryList;
	}
}
