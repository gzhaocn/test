package com.walmart.mobile.checkout.deliveryMapper;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.jdbc.SQL;

import com.walmart.mobile.checkout.bo.OpenBody;
import com.walmart.mobile.checkout.bo.Page;
import com.walmart.mobile.checkout.domain.delivery.Delivery;

public interface DeliveryMapper {

	@Results({ @Result(property = "deliveryId", column = "delivery_id", id = true), @Result(property = "orderId", column = "order_id"),
			@Result(property = "userId", column = "user_id"), @Result(property = "storeId", column = "store_id"),
			@Result(property = "deliveryType", column = "delivery_type"), @Result(property = "shippingFee", column = "shipping_fee"),
			@Result(property = "deliveryName", column = "delivery_name"), @Result(property = "deliveryPhone", column = "delivery_phone"),
			@Result(property = "deliveryDate", column = "delivery_date"), @Result(property = "deliveryPeriod", column = "delivery_period"),
			@Result(property = "deliveryPeriodDesc", column = "delivery_period_desc"), @Result(property = "deliveryBy", column = "delivery_by"),
			@Result(property = "deliveryStartTime", column = "delivery_start_time"), @Result(property = "deliveryEndTime", column = "delivery_end_time"),
			@Result(property = "createdBy", column = "created_by"), @Result(property = "createdTime", column = "created_time"),
			@Result(property = "updatedBy", column = "updated_by"), @Result(property = "updatedTime", column = "updated_time") })
	@Select("select top ${page.row} * from (select row_number() over(order by created_time desc) as rownumber, * "
			+ "from delivery where user_id = #{userId,jdbcType=VARCHAR}) A where rownumber > #{page.start,jdbcType=INTEGER} order by created_time desc")
	List<Delivery> getDeliveryListByUserId(@Param("page") Page page, @Param("userId") String userId);

	@Results({ @Result(property = "deliveryId", column = "delivery_id", id = true), @Result(property = "orderId", column = "order_id"),
			@Result(property = "userId", column = "user_id"), @Result(property = "storeId", column = "store_id"),
			@Result(property = "deliveryType", column = "delivery_type"), @Result(property = "shippingFee", column = "shipping_fee"),
			@Result(property = "deliveryName", column = "delivery_name"), @Result(property = "deliveryPhone", column = "delivery_phone"),
			@Result(property = "deliveryDate", column = "delivery_date"), @Result(property = "deliveryPeriod", column = "delivery_period"),
			@Result(property = "deliveryPeriodDesc", column = "delivery_period_desc"), @Result(property = "deliveryBy", column = "delivery_by"),
			@Result(property = "deliveryStartTime", column = "delivery_start_time"), @Result(property = "deliveryEndTime", column = "delivery_end_time"),
			@Result(property = "createdBy", column = "created_by"), @Result(property = "createdTime", column = "created_time"),
			@Result(property = "updatedBy", column = "updated_by"), @Result(property = "updatedTime", column = "updated_time") })
	@Select("select  * from delivery where order_id=#{orderId}")
	Delivery getDeliveryByOrderId(String orderId);

	@Results({ @Result(property = "deliveryId", column = "delivery_id", id = true), @Result(property = "orderId", column = "order_id"),
			@Result(property = "userId", column = "user_id"), @Result(property = "storeId", column = "store_id"),
			@Result(property = "deliveryType", column = "delivery_type"), @Result(property = "shippingFee", column = "shipping_fee"),
			@Result(property = "deliveryName", column = "delivery_name"), @Result(property = "deliveryPhone", column = "delivery_phone"),
			@Result(property = "deliveryDate", column = "delivery_date"), @Result(property = "deliveryPeriod", column = "delivery_period"),
			@Result(property = "deliveryPeriodDesc", column = "delivery_period_desc"), @Result(property = "deliveryBy", column = "delivery_by"),
			@Result(property = "deliveryStartTime", column = "delivery_start_time"), @Result(property = "deliveryEndTime", column = "delivery_end_time"),
			@Result(property = "createdBy", column = "created_by"), @Result(property = "createdTime", column = "created_time"),
			@Result(property = "updatedBy", column = "updated_by"), @Result(property = "updatedTime", column = "updated_time") })
	@Select("select * from delivery where delivery_id=#{deliveryId}")
	Delivery getDeliveryByDeliveryId(String deliveryId);

	@Results({ @Result(property = "deliveryId", column = "delivery_id", id = true), @Result(property = "orderId", column = "order_id"),
			@Result(property = "userId", column = "user_id"), @Result(property = "storeId", column = "store_id"),
			@Result(property = "deliveryType", column = "delivery_type"), @Result(property = "shippingFee", column = "shipping_fee"),
			@Result(property = "deliveryName", column = "delivery_name"), @Result(property = "deliveryPhone", column = "delivery_phone"),
			@Result(property = "deliveryDate", column = "delivery_date"), @Result(property = "deliveryPeriod", column = "delivery_period"),
			@Result(property = "deliveryPeriodDesc", column = "delivery_period_desc"), @Result(property = "deliveryBy", column = "delivery_by"),
			@Result(property = "deliveryStartTime", column = "delivery_start_time"), @Result(property = "deliveryEndTime", column = "delivery_end_time"),
			@Result(property = "createdBy", column = "created_by"), @Result(property = "createdTime", column = "created_time"),
			@Result(property = "updatedBy", column = "updated_by"), @Result(property = "updatedTime", column = "updated_time") })
	@Select("select top 1 * from delivery where user_id=#{userId} and store_id = #{storeId} and status=#{status} order by created_time desc")
	Delivery getDeliveryByUserId(@Param("userId") String userId, @Param("status") Integer status, @Param("storeId") Integer storeId);

	@Update("update delivery set status= #{toStatus},updated_time=#{currentDate} where order_id=#{orderId} and status in (${statusList})")
	Integer updateDeliveryByOrderId(@Param("orderId") String orderId, @Param("statusList") String statusList, @Param("toStatus") Integer toStatus,
			@Param("currentDate") Date currentDate);

	@Update("update delivery set status= #{toStatus},updated_time=#{currentDate} where delivery_id=#{deliveryId} and status in (${statusList})")
	Integer updateDeliveryByDeliveryId(@Param("deliveryId") String deliveryId, @Param("statusList") String statusList, @Param("toStatus") Integer toStatus,
			@Param("currentDate") Date currentDate);

	@Update("update delivery set status= #{toStatus},updated_time=#{currentDate} where store_id = #{storeId} and delivery_id=#{deliveryId} and status in (${statusList})")
	Integer updateDeliveryByStoreAndDeliveryId(@Param("storeId") Integer storeId, @Param("deliveryId") String deliveryId,
			@Param("statusList") String statusList, @Param("toStatus") Integer toStatus, @Param("currentDate") Date currentDate);

	@Results({ @Result(property = "deliveryId", column = "delivery_id", id = true), @Result(property = "orderId", column = "order_id"),
			@Result(property = "userId", column = "user_id"), @Result(property = "storeId", column = "store_id"),
			@Result(property = "deliveryType", column = "delivery_type"), @Result(property = "shippingFee", column = "shipping_fee"),
			@Result(property = "deliveryName", column = "delivery_name"), @Result(property = "deliveryPhone", column = "delivery_phone"),
			@Result(property = "deliveryDate", column = "delivery_date"), @Result(property = "deliveryPeriod", column = "delivery_period"),
			@Result(property = "deliveryPeriodDesc", column = "delivery_period_desc"), @Result(property = "deliveryBy", column = "delivery_by"),
			@Result(property = "deliveryStartTime", column = "delivery_start_time"), @Result(property = "deliveryEndTime", column = "delivery_end_time"),
			@Result(property = "createdBy", column = "created_by"), @Result(property = "createdTime", column = "created_time"),
			@Result(property = "updatedBy", column = "updated_by"), @Result(property = "updatedTime", column = "updated_time") })
	@SelectProvider(type = DeliveryProvider.class, method = "getDeliveryListByStore")
	List<Delivery> getDeliveryListByStore(OpenBody openBody);

	class DeliveryProvider {
		public String getDeliveryListByStore(OpenBody openBody) {
			String body = new StringBuilder().append("store_id=#{storeId} and")
					.append(openBody.getDeliveryId() != null ? " delivery_id = #{deliveryId}" : " status = #{status}").toString();
			return new SQL().SELECT("*").FROM("delivery").WHERE(body).ORDER_BY("created_time desc").toString();
		}
	}
}