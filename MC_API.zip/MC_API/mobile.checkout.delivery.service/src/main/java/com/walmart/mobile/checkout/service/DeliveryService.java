package com.walmart.mobile.checkout.service;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.walmart.mobile.checkout.bo.BindBox;
import com.walmart.mobile.checkout.bo.Page;
import com.walmart.mobile.checkout.bo.StoreOrder;
import com.walmart.mobile.checkout.constant.AppConstants;
import com.walmart.mobile.checkout.constant.DeliveryConstant;
import com.walmart.mobile.checkout.constant.DeliveryErrorInfoEnum;
import com.walmart.mobile.checkout.deliveryMapper.DeliveryLineMapper;
import com.walmart.mobile.checkout.deliveryMapper.DeliveryMapper;
import com.walmart.mobile.checkout.deliveryMapper.DeliverySequenceMapper;
import com.walmart.mobile.checkout.domain.delivery.Delivery;
import com.walmart.mobile.checkout.domain.delivery.DeliveryLine;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.utils.ThreadLocalContextHolder;

@Service
public class DeliveryService {

	private final Logger logger = LoggerFactory.getLogger(DeliveryService.class);

	@Autowired
	private DeliveryMapper deliveryMapper;

	/*
	 * @Autowired private DeliveryBoxMapper deliveryBoxMapper;
	 */

	/*
	 * @Autowired private DeliveryBoxMappingMapper deliveryBoxMappingMapper;
	 */

	@Autowired
	private DeliverySequenceMapper deliverySequenceMapper;

	@Autowired
	private DeliveryLineMapper deliveryLineMapper;

	public boolean paidDelivery(String orderId) {
		return deliveryMapper.updateDeliveryByOrderId(orderId, DeliveryConstant.getAllowStatusSql(DeliveryConstant.TO_BE_DELIVERY), DeliveryConstant.TO_BE_DELIVERY, new Date()) > 0;
	}

	public boolean cancelDelivery(String orderId) throws GlobalErrorInfoException {
		Delivery delivery = getDeliveryWithoutLine(orderId, false);
		logger.info("current delivery status:{},deliveryId:{},orderId:{}", delivery.getStatus(), delivery.getDeliveryId(), orderId);
		return deliveryMapper.updateDeliveryByOrderId(orderId, DeliveryConstant.getAllowStatusSql(DeliveryConstant.CANCEL), DeliveryConstant.CANCEL, new Date()) > 0;
	}

	public List<Delivery> getDeliveryListByUserId(Page page) {
		return deliveryMapper.getDeliveryListByUserId(page, ThreadLocalContextHolder.getUserId());
	}

	// public Delivery getDeliveryByUserId(Integer storeId) throws
	// GlobalErrorInfoException {
	// String currentUserId = ThreadLocalContextHolder.get(AppConstants.USERID,
	// String.class);
	// Delivery delivery = deliveryMapper.getDeliveryByUserId(currentUserId,
	// DeliveryConstant.TO_BE_PACKAGE, storeId);
	// if (delivery == null) {
	// throw new GlobalErrorInfoException(DeliveryErrorInfoEnum.NOT_BIND_BOX);
	// }
	// List<DeliveryLine> deliveryLineList =
	// deliveryLineMapper.getDeliveryLineByOrderId(delivery.getOrderId());
	// delivery.setDeliveryLineList(deliveryLineList);
	// return delivery;
	// }

	public Delivery getDeliveryByOrderId(StoreOrder storeOrder) throws GlobalErrorInfoException {
		Delivery delivery = getDeliveryWithoutLine(storeOrder.getOrderId(), false);
		setDeliveryLine(delivery);
		return delivery;
	}

	private void setDeliveryLine(Delivery delivery) throws GlobalErrorInfoException {
		if (delivery == null) {
			throw new GlobalErrorInfoException(DeliveryErrorInfoEnum.DELIVERY_IS_CREATING);
		}
		List<DeliveryLine> deliveryLineList = deliveryLineMapper.getDeliveryLineByOrderId(delivery.getOrderId());
		// delivery.setDeliveryBoxList(deliveryBoxMappingMapper.getDeliveryBoxList(delivery.getDeliveryId()));
		delivery.setDeliveryLineList(deliveryLineList);
	}

	public Delivery getDeliveryWithoutLine(String id, Boolean isDeliveryId) {
		if (isDeliveryId) {
			return deliveryMapper.getDeliveryByDeliveryId(id);
		} else {
			return deliveryMapper.getDeliveryByOrderId(id);
		}
	}

	@Transactional(rollbackFor = Exception.class, transactionManager = "deliverySqlServerTransactionManager")
	public void packageDelivery(BindBox bindBox, Delivery delivery) throws GlobalErrorInfoException {
		Date currentDate = new Date();
		// executeDeliveryBox(bindBox, delivery, currentDate);
		doPackageDelivery(bindBox, currentDate);
	}

	private void doPackageDelivery(BindBox bindBox, Date currentDate) throws GlobalErrorInfoException {
		Boolean isfail = deliveryMapper.updateDeliveryByDeliveryId(bindBox.getDeliveryId(), DeliveryConstant.getAllowStatusSql(DeliveryConstant.TO_BE_DELIVERY), DeliveryConstant.TO_BE_DELIVERY,
				currentDate) == 0;
		if (isfail) {
			throw new GlobalErrorInfoException(DeliveryErrorInfoEnum.BIND_BOX_FAIL);
		}
	}

	// private void insertDeliveryBoxMapping(String boxId, Delivery delivery,
	// Date currentDate) {
	// DeliverBoxMapping deliverBoxMapping = new DeliverBoxMapping();
	// deliverBoxMapping.setMappingId(getDeliveryMappingId());
	// deliverBoxMapping.setDeliveryId(delivery.getDeliveryId());
	// deliverBoxMapping.setOrderId(delivery.getOrderId());
	// deliverBoxMapping.setDeliveryBoxId(boxId);
	// deliverBoxMapping.setDeliveryStartTime(delivery.getDeliveryStartTime());
	// deliverBoxMapping.setDeliveryEndTime(delivery.getDeliveryEndTime());
	// deliverBoxMapping.setCreatedTime(delivery.getCreatedTime());
	// deliverBoxMapping.setCreatedBy(delivery.getCreatedBy());
	// deliverBoxMapping.setUpdatedTime(currentDate);
	// deliverBoxMapping.setUpdatedBy(delivery.getUpdatedBy());
	// deliverBoxMapping.setStoreId(delivery.getStoreId());
	// // deliveryBoxMappingMapper.insertMapping(deliverBoxMapping);
	// }

	// private String getDeliveryMappingId() {
	// return new StringBuilder().append(new
	// SimpleDateFormat("yymmdd").format(new
	// Date())).append(deliverySequenceMapper.getSeq("delivery_mapping_seq")).toString();
	// }

	// private void executeDeliveryBox(BindBox bindBox, Delivery delivery, Date
	// currentDate) throws GlobalErrorInfoException {
	// List<String> boxIdList = bindBox.getDeliveryBoxList();
	// for (String boxId : boxIdList) {
	// updateDeliveryBox(boxId, bindBox.getStoreId(), currentDate);
	// // insertDeliveryBoxMapping(boxId, delivery, currentDate);
	// }
	// }

	// private void updateDeliveryBox(String boxId, Integer storeId, Date
	// currentDate) throws GlobalErrorInfoException {
	// DeliveryBox deliveryBox = deliveryBoxMapper.getDeliveryBoxByBoxId(boxId);
	// if (deliveryBox == null) {
	// deliveryBox = new DeliveryBox();
	// deliveryBox.setDeliveryBoxId(boxId);
	// deliveryBox.setStatus(1);
	// String currentUserId = ThreadLocalContextHolder.get(AppConstants.USERID,
	// String.class);
	// deliveryBox.setCreatedBy(currentUserId);
	// deliveryBox.setUpdatedBy(currentUserId);
	// deliveryBox.setUpdatedTime(currentDate);
	// deliveryBox.setStoreId(storeId);
	// deliveryBox.setVersion(0);
	// Boolean isFail = deliveryBoxMapper.insertDeliverBox(deliveryBox) == 0;
	// if (isFail) {
	// throw new
	// GlobalErrorInfoException(DeliveryErrorInfoEnum.INSERT_BOX_FAIL);
	// }
	// } else {
	// deliveryBox.setStatus(1);
	// Boolean isFail = deliveryBoxMapper.updateDeliverBoxUsed(deliveryBox) ==
	// 0;
	// if (isFail) {
	// throw new
	// GlobalErrorInfoException(DeliveryErrorInfoEnum.UPDATE_BOX_STATUS_FAIL);
	// }
	// }
	// }

	public Integer getStoreId(String containStoreId) {
		String storeId = containStoreId.substring(0, 5);
		return Integer.parseInt(storeId);
	}

	// public void checkBoxId(Integer storeId, List<String> boxList) throws
	// GlobalErrorInfoException {
	// List<String> errorBoxList = new ArrayList<>();
	// boxList.forEach(deliveryBoxId -> {
	// if (deliveryBoxMapper.getDeliveryBoxByBoxIdAndStatus(storeId,
	// deliveryBoxId, 1) != null) {
	// errorBoxList.add(deliveryBoxId);
	// }
	// });
	//
	// if (!errorBoxList.isEmpty()) {
	// ErrorResult<List<String>> errorResult = new ErrorResult<>();
	// errorResult.setErrorResult(errorBoxList);
	// throw new
	// GlobalErrorInfoException(DeliveryErrorInfoEnum.BIND_OTHER_DELIVERY).setDate(errorResult);
	// }
	// }

	public void checkUser(String userId) throws GlobalErrorInfoException {
		String currentUserId = ThreadLocalContextHolder.getUserId();
		if (!userId.equals(currentUserId)) {
			throw new GlobalErrorInfoException(DeliveryErrorInfoEnum.DELIVERY_ILLEGAL_USER);
		}
	}

	public void checkOp(Delivery delivery, Integer status) throws GlobalErrorInfoException {
		if (delivery == null) {
			throw new GlobalErrorInfoException(DeliveryErrorInfoEnum.DELIVERY_NOT_FOUND);
		}
		if (delivery.getStatus() != status) {
			logger.info(DeliveryErrorInfoEnum.DELIVERY_STATUS_CORRECT.getMessage() + " orderId:{}.deliveryId:{},status:{}", delivery.getOrderId(), delivery.getDeliveryId(), delivery.getStatus());
			throw new GlobalErrorInfoException(DeliveryErrorInfoEnum.DELIVERY_STATUS_CORRECT);
		}
	}
}
