package com.walmart.mobile.checkout.bo;

public class ErrorResult<T> {
	private T errorResult;

	public T getErrorResult() {
		return errorResult;
	}

	public void setErrorResult(T errorResult) {
		this.errorResult = errorResult;
	}

}
