package com.walmart.mobile.checkout.deliveryMapper;

import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

public interface DeliverySequenceMapper {
	@Select("select next value for ${key}")
	@Options(flushCache = true)
	long getSeq(@Param("key") String key);
}
