package com.walmart.mobile.checkout.constant;

import com.walmart.mobile.checkout.exception.handler.ErrorInfoInterface;

/**
 * 系统及业务级别的错误码
 */
public enum DeliveryErrorInfoEnum implements ErrorInfoInterface {
	DELIVERY_NOT_FOUND("-900", "not found delivery."), STORE_DAG_NOT_FOUND("-901", "not found store dag."), BIND_BOX_FAIL("-902",
			"bind box fail."), UNBIND_BOX_FAIL("-903", "unbind box fail."), DELIVERY_STATUS_CORRECT("-904",
					"The delivery status is not correct."), DELIVERY_ILLEGAL_USER("-905", "illegal user"), DELIVERY_IS_CREATING("-906",
							"delivery order is creating"), NOT_BIND_BOX("-907", "not bind box"), BIND_OTHER_DELIVERY("-908",
									"bind other delivery"), INSERT_BOX_FAIL("-909", "insert box fail"), UPDATE_BOX_STATUS_FAIL("-910",
											"update box status fail"), SIGN_CHECKSUM_FAIL("-911",
													"sign checksum fail "), ENCRYPT_NOSUCH_ALGORITHM("-912", "no such algorithm");
	private String code;

	private String message;

	DeliveryErrorInfoEnum(String code, String message) {
		this.code = code;
		this.message = message;
	}

	@Override
	public String getCode() {
		return this.code;
	}

	@Override
	public String getMessage() {
		return this.message;
	}
}
