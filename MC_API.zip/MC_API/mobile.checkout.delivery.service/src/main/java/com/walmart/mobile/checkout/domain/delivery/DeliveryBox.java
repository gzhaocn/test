package com.walmart.mobile.checkout.domain.delivery;

import java.util.Date;

public class DeliveryBox {

	private String deliveryBoxId;

	private Integer status;

	private String createdBy;

	private String updatedBy;

	private Date updatedTime;

	private Integer storeId;

	private Integer version;

	public String getDeliveryBoxId() {
		return deliveryBoxId;
	}

	public void setDeliveryBoxId(String deliveryBoxId) {
		this.deliveryBoxId = deliveryBoxId;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedTime() {
		return updatedTime;
	}

	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}
}
