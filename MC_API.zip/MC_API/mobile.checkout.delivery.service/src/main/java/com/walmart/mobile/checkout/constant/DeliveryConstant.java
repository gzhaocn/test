package com.walmart.mobile.checkout.constant;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 运单状态常量
 */
public class DeliveryConstant {
	private static Map<Integer, List<Integer>> map = new HashMap<>();

	private static void setData(Integer status, Integer... allowList) {
		if (!map.containsKey(status)) {
			map.put(status, new ArrayList<>());
		}
		List<Integer> list = map.get(status);
		for (Integer allow : allowList) {
			list.remove(allow);
			list.add(allow);
		}
	}

	static {
		setData(DeliveryConstant.TO_BE_DELIVERY, DeliveryConstant.TO_BE_PAID);
		setData(DeliveryConstant.CANCEL, DeliveryConstant.TO_BE_PAID, DeliveryConstant.TO_BE_DELIVERY);
		setData(DeliveryConstant.TO_BE_SIGN, DeliveryConstant.TO_BE_DELIVERY);
		setData(DeliveryConstant.SIGN, DeliveryConstant.TO_BE_SIGN);
	}

	public static List<Integer> getAllowStatusList(Integer currentStatus) {
		return map.get(currentStatus);
	}

	public static String getAllowStatusSql(Integer currentStatus) {
		return getAllowStatusList(currentStatus).toString().replace("[", "").replace("]", "");
	}

	private DeliveryConstant() {
	}

	/** 已创建待支付 */
	public static final int TO_BE_PAID = 5;

	/** 运单取消 */
	public static final int CANCEL = 15;

	/** 运单已打包待送货 */
	public static final int TO_BE_DELIVERY = 20;

	/** 运单已送货待签收 */
	public static final int TO_BE_SIGN = 30;

	/** 运单已签收 */
	public static final int SIGN = 40;

}
