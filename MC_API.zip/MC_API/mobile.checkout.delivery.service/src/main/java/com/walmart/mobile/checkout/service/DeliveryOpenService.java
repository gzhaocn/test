package com.walmart.mobile.checkout.service;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.walmart.mobile.checkout.bo.OpenBody;
import com.walmart.mobile.checkout.constant.DeliveryConstant;
import com.walmart.mobile.checkout.constant.DeliveryErrorInfoEnum;
import com.walmart.mobile.checkout.deliveryMapper.DeliveryLineMapper;
import com.walmart.mobile.checkout.deliveryMapper.DeliveryMapper;
import com.walmart.mobile.checkout.domain.delivery.Delivery;
import com.walmart.mobile.checkout.domain.delivery.DeliveryLine;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;

@Service
public class DeliveryOpenService {

	private final Logger logger = LoggerFactory.getLogger(DeliveryOpenService.class);

	@Autowired
	private DeliveryMapper deliveryMapper;

	/*
	 * @Autowired private DeliveryBoxMapper deliveryBoxMapper;
	 */

	/*
	 * @Autowired private DeliveryBoxMappingMapper deliveryBoxMappingMapper;
	 */

	@Autowired
	private DeliveryLineMapper deliveryLineMapper;

	public List<Delivery> getDeliveryListByStore(OpenBody openBody) {
		return deliveryMapper.getDeliveryListByStore(openBody);
	}

	public Delivery getDeliveryByDeliveryId(OpenBody openBody) throws GlobalErrorInfoException {
		Delivery delivery = deliveryMapper.getDeliveryByDeliveryId(openBody.getDeliveryId());
		setDeliveryLine(delivery);
		return delivery;
	}

	private void setDeliveryLine(Delivery delivery) throws GlobalErrorInfoException {
		if (delivery == null) {
			throw new GlobalErrorInfoException(DeliveryErrorInfoEnum.DELIVERY_IS_CREATING);
		}
		List<DeliveryLine> deliveryLineList = deliveryLineMapper.getDeliveryLineByOrderId(delivery.getOrderId());
		// delivery.setDeliveryBoxList(deliveryBoxMappingMapper.getDeliveryBoxList(delivery.getDeliveryId()));
		delivery.setDeliveryLineList(deliveryLineList);
	}

	// @Transactional(rollbackFor = Exception.class, transactionManager =
	// "deliverySqlServerTransactionManager")
	// public Integer packageDelivery(OpenBody openBody) {
	// Date currentDate = new Date();
	// return doUpdateDelivery(openBody, DeliveryConstant.TO_BE_DELIVERY,
	// currentDate);
	// }

	@Transactional(rollbackFor = Exception.class, transactionManager = "deliverySqlServerTransactionManager")
	public Integer sendDelivery(OpenBody openBody) {
		Date currentDate = new Date();
		return doUpdateDelivery(openBody, DeliveryConstant.TO_BE_SIGN, currentDate);
	}

	@Transactional(rollbackFor = Exception.class, transactionManager = "deliverySqlServerTransactionManager")
	public Integer signDelivery(OpenBody openBody) {
		Date currentDate = new Date();
		return doUpdateDelivery(openBody, DeliveryConstant.SIGN, currentDate);
	}

	// private void updateDeliveryBoxMapping(OpenBody openBody, Date
	// currentDate, boolean isSign) {
	// for (String deliveryId : openBody.getDeliveryList()) {
	// List<String> deliveryBoxList =
	// deliveryBoxMappingMapper.getDeliveryBoxList(deliveryId);
	// deliveryBoxList.forEach(deliveryBoxId -> {
	// DeliverBoxMapping deliverBoxMapping = new DeliverBoxMapping();
	// deliverBoxMapping.setDeliveryBoxId(deliveryBoxId);
	// deliverBoxMapping.setDeliveryId(deliveryId);
	// deliverBoxMapping.setUpdatedBy(openBody.getUpdateBy());
	// deliverBoxMapping.setUpdatedTime(currentDate);
	// deliverBoxMapping.setStoreId(openBody.getStoreId());
	// deliveryBoxMappingMapper.updateMapping(deliverBoxMapping);
	// if (isSign) {
	// releaseBox(openBody, deliveryBoxId);
	// }
	// });
	// }
	// }

	// private void releaseBox(OpenBody openBody, String deliveryBoxId) {
	// DeliveryBox deliveryBox = new DeliveryBox();
	// deliveryBox.setDeliveryBoxId(deliveryBoxId);
	// deliveryBox.setStatus(0);
	// deliveryBox.setStoreId(openBody.getStoreId());
	// deliveryBox.setUpdatedBy(openBody.getUpdateBy());
	// deliveryBoxMapper.updateDeliverBoxUnused(deliveryBox);
	// }

	private Integer doUpdateDelivery(OpenBody openBody, Integer toStatus, Date currentDate) {
		Integer result = 0;
		for (String deliveryId : openBody.getDeliveryList()) {
			if (!updateDelivery(openBody.getStoreId(), deliveryId, currentDate, toStatus)) {
				result++;
			}
		}
		return result;
	}

	private boolean updateDelivery(Integer storeId, String deliveryId, Date currentDate, Integer toStatus) {
		return deliveryMapper.updateDeliveryByStoreAndDeliveryId(storeId, deliveryId, DeliveryConstant.getAllowStatusSql(toStatus), toStatus, currentDate) == 0;
	}
}
