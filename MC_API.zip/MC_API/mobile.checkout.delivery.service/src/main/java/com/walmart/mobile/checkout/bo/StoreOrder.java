package com.walmart.mobile.checkout.bo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "门店订单参数模型")
public class StoreOrder {
	@ApiModelProperty(value = "门店")
	private Integer storeId;

	@ApiModelProperty(value = "订单号")
	private String orderId;

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
}
