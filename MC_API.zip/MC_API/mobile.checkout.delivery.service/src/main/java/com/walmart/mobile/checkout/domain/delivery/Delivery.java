package com.walmart.mobile.checkout.domain.delivery;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "运单参数模型")
public class Delivery {
	@ApiModelProperty(value = "运单id")
	private String deliveryId;

	@ApiModelProperty(value = "运单的宿主订单id")
	private String orderId;

	@ApiModelProperty(value = "运单的用户id")
	private String userId;

	@ApiModelProperty(value = "门店")
	private Integer storeId;

	@ApiModelProperty(value = "运单属性  0支付前下的运单(默认值) 1支付后下的运单")
	private Integer deliveryType;

	@ApiModelProperty(value = "运单状态  10 待打包 20 待发货 30 待签收  40 已签收")
	private int status;

	@ApiModelProperty(value = "运费")
	private BigDecimal shippingFee;

	@ApiModelProperty(value = "省份")
	private String province;

	@ApiModelProperty(value = "城市")
	private String city;

	@ApiModelProperty(value = "区域")
	private String district;

	@ApiModelProperty(value = "地址")
	private String address;

	@ApiModelProperty(value = "邮编")
	private String zipcode;

	@ApiModelProperty(value = "经度")
	private Double longitude;

	@ApiModelProperty(value = "维度")
	private Double latitude;

	@ApiModelProperty(value = "收货人姓名")
	private String deliveryName;

	@ApiModelProperty(value = "收货人手机号码")
	private String deliveryPhone;

	@ApiModelProperty(value = "预备送货时间")
	private Date deliveryDate;

	@ApiModelProperty(value = "预备送货时段  例： 1 代表9:00 - 12:00 等等")
	private Integer deliveryPeriod;

	@ApiModelProperty(value = "预备送货时段描述")
	private String deliveryPeriodDesc;

	@ApiModelProperty(value = "预备送货时段描述")
	private String deliveryInstruction;

	@ApiModelProperty(value = "送货人")
	private String deliveryBy;

	@ApiModelProperty(value = "送货开始时间")
	private Date deliveryStartTime;

	@ApiModelProperty(value = "送货完成时间")
	private Date deliveryEndTime;

	@ApiModelProperty(value = "运单创建人")
	private String createdBy;

	@ApiModelProperty(value = "运单创建时间")
	private Date createdTime;

	@ApiModelProperty(value = "运单更新人")
	private String updatedBy;

	@ApiModelProperty(value = "运单更新时间")
	private Date updatedTime;

	@ApiModelProperty(value = "版本")
	private Integer version;

	@ApiModelProperty(value = "运单明细")
	private List<DeliveryLine> deliveryLineList;

	@ApiModelProperty(value = "运单绑定box的列表")
	private List<String> deliveryBoxList;

	public List<String> getDeliveryBoxList() {
		return deliveryBoxList;
	}

	public void setDeliveryBoxList(List<String> deliveryBoxList) {
		this.deliveryBoxList = deliveryBoxList;
	}

	public String getDeliveryInstruction() {
		return deliveryInstruction;
	}

	public void setDeliveryInstruction(String deliveryInstruction) {
		this.deliveryInstruction = deliveryInstruction;
	}

	public List<DeliveryLine> getDeliveryLineList() {
		return deliveryLineList;
	}

	public void setDeliveryLineList(List<DeliveryLine> deliveryLineList) {
		this.deliveryLineList = deliveryLineList;
	}

	public String getDeliveryId() {
		return deliveryId;
	}

	public void setDeliveryId(String deliveryId) {
		this.deliveryId = deliveryId;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public Integer getDeliveryType() {
		return deliveryType;
	}

	public void setDeliveryType(Integer deliveryType) {
		this.deliveryType = deliveryType;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public BigDecimal getShippingFee() {
		return shippingFee;
	}

	public void setShippingFee(BigDecimal shippingFee) {
		this.shippingFee = shippingFee;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public String getDeliveryName() {
		return deliveryName;
	}

	public void setDeliveryName(String deliveryName) {
		this.deliveryName = deliveryName;
	}

	public String getDeliveryPhone() {
		return deliveryPhone;
	}

	public void setDeliveryPhone(String deliveryPhone) {
		this.deliveryPhone = deliveryPhone;
	}

	public Date getDeliveryDate() {
		return deliveryDate;
	}

	public void setDeliveryDate(Date deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	public Integer getDeliveryPeriod() {
		return deliveryPeriod;
	}

	public void setDeliveryPeriod(Integer deliveryPeriod) {
		this.deliveryPeriod = deliveryPeriod;
	}

	public String getDeliveryPeriodDesc() {
		return deliveryPeriodDesc;
	}

	public void setDeliveryPeriodDesc(String deliveryPeriodDesc) {
		this.deliveryPeriodDesc = deliveryPeriodDesc;
	}

	public String getDeliveryBy() {
		return deliveryBy;
	}

	public void setDeliveryBy(String deliveryBy) {
		this.deliveryBy = deliveryBy;
	}

	public Date getDeliveryStartTime() {
		return deliveryStartTime;
	}

	public void setDeliveryStartTime(Date deliveryStartTime) {
		this.deliveryStartTime = deliveryStartTime;
	}

	public Date getDeliveryEndTime() {
		return deliveryEndTime;
	}

	public void setDeliveryEndTime(Date deliveryEndTime) {
		this.deliveryEndTime = deliveryEndTime;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedTime() {
		return updatedTime;
	}

	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}
}
