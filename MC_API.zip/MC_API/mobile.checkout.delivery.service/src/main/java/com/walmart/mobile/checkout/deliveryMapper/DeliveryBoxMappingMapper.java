package com.walmart.mobile.checkout.deliveryMapper;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.walmart.mobile.checkout.domain.delivery.DeliverBoxMapping;

public interface DeliveryBoxMappingMapper {
	@Insert("INSERT INTO delivery_box_mapping (mapping_id ,delivery_id ,order_id ,delivery_box_id ,delivery_start_time ,delivery_end_time ,"
			+ "created_time ,created_by ,updated_time ,updated_by ,store_id ) VALUES (#{mappingId} ,#{deliveryId} ,#{orderId} ,#{deliveryBoxId} ,"
			+ "#{deliveryStartTime} ,#{deliveryEndTime} ,#{createdTime} ,#{createdBy} ,#{updatedTime} ,#{updatedBy} ,#{storeId})")
	Integer insertMapping(DeliverBoxMapping deliverBoxMapping);

	@Select("SELECT delivery_box_id FROM delivery_box_mapping where delivery_id = #{deliveryId} ")
	List<String> getDeliveryBoxList(String deliveryId);

	@Update("UPDATE delivery_box_mapping SET updated_time = #{updatedTime,jdbcType=TIMESTAMP}, updated_by = #{updatedBy} "
			+ "WHERE delivery_id = #{deliveryId} and delivery_box_id = #{deliveryBoxId} and store_id = #{storeId}")
	Integer updateMapping(DeliverBoxMapping deliverBoxMapping);
}