package com.walmart.mobile.checkout.deliveryMapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.walmart.mobile.checkout.domain.delivery.DeliveryBox;

public interface DeliveryBoxMapper {

	@Results({ @Result(property = "deliveryBoxId", column = "delivery_box_id", id = true), @Result(property = "createBy", column = "create_by"),
			@Result(property = "updateBy", column = "update_by"), @Result(property = "updateTime", column = "update_time"),
			@Result(property = "storeId", column = "store_id") })
	@Select("SELECT * FROM delivery_box where store_id= #{storeId} and delivery_box_id = #{deliveryBoxId} and status= #{status}")
	DeliveryBox getDeliveryBoxByBoxIdAndStatus(@Param("storeId") Integer storeId, @Param("deliveryBoxId") String deliveryBoxId, @Param("status") int status);

	@Results({ @Result(property = "deliveryBoxId", column = "delivery_box_id", id = true), @Result(property = "createBy", column = "create_by"),
			@Result(property = "updateBy", column = "update_by"), @Result(property = "updateTime", column = "update_time"),
			@Result(property = "storeId", column = "store_id") })
	@Select("SELECT * FROM delivery_box where delivery_box_id = #{deliveryBoxId}")
	DeliveryBox getDeliveryBoxByBoxId(String deliveryBoxId);

	@Insert("INSERT INTO delivery_box (delivery_box_id ,status ,created_by ,updated_time ,updated_by ,store_id ,version)"
			+ " VALUES (#{deliveryBoxId} ,#{status} ,#{createdBy} ,#{updatedTime} ,#{updatedBy} ,#{storeId} ,#{version})")
	Integer insertDeliverBox(DeliveryBox deliveryBox);

	@Update("UPDATE delivery_box SET status = #{status}, updated_by = #{updatedBy} "
			+ "WHERE delivery_box_id = #{deliveryBoxId} and store_id = #{storeId} and status = 0 ")
	Integer updateDeliverBoxUsed(DeliveryBox deliveryBox);

	@Update("UPDATE delivery_box SET status = #{status}, updated_by = #{updatedBy} "
			+ "WHERE delivery_box_id = #{deliveryBoxId} and store_id = #{storeId} and status = 1 ")
	Integer updateDeliverBoxUnused(DeliveryBox deliveryBox);
}