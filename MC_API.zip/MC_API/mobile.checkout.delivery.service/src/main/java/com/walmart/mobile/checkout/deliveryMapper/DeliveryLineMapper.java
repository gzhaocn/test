package com.walmart.mobile.checkout.deliveryMapper;

import java.util.List;

import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import com.walmart.mobile.checkout.domain.delivery.DeliveryLine;

public interface DeliveryLineMapper {

	@Results({ @Result(property = "deliveryLineId", column = "delivery_line_id", id = true), @Result(property = "deliveryId", column = "delivery_id"),
			@Result(property = "productId", column = "product_id"), @Result(property = "cartItemId", column = "cart_item_id"),
			@Result(property = "requestQuantity", column = "request_quantity"), @Result(property = "signQuantity", column = "sign_quantity"),
			@Result(property = "descOnline", column = "desc_online"), @Result(property = "posDescOnline", column = "pos_desc_online"),
			@Result(property = "priceWithTax", column = "price_with_tax"), @Result(property = "wasPrice", column = "was_price"),
			@Result(property = "priceWithoutTax", column = "price_without_tax"), @Result(property = "itemNumber", column = "item_number"),
			@Result(property = "itemType", column = "item_type"), @Result(property = "itemAmount", column = "item_amount"),
			@Result(property = "storeId", column = "store_id") })
	@Select("select * from delivery_line where order_id = #{orderId}")
	List<DeliveryLine> getDeliveryLineByOrderId(String orderId);

}