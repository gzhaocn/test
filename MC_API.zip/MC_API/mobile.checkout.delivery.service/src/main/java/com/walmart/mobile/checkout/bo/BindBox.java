package com.walmart.mobile.checkout.bo;

import java.util.List;

import io.swagger.annotations.ApiModelProperty;

public class BindBox {
	@ApiModelProperty(value = "门店")
	private Integer storeId;

	@ApiModelProperty(value = "打包id列表")
	private List<String> deliveryBoxList;

	@ApiModelProperty(value = "运单号")
	private String deliveryId;

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public List<String> getDeliveryBoxList() {
		return deliveryBoxList;
	}

	public void setDeliveryBoxList(List<String> deliveryBoxList) {
		this.deliveryBoxList = deliveryBoxList;
	}

	public String getDeliveryId() {
		return deliveryId;
	}

	public void setDeliveryId(String deliveryId) {
		this.deliveryId = deliveryId;
	}
}
