package com.walmart.mobile.checkout.domain.delivery;

import java.math.BigDecimal;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "运单明细模型")
public class DeliveryLine {

	@ApiModelProperty(value = "运单明细id")
	private String deliveryLineId;

	@ApiModelProperty(value = "运单id")
	private String deliveryId;

	@ApiModelProperty(value = "订单id")
	private String orderId;

	@ApiModelProperty(value = "商品id")
	private Long productId;

	@ApiModelProperty(value = "购物车商品编号")
	private Long cartItemId;

	@ApiModelProperty(value = "运单请求送货数量")
	private Integer requestQuantity;

	@ApiModelProperty(value = "运单实际送货数量")
	private Integer signQuantity;

	@ApiModelProperty(value = "upc")
	private Long upc;

	@ApiModelProperty(value = "商品名称")
	private String descOnline;

	@ApiModelProperty(value = "商品pos名称")
	private String posDescOnline;

	@ApiModelProperty(value = "未税价")
	private BigDecimal priceWithTax;

	@ApiModelProperty(value = "原价")
	private BigDecimal wasPrice;

	@ApiModelProperty(value = "含税价")
	private BigDecimal priceWithoutTax;

	@ApiModelProperty(value = "部门")
	private Integer department;

	@ApiModelProperty(value = "内部商品编号")
	private Long itemNumber;

	@ApiModelProperty(value = "商品类型")
	private Integer itemType;

	@ApiModelProperty(value = "称重商品的金额")
	private BigDecimal itemAmount;

	@ApiModelProperty(value = "门店")
	private Integer storeId;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getDeliveryLineId() {
		return deliveryLineId;
	}

	public void setDeliveryLineId(String deliveryLineId) {
		this.deliveryLineId = deliveryLineId;
	}

	public String getDeliveryId() {
		return deliveryId;
	}

	public void setDeliveryId(String deliveryId) {
		this.deliveryId = deliveryId;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public Long getCartItemId() {
		return cartItemId;
	}

	public void setCartItemId(Long cartItemId) {
		this.cartItemId = cartItemId;
	}

	public Integer getRequestQuantity() {
		return requestQuantity;
	}

	public void setRequestQuantity(Integer requestQuantity) {
		this.requestQuantity = requestQuantity;
	}

	public Integer getSignQuantity() {
		return signQuantity;
	}

	public void setSignQuantity(Integer signQuantity) {
		this.signQuantity = signQuantity;
	}

	public Long getUpc() {
		return upc;
	}

	public void setUpc(Long upc) {
		this.upc = upc;
	}

	public String getDescOnline() {
		return descOnline;
	}

	public void setDescOnline(String descOnline) {
		this.descOnline = descOnline;
	}

	public String getPosDescOnline() {
		return posDescOnline;
	}

	public void setPosDescOnline(String posDescOnline) {
		this.posDescOnline = posDescOnline;
	}

	public BigDecimal getPriceWithTax() {
		return priceWithTax;
	}

	public void setPriceWithTax(BigDecimal priceWithTax) {
		this.priceWithTax = priceWithTax;
	}

	public BigDecimal getWasPrice() {
		return wasPrice;
	}

	public void setWasPrice(BigDecimal wasPrice) {
		this.wasPrice = wasPrice;
	}

	public BigDecimal getPriceWithoutTax() {
		return priceWithoutTax;
	}

	public void setPriceWithoutTax(BigDecimal priceWithoutTax) {
		this.priceWithoutTax = priceWithoutTax;
	}

	public Integer getDepartment() {
		return department;
	}

	public void setDepartment(Integer department) {
		this.department = department;
	}

	public Long getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(Long itemNumber) {
		this.itemNumber = itemNumber;
	}

	public Integer getItemType() {
		return itemType;
	}

	public void setItemType(Integer itemType) {
		this.itemType = itemType;
	}

	public BigDecimal getItemAmount() {
		return itemAmount;
	}

	public void setItemAmount(BigDecimal itemAmount) {
		this.itemAmount = itemAmount;
	}

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}
}
