package com.walmart.mobile.checkout.bo;

import java.security.NoSuchAlgorithmException;

import com.alibaba.fastjson.JSON;
import com.walmart.mobile.checkout.constant.DeliveryErrorInfoEnum;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.utils.PropertyUtils;
import com.walmart.mobile.checkout.utils.crypto.SHA512;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "open API 参数模型")
public class OpenParam<T> {

	@ApiModelProperty(value = "请求时间. 例:2017-12-12 12:54:21")
	private String requestDate;

	@ApiModelProperty(value = "数据加密签名. SHA512(requestDate + secret + JSON.toJSONString(body))")
	private String sign;

	@ApiModelProperty(value = "业务对象,列表，详情等业务的对象数据")
	private T body;

	public String getRequestDate() {
		return requestDate;
	}

	public void setRequestDate(String requestDate) {
		this.requestDate = requestDate;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	public T getBody() {
		return body;
	}

	public void setBody(T body) {
		this.body = body;
	}

	@Override
	public String toString() {
		return requestDate + PropertyUtils.getConfigValue("delivery.secret") + JSON.toJSONString(body);
	}

	public void checkSum() throws GlobalErrorInfoException {
		try {
			Boolean isSuccess = SHA512.hashValue(this.toString()).equals(sign);
			if (!isSuccess) {
				throw new GlobalErrorInfoException(DeliveryErrorInfoEnum.SIGN_CHECKSUM_FAIL);
			}
		} catch (NoSuchAlgorithmException e) {
			throw new GlobalErrorInfoException(DeliveryErrorInfoEnum.ENCRYPT_NOSUCH_ALGORITHM, e);
		}

	}
}
