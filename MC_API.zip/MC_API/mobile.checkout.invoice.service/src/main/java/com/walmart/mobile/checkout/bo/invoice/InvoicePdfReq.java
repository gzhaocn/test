package com.walmart.mobile.checkout.bo.invoice;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModel;

@ApiModel(description = "发票回调参数模型")
public class InvoicePdfReq implements Serializable {

	private static final long serialVersionUID = -1458632734353872843L;

	private InvoicePdfMain main;

	private List<InvoicePdfItem> details = new ArrayList<>();

	public InvoicePdfMain getMain() {
		return main;
	}

	public void setMain(InvoicePdfMain main) {
		this.main = main;
	}

	public List<InvoicePdfItem> getDetails() {
		return details;
	}

	public void setDetails(List<InvoicePdfItem> details) {
		this.details = details;
	}

}
