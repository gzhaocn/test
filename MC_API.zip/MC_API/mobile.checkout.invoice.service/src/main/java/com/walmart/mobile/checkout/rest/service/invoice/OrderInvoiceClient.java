package com.walmart.mobile.checkout.rest.service.invoice;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.walmart.mobile.checkout.bo.order.OrderBo;
import com.walmart.mobile.checkout.domain.order.Order;

@FeignClient("orderService")
public interface OrderInvoiceClient {

	@RequestMapping(value = "/requestOrderDetailByUserIdAndOrderId")
	OrderBo requestOrderDetailByUserIdAndOrderId(@RequestParam(value = "userId") String userId,
			@RequestParam(value = "orderId") String orderId);

	@RequestMapping(value = "/getOrderByOrderId")
	Order getOrderByOrderId(@RequestParam(value = "orderId") String orderId);

	@RequestMapping(value = "/updateInvoicePdfUrl")
	int updateInvoicePdfUrl(@RequestParam("orderId") String orderId,
			@RequestParam("invoicePdfUrl") String invoicePdfUrl, @RequestParam("version") Integer version,
			@RequestParam("invoiceNo") String invoiceNo, @RequestParam("invoiceCode") String invoiceCode,
			@RequestParam("reverseInvoiceUrl") String reverseInvoiceUrl);
	
	@RequestMapping(value = "/updatePaperInvoiceInvoiceNo")
	int updatePaperInvoiceInvoiceNo(@RequestParam("orderId") String orderId,@RequestParam("invoiceNo") String invoiceNo);
}
