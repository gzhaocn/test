package com.walmart.mobile.checkout.bo.invoice;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "纸质发票参数")
public class PaperInvoiceParamter {   
	
	@ApiModelProperty(value = "订单号", required = true)
	private String orderId;
	@ApiModelProperty(value = "开票类型（1、开票  2、红冲）", required = true)
	private String recordType;
	
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getRecordType() {
		return recordType;
	}
	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

}
