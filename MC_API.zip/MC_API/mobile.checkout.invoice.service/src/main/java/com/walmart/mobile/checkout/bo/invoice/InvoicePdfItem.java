package com.walmart.mobile.checkout.bo.invoice;

import java.io.Serializable;
import java.math.BigDecimal;

public class InvoicePdfItem implements Serializable {

	private static final long serialVersionUID = -4213976339679543401L;
	private String itemSpec; // 型号规格
	private BigDecimal taxAmount; // 税额
	private String cargoName; // 货物或应税劳务名称
	private String quantityUnit; // 数量单位
	private String cargoCode; // 货物或应税劳务代码
	private BigDecimal quantity; // 数量
	private BigDecimal taxRate; // 税率
	private BigDecimal amountWithTax; // 含税金额
	private String goodsTaxNo; // 税收分类编码
	private String sellerInvoiceId; //
	private BigDecimal unitPrice; // 单价
	private BigDecimal amountWithoutTax; // 不含税金额

	public String getItemSpec() {
		return itemSpec;
	}

	public void setItemSpec(String itemSpec) {
		this.itemSpec = itemSpec;
	}

	public BigDecimal getTaxAmount() {
		return taxAmount;
	}

	public void setTaxAmount(BigDecimal taxAmount) {
		this.taxAmount = taxAmount;
	}

	public String getCargoName() {
		return cargoName;
	}

	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}

	public String getQuantityUnit() {
		return quantityUnit;
	}

	public void setQuantityUnit(String quantityUnit) {
		this.quantityUnit = quantityUnit;
	}

	public String getCargoCode() {
		return cargoCode;
	}

	public void setCargoCode(String cargoCode) {
		this.cargoCode = cargoCode;
	}

	public BigDecimal getQuantity() {
		return quantity;
	}

	public void setQuantity(BigDecimal quantity) {
		this.quantity = quantity;
	}

	public BigDecimal getTaxRate() {
		return taxRate;
	}

	public void setTaxRate(BigDecimal taxRate) {
		this.taxRate = taxRate;
	}

	public BigDecimal getAmountWithTax() {
		return amountWithTax;
	}

	public void setAmountWithTax(BigDecimal amountWithTax) {
		this.amountWithTax = amountWithTax;
	}

	public String getGoodsTaxNo() {
		return goodsTaxNo;
	}

	public void setGoodsTaxNo(String goodsTaxNo) {
		this.goodsTaxNo = goodsTaxNo;
	}

	public String getSellerInvoiceId() {
		return sellerInvoiceId;
	}

	public void setSellerInvoiceId(String sellerInvoiceId) {
		this.sellerInvoiceId = sellerInvoiceId;
	}

	public BigDecimal getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(BigDecimal unitPrice) {
		this.unitPrice = unitPrice;
	}

	public BigDecimal getAmountWithoutTax() {
		return amountWithoutTax;
	}

	public void setAmountWithoutTax(BigDecimal amountWithoutTax) {
		this.amountWithoutTax = amountWithoutTax;
	}

}
