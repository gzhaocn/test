package com.walmart.mobile.checkout.bo.invoice;

import java.io.Serializable;

public class InvoicePdfMain implements Serializable {

	private static final long serialVersionUID = 3336669080602086550L;

	private String invoicerName; // 开票人姓名
	private String tenantCode; // 集团标志
	private String remark; // 备注
	private String purchaserName; // 购方名称
	private String cashierName; // 收款人姓名

	private String settlementNo; // 订单号 //tc number

	private String sellerName; // 销方名称
	private String paperDrewDate; // 发票开票日期 格式：yyyyMMdd
	private String redNotificationNo; // 红字信息表编号
	private String sellerAddress; // 销方地址
	private String purchaserBankAccount; // 购方银行账号
	private String sellerBankInfo; // 销方银行名称账号
	private String purchaserTaxNo; // 购方税号
	private String purchaserBankInfo; // 购方银行名称账号
	private String taxRate; // 税率
	private String status; // 发票状态 0-作废、1-正常
	private String checkerName; // 复核人姓名
	private String purchaserTel; // 购方电话
	private String purchaserAddrTel; // 购方地址电话
	private String amountWithoutTax; // 不含税金额
	private String sellerTaxNo; // 销方税号
	private String purchaserAddress; // 购方地址
	private String sellerAddrTel; // 销方地址电话
	private String purchaserNo; // 购方公司编号
	private String invoiceNo; // 发票号码
	private String invoiceCode; // 发票代码
	private String amountWithTax; // 不含税金额
	private String taxAmount; // 税额
	private String invoiceType; // 发票类型 c-增值税普通发票、s-增值税专用发票、ce-增值税电子普通发票
	private String sellerTel; // 销方电话
	private String originInvoiceCode; // 原发票代码
	private String originInvoiceNo; // 原发票号码
	private String sellerNo; // 销方公司编号
	private String sellerBankName; // 销方银行名称

	private String sellerBankAccount; // 销方银行账号
	private String purchaserBankName; // 购方银行名称
	private String pdfUrl; // 电票地址

	public String getInvoicerName() {
		return invoicerName;
	}

	public void setInvoicerName(String invoicerName) {
		this.invoicerName = invoicerName;
	}

	public String getTenantCode() {
		return tenantCode;
	}

	public void setTenantCode(String tenantCode) {
		this.tenantCode = tenantCode;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getPurchaserName() {
		return purchaserName;
	}

	public void setPurchaserName(String purchaserName) {
		this.purchaserName = purchaserName;
	}

	public String getCashierName() {
		return cashierName;
	}

	public void setCashierName(String cashierName) {
		this.cashierName = cashierName;
	}

	public String getInvoiceCode() {
		return invoiceCode;
	}

	public void setInvoiceCode(String invoiceCode) {
		this.invoiceCode = invoiceCode;
	}

	public String getSettlementNo() {
		return settlementNo;
	}

	public void setSettlementNo(String settlementNo) {
		this.settlementNo = settlementNo;
	}

	public String getOriginInvoiceCode() {
		return originInvoiceCode;
	}

	public void setOriginInvoiceCode(String originInvoiceCode) {
		this.originInvoiceCode = originInvoiceCode;
	}

	public String getSellerName() {
		return sellerName;
	}

	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}

	public String getPaperDrewDate() {
		return paperDrewDate;
	}

	public void setPaperDrewDate(String paperDrewDate) {
		this.paperDrewDate = paperDrewDate;
	}

	public String getRedNotificationNo() {
		return redNotificationNo;
	}

	public void setRedNotificationNo(String redNotificationNo) {
		this.redNotificationNo = redNotificationNo;
	}

	public String getSellerAddress() {
		return sellerAddress;
	}

	public void setSellerAddress(String sellerAddress) {
		this.sellerAddress = sellerAddress;
	}

	public String getPurchaserBankAccount() {
		return purchaserBankAccount;
	}

	public void setPurchaserBankAccount(String purchaserBankAccount) {
		this.purchaserBankAccount = purchaserBankAccount;
	}

	public String getSellerBankInfo() {
		return sellerBankInfo;
	}

	public void setSellerBankInfo(String sellerBankInfo) {
		this.sellerBankInfo = sellerBankInfo;
	}

	public String getPurchaserTaxNo() {
		return purchaserTaxNo;
	}

	public void setPurchaserTaxNo(String purchaserTaxNo) {
		this.purchaserTaxNo = purchaserTaxNo;
	}

	public String getPurchaserBankInfo() {
		return purchaserBankInfo;
	}

	public void setPurchaserBankInfo(String purchaserBankInfo) {
		this.purchaserBankInfo = purchaserBankInfo;
	}

	public String getTaxRate() {
		return taxRate;
	}

	public void setTaxRate(String taxRate) {
		this.taxRate = taxRate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCheckerName() {
		return checkerName;
	}

	public void setCheckerName(String checkerName) {
		this.checkerName = checkerName;
	}

	public String getPurchaserTel() {
		return purchaserTel;
	}

	public void setPurchaserTel(String purchaserTel) {
		this.purchaserTel = purchaserTel;
	}

	public String getPurchaserAddrTel() {
		return purchaserAddrTel;
	}

	public void setPurchaserAddrTel(String purchaserAddrTel) {
		this.purchaserAddrTel = purchaserAddrTel;
	}

	public String getAmountWithoutTax() {
		return amountWithoutTax;
	}

	public void setAmountWithoutTax(String amountWithoutTax) {
		this.amountWithoutTax = amountWithoutTax;
	}

	public String getSellerTaxNo() {
		return sellerTaxNo;
	}

	public void setSellerTaxNo(String sellerTaxNo) {
		this.sellerTaxNo = sellerTaxNo;
	}

	public String getPurchaserAddress() {
		return purchaserAddress;
	}

	public void setPurchaserAddress(String purchaserAddress) {
		this.purchaserAddress = purchaserAddress;
	}

	public String getSellerAddrTel() {
		return sellerAddrTel;
	}

	public void setSellerAddrTel(String sellerAddrTel) {
		this.sellerAddrTel = sellerAddrTel;
	}

	public String getPurchaserNo() {
		return purchaserNo;
	}

	public void setPurchaserNo(String purchaserNo) {
		this.purchaserNo = purchaserNo;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public String getAmountWithTax() {
		return amountWithTax;
	}

	public void setAmountWithTax(String amountWithTax) {
		this.amountWithTax = amountWithTax;
	}

	public String getTaxAmount() {
		return taxAmount;
	}

	public void setTaxAmount(String taxAmount) {
		this.taxAmount = taxAmount;
	}

	public String getInvoiceType() {
		return invoiceType;
	}

	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}

	public String getSellerTel() {
		return sellerTel;
	}

	public void setSellerTel(String sellerTel) {
		this.sellerTel = sellerTel;
	}

	public String getOriginInvoiceNo() {
		return originInvoiceNo;
	}

	public void setOriginInvoiceNo(String originInvoiceNo) {
		this.originInvoiceNo = originInvoiceNo;
	}

	public String getSellerNo() {
		return sellerNo;
	}

	public void setSellerNo(String sellerNo) {
		this.sellerNo = sellerNo;
	}

	public String getSellerBankName() {
		return sellerBankName;
	}

	public void setSellerBankName(String sellerBankName) {
		this.sellerBankName = sellerBankName;
	}

	public String getSellerBankAccount() {
		return sellerBankAccount;
	}

	public void setSellerBankAccount(String sellerBankAccount) {
		this.sellerBankAccount = sellerBankAccount;
	}

	public String getPurchaserBankName() {
		return purchaserBankName;
	}

	public void setPurchaserBankName(String purchaserBankName) {
		this.purchaserBankName = purchaserBankName;
	}

	public String getPdfUrl() {
		return pdfUrl;
	}

	public void setPdfUrl(String pdfUrl) {
		this.pdfUrl = pdfUrl;
	}

}
