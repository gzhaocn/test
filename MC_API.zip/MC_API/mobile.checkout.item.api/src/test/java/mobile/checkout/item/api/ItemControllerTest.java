package mobile.checkout.item.api;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import com.walmart.mobile.checkout.config.MainConfig;
import com.walmart.mobile.checkout.exception.handler.ResultBody;
import com.walmart.mobile.checkout.utils.ProductIdGenerator;
import com.alibaba.fastjson.JSONObject;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import com.walmart.mobile.checkout.bo.ScanItemParameter;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import org.junit.Assert;
import org.springframework.http.MediaType;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { MainConfig.class })
public class ItemControllerTest { 

	protected MockHttpServletResponse response;
	protected MockMvc mockMVC;
	@Autowired
	private WebApplicationContext wac;

	@Before
	public void before() { 
		mockMVC = MockMvcBuilders.webAppContextSetup(wac).build();
		MockitoAnnotations.initMocks(this);
	}
	
	/**
	 * test common item
	 */
	@Test
	public void scanTest_upc_common() throws Exception {
		ScanItemParameter scanItemParameter=new ScanItemParameter();
		scanItemParameter.setStoreId(610);
		scanItemParameter.setUpcForTest(ProductIdGenerator.encode(240000245187L));		
		String restUrl = "/items/scan";
		String requestJson = JSONObject.toJSONString(scanItemParameter);
		String responseString = mockMVC.perform(MockMvcRequestBuilders.post(restUrl).contentType(MediaType.APPLICATION_JSON).content(requestJson))
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
		
		ResultBody resultBody = JSONObject.parseObject(responseString, ResultBody.class);
		Assert.assertTrue("", resultBody.getCode().equals("0"));		
	}
	
	@Test
	public void scanTest_upc_scaleWeight() throws Exception {
		ScanItemParameter scanItemParameter=new ScanItemParameter();
		scanItemParameter.setStoreId(5500);
		scanItemParameter.setUpcForTest(ProductIdGenerator.encode(219919099999L));		
		String restUrl = "/items/scan";
		String requestJson = JSONObject.toJSONString(scanItemParameter);
		String responseString = mockMVC.perform(MockMvcRequestBuilders.post(restUrl).contentType(MediaType.APPLICATION_JSON).content(requestJson))// .andDo(print())
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
		ResultBody resultBody = JSONObject.parseObject(responseString, ResultBody.class);
		Assert.assertTrue("", resultBody.getCode().equals("0"));		
	}
	
	@Test
	public void scanTest_itemNumber() throws Exception {
		ScanItemParameter scanItemParameter=new ScanItemParameter();
		scanItemParameter.setStoreId(1059);
		scanItemParameter.setItemNumber(20555342L);
		String restUrl = "/items/scan";
		String requestJson = JSONObject.toJSONString(scanItemParameter);
		String responseString = mockMVC.perform(MockMvcRequestBuilders.post(restUrl).contentType(MediaType.APPLICATION_JSON).content(requestJson))// .andDo(print())
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
		ResultBody resultBody = JSONObject.parseObject(responseString, ResultBody.class);
		Assert.assertTrue("", resultBody.getCode().equals("0"));		
	}
	
	@Test
	public void scanTest_specialPackageItem() throws Exception {
		//TO DO		
	}
	
	public void selectItemsTest() throws Exception {
		//TO DO
	}
}
