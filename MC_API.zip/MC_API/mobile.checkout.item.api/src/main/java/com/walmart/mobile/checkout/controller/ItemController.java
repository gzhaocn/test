package com.walmart.mobile.checkout.controller;
 
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.walmart.mobile.checkout.annotation.PrivilegeInfo;
import com.walmart.mobile.checkout.bo.EwsStore;
import com.walmart.mobile.checkout.bo.ItemScanResp;
import com.walmart.mobile.checkout.bo.ScanItemParameter;
import com.walmart.mobile.checkout.bo.SelectItemsParameter;
import com.walmart.mobile.checkout.bo.ShoppingCartResp;
import com.walmart.mobile.checkout.constant.AppConstants;
import com.walmart.mobile.checkout.constant.ItemErrorInfoEnum;
import com.walmart.mobile.checkout.entity.ShoppingItem;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.exception.handler.ResultBody;
import com.walmart.mobile.checkout.rest.EmployeeClient;
import com.walmart.mobile.checkout.service.EwsPriceService;
import com.walmart.mobile.checkout.service.ItemService;
import com.walmart.mobile.checkout.utils.ThreadLocalContextHolder;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/items")
public class ItemController {

	@Autowired
	ItemService itemService;

	@Autowired
	EwsPriceService ewsPriceService;
 
	/**
	 * scan interface: get item details by storeId and UPC.
	 *
	 * @param upc
	 * @param storeId
	 * @return
	 * @throws GlobalErrorInfoException
	 * @throws IOException
	 */
	@ApiOperation(value = "scan", notes = "by storeId and upc/itemNumber")
	@RequestMapping(value = "/scan", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	@ApiResponses({ @ApiResponse(code = -600, message = "商品未找到"), @ApiResponse(code = -601, message = "没有storeId") })
	public ResultBody scan(@RequestBody ScanItemParameter scanItemParameter, HttpServletRequest request)
			throws GlobalErrorInfoException {
		if (scanItemParameter.getStoreId() == null) {
			throw new GlobalErrorInfoException(ItemErrorInfoEnum.MISSING_STOREID);
		}
		ItemScanResp itemScanResp = null;
		if (scanItemParameter.getUpc() != null) {
			itemScanResp = this.itemService.getItemDetailByStoreIdAndUpc(scanItemParameter.getStoreId(),
					scanItemParameter.getUpc());
		}
		if (itemScanResp == null && scanItemParameter.getItemNumber() != null) {
			itemScanResp = this.itemService.getItemDetailByItemNumber(scanItemParameter.getStoreId(),
					scanItemParameter.getItemNumber());
		}
		if (itemScanResp == null || itemScanResp.getItemDetail() == null) {
			throw new GlobalErrorInfoException(ItemErrorInfoEnum.ITEM_NOT_FOUND);
		}
		return new ResultBody(itemScanResp);
	}
	
	@Autowired
	private EmployeeClient employeeClient;

	private Integer getEmployeeDiscount() {
		return employeeClient.getEmployeeDiscount(ThreadLocalContextHolder.getUserId());
	}

	/**
	 * update items for shopping cart
	 *
	 * @param storeId
	 * @param productIds
	 * @return
	 * @throws IOException
	 * @throws GlobalErrorInfoException
	 */
	@ApiOperation(value = "update items for batch", notes = "by storeId and updateItemParameter")
	@ApiResponses({ @ApiResponse(code = -601, message = "没有storeId") })
	@RequestMapping(value = "/selectItems", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	@PrivilegeInfo
	public ResultBody selectItems(@RequestBody SelectItemsParameter selectItemsParameter, HttpServletRequest request)
			throws GlobalErrorInfoException {

		Integer storeId = selectItemsParameter.getStoreId();
		if (storeId == null) {
			throw new GlobalErrorInfoException(ItemErrorInfoEnum.MISSING_STOREID);
		}

		List<ShoppingItem> updateItems = selectItemsParameter.getShoppingItems();
		
		ShoppingCartResp itemCartResp = this.itemService.updateShoppingCartItems(storeId, updateItems);
		
		itemCartResp.setAssocDiscount(getEmployeeDiscount());
		return new ResultBody(itemCartResp);
	}

	@ApiOperation(value = "allEwsPrice", notes = "获取所有的延保服务价格区间数据")
	@RequestMapping(value = "/allEwsPrice", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody getAllEwsPrice(@RequestBody EwsStore ewsStore) throws GlobalErrorInfoException {
		return new ResultBody(ewsPriceService.getAllEwsPrice(ewsStore));
	}
}
