package order;

import java.util.Arrays;
import java.util.List;

import org.easymock.EasyMock;
import org.easymock.IMocksControl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.Assert;

import com.alibaba.fastjson.JSON;
import com.walmart.mobile.checkout.bo.order.OrderBo;
import com.walmart.mobile.checkout.bo.order.OrderLineBo;
import com.walmart.mobile.checkout.config.MainConfig;
import com.walmart.mobile.checkout.constant.order.OrderStatus;
import com.walmart.mobile.checkout.domain.order.Order;
import com.walmart.mobile.checkout.domain.order.OrderDiscount;
import com.walmart.mobile.checkout.domain.order.OrderLine;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.mapper.OrderDiscountMapper;
import com.walmart.mobile.checkout.mapper.OrderEwsMapper;
import com.walmart.mobile.checkout.mapper.OrderLineMapper;
import com.walmart.mobile.checkout.mapper.OrderMapper;
import com.walmart.mobile.checkout.service.OrderService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MainConfig.class })
@WebAppConfiguration
public class OrderServiceMockTest {
	@Autowired
	private OrderService orderService;

	@Test
	public void orderServiceSelectOrderByUserIdAndOrderIdTest() throws GlobalErrorInfoException {

		IMocksControl mocksControl = EasyMock.createControl();
		OrderMapper mockOrderMapper = mocksControl.createMock(OrderMapper.class);
		// 创建虚拟对象方法期望的返回值
		String orderJson = "{\"amount\":282.00,\"cancelReason\":0,\"createdTime\":1499323183217,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000034761\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":10,\"storeId\":9999,\"timeout\":true,\"totalGpDiscount\":3.60,\"userId\":\"test\",\"version\":1,\"voucherDiscount\":0.00}";
		Order order = JSON.parseObject(orderJson, Order.class);
		// 录制动作
		EasyMock.expect(mockOrderMapper.selectOrderByUserIdAndOrderId(EasyMock.anyString(), EasyMock.anyString())).andReturn(order);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(orderService, "orderMapper", mockOrderMapper, OrderMapper.class);
		// 执行测试方法
		Order p = orderService.selectOrderByUserIdAndOrderId(EasyMock.anyString(), EasyMock.anyString());
		Assert.isTrue(p != null, "");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockOrderMapper);
		mocksControl.reset();
	}

	@Test
	public void orderServiceRequestOrderDetailByUserIdAndOrderIdTest() throws GlobalErrorInfoException {
		IMocksControl mocksControl = EasyMock.createStrictControl();

		OrderMapper mockOrderMapper = mocksControl.createMock(OrderMapper.class);
		OrderLineMapper mockOrderLineMapper = mocksControl.createMock(OrderLineMapper.class);
		OrderDiscountMapper mockOrderDiscountMapper = mocksControl.createMock(OrderDiscountMapper.class);
		OrderEwsMapper mockOrderEwsMapper = mocksControl.createMock(OrderEwsMapper.class);

		String orderJson = "{\"amount\":282.00,\"cancelReason\":0,\"createdTime\":1499323183217,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000034761\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":10,\"storeId\":9999,\"timeout\":true,\"totalGpDiscount\":3.60,\"userId\":\"test\",\"version\":1,\"voucherDiscount\":0.00}";
		Order order = JSON.parseObject(orderJson, Order.class);

		String orderLineJson = "[{\"cartItemId\":31000002600222,\"department\":96,\"descOnline\":\"Marques del norte马奎斯德诺 西班牙进口 红葡萄酒 750ml\",\"gpDiscount\":0.00,\"itemAmount\":0.00,\"itemNumber\":31000002600222,\"itemType\":0,\"orderId\":\"099991700100000034761\",\"orderQuantity\":2,\"orderWeight\":0.00000,\"priceWithTax\":38.00,\"priceWithoutTax\":0.00,\"productId\":31000002600222,\"returnBy\":1500532783217,\"storeId\":9999,\"taxRate\":0.0000,\"thumbnailUrl\":\"1000002600222_0_1_1423389442486.JPG\",\"unitCost\":0.0000,\"upc\":2600222,\"wasPrice\":0.00},{\"cartItemId\":31000002750720,\"department\":96,\"descOnline\":\"Marques del norte马奎斯德诺 西班牙进口 珍藏红葡萄酒 750ml\",\"gpDiscount\":0.00,\"itemAmount\":0.00,\"itemNumber\":31000002750720,\"itemType\":0,\"orderId\":\"099991700100000034761\",\"orderQuantity\":2,\"orderWeight\":0.00000,\"priceWithTax\":88.00,\"priceWithoutTax\":0.00,\"productId\":31000002750720,\"returnBy\":1500532783217,\"storeId\":9999,\"taxRate\":0.0000,\"thumbnailUrl\":\"1000002750720_0_1_1426752461442.JPG\",\"unitCost\":0.0000,\"upc\":2750720,\"wasPrice\":0.00},{\"cartItemId\":31002980105401,\"department\":92,\"descOnline\":\"Belgian Butters伯珍 比利时进口 黄油华夫薄脆饼干 100g\",\"gpDiscount\":3.60,\"itemAmount\":0.00,\"itemNumber\":31002980105401,\"itemType\":0,\"orderId\":\"099991700100000034761\",\"orderQuantity\":2,\"orderWeight\":0.00000,\"priceWithTax\":16.80,\"priceWithoutTax\":0.00,\"productId\":31002980105401,\"returnBy\":1500532783217,\"storeId\":9999,\"taxRate\":0.0000,\"thumbnailUrl\":\"1002980105401_0_1_1438842718396.jpg\",\"unitCost\":0.0000,\"upc\":2980105401,\"wasPrice\":0.00}]";
		List<OrderLine> orderLines = JSON.parseArray(orderLineJson, OrderLine.class);

		String orderDiscountJson = "[{\"cartItemId\":31000002600222,\"gpDiscount\":0.00,\"gpDiscountTimes\":0,\"gpGroupSeq\":1,\"gpOfferId\":20845993,\"gpTypeCode\":1,\"orderId\":\"099991700100000034761\",\"productId\":31000002600222,\"promotionDescCn\":\"6件及以上享9折\",\"storeId\":9999},{\"cartItemId\":31000002750720,\"gpDiscount\":0.00,\"gpDiscountTimes\":0,\"gpGroupSeq\":1,\"gpOfferId\":20845993,\"gpTypeCode\":1,\"orderId\":\"099991700100000034761\",\"productId\":31000002750720,\"promotionDescCn\":\"6件及以上1享9折\",\"storeId\":9999},{\"cartItemId\":31002980105401,\"gpDiscount\":3.60,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":20845798,\"gpTypeCode\":4,\"orderId\":\"099991700100000034761\",\"productId\":31002980105401,\"promotionDescCn\":\"参与本活动1的商品任选2件仅需30元\",\"storeId\":9999}]";
		List<OrderDiscount> orderDiscountList = JSON.parseArray(orderDiscountJson, OrderDiscount.class);
		// 录制动作
		EasyMock.expect(mockOrderMapper.selectOrderByUserIdAndOrderId("test", "099991700100000033581")).andReturn(order);
		EasyMock.expect(mockOrderLineMapper.selectOrderLineListByOrderId(EasyMock.anyString())).andReturn(orderLines);
		EasyMock.expect(mockOrderDiscountMapper.selectOrderDiscountListByCartItemId(EasyMock.anyString(), EasyMock.anyObject(List.class))).andReturn(orderDiscountList);
		EasyMock.expect(mockOrderEwsMapper.selectOrderEwsList(EasyMock.anyString())).andReturn(null);
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(orderService, "orderMapper", mockOrderMapper, OrderMapper.class);
		ReflectionTestUtils.setField(orderService, "orderLineMapper", mockOrderLineMapper, OrderLineMapper.class);
		ReflectionTestUtils.setField(orderService, "orderDiscountMapper", mockOrderDiscountMapper, OrderDiscountMapper.class);
		ReflectionTestUtils.setField(orderService, "orderEwsMapper", mockOrderEwsMapper, OrderEwsMapper.class);
		// 执行测试方法
		OrderBo orderDetail = orderService.requestOrderDetailByUserIdAndOrderId("test", "099991700100000033581");
		Assert.isTrue(orderDetail != null, "");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockOrderMapper);
		EasyMock.verify(mockOrderLineMapper);
		EasyMock.verify(mockOrderDiscountMapper);
		EasyMock.verify(mockOrderEwsMapper);
		mocksControl.reset();

	}

	// @Test
	public void orderServiceGetOrderListByPaginationTest() throws GlobalErrorInfoException {
		IMocksControl mocksControl = EasyMock.createStrictControl();

		OrderMapper mockOrderMapper = mocksControl.createMock(OrderMapper.class);
		OrderLineMapper mockOrderLineMapper = mocksControl.createMock(OrderLineMapper.class);
		String orderJson = "[{\"amount\":31.60,\"cancelReason\":0,\"createdTime\":1515058454633,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"mobilePhone\":\"13424323256\",\"orderId\":\"19999180010002034883\",\"orderType\":1,\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":10,\"storeId\":9999,\"taxCode\":\"123123123\",\"timeout\":true,\"totalGpDiscount\":10.00,\"userId\":\"test\",\"version\":1,\"voucherDiscount\":0.00},{\"amount\":81.00,\"cancelReason\":0,\"createdTime\":1515058454567,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"mobilePhone\":\"13424323256\",\"orderId\":\"19999180010002034794\",\"orderType\":1,\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":10,\"storeId\":9999,\"taxCode\":\"123123123\",\"timeout\":true,\"totalGpDiscount\":513.00,\"userId\":\"test\",\"version\":1,\"voucherDiscount\":0.00},{\"amount\":31.60,\"cancelReason\":0,\"createdTime\":1515053375420,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"mobilePhone\":\"13424323256\",\"orderId\":\"19999180010002034453\",\"orderType\":1,\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":10,\"storeId\":9999,\"taxCode\":\"123123123\",\"timeout\":true,\"totalGpDiscount\":10.00,\"userId\":\"test\",\"version\":1,\"voucherDiscount\":0.00},{\"amount\":81.00,\"cancelReason\":0,\"createdTime\":1515053375307,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"mobilePhone\":\"13424323256\",\"orderId\":\"19999180010002034355\",\"orderType\":1,\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":10,\"storeId\":9999,\"taxCode\":\"123123123\",\"timeout\":true,\"totalGpDiscount\":513.00,\"userId\":\"test\",\"version\":1,\"voucherDiscount\":0.00},{\"amount\":81.00,\"cancelReason\":0,\"createdTime\":1515053279297,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"mobilePhone\":\"13424323256\",\"orderId\":\"19999180010002034292\",\"orderType\":1,\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":10,\"storeId\":9999,\"taxCode\":\"123123123\",\"timeout\":true,\"totalGpDiscount\":513.00,\"userId\":\"test\",\"version\":1,\"voucherDiscount\":0.00},{\"amount\":81.00,\"cancelReason\":0,\"createdTime\":1515053114873,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"mobilePhone\":\"13424323256\",\"orderId\":\"19999180010002030427\",\"orderType\":1,\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":10,\"storeId\":9999,\"taxCode\":\"123123123\",\"timeout\":true,\"totalGpDiscount\":513.00,\"userId\":\"test\",\"version\":1,\"voucherDiscount\":0.00},{\"amount\":31.60,\"cancelReason\":0,\"createdTime\":1515052992240,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"mobilePhone\":\"13424323256\",\"orderId\":\"19999180010002030379\",\"orderType\":1,\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":10,\"storeId\":9999,\"taxCode\":\"123123123\",\"timeout\":true,\"totalGpDiscount\":10.00,\"userId\":\"test\",\"version\":1,\"voucherDiscount\":0.00},{\"amount\":97.30,\"cancelReason\":0,\"createdTime\":1515052992167,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"mobilePhone\":\"13424323256\",\"orderId\":\"19999180010002030200\",\"orderType\":1,\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":10,\"storeId\":9999,\"taxCode\":\"123123123\",\"timeout\":true,\"totalGpDiscount\":0.00,\"userId\":\"test\",\"version\":1,\"voucherDiscount\":0.00},{\"amount\":21.30,\"cancelReason\":0,\"createdTime\":1515052992093,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"mobilePhone\":\"13424323256\",\"orderId\":\"19999180010002030188\",\"orderType\":1,\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":10,\"storeId\":9999,\"taxCode\":\"123123123\",\"timeout\":true,\"totalGpDiscount\":0.00,\"userId\":\"test\",\"version\":1,\"voucherDiscount\":0.00},{\"amount\":81.00,\"cancelReason\":0,\"createdTime\":1515052992027,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"mobilePhone\":\"13424323256\",\"orderId\":\"19999180010002030015\",\"orderType\":1,\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":10,\"storeId\":9999,\"taxCode\":\"123123123\",\"teout\":true,\"totalGpDiscount\":513.00,\"userId\":\"test\",\"version\":1,\"voucherDiscount\":0.00}]";
		List<Order> orderDetails = JSON.parseArray(orderJson, Order.class);

		String orderLineJson = "[{\"cartItemId\":31001538805804,\"department\":-1,\"descOnline\":\"Bakeis 6连杯蛋糕模 1个\",\"gpDiscount\":513.00,\"itemAmount\":0.00,\"itemNumber\":31001538805804,\"itemType\":0,\"orderDiscountList\":[],\"orderId\":\"19999180010002030015\",\"orderQuantity\":3,\"orderWeight\":0.00000,\"priceWithTax\":198.00,\"priceWithoutTax\":0.00,\"productId\":31001538805804,\"returnBy\":1516262592027,\"specialItemFlag\":0,\"storeId\":9999,\"taxRate\":0.0000,\"thumbnailUrl\":\"1001538805804_0_1_1436768349244.JPG\",\"unitCost\":0.0000,\"unitPriceItemFlag\":0,\"upc\":1538805804,\"wasPrice\":0.00},{\"cartItemId\":0,\"department\":-1,\"descOnline\":\"东北绿豆Test.              \",\"gpDiscount\":0.00,\"itemAmount\":21.30,\"itemNumber\":1212222300000,\"itemType\":1,\"magneticFlag\":1,\"orderDiscountList\":[],\"orderId\":\"19999180010002030188\",\"orderQuantity\":3,\"orderWeight\":0.32769,\"priceWithTax\":65.00,\"priceWithoutTax\":0.00,\"productId\":1212222300000,\"returnBy\":1516262592093,\"specialItemFlag\":0,\"storeId\":9999,\"taxRate\":0.0000,\"thumbnailUrl\":\"\",\"unitCost\":0.0000,\"unitPriceItemFlag\":0,\"upc\":212222300000,\"wasPrice\":0.00},{\"cartItemId\":0,\"department\":-1,\"descOnline\":\"东北绿豆Test.              \",\"gpDiscount\":0.00,\"itemAmount\":21.30,\"itemNumber\":1212222300000,\"itemType\":1,\"magneticFlag\":1,\"orderDiscountList\":[],\"orderId\":\"19999180010002030200\",\"orderQuantity\":3,\"orderWeight\":0.32769,\"priceWithTax\":65.00,\"priceWithoutTax\":0.00,\"productId\":1212222300000,\"returnBy\":1516262592167,\"specialItemFlag\":0,\"storeId\":9999,\"taxRate\":0.0000,\"thumbnailUrl\":\"\",\"unitCost\":0.0000,\"unitPriceItemFlag\":0,\"upc\":212222300000,\"wasPrice\":0.00},{\"cartItemId\":31000002600222,\"department\":-1,\"descOnline\":\"Marques del norte马奎斯德诺 西班牙进口 红葡萄酒 750ml\",\"gpDiscount\":0.00,\"itemAmount\":0.00,\"itemNumber\":31000002600222,\"itemType\":0,\"magneticFlag\":0,\"orderDiscountList\":[],\"orderId\":\"19999180010002030200\",\"orderQuantity\":2,\"orderWeight\":0.00000,\"priceWithTax\":38.00,\"priceWithoutTax\":0.00,\"productId\":31000002600222,\"returnBy\":1516262592167,\"specialItemFlag\":0,\"storeId\":9999,\"taxRate\":0.0000,\"thumbnailUrl\":\"1000002600222_0_1_1423389442486.JPG\",\"unitCost\":0.0000,\"unitPriceItemFlag\":0,\"upc\":2600222,\"wasPrice\":0.00},{\"cartItemId\":0,\"department\":-1,\"descOnline\":\"东北绿豆Test2.              \",\"gpDiscount\":5.00,\"itemAmount\":20.80,\"itemNumber\":12122222000000,\"itemType\":1,\"orderDiscountList\":[],\"orderId\":\"19999180010002030379\",\"orderQuantity\":1,\"orderWeight\":1.00000,\"priceWithTax\":20.80,\"priceWithoutTax\":17.78,\"productId\":12122222000000,\"returnBy\":1516262592240,\"specialItemFlag\":0,\"storeId\":9999,\"taxRate\":0.1700,\"thumbnailUrl\":\"\",\"unitCost\":13.9313,\"unitPriceItemFlag\":0,\"upc\":2122222000000,\"wasPrice\":0.00},{\"cartItemId\":1,\"department\":-1,\"descOnline\":\"东北绿豆Test2.              \",\"gpDiscount\":5.00,\"itemAmount\":20.80,\"itemNumber\":12122222000000,\"itemType\":1,\"orderDiscountList\":[],\"orderId\":\"19999180010002030379\",\"orderQuantity\":1,\"orderWeight\":1.00000,\"priceWithTax\":20.80,\"priceWithoutTax\":17.78,\"productId\":12122222000000,\"returnBy\":1516262592240,\"specialItemFlag\":0,\"storeId\":9999,\"taxRate\":0.1700,\"thumbnailUrl\":\"\",\"unitCost\":13.9313,\"unitPriceItemFlag\":0,\"upc\":2122222000000,\"wasPrice\":0.00},{\"cartItemId\":31001538805804,\"department\":-1,\"descOnline\":\"Bakeis 6连杯蛋糕模 1个\",\"gpDiscount\":513.00,\"itemAmount\":0.00,\"itemNumber\":31001538805804,\"itemType\":0,\"orderDiscountList\":[],\"orderId\":\"19999180010002030427\",\"orderQuantity\":3,\"orderWeight\":0.00000,\"priceWithTax\":198.00,\"priceWithoutTax\":0.00,\"productId\":31001538805804,\"returnBy\":1516262714873,\"specialItemFlag\":0,\"storeId\":9999,\"taxRate\":0.0000,\"thumbnailUrl\":\"1001538805804_0_1_1436768349244.JPG\",\"unitCost\":0.0000,\"unitPriceItemFlag\":0,\"upc\":1538805804,\"wasPrice\":0.00},{\"cartItemId\":31001538805804,\"department\":-1,\"descOnline\":\"Bakeis 6连杯蛋糕模 1个\",\"gpDiscount\":513.00,\"itemAmount\":0.00,\"itemNumber\":31001538805804,\"itemType\":0,\"orderDiscountList\":[],\"orderId\":\"19999180010002034292\",\"orderQuantity\":3,\"orderWeight\":0.00000,\"priceWithTax\":198.00,\"priceWithoutTax\":0.00,\"productId\":31001538805804,\"returnBy\":1516262879297,\"specialItemFlag\":0,\"storeId\":9999,\"taxRate\":0.0000,\"thumbnailUrl\":\"1001538805804_0_1_1436768349244.JPG\",\"unitCost\":0.0000,\"unitPriceItemFlag\":0,\"upc\":1538805804,\"wasPrice\":0.00},{\"cartItemId\":31001538805804,\"department\":-1,\"descOnline\":\"Bakeis 6连杯蛋糕模 1个\",\"gpDiscount\":513.00,\"itemAmount\":0.00,\"itemNumber\":31001538805804,\"itemType\":0,\"orderDiscountList\":[],\"orderId\":\"19999180010002034355\",\"orderQuantity\":3,\"orderWeight\":0.00000,\"priceWithTax\":198.00,\"priceWithoutTax\":0.00,\"productId\":31001538805804,\"returnBy\":1516262975307,\"specialItemFlag\":0,\"storeId\":9999,\"taxRate\":0.0000,\"thumbnailUrl\":\"1001538805804_0_1_1436768349244.JPG\",\"unitCost\":0.0000,\"unitPriceItemFlag\":0,\"upc\":1538805804,\"wasPrice\":0.00},{\"cartItemId\":0,\"department\":-1,\"descOnline\":\"东北绿豆Test2.              \",\"gpDiscount\":5.00,\"itemAmount\":20.80,\"itemNumber\":12122222000000,\"itemType\":1,\"orderDiscountList\":[],\"orderId\":\"19999180010002034453\",\"orderQuantity\":1,\"orderWeight\":1.00000,\"priceWithTax\":20.80,\"priceWithoutTax\":17.78,\"productId\":12122222000000,\"returnBy\":1516262975420,\"specialItemFlag\":0,\"storeId\":9999,\"taxRate\":0.1700,\"thumbnailUrl\":\"\",\"unitCost\":13.9313,\"unitPriceItemFlag\":0,\"upc\":2122222000000,\"wasPrice\":0.00},{\"cartItemId\":1,\"department\":-1,\"descOnline\":\"东北绿豆Test2.              \",\"gpDiscount\":5.00,\"itemAmount\":20.80,\"itemNumber\":12122222000000,\"itemType\":1,\"orderDiscountList\":[],\"orderId\":\"19999180010002034453\",\"orderQuantity\":1,\"orderWeight\":1.00000,\"priceWithTax\":20.80,\"priceWithoutTax\":17.78,\"productId\":12122222000000,\"returnBy\":1516262975420,\"specialItemFlag\":0,\"storeId\":9999,\"taxRate\":0.1700,\"thumbnailUrl\":\"\",\"unitCost\":13.9313,\"unitPriceItemFlag\":0,\"upc\":2122222000000,\"wasPrice\":0.00},{\"cartItemId\":31001538805804,\"department\":-1,\"descOnline\":\"Bakeis 6连杯蛋糕模 1个\",\"gpDiscount\":513.00,\"itemAmount\":0.00,\"itemNumber\":31001538805804,\"itemType\":0,\"orderDiscountList\":[],\"orderId\":\"19999180010002034794\",\"orderQuantity\":3,\"orderWeight\":0.00000,\"priceWithTax\":198.00,\"priceWithoutTax\":0.00,\"productId\":31001538805804,\"returnBy\":1516268054567,\"specialItemFlag\":0,\"storeId\":9999,\"taxRate\":0.0000,\"thumbnailUrl\":\"1001538805804_0_1_1436768349244.JPG\",\"unitCost\":0.0000,\"unitPriceItemFlag\":0,\"upc\":1538805804,\"wasPrice\":0.00},{\"cartItemId\":0,\"department\":-1,\"descOnline\":\"东北绿豆Test2.              \",\"gpDiscount\":5.00,\"itemAmount\":20.80,\"itemNumber\":12122222000000,\"itemType\":1,\"orderDiscountList\":[],\"orderId\":\"19999180010002034883\",\"orderQuantity\":1,\"orderWeight\":1.00000,\"priceWithTax\":20.80,\"priceWithoutTax\":17.78,\"productId\":12122222000000,\"returnBy\":1516268054633,\"specialItemFlag\":0,\"storeId\":9999,\"taxRate\":0.1700,\"thumbnailUrl\":\"\",\"unitCost\":13.9313,\"unitPriceItemFlag\":0,\"upc\":2122222000000,\"wasPrice\":0.00},{\"cartItemId\":1,\"department\":-1,\"descOnline\":\"东北绿豆Test2.              \",\"gpDiscount\":5.00,\"itemAmount\":20.80,\"itemNumber\":12122222000000,\"itemType\":1,\"orderDiscountList\":[],\"orderId\":\"19999180010002034883\",\"orderQuantity\":1,\"orderWeight\":1.00000,\"priceWithTax\":20.80,\"priceWithoutTax\":17.78,\"productId\":12122222000000,\"returnBy\":1516268054633,\"specialItemFlag\":0,\"storeId\":9999,\"taxRate\":0.1700,\"thumbnailUrl\":\"\",\"unitCost\":13.9313,\"unitPriceItemFlag\":0,\"upc\":2122222000000,\"wasPrice\":0.00}]";
		List<OrderLineBo> orderLineList = JSON.parseArray(orderLineJson, OrderLineBo.class);
		String orderIdJson = "[\"19999180010002034883\",\"19999180010002034794\",\"19999180010002034453\",\"19999180010002034355\",\"19999180010002034292\",\"19999180010002030427\",\"19999180010002030379\",\"19999180010002030200\",\"19999180010002030188\",\"19999180010002030015\"]";
		List<String> orderIds = JSON.parseArray(orderIdJson, String.class);
		// 录制动作
		EasyMock.expect(mockOrderMapper.selectOrderPageByUserId("test", 0, 10)).andReturn(orderDetails);
		EasyMock.expect(mockOrderLineMapper.selectOrderLineBosByOrderIds(orderIds)).andReturn(orderLineList);
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(orderService, "orderMapper", mockOrderMapper, OrderMapper.class);
		ReflectionTestUtils.setField(orderService, "orderLineMapper", mockOrderLineMapper, OrderLineMapper.class);
		// 执行测试方法
		List<OrderBo> orderDetailList = orderService.getOrderListByPagination(0, 10, "test");
		Assert.isTrue(orderDetailList != null, "");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockOrderMapper);
		EasyMock.verify(mockOrderLineMapper);
		mocksControl.reset();

	}

	@Test
	public void orderServiceSelectOrderListbyUserIdAndstatusAndChangeStatusTest() throws GlobalErrorInfoException {
		IMocksControl mocksControl = EasyMock.createStrictControl();

		OrderMapper mockOrderMapper = mocksControl.createMock(OrderMapper.class);
		String orderJson = "[{\"amount\":76.00,\"cancelReason\":0,\"createdTime\":1499323183097,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000033581\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":30,\"storeId\":9999,\"timeout\":false,\"totalGpDiscount\":0.00,\"userId\":\"test\",\"version\":839,\"voucherDiscount\":0.00}]";
		List<OrderBo> orderBoList = JSON.parseArray(orderJson, OrderBo.class);

		// 录制动作
		EasyMock.expect(mockOrderMapper.selectOrderListbyUserIdAndstatusAndStoreId("test", OrderStatus.PAID, 9999)).andReturn(orderBoList);
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(orderService, "orderMapper", mockOrderMapper, OrderMapper.class);
		// 执行测试方法
		List<String> orderIdlist = orderService.selectOrderListbyUserIdAndstatusAndChangeStatus("test", OrderStatus.PAID, 9999);
		Assert.isTrue(orderIdlist != null, "");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockOrderMapper);
		mocksControl.reset();

	}

	@Test
	public void orderServiceSelectOrderListByUserIdAndOrderIdsTest() throws GlobalErrorInfoException {
		IMocksControl mocksControl = EasyMock.createStrictControl();

		OrderMapper mockOrderMapper = mocksControl.createMock(OrderMapper.class);
		String orderJson = "[{\"amount\":29.35,\"cancelReason\":0,\"createdTime\":1499323185083,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000060661\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":1,\"storeId\":9999,\"timeout\":false,\"totalGpDiscount\":47.85,\"userId\":\"test\",\"version\":0,\"voucherDiscount\":0.00},{\"amount\":169.00,\"cancelReason\":0,\"createdTime\":1499323185197,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000061341\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":1,\"storeId\":9999,\"timeout\":false,\"totalGpDiscount\":1025.00,\"userId\":\"test\",\"version\":0,\"voucherDiscount\":0.00},{\"amount\":122.40,\"cancelReason\":0,\"createdTime\":1499323185320,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000062601\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":1,\"storeId\":9999,\"timeout\":false,\"totalGpDiscount\":1269.60,\"userId\":\"test\",\"version\":0,\"voucherDiscount\":0.00},{\"amount\":236.40,\"cancelReason\":0,\"createdTime\":1499323185437,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000063841\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":1,\"storeId\":9999,\"timeout\":false,\"totalGpDiscount\":1155.60,\"userId\":\"test\",\"version\":0,\"voucherDiscount\":0.00},{\"amount\":185.40,\"cancelReason\":0,\"createdTime\":1499323185553,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000064441\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":1,\"storeId\":9999,\"timeout\":false,\"totalGpDiscount\":1206.60,\"userId\":\"test\",\"version\":0,\"voucherDiscount\":0.00},{\"amount\":34.40,\"cancelReason\":0,\"createdTime\":1499323185663,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000065241\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":1,\"storeId\":9999,\"timeout\":false,\"totalGpDiscount\":757.60,\"userId\":\"test\",\"version\":0,\"voucherDiscount\":0.00}]";
		List<Order> orderBoList = JSON.parseArray(orderJson, Order.class);

		String[] orderIdArray = { "099991700100000060661", "099991700100000061341", "099991700100000062601", "099991700100000063841", "099991700100000064441", "099991700100000065241" };
		// 录制动作
		EasyMock.expect(mockOrderMapper.selectOrderListByUserIdAndOrderIds("test", Arrays.asList(orderIdArray))).andReturn(orderBoList);
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(orderService, "orderMapper", mockOrderMapper, OrderMapper.class);
		// 执行测试方法
		List<Order> orderBoLists = orderService.selectOrderListByUserIdAndOrderIds("test", Arrays.asList(orderIdArray));
		Assert.isTrue(orderBoLists != null, "");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockOrderMapper);
		mocksControl.reset();
	}

	@Test
	public void orderServiceRequestOrderDetailByOrderTest() throws GlobalErrorInfoException {
		IMocksControl mocksControl = EasyMock.createStrictControl();

		OrderLineMapper mockOrderLineMapper = mocksControl.createMock(OrderLineMapper.class);
		OrderDiscountMapper mockOrderDiscountMapper = mocksControl.createMock(OrderDiscountMapper.class);
		OrderEwsMapper mockOrderEwsMapper = mocksControl.createMock(OrderEwsMapper.class);

		String orderJson = "{\"amount\":282.00,\"cancelReason\":0,\"createdTime\":1499323183217,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000034761\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":10,\"storeId\":9999,\"timeout\":true,\"totalGpDiscount\":3.60,\"userId\":\"test\",\"version\":1,\"voucherDiscount\":0.00}";
		Order order = JSON.parseObject(orderJson, Order.class);

		String orderLineJson = "[{\"cartItemId\":31000002600222,\"department\":96,\"descOnline\":\"Marques del norte马奎斯德诺 西班牙进口 红葡萄酒 750ml\",\"gpDiscount\":0.00,\"itemAmount\":0.00,\"itemNumber\":31000002600222,\"itemType\":0,\"orderId\":\"099991700100000034761\",\"orderQuantity\":2,\"orderWeight\":0.00000,\"priceWithTax\":38.00,\"priceWithoutTax\":0.00,\"productId\":31000002600222,\"returnBy\":1500532783217,\"storeId\":9999,\"taxRate\":0.0000,\"thumbnailUrl\":\"1000002600222_0_1_1423389442486.JPG\",\"unitCost\":0.0000,\"upc\":2600222,\"wasPrice\":0.00},{\"cartItemId\":31000002750720,\"department\":96,\"descOnline\":\"Marques del norte马奎斯德诺 西班牙进口 珍藏红葡萄酒 750ml\",\"gpDiscount\":0.00,\"itemAmount\":0.00,\"itemNumber\":31000002750720,\"itemType\":0,\"orderId\":\"099991700100000034761\",\"orderQuantity\":2,\"orderWeight\":0.00000,\"priceWithTax\":88.00,\"priceWithoutTax\":0.00,\"productId\":31000002750720,\"returnBy\":1500532783217,\"storeId\":9999,\"taxRate\":0.0000,\"thumbnailUrl\":\"1000002750720_0_1_1426752461442.JPG\",\"unitCost\":0.0000,\"upc\":2750720,\"wasPrice\":0.00},{\"cartItemId\":31002980105401,\"department\":92,\"descOnline\":\"Belgian Butters伯珍 比利时进口 黄油华夫薄脆饼干 100g\",\"gpDiscount\":3.60,\"itemAmount\":0.00,\"itemNumber\":31002980105401,\"itemType\":0,\"orderId\":\"099991700100000034761\",\"orderQuantity\":2,\"orderWeight\":0.00000,\"priceWithTax\":16.80,\"priceWithoutTax\":0.00,\"productId\":31002980105401,\"returnBy\":1500532783217,\"storeId\":9999,\"taxRate\":0.0000,\"thumbnailUrl\":\"1002980105401_0_1_1438842718396.jpg\",\"unitCost\":0.0000,\"upc\":2980105401,\"wasPrice\":0.00}]";
		List<OrderLine> orderLines = JSON.parseArray(orderLineJson, OrderLine.class);

		String orderDiscountJson = "[{\"cartItemId\":31000002600222,\"gpDiscount\":0.00,\"gpDiscountTimes\":0,\"gpGroupSeq\":1,\"gpOfferId\":20845993,\"gpTypeCode\":1,\"orderId\":\"099991700100000034761\",\"productId\":31000002600222,\"promotionDescCn\":\"6件及以上享9折\",\"storeId\":9999},{\"cartItemId\":31000002750720,\"gpDiscount\":0.00,\"gpDiscountTimes\":0,\"gpGroupSeq\":1,\"gpOfferId\":20845993,\"gpTypeCode\":1,\"orderId\":\"099991700100000034761\",\"productId\":31000002750720,\"promotionDescCn\":\"6件及以上1享9折\",\"storeId\":9999},{\"cartItemId\":31002980105401,\"gpDiscount\":3.60,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":20845798,\"gpTypeCode\":4,\"orderId\":\"099991700100000034761\",\"productId\":31002980105401,\"promotionDescCn\":\"参与本活动1的商品任选2件仅需30元\",\"storeId\":9999}]";
		List<OrderDiscount> orderDiscountList = JSON.parseArray(orderDiscountJson, OrderDiscount.class);
		// 录制动作
		EasyMock.expect(mockOrderLineMapper.selectOrderLineListByOrderId(EasyMock.anyString())).andReturn(orderLines);
		EasyMock.expect(mockOrderDiscountMapper.selectOrderDiscountListByCartItemId(EasyMock.anyString(), EasyMock.anyObject(List.class))).andReturn(orderDiscountList);
		EasyMock.expect(mockOrderEwsMapper.selectOrderEwsList(EasyMock.anyString())).andReturn(null);
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(orderService, "orderLineMapper", mockOrderLineMapper, OrderLineMapper.class);
		ReflectionTestUtils.setField(orderService, "orderDiscountMapper", mockOrderDiscountMapper, OrderDiscountMapper.class);
		ReflectionTestUtils.setField(orderService, "orderEwsMapper", mockOrderEwsMapper, OrderEwsMapper.class);
		// 执行测试方法

		OrderBo orderBo = orderService.requestOrderDetailByOrder(order);
		Assert.isTrue(orderBo != null, "");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockOrderLineMapper);
		EasyMock.verify(mockOrderDiscountMapper);
		EasyMock.verify(mockOrderEwsMapper);
		mocksControl.reset();
	}

}
