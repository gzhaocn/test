package order;

import java.util.List;

import org.easymock.EasyMock;
import org.easymock.IMocksControl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.Assert;

import com.alibaba.fastjson.JSON;
import com.walmart.mobile.checkout.bo.order.OrderBo;
import com.walmart.mobile.checkout.bo.order.OrderLineBo;
import com.walmart.mobile.checkout.bo.order.OrderParameter;
import com.walmart.mobile.checkout.config.MainConfig;
import com.walmart.mobile.checkout.domain.StoreVo;
import com.walmart.mobile.checkout.domain.order.Order;
import com.walmart.mobile.checkout.domain.order.OrderDiscount;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.mapper.OrderDiscountMapper;
import com.walmart.mobile.checkout.mapper.OrderEwsMapper;
import com.walmart.mobile.checkout.mapper.OrderLineMapper;
import com.walmart.mobile.checkout.mapper.OrderMapper;
import com.walmart.mobile.checkout.rest.StoreServiceClient;
import com.walmart.mobile.checkout.rest.order.EwsPriceServiceClient;
import com.walmart.mobile.checkout.rest.order.GpOfferServiceClient;
import com.walmart.mobile.checkout.rest.order.ItemServiceClient;
import com.walmart.mobile.checkout.rest.vo.EwsPriceVo;
import com.walmart.mobile.checkout.rest.vo.GpOfferVo;
import com.walmart.mobile.checkout.rest.vo.InventoryPriceVo;
import com.walmart.mobile.checkout.rest.vo.ProductDetailVo;
import com.walmart.mobile.checkout.rest.vo.SpecialItemVo;
import com.walmart.mobile.checkout.service.OrderService;
import com.walmart.mobile.checkout.service.OrderStatusService;
import com.walmart.mobile.checkout.service.OrderValidationService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MainConfig.class })
@WebAppConfiguration
public class OrderServiceMock2Test {
	@Autowired
	private OrderService orderService;
	@Autowired
	OrderStatusService orderStatusService;
	@Autowired
	private OrderValidationService orderValidationService;

	@Test
	public void orderServiceGetOrderBoListTest() throws GlobalErrorInfoException {

		IMocksControl mocksControl = EasyMock.createStrictControl();
		OrderLineMapper mockOrderLineMapper = mocksControl.createMock(OrderLineMapper.class);
		OrderDiscountMapper mockOrderDiscountMapper = mocksControl.createMock(OrderDiscountMapper.class);
		OrderEwsMapper mockOrderEwsMapper = mocksControl.createMock(OrderEwsMapper.class);

		String orderLineJson = "[{\"cartItemId\":31000008017718,\"department\":1,\"descOnline\":\"健达 意大利进口 巧克力康脆麦 23.5g\",\"gpDiscount\":9.85,\"itemAmount\":0.00,\"itemNumber\":31000008017718,\"itemType\":0,\"orderDiscountList\":[],\"orderId\":\"099991700100000060661\",\"orderQuantity\":4,\"orderWeight\":0.00000,\"priceWithTax\":4.30,\"priceWithoutTax\":0.00,\"productId\":31000008017718,\"returnBy\":1500532785083,\"storeId\":9999,\"taxRate\":0.0000,\"thumbnailUrl\":\"1000008017718_0_1_1422498919414.JPG\",\"unitCost\":0.0000,\"upc\":8017718,\"wasPrice\":0.00},{\"cartItemId\":31212399500000,\"department\":98,\"descOnline\":\"沃尔玛 小甜包 12个\",\"gpDiscount\":28.00,\"itemAmount\":0.00,\"itemNumber\":31212399500000,\"itemType\":0,\"orderDiscountList\":[],\"orderId\":\"099991700100000060661\",\"orderQuantity\":8,\"orderWeight\":0.00000,\"priceWithTax\":5.00,\"priceWithoutTax\":0.00,\"productId\":31212399500000,\"returnBy\":1500532785083,\"storeId\":9999,\"taxRate\":0.0000,\"thumbnailUrl\":\"1212399500000_0_1_1450930266628.jpg\",\"unitCost\":0.0000,\"upc\":212399500000,\"wasPrice\":0.00},{\"cartItemId\":31489102870594,\"department\":92,\"descOnline\":\"ViTa维他 香港进口 柠檬味茶饮料 500ml\",\"gpDiscount\":10.00,\"itemAmount\":0.00,\"itemNumber\":31489102870594,\"itemType\":0,\"orderDiscountList\":[],\"orderId\":\"099991700100000060661\",\"orderQuantity\":4,\"orderWeight\":0.00000,\"priceWithTax\":5.00,\"priceWithoutTax\":0.00,\"productId\":31489102870594,\"returnBy\":1500532785083,\"storeId\":9999,\"taxRate\":0.0000,\"thumbnailUrl\":\"1489102870594_0_1_1423199500450.JPG\",\"unitCost\":0.0000,\"upc\":489102870594,\"wasPrice\":0.00},{\"cartItemId\":31001538805802,\"department\":14,\"descOnline\":\"Bakeis 可爱熊蛋糕模 1个\",\"gpDiscount\":512.00,\"itemAmount\":0.00,\"itemNumber\":31001538805802,\"itemType\":0,\"orderDiscountList\":[],\"orderId\":\"099991700100000061341\",\"orderQuantity\":3,\"orderWeight\":0.00000,\"priceWithTax\":200.00,\"priceWithoutTax\":0.00,\"productId\":31001538805802,\"returnBy\":1500532785197,\"storeId\":9999,\"taxRate\":0.0000,\"thumbnailUrl\":\"1001538805802_0_1_1436773393288.JPG\",\"unitCost\":0.0000,\"upc\":1538805802,\"wasPrice\":0.00},{\"cartItemId\":31001538805804,\"department\":14,\"descOnline\":\"Bakeis 6连杯蛋糕模 1个\",\"gpDiscount\":513.00,\"itemAmount\":0.00,\"itemNumber\":31001538805804,\"itemType\":0,\"orderDiscountList\":[],\"orderId\":\"099991700100000061341\",\"orderQuantity\":3,\"orderWeight\":0.00000,\"priceWithTax\":198.00,\"priceWithoutTax\":0.00,\"productId\":31001538805804,\"returnBy\":1500532785197,\"storeId\":9999,\"taxRate\":0.0000,\"thumbnailUrl\":\"1001538805804_0_1_1436768349244.JPG\",\"unitCost\":0.0000,\"upc\":1538805804,\"wasPrice\":0.00},{\"cartItemId\":31001538805802,\"department\":14,\"descOnline\":\"Bakeis 可爱熊蛋糕模 1个\",\"gpDiscount\":512.00,\"itemAmount\":0.00,\"itemNumber\":31001538805802,\"itemType\":0,\"orderDiscountList\":[],\"orderId\":\"099991700100000062601\",\"orderQuantity\":3,\"orderWeight\":0.00000,\"priceWithTax\":200.00,\"priceWithoutTax\":0.00,\"productId\":31001538805802,\"returnBy\":1500532785320,\"storeId\":9999,\"taxRate\":0.0000,\"thumbnailUrl\":\"1001538805802_0_1_1436773393288.JPG\",\"unitCost\":0.0000,\"upc\":1538805802,\"wasPrice\":0.00},{\"cartItemId\":31001538805804,\"department\":14,\"descOnline\":\"Bakeis 6连杯蛋糕模 1个\",\"gpDiscount\":757.60,\"itemAmount\":0.00,\"itemNumber\":31001538805804,\"itemType\":0,\"orderDiscountList\":[],\"orderId\":\"099991700100000062601\",\"orderQuantity\":4,\"orderWeight\":0.00000,\"priceWithTax\":198.00,\"priceWithoutTax\":0.00,\"productId\":31001538805804,\"returnBy\":1500532785320,\"storeId\":9999,\"taxRate\":0.0000,\"thumbnailUrl\":\"1001538805804_0_1_1436768349244.JPG\",\"unitCost\":0.0000,\"upc\":1538805804,\"wasPrice\":0.00},{\"cartItemId\":31001538805804,\"department\":14,\"descOnline\":\"Bakeis 6连杯蛋糕模 1个\",\"gpDiscount\":757.60,\"itemAmount\":0.00,\"itemNumber\":31001538805804,\"itemType\":0,\"orderDiscountList\":[],\"orderId\":\"099991700100000063841\",\"orderQuantity\":4,\"orderWeight\":0.00000,\"priceWithTax\":198.00,\"priceWithoutTax\":0.00,\"productId\":31001538805804,\"returnBy\":1500532785437,\"storeId\":9999,\"taxRate\":0.0000,\"thumbnailUrl\":\"1001538805804_0_1_1436768349244.JPG\",\"unitCost\":0.0000,\"upc\":1538805804,\"wasPrice\":0.00},{\"cartItemId\":31030008718001,\"department\":92,\"descOnline\":\"Wyeth惠氏 爱尔兰进口 金装爱儿加早产儿出院后配方奶粉 400g\",\"gpDiscount\":398.00,\"itemAmount\":0.00,\"itemNumber\":31030008718001,\"itemType\":0,\"orderDiscountList\":[],\"orderId\":\"099991700100000063841\",\"orderQuantity\":3,\"orderWeight\":0.00000,\"priceWithTax\":200.00,\"priceWithoutTax\":0.00,\"productId\":31030008718001,\"returnBy\":1500532785437,\"storeId\":9999,\"taxRate\":0.0000,\"thumbnailUrl\":\"1030008718001_0_1_1418363416841.jpg\",\"unitCost\":0.0000,\"upc\":30008718001,\"wasPrice\":0.00},{\"cartItemId\":31001538805804,\"department\":14,\"descOnline\":\"Bakeis 6连杯蛋糕模 1个\",\"gpDiscount\":757.60,\"itemAmount\":0.00,\"itemNumber\":31001538805804,\"itemType\":0,\"orderDiscountList\":[],\"orderId\":\"099991700100000064441\",\"orderQuantity\":4,\"orderWeight\":0.00000,\"priceWithTax\":198.00,\"priceWithoutTax\":0.00,\"productId\":31001538805804,\"returnBy\":1500532785553,\"storeId\":9999,\"taxRate\":0.0000,\"thumbnailUrl\":\"1001538805804_0_1_1436768349244.JPG\",\"unitCost\":0.0000,\"upc\":1538805804,\"wasPrice\":0.00},{\"cartItemId\":31691462121086,\"department\":15,\"descOnline\":\"艾美特 台扇FD3006T2\",\"gpDiscount\":449.00,\"itemAmount\":0.00,\"itemNumber\":31691462121086,\"itemType\":0,\"orderDiscountList\":[],\"orderId\":\"099991700100000064441\",\"orderQuantity\":3,\"orderWeight\":0.00000,\"priceWithTax\":200.00,\"priceWithoutTax\":0.00,\"productId\":31691462121086,\"returnBy\":1500532785553,\"storeId\":9999,\"taxRate\":0.0000,\"thumbnailUrl\":\"1691462121086_0_1_1455766425441.jpg\",\"unitCost\":0.0000,\"upc\":691462121086,\"wasPrice\":0.00},{\"cartItemId\":31001538805804,\"department\":14,\"descOnline\":\"Bakeis 6连杯蛋糕模 1个\",\"gpDiscount\":757.60,\"itemAmount\":0.00,\"itemNumber\":31001538805804,\"itemType\":0,\"orderDiscountList\":[],\"orderId\":\"099991700100000065241\",\"orderQuantity\":4,\"orderWeight\":0.00000,\"priceWithTax\":198.00,\"priceWithoutTax\":0.00,\"productId\":31001538805804,\"returnBy\":1500532785663,\"storeId\":9999,\"taxRate\":0.0000,\"thumbnailUrl\":\"1001538805804_0_1_1436768349244.JPG\",\"unitCost\":0.0000,\"upc\":1538805804,\"wasPrice\":0.00}]";
		List<OrderLineBo> orderLines = JSON.parseArray(orderLineJson, OrderLineBo.class);

		String orderDiscountJson = "[{\"cartItemId\":31000008017718,\"gpDiscount\":5.85,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":2015,\"gpTypeCode\":3,\"orderId\":\"099991700100000060661\",\"productId\":31000008017718,\"promotionDescCn\":\"2件享7折，3件及以上享6.6折\",\"storeId\":9999},{\"cartItemId\":31000008017718,\"gpDiscount\":4.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":20778009,\"gpTypeCode\":2,\"orderId\":\"099991700100000060661\",\"productId\":31000008017718,\"promotionDescCn\":\"2件减2元，3件及以上减4元\",\"storeId\":9999},{\"cartItemId\":31000008017718,\"gpDiscount\":0.00,\"gpDiscountTimes\":0,\"gpGroupSeq\":1,\"gpOfferId\":20959184,\"gpTypeCode\":1,\"orderId\":\"099991700100000060661\",\"productId\":31000008017718,\"promotionDescCn\":\"6件及以上享9折\",\"storeId\":9999},{\"cartItemId\":31212399500000,\"gpDiscount\":16.00,\"gpDiscountTimes\":8,\"gpGroupSeq\":1,\"gpOfferId\":2028,\"gpTypeCode\":0,\"orderId\":\"099991700100000060661\",\"productId\":31212399500000,\"promotionDescCn\":\"满1件立减2元\",\"storeId\":9999},{\"cartItemId\":31212399500000,\"gpDiscount\":0.00,\"gpDiscountTimes\":4,\"gpGroupSeq\":1,\"gpOfferId\":20900049,\"gpTypeCode\":0,\"orderId\":\"099991700100000060661\",\"productId\":31212399500000,\"promotionDescCn\":\"满2件立减18元\",\"storeId\":9999},{\"cartItemId\":31212399500000,\"gpDiscount\":12.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":20900088,\"gpTypeCode\":1,\"orderId\":\"099991700100000060661\",\"productId\":31212399500000,\"promotionDescCn\":\"2件及以上享7折\",\"storeId\":9999},{\"cartItemId\":31489102870594,\"gpDiscount\":10.00,\"gpDiscountTimes\":2,\"gpGroupSeq\":1,\"gpOfferId\":20779530,\"gpTypeCode\":0,\"orderId\":\"099991700100000060661\",\"productId\":31489102870594,\"promotionDescCn\":\"满2件立减5元\",\"storeId\":9999},{\"cartItemId\":31489102870594,\"gpDiscount\":0.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":20914954,\"gpTypeCode\":1,\"orderId\":\"099991700100000060661\",\"productId\":31489102870594,\"promotionDescCn\":\"购买参加本活动的任意商品2件及以上享5折\",\"storeId\":9999},{\"cartItemId\":31489102870594,\"gpDiscount\":0.00,\"gpDiscountTimes\":2,\"gpGroupSeq\":1,\"gpOfferId\":2011000015,\"gpTypeCode\":6,\"orderId\":\"099991700100000060661\",\"productId\":31489102870594,\"promotionDescCn\":\"满10元立减5元\",\"storeId\":9999},{\"cartItemId\":31001538805802,\"gpDiscount\":21.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":2011000001,\"gpTypeCode\":0,\"orderId\":\"099991700100000061341\",\"productId\":31001538805802,\"promotionDescCn\":\"满2件立减21元\",\"storeId\":9999},{\"cartItemId\":31001538805802,\"gpDiscount\":174.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":2011000003,\"gpTypeCode\":1,\"orderId\":\"099991700100000061341\",\"productId\":31001538805802,\"promotionDescCn\":\"3件及以上享7.1折\",\"storeId\":9999},{\"cartItemId\":31001538805802,\"gpDiscount\":101.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":2011000004,\"gpTypeCode\":2,\"orderId\":\"099991700100000061341\",\"productId\":31001538805802,\"promotionDescCn\":\"2件减101元，4件及以上减211元\",\"storeId\":9999},{\"cartItemId\":31001538805802,\"gpDiscount\":114.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":2011000005,\"gpTypeCode\":3,\"orderId\":\"099991700100000061341\",\"productId\":31001538805802,\"promotionDescCn\":\"2件享8.1折，4件及以上享7.6折\",\"storeId\":9999},{\"cartItemId\":31001538805802,\"gpDiscount\":39.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":2011000006,\"gpTypeCode\":4,\"orderId\":\"099991700100000061341\",\"productId\":31001538805802,\"promotionDescCn\":\"2件仅需361元\",\"storeId\":9999},{\"cartItemId\":31001538805802,\"gpDiscount\":63.00,\"gpDiscountTimes\":3,\"gpGroupSeq\":1,\"gpOfferId\":2011000008,\"gpTypeCode\":6,\"orderId\":\"099991700100000061341\",\"productId\":31001538805802,\"promotionDescCn\":\"满105元立减21元\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":20.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":201000001,\"gpTypeCode\":0,\"orderId\":\"099991700100000061341\",\"productId\":31001538805804,\"promotionDescCn\":\"满2件立减20元\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":0.00,\"gpDiscountTimes\":0,\"gpGroupSeq\":1,\"gpOfferId\":201000002,\"gpTypeCode\":0,\"orderId\":\"099991700100000061341\",\"productId\":31001538805804,\"promotionDescCn\":\"满1组减15元（9件为1组:需包含第1类任意4件，第2类任意5件）\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":178.20,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":201000003,\"gpTypeCode\":1,\"orderId\":\"099991700100000061341\",\"productId\":31001538805804,\"promotionDescCn\":\"3件及以上享7折\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":100.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":201000004,\"gpTypeCode\":2,\"orderId\":\"099991700100000061341\",\"productId\":31001538805804,\"promotionDescCn\":\"2件减100元，4件及以上减210元\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":118.80,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":201000005,\"gpTypeCode\":3,\"orderId\":\"099991700100000061341\",\"productId\":31001538805804,\"promotionDescCn\":\"2件享8折，4件及以上享7.5折\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":36.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":201000006,\"gpTypeCode\":4,\"orderId\":\"099991700100000061341\",\"productId\":31001538805804,\"promotionDescCn\":\"2件仅需360元\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":60.00,\"gpDiscountTimes\":3,\"gpGroupSeq\":1,\"gpOfferId\":201000008,\"gpTypeCode\":6,\"orderId\":\"099991700100000061341\",\"productId\":31001538805804,\"promotionDescCn\":\"满105元立减20元\",\"storeId\":9999},{\"cartItemId\":31001538805802,\"gpDiscount\":21.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":2011000001,\"gpTypeCode\":0,\"orderId\":\"099991700100000062601\",\"productId\":31001538805802,\"promotionDescCn\":\"满2件立减21元\",\"storeId\":9999},{\"cartItemId\":31001538805802,\"gpDiscount\":174.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":2011000003,\"gpTypeCode\":1,\"orderId\":\"099991700100000062601\",\"productId\":31001538805802,\"promotionDescCn\":\"3件及以上享7.1折\",\"storeId\":9999},{\"cartItemId\":31001538805802,\"gpDiscount\":101.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":2011000004,\"gpTypeCode\":2,\"orderId\":\"099991700100000062601\",\"productId\":31001538805802,\"promotionDescCn\":\"2件减101元，4件及以上减211元\",\"storeId\":9999},{\"cartItemId\":31001538805802,\"gpDiscount\":114.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":2011000005,\"gpTypeCode\":3,\"orderId\":\"099991700100000062601\",\"productId\":31001538805802,\"promotionDescCn\":\"2件享8.1折，4件及以上享7.6折\",\"storeId\":9999},{\"cartItemId\":31001538805802,\"gpDiscount\":39.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":2011000006,\"gpTypeCode\":4,\"orderId\":\"099991700100000062601\",\"productId\":31001538805802,\"promotionDescCn\":\"2件仅需361元\",\"storeId\":9999},{\"cartItemId\":31001538805802,\"gpDiscount\":63.00,\"gpDiscountTimes\":3,\"gpGroupSeq\":1,\"gpOfferId\":2011000008,\"gpTypeCode\":6,\"orderId\":\"099991700100000062601\",\"productId\":31001538805802,\"promotionDescCn\":\"满105元立减21元\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":40.00,\"gpDiscountTimes\":2,\"gpGroupSeq\":1,\"gpOfferId\":201000001,\"gpTypeCode\":0,\"orderId\":\"099991700100000062601\",\"productId\":31001538805804,\"promotionDescCn\":\"满2件立减20元\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":0.00,\"gpDiscountTimes\":0,\"gpGroupSeq\":1,\"gpOfferId\":201000002,\"gpTypeCode\":0,\"orderId\":\"099991700100000062601\",\"productId\":31001538805804,\"promotionDescCn\":\"满1组减15元（9件为1组:需包含第1类任意4件，第2类任意5件）\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":237.60,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":201000003,\"gpTypeCode\":1,\"orderId\":\"099991700100000062601\",\"productId\":31001538805804,\"promotionDescCn\":\"3件及以上享7折\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":210.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":201000004,\"gpTypeCode\":2,\"orderId\":\"099991700100000062601\",\"productId\":31001538805804,\"promotionDescCn\":\"2件减100元，4件及以上减210元\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":198.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":201000005,\"gpTypeCode\":3,\"orderId\":\"099991700100000062601\",\"productId\":31001538805804,\"promotionDescCn\":\"2件享8折，4件及以上享7.5折\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":72.00,\"gpDiscountTimes\":2,\"gpGroupSeq\":1,\"gpOfferId\":201000006,\"gpTypeCode\":4,\"orderId\":\"099991700100000062601\",\"productId\":31001538805804,\"promotionDescCn\":\"2件仅需360元\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":0.00,\"gpDiscountTimes\":3,\"gpGroupSeq\":1,\"gpOfferId\":201000008,\"gpTypeCode\":6,\"orderId\":\"099991700100000062601\",\"productId\":31001538805804,\"promotionDescCn\":\"满105元立减20元\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":40.00,\"gpDiscountTimes\":2,\"gpGroupSeq\":1,\"gpOfferId\":201000001,\"gpTypeCode\":0,\"orderId\":\"099991700100000063841\",\"productId\":31001538805804,\"promotionDescCn\":\"满2件立减20元\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":0.00,\"gpDiscountTimes\":0,\"gpGroupSeq\":1,\"gpOfferId\":201000002,\"gpTypeCode\":0,\"orderId\":\"099991700100000063841\",\"productId\":31001538805804,\"promotionDescCn\":\"满1组减15元（9件为1组:需包含第1类任意4件，第2类任意5件）\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":237.60,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":201000003,\"gpTypeCode\":1,\"orderId\":\"099991700100000063841\",\"productId\":31001538805804,\"promotionDescCn\":\"3件及以上享7折\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":210.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":201000004,\"gpTypeCode\":2,\"orderId\":\"099991700100000063841\",\"productId\":31001538805804,\"promotionDescCn\":\"2件减100元，4件及以上减210元\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":198.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":201000005,\"gpTypeCode\":3,\"orderId\":\"099991700100000063841\",\"productId\":31001538805804,\"promotionDescCn\":\"2件享8折，4件及以上享7.5折\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":72.00,\"gpDiscountTimes\":2,\"gpGroupSeq\":1,\"gpOfferId\":201000006,\"gpTypeCode\":4,\"orderId\":\"099991700100000063841\",\"productId\":31001538805804,\"promotionDescCn\":\"2件仅需360元\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":0.00,\"gpDiscountTimes\":3,\"gpGroupSeq\":1,\"gpOfferId\":201000008,\"gpTypeCode\":6,\"orderId\":\"099991700100000063841\",\"productId\":31001538805804,\"promotionDescCn\":\"满105元立减20元\",\"storeId\":9999},{\"cartItemId\":31030008718001,\"gpDiscount\":0.00,\"gpGroupSeq\":1,\"gpOfferId\":12000005,\"gpTypeCode\":3,\"orderId\":\"099991700100000063841\",\"productId\":31030008718001,\"promotionDescCn\":\"\",\"storeId\":9999},{\"cartItemId\":31030008718001,\"gpDiscount\":21.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":2011000001,\"gpTypeCode\":0,\"orderId\":\"099991700100000063841\",\"productId\":31030008718001,\"promotionDescCn\":\"满2件立减21元\",\"storeId\":9999},{\"cartItemId\":31030008718001,\"gpDiscount\":174.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":2011000003,\"gpTypeCode\":1,\"orderId\":\"099991700100000063841\",\"productId\":31030008718001,\"promotionDescCn\":\"3件及以上享7.1折\",\"storeId\":9999},{\"cartItemId\":31030008718001,\"gpDiscount\":101.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":2011000004,\"gpTypeCode\":2,\"orderId\":\"099991700100000063841\",\"productId\":31030008718001,\"promotionDescCn\":\"2件减101元，4件及以上减211元\",\"storeId\":9999},{\"cartItemId\":31030008718001,\"gpDiscount\":39.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":2011000006,\"gpTypeCode\":4,\"orderId\":\"099991700100000063841\",\"productId\":31030008718001,\"promotionDescCn\":\"2件仅需361元\",\"storeId\":9999},{\"cartItemId\":31030008718001,\"gpDiscount\":63.00,\"gpDiscountTimes\":3,\"gpGroupSeq\":1,\"gpOfferId\":2011000008,\"gpTypeCode\":6,\"orderId\":\"099991700100000063841\",\"productId\":31030008718001,\"promotionDescCn\":\"满105元立减21元\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":40.00,\"gpDiscountTimes\":2,\"gpGroupSeq\":1,\"gpOfferId\":201000001,\"gpTypeCode\":0,\"orderId\":\"099991700100000064441\",\"productId\":31001538805804,\"promotionDescCn\":\"满2件立减20元\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":0.00,\"gpDiscountTimes\":0,\"gpGroupSeq\":1,\"gpOfferId\":201000002,\"gpTypeCode\":0,\"orderId\":\"099991700100000064441\",\"productId\":31001538805804,\"promotionDescCn\":\"满1组减15元（9件为1组:需包含第1类任意4件，第2类任意5件）\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":237.60,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":201000003,\"gpTypeCode\":1,\"orderId\":\"099991700100000064441\",\"productId\":31001538805804,\"promotionDescCn\":\"3件及以上享7折\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":210.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":201000004,\"gpTypeCode\":2,\"orderId\":\"099991700100000064441\",\"productId\":31001538805804,\"promotionDescCn\":\"2件减100元，4件及以上减210元\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":198.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":201000005,\"gpTypeCode\":3,\"orderId\":\"099991700100000064441\",\"productId\":31001538805804,\"promotionDescCn\":\"2件享8折，4件及以上享7.5折\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":72.00,\"gpDiscountTimes\":2,\"gpGroupSeq\":1,\"gpOfferId\":201000006,\"gpTypeCode\":4,\"orderId\":\"099991700100000064441\",\"productId\":31001538805804,\"promotionDescCn\":\"2件仅需360元\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":0.00,\"gpDiscountTimes\":3,\"gpGroupSeq\":1,\"gpOfferId\":201000008,\"gpTypeCode\":6,\"orderId\":\"099991700100000064441\",\"productId\":31001538805804,\"promotionDescCn\":\"满105元立减20元\",\"storeId\":9999},{\"cartItemId\":31691462121086,\"gpDiscount\":0.00,\"gpGroupSeq\":1,\"gpOfferId\":12000008,\"gpTypeCode\":6,\"orderId\":\"099991700100000064441\",\"productId\":31691462121086,\"promotionDescCn\":\"\",\"storeId\":9999},{\"cartItemId\":31691462121086,\"gpDiscount\":21.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":2011000001,\"gpTypeCode\":0,\"orderId\":\"099991700100000064441\",\"productId\":31691462121086,\"promotionDescCn\":\"满2件立减21元\",\"storeId\":9999},{\"cartItemId\":31691462121086,\"gpDiscount\":174.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":2011000003,\"gpTypeCode\":1,\"orderId\":\"099991700100000064441\",\"productId\":31691462121086,\"promotionDescCn\":\"3件及以上享7.1折\",\"storeId\":9999},{\"cartItemId\":31691462121086,\"gpDiscount\":101.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":2011000004,\"gpTypeCode\":2,\"orderId\":\"099991700100000064441\",\"productId\":31691462121086,\"promotionDescCn\":\"2件减101元，4件及以上减211元\",\"storeId\":9999},{\"cartItemId\":31691462121086,\"gpDiscount\":114.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":2011000005,\"gpTypeCode\":3,\"orderId\":\"099991700100000064441\",\"productId\":31691462121086,\"promotionDescCn\":\"2件享8.1折，4件及以上享7.6折\",\"storeId\":9999},{\"cartItemId\":31691462121086,\"gpDiscount\":39.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":2011000006,\"gpTypeCode\":4,\"orderId\":\"099991700100000064441\",\"productId\":31691462121086,\"promotionDescCn\":\"2件仅需361元\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":40.00,\"gpDiscountTimes\":2,\"gpGroupSeq\":1,\"gpOfferId\":201000001,\"gpTypeCode\":0,\"orderId\":\"099991700100000065241\",\"productId\":31001538805804,\"promotionDescCn\":\"满2件立减20元\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":0.00,\"gpDiscountTimes\":0,\"gpGroupSeq\":1,\"gpOfferId\":201000002,\"gpTypeCode\":0,\"orderId\":\"099991700100000065241\",\"productId\":31001538805804,\"promotionDescCn\":\"满1组减15元（9件为1组:需包含第1类任意4件，第2类任意5件）\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":237.60,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":201000003,\"gpTypeCode\":1,\"orderId\":\"099991700100000065241\",\"productId\":31001538805804,\"promotionDescCn\":\"3件及以上享7折\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":210.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":201000004,\"gpTypeCode\":2,\"orderId\":\"099991700100000065241\",\"productId\":31001538805804,\"promotionDescCn\":\"2件减100元，4件及以上减210元\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":198.00,\"gpDiscountTimes\":1,\"gpGroupSeq\":1,\"gpOfferId\":201000005,\"gpTypeCode\":3,\"orderId\":\"099991700100000065241\",\"productId\":31001538805804,\"promotionDescCn\":\"2件享8折，4件及以上享7.5折\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":72.00,\"gpDiscountTimes\":2,\"gpGroupSeq\":1,\"gpOfferId\":201000006,\"gpTypeCode\":4,\"orderId\":\"099991700100000065241\",\"productId\":31001538805804,\"promotionDescCn\":\"2件仅需360元\",\"storeId\":9999},{\"cartItemId\":31001538805804,\"gpDiscount\":0.00,\"gpDiscountTimes\":3,\"gpGroupSeq\":1,\"gpOfferId\":201000008,\"gpTypeCode\":6,\"orderId\":\"099991700100000065241\",\"productId\":31001538805804,\"promotionDescCn\":\"满105元立减20元\",\"storeId\":9999}]";
		List<OrderDiscount> orderDiscountList = JSON.parseArray(orderDiscountJson, OrderDiscount.class);
		// 录制动作
		EasyMock.expect(mockOrderLineMapper.selectOrderLineBosByOrderIds(EasyMock.anyObject(List.class))).andReturn(orderLines).anyTimes();
		EasyMock.expect(mockOrderDiscountMapper.selectOrderDiscountListByOrderIds(EasyMock.anyObject(List.class))).andReturn(orderDiscountList);
		EasyMock.expect(mockOrderEwsMapper.selectOrderEwsListByOrderIds(EasyMock.anyObject(List.class))).andReturn(null);
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(orderService, "orderLineMapper", mockOrderLineMapper, OrderLineMapper.class);
		ReflectionTestUtils.setField(orderService, "orderDiscountMapper", mockOrderDiscountMapper, OrderDiscountMapper.class);
		ReflectionTestUtils.setField(orderService, "orderEwsMapper", mockOrderEwsMapper, OrderEwsMapper.class);
		// 执行测试方法
		String orderboListJson = "[{\"amount\":29.35,\"cancelReason\":0,\"createdTime\":1499323185083,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000060661\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":1,\"storeId\":9999,\"timeout\":false,\"totalGpDiscount\":47.85,\"userId\":\"test\",\"version\":0,\"voucherDiscount\":0.00},{\"amount\":169.00,\"cancelReason\":0,\"createdTime\":1499323185197,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000061341\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":1,\"storeId\":9999,\"timeout\":false,\"totalGpDiscount\":1025.00,\"userId\":\"test\",\"version\":0,\"voucherDiscount\":0.00},{\"amount\":122.40,\"cancelReason\":0,\"createdTime\":1499323185320,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000062601\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":1,\"storeId\":9999,\"timeout\":false,\"totalGpDiscount\":1269.60,\"userId\":\"test\",\"version\":0,\"voucherDiscount\":0.00},{\"amount\":236.40,\"cancelReason\":0,\"createdTime\":1499323185437,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000063841\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":1,\"storeId\":9999,\"timeout\":false,\"totalGpDiscount\":1155.60,\"userId\":\"test\",\"version\":0,\"voucherDiscount\":0.00},{\"amount\":185.40,\"cancelReason\":0,\"createdTime\":1499323185553,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000064441\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":1,\"storeId\":9999,\"timeout\":false,\"totalGpDiscount\":1206.60,\"userId\":\"test\",\"version\":0,\"voucherDiscount\":0.00},{\"amount\":34.40,\"cancelReason\":0,\"createdTime\":1499323185663,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000065241\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":1,\"storeId\":9999,\"timeout\":false,\"totalGpDiscount\":757.60,\"userId\":\"test\",\"version\":0,\"voucherDiscount\":0.00}]";
		List<Order> orderList = JSON.parseArray(orderboListJson, Order.class);
		List<OrderBo> listbo = orderService.getOrderBoList(orderList);
		Assert.isTrue(listbo != null, "");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockOrderLineMapper);
		EasyMock.verify(mockOrderDiscountMapper);
		EasyMock.verify(mockOrderEwsMapper);
		mocksControl.reset();
	}

	@Test
	public void orderServiceUnPaidCancelTest() throws GlobalErrorInfoException {

		IMocksControl mocksControl = EasyMock.createControl();

		OrderMapper mockOrderMapper = mocksControl.createMock(OrderMapper.class);
		// 创建虚拟对象方法期望的返回值
		String orderJson = " {\"amount\":559.00,\"cancelReason\":0,\"createdTime\":1499323184437,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000050561\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":1,\"storeId\":9999,\"timeout\":false,\"totalGpDiscount\":38.00,\"userId\":\"test\",\"version\":1513,\"voucherDiscount\":0.00}";
		Order order = JSON.parseObject(orderJson, Order.class);
		// 录制动作
		EasyMock.expect(mockOrderMapper.updateOrderStatus(EasyMock.anyObject())).andReturn(1);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(orderStatusService, "orderMapper", mockOrderMapper, OrderMapper.class);
		// 执行测试方法
		orderService.unPaidCancel(order, 0);
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockOrderMapper);
		mocksControl.reset();
	}

	@Test
	public void orderServiceUpdateByPrimaryKeySelectiveTest() throws GlobalErrorInfoException {

		IMocksControl mocksControl = EasyMock.createControl();

		OrderMapper mockOrderMapper = mocksControl.createMock(OrderMapper.class);
		// 创建虚拟对象方法期望的返回值
		String orderJson = " {\"amount\":559.00,\"cancelReason\":0,\"createdTime\":1499323184437,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000050561\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":1,\"storeId\":9999,\"timeout\":false,\"totalGpDiscount\":38.00,\"userId\":\"test\",\"version\":1513,\"voucherDiscount\":0.00}";
		Order order = JSON.parseObject(orderJson, Order.class);
		// 录制动作
		EasyMock.expect(mockOrderMapper.updateByPrimaryKeySelective(EasyMock.anyObject())).andReturn(1);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(orderService, "orderMapper", mockOrderMapper, OrderMapper.class);
		// 执行测试方法
		orderService.updateByPrimaryKeySelective(order);
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockOrderMapper);
		mocksControl.reset();
	}

	@Test
	public void orderValidateServicePrepareValidateHandlerTest() throws GlobalErrorInfoException {

		IMocksControl mocksControl = EasyMock.createControl();

		ItemServiceClient mockItemServiceClient = mocksControl.createMock(ItemServiceClient.class);
		GpOfferServiceClient mockGpOfferServiceClient = mocksControl.createMock(GpOfferServiceClient.class);
		EwsPriceServiceClient mockEwsPriceServiceClient = mocksControl.createMock(EwsPriceServiceClient.class);
		StoreServiceClient mockStoreServiceClient = mocksControl.createMock(StoreServiceClient.class);

		// 创建虚拟对象方法期望的返回值
		String orderParam = "{\"amount\":77.4,\"dagId\":\"001\",\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceEmail\":\"\",\"invoiceTitle\":\"\",\"invoiceType\":0,\"mobilePhone\":\"18664322886\",\"orderLines\":[{\"barCode\":691953802233,\"cartItemId\":2,\"descOnline\":\"创维55电视\",\"ewsOptFlag\":1,\"ewsPrice\":{\"category\":\"小家电\",\"desc\":\"置换1年\",\"endPrice\":200,\"ewsAmount\":75,\"ewsBarcode\":40021582322,\"ewsQuantity\":3,\"extendedWarrantyPrice\":25,\"itemNumber\":21582322,\"startPrice\":0,\"timeSlot\":1},\"gpDiscount\":1.00,\"gpOffers\":[{\"gpDiscount\":1,\"gpGroupSeq\":1,\"gpOfferId\":1405567,\"gpTypeCode\":6,\"linkSaveId\":176,\"promotionDescCn\":\"满3元立减1元\",\"promotionTitleCn\":\"满3元减1元\"}],\"itemAmount\":0,\"itemType\":0,\"orderQuantity\":3,\"orderWeight\":0,\"priceWithTax\":1,\"productId\":3456118219370,\"thumbnailUrl\":\"\",\"unitPriceItemFlag\":0,\"upc\":0},{\"barCode\":40020645361,\"cartItemId\":100009,\"descOnline\":\"中号\",\"ewsOptFlag\":0,\"gpDiscount\":0.00,\"gpOffers\":[],\"itemAmount\":0,\"itemType\":0,\"orderQuantity\":2,\"orderWeight\":0,\"priceWithTax\":0.2,\"productId\":3834875682406,\"thumbnailUrl\":\"\",\"unitPriceItemFlag\":0,\"upc\":0}],\"orderType\":1,\"packagingFee\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"storeId\":1059,\"taxCode\":\"\",\"totalGpDiscount\":1,\"userId\":\"C708D20B1DF84826B954A736DA1EE2C4\"}";
		OrderParameter orderParameter = JSON.parseObject(orderParam, OrderParameter.class);

		String inventoryPriceJson = "[{\"clientStockStatus\":1,\"descOnline\":\"创维55电视.\",\"ewsFlag\":1,\"gpOfferIds\":[1405567],\"gpOffers\":[{\"gpDiscount\":0,\"gpGroupSeq\":1,\"gpOfferId\":1405567,\"gpTypeCode\":6,\"linkSaveId\":176,\"promotionDescCn\":\"满3元立减{1}元\",\"promotionTitleCn\":\"满3元减{1}元\"}],\"id\":27645821389563515523978442724,\"inStock\":1,\"inventory\":1,\"itemNumber\":20166656,\"magneticFlag\":0,\"posDescOnline\":\"创维\",\"priceWithTax\":1.0,\"priceWithoutTax\":1,\"productId\":3456118219370,\"reportCode\":0,\"restrictionQty\":300,\"stockStatus\":1,\"storeId\":1059,\"taxRate\":0.17,\"unitCost\":2651.33,\"upc\":691953802233,\"wasPrice\":0.0},{\"clientStockStatus\":1,\"descOnline\":\"中号购物袋.\",\"ewsFlag\":0,\"gpOfferIds\":[],\"gpOffers\":[],\"id\":27645797482583195996398384921,\"inStock\":1,\"inventory\":0,\"itemNumber\":20645361,\"magneticFlag\":0,\"posDescOnline\":\"塑料购物袋\",\"priceWithTax\":0.2,\"priceWithoutTax\":0.17,\"productId\":3834875682406,\"reportCode\":0,\"restrictionQty\":300,\"stockStatus\":1,\"storeId\":1059,\"taxRate\":0.17,\"unitCost\":0.1037,\"upc\":40020645361,\"wasPrice\":0.0}]";
		List<InventoryPriceVo> ipList = JSON.parseArray(inventoryPriceJson, InventoryPriceVo.class);

		String specialItemJson = "";
		List<SpecialItemVo> spcialItemList = null;

		String productDetailJson = "[{\"departmentWmInternal\":5,\"descOnline\":\"创维\",\"id\":27842072499734432259451466030,\"itemNumber\":20166656,\"itemType\":0,\"status\":0,\"upc\":691953802233},{\"departmentWmInternal\":82,\"descOnline\":\"中号购物袋\",\"id\":27842075727914645158623610242,\"itemNumber\":20645361,\"itemType\":0,\"status\":0,\"upc\":40020645361}]";
		List<ProductDetailVo> productList = JSON.parseArray(productDetailJson, ProductDetailVo.class);

		String gpOfferJson = "[{\"beginDate\":1509552000608,\"discountFactor\":1.0,\"discountTimes\":1,\"endDate\":1510675200608,\"gpOfferId\":1405567,\"gpTypeCode\":6,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":3.0,\"thresholdQty\":0}],\"id\":27842094027084766278499286066,\"promotionDesc\":\"满3元立减1元\",\"promotionDescCn\":\"满3元立减1元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满3元减1元\",\"status\":0}]";
		List<GpOfferVo> gpOfferList = JSON.parseArray(gpOfferJson, GpOfferVo.class);

		String ewsPriceJson = "[{\"category\":\"小家电\",\"desc\":\"置换1年\",\"endPrice\":200,\"ewsBarcode\":40021582322,\"extendedWarrantyPrice\":25.0,\"itemNumber\":21582322,\"startPrice\":0,\"timeSlot\":1},{\"category\":\"小家电\",\"desc\":\"置换1年\",\"endPrice\":400,\"ewsBarcode\":40021582323,\"extendedWarrantyPrice\":50.0,\"itemNumber\":21582323,\"startPrice\":200,\"timeSlot\":1},{\"category\":\"小家电\",\"desc\":\"置换1年\",\"endPrice\":800,\"ewsBarcode\":40021582324,\"extendedWarrantyPrice\":70.0,\"itemNumber\":21582324,\"startPrice\":400,\"timeSlot\":1},{\"category\":\"通用电器\",\"desc\":\"延保1年\",\"endPrice\":1500,\"ewsBarcode\":40021582325,\"extendedWarrantyPrice\":80.0,\"itemNumber\":21582325,\"startPrice\":800,\"timeSlot\":1},{\"category\":\"通用电器\",\"desc\":\"延保2年\",\"endPrice\":1500,\"ewsBarcode\":40021582326,\"extendedWarrantyPrice\":120.0,\"itemNumber\":21582326,\"startPrice\":800,\"timeSlot\":2},{\"category\":\"通用电器\",\"desc\":\"延保1年\",\"endPrice\":3000,\"ewsBarcode\":40021582327,\"extendedWarrantyPrice\":100.0,\"itemNumber\":21582327,\"startPrice\":1500,\"timeSlot\":1},{\"category\":\"通用电器\",\"desc\":\"延保2年\",\"endPrice\":3000,\"ewsBarcode\":40021582328,\"extendedWarrantyPrice\":150.0,\"itemNumber\":21582328,\"startPrice\":1500,\"timeSlot\":2},{\"category\":\"通用电器\",\"desc\":\"延保1年\",\"endPrice\":5000,\"ewsBarcode\":40021582329,\"extendedWarrantyPrice\":140.0,\"itemNumber\":21582329,\"startPrice\":3000,\"timeSlot\":1},{\"category\":\"通用电器\",\"desc\":\"延保2年\",\"endPrice\":5000,\"ewsBarcode\":40021582330,\"extendedWarrantyPrice\":210.0,\"itemNumber\":21582330,\"startPrice\":3000,\"timeSlot\":2},{\"category\":\"通用电器\",\"desc\":\"延保1年\",\"endPrice\":8000,\"ewsBarcode\":40021582331,\"extendedWarrantyPrice\":220.0,\"itemNumber\":21582331,\"startPrice\":5000,\"timeSlot\":1},{\"category\":\"通用电器\",\"desc\":\"延保2年\",\"endPrice\":8000,\"ewsBarcode\":40021582332,\"extendedWarrantyPrice\":330.0,\"itemNumber\":21582332,\"startPrice\":5000,\"timeSlot\":2},{\"category\":\"通用电器\",\"desc\":\"延保1年\",\"endPrice\":50000,\"ewsBarcode\":40021582333,\"extendedWarrantyPrice\":420.0,\"itemNumber\":21582333,\"startPrice\":8000,\"timeSlot\":1},{\"category\":\"通用电器\",\"desc\":\"延保2年\",\"endPrice\":50000,\"ewsBarcode\":40021582334,\"extendedWarrantyPrice\":630.0,\"itemNumber\":21582334,\"startPrice\":8000,\"timeSlot\":2}]";
		List<EwsPriceVo> ewsPriceVoList = JSON.parseArray(ewsPriceJson, EwsPriceVo.class);

		String shippingInventoryPriceJson = "{\"clientStockStatus\":1,\"descOnline\":\"百奇芒果饼干\",\"ewsFlag\":0,\"gpOfferIds\":[],\"gpOffers\":[],\"id\":27645811557448924236787038656,\"inStock\":1,\"inventory\":78,\"itemNumber\":20487906,\"magneticFlag\":0,\"posDescOnline\":\"进口百奇\",\"priceWithTax\":10.0,\"priceWithoutTax\":8.55,\"productId\":3022399929804,\"reportCode\":0,\"restrictionQty\":300,\"stockStatus\":1,\"storeId\":1059,\"taxRate\":0.17,\"unitCost\":6.8377,\"upc\":885101901022,\"wasPrice\":0.0}";
		InventoryPriceVo shippingInventoryPriceVo = JSON.parseObject(shippingInventoryPriceJson, InventoryPriceVo.class);
		// 录制动作
		StoreVo storeVO = new StoreVo();
		storeVO.setStoreId(1059);
		EasyMock.expect(mockItemServiceClient.selectInventoryPriceByStoreAndProductIds(EasyMock.anyInt(), EasyMock.anyObject(List.class))).andReturn(ipList);
		EasyMock.expect(mockItemServiceClient.findByUpcIn(EasyMock.anyObject(List.class))).andReturn(spcialItemList);
		EasyMock.expect(mockItemServiceClient.findByItemNumberIn(EasyMock.anyObject(List.class))).andReturn(productList);
		EasyMock.expect(mockGpOfferServiceClient.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gpOfferList);
		EasyMock.expect(mockEwsPriceServiceClient.getAllEwsPrice(EasyMock.anyObject())).andReturn(ewsPriceVoList);
		EasyMock.expect(mockStoreServiceClient.findByStoreId(EasyMock.anyInt())).andReturn(storeVO);
		// EasyMock.expect(mockItemServiceClient.findByStoreIdAndUpc(EasyMock.anyInt(),
		// EasyMock.anyLong())).andReturn(shippingInventoryPriceVo);
		EasyMock.expect(mockItemServiceClient.findByNoDeliveryItemUpcIn(EasyMock.anyObject(List.class))).andReturn(null);

		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段

		ReflectionTestUtils.setField(orderValidationService, "itemServiceClient", mockItemServiceClient, ItemServiceClient.class);
		ReflectionTestUtils.setField(orderValidationService, "gpOfferServiceClient", mockGpOfferServiceClient, GpOfferServiceClient.class);
		ReflectionTestUtils.setField(orderValidationService, "ewsPriceServiceClient", mockEwsPriceServiceClient, EwsPriceServiceClient.class);
		ReflectionTestUtils.setField(orderValidationService, "storeServiceClient", mockStoreServiceClient, StoreServiceClient.class);

		// 执行测试方法
		orderValidationService.prepareValidateHandler(orderParameter);
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockItemServiceClient);
		EasyMock.verify(mockGpOfferServiceClient);
		EasyMock.verify(mockEwsPriceServiceClient);
		mocksControl.reset();
	}

	@Test
	public void orderValidateServicePrepareEwsOrderLineListTest() throws GlobalErrorInfoException {

		IMocksControl mocksControl = EasyMock.createControl();

		ItemServiceClient mockItemServiceClient = mocksControl.createMock(ItemServiceClient.class);
		GpOfferServiceClient mockGpOfferServiceClient = mocksControl.createMock(GpOfferServiceClient.class);
		EwsPriceServiceClient mockEwsPriceServiceClient = mocksControl.createMock(EwsPriceServiceClient.class);

		// 创建虚拟对象方法期望的返回值
		String orderParam = "{\"amount\":77.4,\"dagId\":\"001\",\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceEmail\":\"\",\"invoiceTitle\":\"\",\"invoiceType\":0,\"mobilePhone\":\"18664322886\",\"orderLines\":[{\"barCode\":691953802233,\"cartItemId\":2,\"descOnline\":\"创维55电视\",\"ewsOptFlag\":1,\"ewsPrice\":{\"category\":\"小家电\",\"desc\":\"置换1年\",\"endPrice\":200,\"ewsAmount\":75,\"ewsBarcode\":40021582322,\"ewsQuantity\":3,\"extendedWarrantyPrice\":25,\"itemNumber\":21582322,\"startPrice\":0,\"timeSlot\":1},\"gpDiscount\":1.00,\"gpOffers\":[{\"gpDiscount\":1,\"gpGroupSeq\":1,\"gpOfferId\":1405567,\"gpTypeCode\":6,\"linkSaveId\":176,\"promotionDescCn\":\"满3元立减1元\",\"promotionTitleCn\":\"满3元减1元\"}],\"itemAmount\":0,\"itemType\":0,\"orderQuantity\":3,\"orderWeight\":0,\"priceWithTax\":1,\"productId\":3456118219370,\"thumbnailUrl\":\"\",\"unitPriceItemFlag\":0,\"upc\":0},{\"barCode\":40020645361,\"cartItemId\":100009,\"descOnline\":\"中号\",\"ewsOptFlag\":0,\"gpDiscount\":0.00,\"gpOffers\":[],\"itemAmount\":0,\"itemType\":0,\"orderQuantity\":2,\"orderWeight\":0,\"priceWithTax\":0.2,\"productId\":3834875682406,\"thumbnailUrl\":\"\",\"unitPriceItemFlag\":0,\"upc\":0}],\"orderType\":1,\"packagingFee\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"storeId\":1059,\"taxCode\":\"\",\"totalGpDiscount\":1,\"userId\":\"C708D20B1DF84826B954A736DA1EE2C4\"}";
		OrderParameter orderParameter = JSON.parseObject(orderParam, OrderParameter.class);

		String inventoryPriceJson = "[{\"clientStockStatus\":1,\"descOnline\":\"置换1年.\",\"ewsFlag\":0,\"gpOfferIds\":[],\"gpOffers\":[],\"id\":27645652583408497007883899678,\"inStock\":1,\"inventory\":0,\"itemNumber\":21582322,\"magneticFlag\":0,\"posDescOnline\":\"置换1年.\",\"priceWithTax\":25.0,\"priceWithoutTax\":21.37,\"productId\":3835041291238,\"reportCode\":0,\"restrictionQty\":300,\"stockStatus\":1,\"storeId\":1059,\"taxRate\":0.17,\"unitCost\":13.25,\"upc\":40021582322,\"wasPrice\":0.0}]";
		List<InventoryPriceVo> ipList = JSON.parseArray(inventoryPriceJson, InventoryPriceVo.class);

		String productDetailJson = "[{\"departmentWmInternal\":58,\"descOnline\":\"置换1年\",\"id\":27842077056080218465711583875,\"itemNumber\":21582322,\"itemType\":0,\"status\":0,\"upc\":40021582322}]";
		List<ProductDetailVo> productList = JSON.parseArray(productDetailJson, ProductDetailVo.class);

		// 录制动作
		StoreVo storeVO = new StoreVo();

		EasyMock.expect(mockItemServiceClient.findByStoreIdAndItemNumberIn(EasyMock.anyInt(), EasyMock.anyObject(List.class))).andReturn(ipList);
		EasyMock.expect(mockItemServiceClient.findByItemNumberIn(EasyMock.anyObject(List.class))).andReturn(productList);

		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段

		ReflectionTestUtils.setField(orderValidationService, "itemServiceClient", mockItemServiceClient, ItemServiceClient.class);

		// 执行测试方法
		orderValidationService.prepareEwsOrderLineList(orderParameter);
		Assert.isTrue(orderParameter.getOrderEwsLineList() != null, "");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockItemServiceClient);
		mocksControl.reset();
	}

}
