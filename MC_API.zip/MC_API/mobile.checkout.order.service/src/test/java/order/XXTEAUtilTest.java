package order;

import org.apache.commons.lang.StringUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.util.Assert;

import com.walmart.mobile.checkout.bo.order.OrderScanParameter;
import com.walmart.mobile.checkout.config.MainConfig;
import com.walmart.mobile.checkout.utils.crypto.XXTEAUtil;

/**
 * @author lliao2
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MainConfig.class })
@WebAppConfiguration

public class XXTEAUtilTest {

	@Test
	public void testXXTEAUtilTest() {
		OrderScanParameter orderScanParameter = new OrderScanParameter();
		orderScanParameter.setAppKey("123456789ABD1234kfmv34&$");
		orderScanParameter.setFormat("json");
		orderScanParameter.setMac("008139921539");
		orderScanParameter.setOrderId("11059170020000013299");
		orderScanParameter.setTimeStamp("2017-07-29 19:38:02");
		orderScanParameter.setVersion("1.0");
		StringBuilder sb = new StringBuilder();
		String signString = sb.append(orderScanParameter.getAppKey()).append(orderScanParameter.getVersion()).append(orderScanParameter.getFormat()).append(orderScanParameter.getTimeStamp())
				.append(orderScanParameter.getOrderId()).append(orderScanParameter.getMac()).toString();
		Assert.isTrue(StringUtils.equals("123456789ABD1234kfmv34&$1.0json2017-07-29 19:38:0211059170020000013299008139921539", signString), "");
		Assert.isTrue(signString.length() == 82, "");

		String s = XXTEAUtil.encryptIntToString(signString, "12345678ABCD@#$%");
		Assert.isTrue(
				"EDB4159BFC6AA75C7D88391F239F5128387C46D0A9888A2807DEBB9F87B793B434EA33A0408C2E760D11DCD6853763720D8E020AA610AD218B9F6DA3FB5AA1006EDEE8374BDC54CBCE95844B741648102F56CCE7".equals(s),
				"");
		Assert.isTrue(s.length() ==168,"");

	}

}
