package order;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.util.Assert;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.bo.order.OrderCreateResult;
import com.walmart.mobile.checkout.bo.order.OrderItemMap;
import com.walmart.mobile.checkout.bo.order.OrderLineParameter;
import com.walmart.mobile.checkout.bo.order.OrderParameter;
import com.walmart.mobile.checkout.dag.DagHost;
import com.walmart.mobile.checkout.dag.HostData;
import com.walmart.mobile.checkout.datasource.DynamicDataSource;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.rest.StoreServiceClient;
import com.walmart.mobile.checkout.rest.order.GpOfferServiceClient;
import com.walmart.mobile.checkout.rest.order.ItemServiceClient;
import com.walmart.mobile.checkout.rest.vo.GpCartItemVo;
import com.walmart.mobile.checkout.rest.vo.GpOfferVo;
import com.walmart.mobile.checkout.rest.vo.InventoryPriceVo;
import com.walmart.mobile.checkout.rest.vo.OfferVo;
import com.walmart.mobile.checkout.rest.vo.ProductDetailVo;
import com.walmart.mobile.checkout.service.OrderService;
import com.walmart.mobile.checkout.service.OrderValidationService;
import com.walmart.mobile.checkout.utils.ThreadLocalContextHolder;

/*@RunWith(SpringJUnit4ClassRunner.class)
 @ContextConfiguration(classes = { MainConfig.class })
 @WebAppConfiguration*/
public class CreateOrderTest {

	@Autowired
	ItemServiceClient itemServiceClient;

	@Autowired
	OrderValidationService orderValidationService;
	@Autowired
	GpOfferServiceClient gpOfferServiceClient;

	@Autowired
	private OrderService orderService;

	@Autowired
	private StoreServiceClient storeServiceClient;

	@Autowired
	@Qualifier("dynamicDataSource")
	public DynamicDataSource dynamicDataSource;

	@Value("${ddr.request.param}")
	private String ddrParam;

	@Value("${ddr.request.url}")
	private String ddrUrl;

	@Autowired
	private RestTemplate restTemplate;

	private void initDatasourceRouter() {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<>(ddrParam, headers);
		String result = restTemplate.postForObject(ddrUrl, entity, String.class);
		List<DagHost> dss = JSONObject.parseObject(result, HostData.class).getData();
		Map<Object, Object> dataSources = new HashMap<>(3);
		for (int i = 0; i < dss.size(); i++) {
			DagHost dh = dss.get(i);
			String key = dh.getDagId();
			// String dagId = dh.getDagId();
			dataSources.put(key, dh.getDataSource());
			if (i == 0) {
				dynamicDataSource.setDefaultTargetDataSource(dh.getDataSource());
			}
		}
		dynamicDataSource.setTargetDataSources(dataSources);
		dynamicDataSource.afterPropertiesSet();

	}

	@PostConstruct
	private void init() {
		initDatasourceRouter();

	}

	/**
	 * private static SimpleDateFormat sdf = new
	 * SimpleDateFormat("yyyy-MM-dd hh:ss:mm"); private static Date date = null;
	 * static { TimeZone gmtTime = TimeZone.getTimeZone("GMT"); try {
	 * sdf.setTimeZone(gmtTime); Calendar ca = Calendar.getInstance();
	 * ca.setTime(new Date()); ca.add(Calendar.DAY_OF_MONTH, 5); String ss =
	 * sdf.format(ca.getTime()); date = sdf.parse(ss); } catch (ParseException
	 * e) { e.printStackTrace(); } }
	 */

	List<String> orderIdList = new ArrayList<>();
	List<Integer> offerIdList = new ArrayList<>();
	Integer storeId7 = 7777;
	Integer storeId8 = 8888;
	Integer storeId9 = 9999;
	String mobilePhone = "13243858258";
	String username = "test user for order test";
	String password = "1qqqqq";
	String userId = null;

	private static final Logger LOG = LoggerFactory.getLogger(CreateOrderTest.class);

	// @Before
	public void setup() throws Exception {

		/** buildStore(); */
		updateGpofferStatus();
	}

	private void calcAmountAndGpDiscount(OrderParameter orderParameter, List<GpCartItemVo> items) {

		BigDecimal totalGpDiscount = (orderParameter.getTotalGpDiscount() == null ? BigDecimal.ZERO : orderParameter.getTotalGpDiscount()); // 整个订单的优惠

		List<OrderLineParameter> orderLines = orderParameter.getOrderLines();

		for (OrderLineParameter orderLine : orderLines) {
			BigDecimal gpDiscount = BigDecimal.ZERO;
			List<OfferVo> offers = orderLine.getGpOffers();
			if (CollectionUtils.isNotEmpty(offers)) {
				for (OfferVo offer : offers) {
					for (GpCartItemVo gpCartItem : items) {
						if (offer.getGpOfferId().equals(gpCartItem.getGpOfferId()) && orderLine.getCartItemId().equals(gpCartItem.getCartItemId())) {
							offer.setGpDiscount(gpCartItem.getClientDiscount());
							gpDiscount = gpDiscount.add(gpCartItem.getClientDiscount());
						}
					}
				}
				orderLine.setGpDiscount(gpDiscount);
				totalGpDiscount = totalGpDiscount.add(gpDiscount);
			}
		}

		orderParameter.setTotalGpDiscount(totalGpDiscount); // 设置整个订单的优惠

		// 计算总金额
		BigDecimal amount = (orderParameter.getAmount() == null ? BigDecimal.ZERO : orderParameter.getAmount());
		for (OrderLineParameter orderLine : orderLines) {
			if (orderLine.getItemType() == 1) {
				amount = amount.add(orderLine.getItemAmount());
			} else {
				amount = amount.add(orderLine.getPriceWithTax().multiply(new BigDecimal(orderLine.getOrderQuantity())));
			}
		}
		amount = amount.subtract(totalGpDiscount); // 减去优惠的金额
		amount = amount.add(orderParameter.getPackagingFee());
		amount = amount.add(orderParameter.getShippingFee());
		amount = amount.setScale(2, RoundingMode.DOWN);
		orderParameter.setAmount(amount); // 设置 orderParameter的金额
	}

	private void addOrderLineByProductId(long productId, int quantity, int storeId, OrderParameter orderParameter) {
		InventoryPriceVo invPrice = this.itemServiceClient.findByStoreIdAndProductId(storeId, productId);

		ProductDetailVo productDetail = itemServiceClient.findByItemNumber(productId);
		OrderLineParameter orderLine = new OrderLineParameter();
		orderLine.setDescOnline(productDetail.getDescOnline());
		orderLine.setPriceWithTax(new BigDecimal(invPrice.getPriceWithTax().toString()));
		orderLine.setOrderQuantity(quantity);
		orderLine.setCartItemId(productId);
		orderLine.setGpOffers(invPrice.getGpOffers());
		orderLine.setThumbnailUrl(productDetail.getThumbnailUrl());
		orderLine.setProductId(productId);

		List<OrderLineParameter> orderLines = orderParameter.getOrderLines() == null ? new ArrayList<OrderLineParameter>() : orderParameter.getOrderLines();
		orderLines.add(orderLine);
		orderParameter.setOrderLines(orderLines);
	}

	private void addbarCodeOrderLineByProductId(long productId, int quantity, int storeId, OrderParameter orderParameter, Long barCode, Long cartItemId, BigDecimal itemAmount) {
		InventoryPriceVo invPrice = this.itemServiceClient.findByStoreIdAndProductId(storeId, productId);

		ProductDetailVo productDetail = itemServiceClient.findByItemNumber(productId);
		OrderLineParameter orderLine = new OrderLineParameter();
		orderLine.setDescOnline(productDetail.getDescOnline());
		orderLine.setPriceWithTax(new BigDecimal(invPrice.getPriceWithTax().toString()));
		orderLine.setOrderQuantity(quantity);
		orderLine.setCartItemId(productId);
		orderLine.setGpOffers(invPrice.getGpOffers());
		orderLine.setThumbnailUrl(productDetail.getThumbnailUrl());
		orderLine.setProductId(productId);
		orderLine.setBarCode(barCode);
		orderLine.setItemType(1);
		orderLine.setCartItemId(cartItemId);
		orderLine.setItemAmount(itemAmount);

		List<OrderLineParameter> orderLines = orderParameter.getOrderLines() == null ? new ArrayList<OrderLineParameter>() : orderParameter.getOrderLines();
		orderLines.add(orderLine);
		orderParameter.setOrderLines(orderLines);
	}

	private OrderParameter getInitialCreateOrderParameter(int deliveryMethod, int storeId) {
		OrderParameter orderParameter = new OrderParameter();
		orderParameter.setDagId("001");
		orderParameter.setShortNameCn("香蜜湖店");
		orderParameter.setOrderType(1);
		orderParameter.setMobilePhone("13424323256");
		orderParameter.setTaxCode("123123123");
		// orderParameter.setDeliveryName("香蜜湖店"); // 自提时设置为门店名,配送时设置为用户名
		// orderParameter.setProvince("广东省");
		// orderParameter.setCity("深圳市");
		// orderParameter.setDistrict("福田区");
		// orderParameter.setAddress("广东省深圳市福田区俐");
		// orderParameter.setDeliveryPhone("香梅北路2001号");
		// orderParameter.setInvoiceType(0);
		// orderParameter.setInvoiceTitle("");
		// orderParameter.setDeliveryPhone("0755-83931252");
		// orderParameter.setShippingFee(new BigDecimal("0.00")); //
		// 188元以下18元,满188免运费
		// orderParameter.setPackagingFee(new BigDecimal("0.00"));
		// orderParameter.setDeliveryMethod(deliveryMethod);

		// orderParameter.setDeliveryDate(date);
		// orderParameter.setDeliveryPeriod(11001400);
		// orderParameter.setDeliveryPeriodDesc("11:00-14:00");
		// orderParameter.setLongitude(0.00);
		// orderParameter.setLatitude(0.00);
		// orderParameter.setVoucherDiscount(BigDecimal.ZERO);
		orderParameter.setStoreId(storeId);

		orderParameter.setUserId(userId);
		return orderParameter;
	}

	// @Test
	public void testCreateOrder() throws Exception {
		ThreadLocalContextHolder.put("dagId", "001");
		OrderParameter orderParameter = null;
		BigDecimal itemAmount = BigDecimal.ZERO;
		orderIdList = new ArrayList<>();
		List<GpCartItemVo> items = new ArrayList<GpCartItemVo>();

		// (商品下架)
		/*
		 * orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31000002600222L, 2, storeId9,
		 * orderParameter); items = new ArrayList<GpCartItemVo>(); items.add(new
		 * GpCartItemVo(31000002600222L, 2600222L, 2, new BigDecimal(38),
		 * 20845993, 1, new BigDecimal(0), 31000002600222L)); ProductDetailVo
		 * productDetail = itemServiceClient.findByItemNumber(31000002600222L);
		 * productDetail.setStatus(2);
		 * 
		 * if(productDetail.getDescOnline().contains(productDetail.getBrandName()
		 * )){
		 * productDetail.setDescOnline(productDetail.getDescOnline().replace(
		 * productDetail.getBrandName(), "").trim()); }
		 * 
		 * 
		 * itemServiceClient.productDetailSave(productDetail);
		 * 
		 * // orderParameter.setProductDetails(productDetails);
		 * createAndValidateOrder(orderParameter, items,
		 * OrderErrorInfoEnum.ITEM_NOTSOLD.getCode()); productDetail =
		 * itemServiceClient.findByItemNumber(31000002600222L);
		 * productDetail.setStatus(0);
		 * if(productDetail.getDescOnline().contains(
		 * productDetail.getBrandName())){
		 * productDetail.setDescOnline(productDetail
		 * .getDescOnline().replace(productDetail.getBrandName(), "").trim()); }
		 * itemServiceClient.productDetailSave(productDetail);
		 */

		// (库存不足)
		/*
		 * orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31000002600222L, 2, storeId9,
		 * orderParameter); items = new ArrayList<GpCartItemVo>(); items.add(new
		 * GpCartItemVo(31000002600222L, 2600222L, 2, new BigDecimal(38),
		 * 20845993, 1, new BigDecimal(0), 31000002600222L)); InventoryPriceVo
		 * inventoryPrice =
		 * itemServiceClient.findByStoreIdAndProductId(storeId9,
		 * 31000002600222L); inventoryPrice.setStockStatus(2);
		 * itemServiceClient.inventoryPriceSave(inventoryPrice);
		 * createAndValidateOrder(orderParameter, items,
		 * OrderErrorInfoEnum.INVENTORY_SHORTAGE.getCode()); inventoryPrice =
		 * itemServiceClient.findByStoreIdAndProductId(storeId9,
		 * 31000002600222L); inventoryPrice.setStockStatus(1);
		 * itemServiceClient.inventoryPriceSave(inventoryPrice);
		 * 
		 * // 8 (速购+到店自提+GP商品) orderParameter = null; items = null;
		 * orderParameter = getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31000002600222L, 2, storeId9,
		 * orderParameter); addOrderLineByProductId(31000002750720L, 2,
		 * storeId9, orderParameter); addOrderLineByProductId(31002980105401L,
		 * 2, storeId9, orderParameter); items = new ArrayList<GpCartItemVo>();
		 * items.add(new GpCartItemVo(31000002600222L, 2600222L, 2, new
		 * BigDecimal(38), 20845993, 1, new BigDecimal(0), 31000002600222L));
		 * items.add(new GpCartItemVo(31000002750720L, 2750720L, 2, new
		 * BigDecimal(88), 20845993, 1, new BigDecimal(0), 31000002750720L));
		 * items.add(new GpCartItemVo(31002980105401L, 2980105401L, 2, new
		 * BigDecimal(16.8), 20845798, 1, new BigDecimal(3.6).setScale(2,
		 * RoundingMode.HALF_UP), 31002980105401L));
		 * createAndValidateOrder(orderParameter, items);
		 * 
		 * // 14 购物车测试数据(速购+到店自提+Normal商品) orderParameter = null; items = null;
		 * orderParameter = getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31489191348111L, 2, storeId9,
		 * orderParameter); addOrderLineByProductId(31489191375038L, 2,
		 * storeId9, orderParameter); addOrderLineByProductId(31691616861655L,
		 * 2, storeId9, orderParameter); items = new ArrayList<GpCartItemVo>();
		 * createAndValidateOrder(orderParameter, items);
		 * 
		 * // 32 购物车测试数据(造数据[921]：速购+到店自提+Normal商品+GP商品+Master商品+修改商品价格)
		 * orderParameter = null; items = null; orderParameter =
		 * getInitialCreateOrderParameter(2, storeId9);
		 * addOrderLineByProductId(31489191348111L, 2, storeId9,
		 * orderParameter); addOrderLineByProductId(31489191375038L, 2,
		 * storeId9, orderParameter); addOrderLineByProductId(31691616861655L,
		 * 2, storeId9, orderParameter);
		 * addOrderLineByProductId(31000002600222L, 2, storeId9,
		 * orderParameter); addOrderLineByProductId(31000002750720L, 2,
		 * storeId9, orderParameter); addOrderLineByProductId(31002980105401L,
		 * 2, storeId9, orderParameter);
		 * addOrderLineByProductId(31695280100070L, 2, storeId9,
		 * orderParameter); inventoryPrice =
		 * itemServiceClient.findByStoreIdAndProductId(storeId9,
		 * 31695280100070L); Float price = inventoryPrice.getPriceWithTax();
		 * inventoryPrice.setPriceWithTax(140.65f);
		 * itemServiceClient.inventoryPriceSave(inventoryPrice); items = new
		 * ArrayList<GpCartItemVo>(); items.add(new
		 * GpCartItemVo(31000002600222L, 2600222L, 2, new BigDecimal(38),
		 * 20845993, 1, new BigDecimal(0), 31000002600222L)); items.add(new
		 * GpCartItemVo(31000002750720L, 2750720L, 2, new BigDecimal(88),
		 * 20845993, 1, new BigDecimal(0), 31000002750720L)); items.add(new
		 * GpCartItemVo(31002980105401L, 2980105401L, 2, new BigDecimal(16.8),
		 * 20845798, 1, new BigDecimal(3.6).setScale(2, RoundingMode.HALF_UP),
		 * 31002980105401L)); createAndValidateOrder(orderParameter, items,
		 * OrderErrorInfoEnum.ITEM_PRICE_CHANGE.getCode());
		 * inventoryPrice.setPriceWithTax(price);
		 * itemServiceClient.inventoryPriceSave(inventoryPrice);
		 * 
		 * // 34 购物车测试数据(造数据[922]：速购+到店自提+Normal商品+GP商品+Master商品+修改GP优惠)
		 * orderParameter = null; items = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31489191348111L, 2, storeId9,
		 * orderParameter); addOrderLineByProductId(31489191375038L, 2,
		 * storeId9, orderParameter); addOrderLineByProductId(31691616861655L,
		 * 2, storeId9, orderParameter);
		 * addOrderLineByProductId(31000002600222L, 2, storeId9,
		 * orderParameter); addOrderLineByProductId(31000002750720L, 2,
		 * storeId9, orderParameter); addOrderLineByProductId(31002980105401L,
		 * 2, storeId9, orderParameter);
		 * addOrderLineByProductId(31695280100070L, 2, storeId9,
		 * orderParameter); items = new ArrayList<GpCartItemVo>(); items.add(new
		 * GpCartItemVo(31000002600222L, 2600222L, 2, new BigDecimal(38),
		 * 20845993, 1, new BigDecimal(0), 31000002600222L)); items.add(new
		 * GpCartItemVo(31000002750720L, 2750720L, 2, new BigDecimal(88),
		 * 20845993, 1, new BigDecimal(0), 31000002750720L)); items.add(new
		 * GpCartItemVo(31002980105401L, 2980105401L, 2, new BigDecimal(16.8),
		 * 20845798, 1, new BigDecimal(15.6).setScale(2, RoundingMode.HALF_UP),
		 * 31002980105401L)); createAndValidateOrder(orderParameter, items,
		 * OrderErrorInfoEnum.DISCOUNT_NOT_MATCH.getCode());
		 * 
		 * // 36 购物车测试数据(造数据[923]：速购+到店自提+Normal商品+GP商品+Master商品+修改总价)
		 * orderParameter = null; items = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31489191348111L, 2, storeId9,
		 * orderParameter); addOrderLineByProductId(31489191375038L, 2,
		 * storeId9, orderParameter); addOrderLineByProductId(31691616861655L,
		 * 2, storeId9, orderParameter);
		 * addOrderLineByProductId(31000002600222L, 2, storeId9,
		 * orderParameter); addOrderLineByProductId(31000002750720L, 2,
		 * storeId9, orderParameter); addOrderLineByProductId(31002980105401L,
		 * 2, storeId9, orderParameter);
		 * addOrderLineByProductId(31695280100070L, 2, storeId9,
		 * orderParameter); items = new ArrayList<GpCartItemVo>(); items.add(new
		 * GpCartItemVo(31000002600222L, 2600222L, 2, new BigDecimal(38),
		 * 20845993, 1, new BigDecimal(0), 31000002600222L)); items.add(new
		 * GpCartItemVo(31000002750720L, 2750720L, 2, new BigDecimal(88),
		 * 20845993, 1, new BigDecimal(0), 31000002750720L)); items.add(new
		 * GpCartItemVo(31002980105401L, 2980105401L, 2, new BigDecimal(16.8),
		 * 20845798, 1, new BigDecimal(3.6).setScale(2, RoundingMode.HALF_UP),
		 * 31002980105401L)); changeAmountAndValidateOrder(orderParameter,
		 * items, OrderErrorInfoEnum.AMOUNT_NOT_MATCH.getCode());
		 * 
		 * // 38 购物车测试数据(造数据[950]：速购+到店自提+Normal商品+修改Gp种类) orderParameter =
		 * null; items = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31489191348111L, 2, storeId9,
		 * orderParameter); addOrderLineByProductId(31489191375038L, 2,
		 * storeId9, orderParameter); addOrderLineByProductId(31691616861655L,
		 * 2, storeId9, orderParameter);
		 * addOrderLineByProductId(31000002600222L, 2, storeId9,
		 * orderParameter); addOrderLineByProductId(31000002750720L, 2,
		 * storeId9, orderParameter); addOrderLineByProductId(31002980105401L,
		 * 2, storeId9, orderParameter);
		 * addOrderLineByProductId(31695280100070L, 2, storeId9,
		 * orderParameter); items = new ArrayList<GpCartItemVo>(); items.add(new
		 * GpCartItemVo(31000002600222L, 2600222L, 2, new BigDecimal(38),
		 * 20845993, 1, new BigDecimal(0), 31000002600222L)); items.add(new
		 * GpCartItemVo(31000002750720L, 2750720L, 2, new BigDecimal(88),
		 * 20845993, 1, new BigDecimal(0), 31000002750720L)); items.add(new
		 * GpCartItemVo(31002980105401L, 2980105401L, 2, new BigDecimal(16.8),
		 * 20845798, 1, new BigDecimal(3.6).setScale(2, RoundingMode.HALF_UP),
		 * 31002980105401L)); GpOfferVo gpOffer =
		 * gpOfferServiceClient.findByGpOfferIdAndStatus(20845993, 0);
		 * gpOffer.setStatus(1); gpOfferServiceClient.gpOfferSave(gpOffer);
		 * gpOffer = gpOfferServiceClient.findByGpOfferIdAndStatus(20845798, 0);
		 * gpOffer.setStatus(1); gpOfferServiceClient.gpOfferSave(gpOffer);
		 * 
		 * createAndValidateOrder(orderParameter, items,
		 * OrderErrorInfoEnum.GP_DATA_NOT_EXIST.getCode()); gpOffer =
		 * gpOfferServiceClient.findByGpOfferIdAndStatus(20845993, 1);
		 * gpOffer.setStatus(0); gpOfferServiceClient.gpOfferSave(gpOffer);
		 * gpOffer = gpOfferServiceClient.findByGpOfferIdAndStatus(20845798, 1);
		 * gpOffer.setStatus(0); gpOfferServiceClient.gpOfferSave(gpOffer);
		 * 
		 * // 40单GP测试：01类型0，满立减（数量），非组合2件 orderParameter = null; orderParameter
		 * = getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31690309617031L, 2, storeId9,
		 * orderParameter); items = new ArrayList<GpCartItemVo>(); items.add(new
		 * GpCartItemVo(31690309617031L, 690309617031L, 2, new BigDecimal(138),
		 * 201000001, 1, new BigDecimal(20), 31690309617031L));
		 * createAndValidateOrder(orderParameter, items);
		 * 
		 * // // ////////////////////////////////////////////////////// //
		 * 41单GP测试：02类型0，满立减（数量），组合0-1 orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31693245062325L, 3, storeId9,
		 * orderParameter); addOrderLineByProductId(31693245068769L, 5,
		 * storeId9, orderParameter); items = new ArrayList<GpCartItemVo>();
		 * items.add(new GpCartItemVo(31693245062325L, 693245062325L, 3, new
		 * BigDecimal(29.9), 201000002, 1, new BigDecimal(0), 31693245062325L));
		 * items.add(new GpCartItemVo(31693245068769L, 693245068769L, 5, new
		 * BigDecimal(9.9), 201000002, 1, new BigDecimal(0), 31693245068769L));
		 * createAndValidateOrder(orderParameter, items); // //
		 * ////////////////////////////////////////////////////// //
		 * 44单GP测试：05类型0，满立减（数量），组合1-1 orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31693245062325L, 4, storeId9,
		 * orderParameter); addOrderLineByProductId(31693245068769L, 5,
		 * storeId9, orderParameter); items = new ArrayList<GpCartItemVo>();
		 * items.add(new GpCartItemVo(31693245062325L, 693245062325L, 4, new
		 * BigDecimal(29.9), 201000002, 1, new BigDecimal(10.61).setScale(2,
		 * RoundingMode.HALF_UP), 31693245062325L)); items.add(new
		 * GpCartItemVo(31693245068769L, 693245068769L, 5, new BigDecimal(9.9),
		 * 201000002, 1, new BigDecimal(4.39).setScale(2, RoundingMode.HALF_UP),
		 * 31693245068769L)); createAndValidateOrder(orderParameter, items); //
		 * // ////////////////////////////////////////////////////// //
		 * 48单GP测试：09类型0，满立减（数量），组合2-2 orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31693245062325L, 8, storeId9,
		 * orderParameter); addOrderLineByProductId(31693245068769L, 10,
		 * storeId9, orderParameter); items = new ArrayList<GpCartItemVo>();
		 * items.add(new GpCartItemVo(31693245062325L, 693245062325L, 8, new
		 * BigDecimal(29.9), 201000002, 1, new BigDecimal(21.22).setScale(2,
		 * RoundingMode.HALF_UP), 31693245062325L)); items.add(new
		 * GpCartItemVo(31693245068769L, 693245068769L, 10, new BigDecimal(9.9),
		 * 201000002, 1, new BigDecimal(8.78).setScale(2, RoundingMode.HALF_UP),
		 * 31693245068769L)); createAndValidateOrder(orderParameter, items); //
		 * // ////////////////////////////////////////////////////// //
		 * 49单GP测试：10类型1，折扣，2件未满足 orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31694317124631L, 2, storeId9,
		 * orderParameter); items = new ArrayList<GpCartItemVo>(); items.add(new
		 * GpCartItemVo(31694317124631L, 694317124631L, 2, new BigDecimal(139),
		 * 201000003, 1, new BigDecimal(0), 31694317124631L));
		 * createAndValidateOrder(orderParameter, items); // //
		 * ////////////////////////////////////////////////////// //
		 * 50单GP测试：11类型1，折扣，3件满足 orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31694317124631L, 3, storeId9,
		 * orderParameter); items = new ArrayList<GpCartItemVo>(); items.add(new
		 * GpCartItemVo(31694317124631L, 694317124631L, 3, new BigDecimal(139),
		 * 201000003, 1, new BigDecimal(125.1).setScale(2,
		 * RoundingMode.HALF_UP), 31694317124631L));
		 * createAndValidateOrder(orderParameter, items); // //
		 * ////////////////////////////////////////////////////// //
		 * 51单GP测试：12类型1，折扣，4件超过 orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31694317124631L, 4, storeId9,
		 * orderParameter); items = new ArrayList<GpCartItemVo>(); items.add(new
		 * GpCartItemVo(31694317124631L, 694317124631L, 4, new BigDecimal(139),
		 * 201000003, 1, new BigDecimal(166.8).setScale(2,
		 * RoundingMode.HALF_UP), 31694317124631L));
		 * createAndValidateOrder(orderParameter, items); // //
		 * ////////////////////////////////////////////////////// //
		 * 52单GP测试：13类型2，阶梯满立减（数量），1件未满足 orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31691080621674L, 1, storeId9,
		 * orderParameter); items = new ArrayList<GpCartItemVo>(); items.add(new
		 * GpCartItemVo(31691080621674L, 691080621674L, 1, new BigDecimal(749),
		 * 201000004, 1, new BigDecimal(0), 31691080621674L));
		 * createAndValidateOrder(orderParameter, items); // //
		 * ////////////////////////////////////////////////////// //
		 * 54单GP测试：15类型2，阶梯满立减（数量），3件满足1阶 orderParameter = null; orderParameter
		 * = getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31691080621674L, 3, storeId9,
		 * orderParameter); items = new ArrayList<GpCartItemVo>(); items.add(new
		 * GpCartItemVo(31691080621674L, 691080621674L, 3, new BigDecimal(749),
		 * 201000004, 1, new BigDecimal(100), 31691080621674L));
		 * createAndValidateOrder(orderParameter, items); // //
		 * ////////////////////////////////////////////////////// //
		 * 56单GP测试：17类型2，阶梯满立减（数量），5件满足2阶 orderParameter = null; orderParameter
		 * = getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31691080621674L, 5, storeId9,
		 * orderParameter); items = new ArrayList<GpCartItemVo>(); items.add(new
		 * GpCartItemVo(31691080621674L, 691080621674L, 5, new BigDecimal(749),
		 * 201000004, 1, new BigDecimal(210), 31691080621674L));
		 * createAndValidateOrder(orderParameter, items);
		 */
		// // //////////////////////////////////////////////////////
		// 57单GP测试：18类型3，阶梯折扣，1件未满足
		/*
		 * orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31692138453064L, 1, storeId9,
		 * orderParameter); items = new ArrayList<GpCartItemVo>(); items.add(new
		 * GpCartItemVo(31692138453064L, 692138453064L, 1, new BigDecimal(269),
		 * 201000005, 1, new BigDecimal(0), 31692138453064L));
		 * createAndValidateOrder(orderParameter, items);
		 */
		// // //////////////////////////////////////////////////////
		// 59单GP测试：20类型3，阶梯折扣，3件满足1阶
		/*
		 * orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31692138453064L, 3, storeId9,
		 * orderParameter); items = new ArrayList<GpCartItemVo>(); items.add(new
		 * GpCartItemVo(31692138453064L, 692138453064L, 3, new BigDecimal(269),
		 * 201000005, 1, new BigDecimal(161.4).setScale(2,
		 * RoundingMode.HALF_UP), 31692138453064L));
		 * createAndValidateOrder(orderParameter, items);
		 */
		// // //////////////////////////////////////////////////////
		// 60单GP测试：21类型3，阶梯折扣，4件满足2阶
		/*
		 * orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31692138453064L, 4, storeId9,
		 * orderParameter); items = new ArrayList<GpCartItemVo>(); items.add(new
		 * GpCartItemVo(31692138453064L, 692138453064L, 4, new BigDecimal(269),
		 * 201000005, 1, new BigDecimal(269), 31692138453064L));
		 * createAndValidateOrder(orderParameter, items);
		 */
		// // //////////////////////////////////////////////////////
		// 62单GP测试：23类型4，固定价格促销，1件未满足
		/*
		 * orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31692138451361L, 1, storeId9,
		 * orderParameter); items = new ArrayList<GpCartItemVo>(); items.add(new
		 * GpCartItemVo(31692138451361L, 692138451361L, 1, new BigDecimal(199),
		 * 201000006, 1, new BigDecimal(0), 31692138451361L));
		 * createAndValidateOrder(orderParameter, items);
		 */
		// // //////////////////////////////////////////////////////
		// 64单GP测试：25类型4，固定价格促销，3件满足1次
		/*
		 * orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31692138451361L, 3, storeId9,
		 * orderParameter); items = new ArrayList<GpCartItemVo>(); items.add(new
		 * GpCartItemVo(31692138451361L, 692138451361L, 3, new BigDecimal(199),
		 * 201000006, 1, new BigDecimal(38), 31692138451361L));
		 * createAndValidateOrder(orderParameter, items);
		 */
		// // //////////////////////////////////////////////////////
		// 66单GP测试：27类型4，固定价格促销，5件满足2次
		/*
		 * orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31692138451361L, 5, storeId9,
		 * orderParameter); items = new ArrayList<GpCartItemVo>(); items.add(new
		 * GpCartItemVo(31692138451361L, 692138451361L, 5, new BigDecimal(199),
		 * 201000006, 1, new BigDecimal(76), 31692138451361L));
		 * createAndValidateOrder(orderParameter, items);
		 */
		// // //////////////////////////////////////////////////////
		// 68单GP测试：29类型6，满立减（金额），n-0.01
		/*
		 * orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31692880401122L, 3, storeId9,
		 * orderParameter); items = new ArrayList<GpCartItemVo>(); items.add(new
		 * GpCartItemVo(31692880401122L, 693245068112L, 3, new BigDecimal(3.33),
		 * 20647409, 1, new BigDecimal(0), 31692880401122L));
		 * createAndValidateOrder(orderParameter, items);
		 */
		// // //////////////////////////////////////////////////////
		// 69单GP测试：30类型6，满立减（金额），n
		/*
		 * orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31002610288451L, 1, storeId9,
		 * orderParameter); addOrderLineByProductId(31693245068112L, 3,
		 * storeId9, orderParameter); items = new ArrayList<GpCartItemVo>();
		 * items.add(new GpCartItemVo(31692880401122L, 693245068112L, 3, new
		 * BigDecimal(3.33), 201000007, 1, new BigDecimal(1), 31692880401122L));
		 * items.add(new GpCartItemVo(31002610288451L, 2610288451L, 1, new
		 * BigDecimal(0.01), 201000007, 1, new BigDecimal(0), 31002610288451L));
		 * createAndValidateOrder(orderParameter, items);
		 */
		// // //////////////////////////////////////////////////////
		// 71单GP测试：32类型6，满立减（金额），n+0.02
		/*
		 * orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31693245068486L, 3, storeId9,
		 * orderParameter); addOrderLineByProductId(31693245068112L, 3,
		 * storeId9, orderParameter); items = new ArrayList<GpCartItemVo>();
		 * items.add(new GpCartItemVo(31693245068486L, 693245068486L, 3, new
		 * BigDecimal(3.32), 201000007, 1, new BigDecimal(0.99).setScale(2,
		 * RoundingMode.HALF_UP), 31693245068486L)); items.add(new
		 * GpCartItemVo(31693245068112L, 693245068112L, 3, new BigDecimal(0.02),
		 * 201000007, 1, new BigDecimal(0.01).setScale(2, RoundingMode.HALF_UP),
		 * 31693245068112L)); createAndValidateOrder(orderParameter, items);
		 */
		// // //////////////////////////////////////////////////////
		// 73单GP测试：34类型6，满立减（金额），2n-0.01
		/*
		 * orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31692880401122L, 7, storeId9,
		 * orderParameter); addOrderLineByProductId(31695006840891L, 8,
		 * storeId9, orderParameter); items = new ArrayList<GpCartItemVo>();
		 * items.add(new GpCartItemVo(31692880401122L, 692880401122L, 7, new
		 * BigDecimal(3.33), 20647409, 1, new BigDecimal(0), 31692880401122L));
		 * items.add(new GpCartItemVo(31695006840891L, 695006840891L, 8, new
		 * BigDecimal(2.49), 201000007, 1, new BigDecimal(1), 31695006840891L));
		 * createAndValidateOrder(orderParameter, items);
		 */
		// // //////////////////////////////////////////////////////
		// 76单GP测试：37类型6，满立减（金额），2n+0.01
		/*
		 * orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31693245068486L, 6, storeId9,
		 * orderParameter); addOrderLineByProductId(31693245068112L, 5,
		 * storeId9, orderParameter); items = new ArrayList<GpCartItemVo>();
		 * items.add(new GpCartItemVo(31693245068486L, 693245068486L, 6, new
		 * BigDecimal(3.32), 201000007, 1, new BigDecimal(1.99).setScale(2,
		 * RoundingMode.HALF_UP), 31693245068486L)); items.add(new
		 * GpCartItemVo(31693245068112L, 693245068112L, 5, new BigDecimal(0.02),
		 * 201000007, 1, new BigDecimal(0.01).setScale(2, RoundingMode.HALF_UP),
		 * 31693245068112L)); createAndValidateOrder(orderParameter, items);
		 */
		// // //////////////////////////////////////////////////////
		// 77单GP测试：38一分钱分摊
		/*
		 * orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31692166980070L, 1, storeId9,
		 * orderParameter); addOrderLineByProductId(31694317128558L, 1,
		 * storeId9, orderParameter); addOrderLineByProductId(31692173020260L,
		 * 1, storeId9, orderParameter);
		 * addOrderLineByProductId(31692017792313L, 1, storeId9,
		 * orderParameter); addOrderLineByProductId(31000004078657L, 1,
		 * storeId9, orderParameter); addOrderLineByProductId(31690894628401L,
		 * 1, storeId9, orderParameter);
		 * addOrderLineByProductId(31692219340052L, 1, storeId9,
		 * orderParameter); items = new ArrayList<GpCartItemVo>(); items.add(new
		 * GpCartItemVo(31690894628401L, 690894628401L, 1, new BigDecimal(7.75),
		 * 20709073, 1, new BigDecimal(0), 31690894628401L)); items.add(new
		 * GpCartItemVo(31690894628401L, 690894628401L, 1, new BigDecimal(7.75),
		 * 20991646, 1, new BigDecimal(0), 31690894628401L)); items.add(new
		 * GpCartItemVo(31690894628401L, 690894628401L, 1, new BigDecimal(7.75),
		 * 201000008, 1, new BigDecimal(0), 31690894628401L)); items.add(new
		 * GpCartItemVo(31692166980070L, 692166980070L, 1, new BigDecimal(15),
		 * 201000008, 1, new BigDecimal(0), 31692166980070L)); items.add(new
		 * GpCartItemVo(31694317128558L, 694317128558L, 1, new BigDecimal(15),
		 * 201000008, 1, new BigDecimal(0), 31694317128558L)); items.add(new
		 * GpCartItemVo(31692173020260L, 692173020260L, 1, new BigDecimal(15),
		 * 201000008, 1, new BigDecimal(0), 31692173020260L)); items.add(new
		 * GpCartItemVo(31692017792313L, 692017792313L, 1, new BigDecimal(15),
		 * 201000008, 1, new BigDecimal(0), 31692017792313L)); items.add(new
		 * GpCartItemVo(31000004078657L, 4078657L, 1, new BigDecimal(15),
		 * 201000008, 1, new BigDecimal(0), 31000004078657L)); items.add(new
		 * GpCartItemVo(31692219340052L, 692219340052L, 1, new BigDecimal(15),
		 * 201000008, 1, new BigDecimal(0), 31692219340052L));
		 * createAndValidateOrder(orderParameter, items);
		 */
		// // //////////////////////////////////////////////////////
		// 80多GP商品下单(1个商品)
		/*
		 * orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31000002719289L, 10, storeId9,
		 * orderParameter); items = new ArrayList<GpCartItemVo>(); items.add(new
		 * GpCartItemVo(31000002719289L, 2719289L, 10, new BigDecimal(9.9),
		 * 2015, 1, new BigDecimal(33.66).setScale(2, RoundingMode.HALF_UP),
		 * 31000002719289L)); items.add(new GpCartItemVo(31000002719289L,
		 * 2719289L, 10, new BigDecimal(9.9), 20778009, 1, new BigDecimal(4),
		 * 31000002719289L)); createAndValidateOrder(orderParameter, items);
		 */
		// // //////////////////////////////////////////////////////
		// 94多GP商品下单(2个商品)
		/*
		 * orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31000008017718L, 8, storeId9,
		 * orderParameter); addOrderLineByProductId(31001410008550L, 6,
		 * storeId9, orderParameter); items = new ArrayList<GpCartItemVo>();
		 * items.add(new GpCartItemVo(31000008017718L, 8017718L, 8, new
		 * BigDecimal(4.3), 2015, 1, new BigDecimal(11.70).setScale(2,
		 * RoundingMode.HALF_UP), 31000008017718L)); items.add(new
		 * GpCartItemVo(31000008017718L, 8017718L, 8, new BigDecimal(4.3),
		 * 20778009, 1, new BigDecimal(4), 31000008017718L)); items.add(new
		 * GpCartItemVo(31000008017718L, 8017718L, 8, new BigDecimal(4.3),
		 * 20959184, 1, new BigDecimal(3.44).setScale(2, RoundingMode.HALF_UP),
		 * 31000008017718L)); items.add(new GpCartItemVo(31001410008550L,
		 * 1410008550L, 6, new BigDecimal(24), 20846231, 1, new BigDecimal(90),
		 * 31001410008550L)); items.add(new GpCartItemVo(31001410008550L,
		 * 1410008550L, 6, new BigDecimal(24), 20914521, 1, new BigDecimal(0),
		 * 31001410008550L)); createAndValidateOrder(orderParameter, items);
		 */
		// // //////////////////////////////////////////////////////
		// 105多GP商品下单(3个商品)
		/*
		 * orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31212399500000L, 8, storeId9,
		 * orderParameter); addOrderLineByProductId(31000008017718L, 4,
		 * storeId9, orderParameter); addOrderLineByProductId(31489102870594L,
		 * 4, storeId9, orderParameter); items = new ArrayList<GpCartItemVo>();
		 * items.add(new GpCartItemVo(31212399500000L, 212399500000L, 8, new
		 * BigDecimal(5), 2028, 1, new BigDecimal(16), 31212399500000L));
		 * items.add(new GpCartItemVo(31212399500000L, 212399500000L, 8, new
		 * BigDecimal(5), 20900049, 1, new BigDecimal(0), 31212399500000L));
		 * items.add(new GpCartItemVo(31212399500000L, 212399500000L, 8, new
		 * BigDecimal(5), 20900088, 1, new BigDecimal(12), 31212399500000L));
		 * items.add(new GpCartItemVo(31000008017718L, 8017718L, 4, new
		 * BigDecimal(4.3), 2015, 1, new BigDecimal(5.85).setScale(2,
		 * RoundingMode.HALF_UP), 31000008017718L)); items.add(new
		 * GpCartItemVo(31000008017718L, 8017718L, 4, new BigDecimal(4.3),
		 * 20778009, 1, new BigDecimal(4), 31000008017718L)); items.add(new
		 * GpCartItemVo(31000008017718L, 8017718L, 4, new BigDecimal(4.3),
		 * 20959184, 1, new BigDecimal(0), 31000008017718L)); items.add(new
		 * GpCartItemVo(31489102870594L, 489102870594L, 4, new BigDecimal(5),
		 * 20779530, 1, new BigDecimal(10), 31489102870594L)); items.add(new
		 * GpCartItemVo(31489102870594L, 489102870594L, 4, new BigDecimal(5),
		 * 20914954, 1, new BigDecimal(0), 31489102870594L)); items.add(new
		 * GpCartItemVo(31489102870594L, 489102870594L, 4, new BigDecimal(5),
		 * 2011000015, 1, new BigDecimal(0), 31489102870594L));
		 * createAndValidateOrder(orderParameter, items);
		 */
		// // //////////////////////////////////////////////////////
		// 108多GP商品下单(itemA满足)+(itemB1满足)
		/*
		 * orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31001538805804L, 3, storeId9,
		 * orderParameter); addOrderLineByProductId(31001538805802L, 3,
		 * storeId9, orderParameter); items = new ArrayList<GpCartItemVo>();
		 * items.add(new GpCartItemVo(31001538805804L, 1538805804L, 3, new
		 * BigDecimal(198), 201000001, 1, new BigDecimal(20), 31001538805804L));
		 * items.add(new GpCartItemVo(31001538805804L, 1538805804L, 3, new
		 * BigDecimal(198), 201000002, 1, new BigDecimal(0), 31001538805804L));
		 * items.add(new GpCartItemVo(31001538805804L, 1538805804L, 3, new
		 * BigDecimal(198), 201000003, 1, new BigDecimal(178.2).setScale(2,
		 * RoundingMode.HALF_UP), 31001538805804L)); items.add(new
		 * GpCartItemVo(31001538805804L, 1538805804L, 3, new BigDecimal(198),
		 * 201000004, 1, new BigDecimal(100), 31001538805804L)); items.add(new
		 * GpCartItemVo(31001538805804L, 1538805804L, 3, new BigDecimal(198),
		 * 201000005, 1, new BigDecimal(118.8).setScale(2,
		 * RoundingMode.HALF_UP), 31001538805804L)); items.add(new
		 * GpCartItemVo(31001538805804L, 1538805804L, 3, new BigDecimal(198),
		 * 201000006, 1, new BigDecimal(36), 31001538805804L)); items.add(new
		 * GpCartItemVo(31001538805804L, 1538805804L, 3, new BigDecimal(198),
		 * 201000008, 1, new BigDecimal(60), 31001538805804L)); items.add(new
		 * GpCartItemVo(31001538805802L, 1538805802L, 3, new BigDecimal(200),
		 * 2011000001, 1, new BigDecimal(21), 31001538805802L)); items.add(new
		 * GpCartItemVo(31001538805802L, 1538805802L, 3, new BigDecimal(200),
		 * 2011000003, 1, new BigDecimal(174), 31001538805802L)); items.add(new
		 * GpCartItemVo(31001538805802L, 1538805802L, 3, new BigDecimal(200),
		 * 2011000004, 1, new BigDecimal(101), 31001538805802L)); items.add(new
		 * GpCartItemVo(31001538805802L, 1538805802L, 3, new BigDecimal(200),
		 * 2011000005, 1, new BigDecimal(114), 31001538805802L)); items.add(new
		 * GpCartItemVo(31001538805802L, 1538805802L, 3, new BigDecimal(200),
		 * 2011000006, 1, new BigDecimal(39), 31001538805802L)); items.add(new
		 * GpCartItemVo(31001538805802L, 1538805802L, 3, new BigDecimal(200),
		 * 2011000008, 1, new BigDecimal(63), 31001538805802L));
		 * createAndValidateOrder(orderParameter, items);
		 */
		// // //////////////////////////////////////////////////////
		// 109多GP商品下单(itemA触发边界)+(itemB1满足)
		/*
		 * orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31001538805804L, 4, storeId9,
		 * orderParameter); addOrderLineByProductId(31001538805802L, 3,
		 * storeId9, orderParameter); items = new ArrayList<GpCartItemVo>();
		 * items.add(new GpCartItemVo(31001538805804L, 1538805804L, 4, new
		 * BigDecimal(198), 201000001, 1, new BigDecimal(40), 31001538805804L));
		 * items.add(new GpCartItemVo(31001538805804L, 1538805804L, 4, new
		 * BigDecimal(198), 201000002, 1, new BigDecimal(0), 31001538805804L));
		 * items.add(new GpCartItemVo(31001538805804L, 1538805804L, 4, new
		 * BigDecimal(198), 201000003, 1, new BigDecimal(237.6).setScale(2,
		 * RoundingMode.HALF_UP), 31001538805804L)); items.add(new
		 * GpCartItemVo(31001538805804L, 1538805804L, 4, new BigDecimal(198),
		 * 201000004, 1, new BigDecimal(210), 31001538805804L)); items.add(new
		 * GpCartItemVo(31001538805804L, 1538805804L, 4, new BigDecimal(198),
		 * 201000005, 1, new BigDecimal(198), 31001538805804L)); items.add(new
		 * GpCartItemVo(31001538805804L, 1538805804L, 4, new BigDecimal(198),
		 * 201000006, 1, new BigDecimal(72), 31001538805804L)); items.add(new
		 * GpCartItemVo(31001538805804L, 1538805804L, 4, new BigDecimal(198),
		 * 201000008, 1, new BigDecimal(0), 31001538805804L)); items.add(new
		 * GpCartItemVo(31001538805802L, 1538805802L, 3, new BigDecimal(200),
		 * 2011000001, 1, new BigDecimal(21), 31001538805802L)); items.add(new
		 * GpCartItemVo(31001538805802L, 1538805802L, 3, new BigDecimal(200),
		 * 2011000003, 1, new BigDecimal(174), 31001538805802L)); items.add(new
		 * GpCartItemVo(31001538805802L, 1538805802L, 3, new BigDecimal(200),
		 * 2011000004, 1, new BigDecimal(101), 31001538805802L)); items.add(new
		 * GpCartItemVo(31001538805802L, 1538805802L, 3, new BigDecimal(200),
		 * 2011000005, 1, new BigDecimal(114), 31001538805802L)); items.add(new
		 * GpCartItemVo(31001538805802L, 1538805802L, 3, new BigDecimal(200),
		 * 2011000006, 1, new BigDecimal(39), 31001538805802L)); items.add(new
		 * GpCartItemVo(31001538805802L, 1538805802L, 3, new BigDecimal(200),
		 * 2011000008, 1, new BigDecimal(63), 31001538805802L));
		 * createAndValidateOrder(orderParameter, items);
		 */
		// // //////////////////////////////////////////////////////
		// 110多GP商品下单(itemA触发边界)+(itemB2触发边界)
		/*
		 * orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31001538805804L, 4, storeId9,
		 * orderParameter); addOrderLineByProductId(31030008718001L, 3,
		 * storeId9, orderParameter); items = new ArrayList<GpCartItemVo>();
		 * items.add(new GpCartItemVo(31001538805804L, 1538805804L, 4, new
		 * BigDecimal(198), 201000001, 1, new BigDecimal(40), 31001538805804L));
		 * items.add(new GpCartItemVo(31001538805804L, 1538805804L, 4, new
		 * BigDecimal(198), 201000002, 1, new BigDecimal(0), 31001538805804L));
		 * items.add(new GpCartItemVo(31001538805804L, 1538805804L, 4, new
		 * BigDecimal(198), 201000003, 1, new BigDecimal(237.6).setScale(2,
		 * RoundingMode.HALF_UP), 31001538805804L)); items.add(new
		 * GpCartItemVo(31001538805804L, 1538805804L, 4, new BigDecimal(198),
		 * 201000004, 1, new BigDecimal(210), 31001538805804L)); items.add(new
		 * GpCartItemVo(31001538805804L, 1538805804L, 4, new BigDecimal(198),
		 * 201000005, 1, new BigDecimal(198), 31001538805804L)); items.add(new
		 * GpCartItemVo(31001538805804L, 1538805804L, 4, new BigDecimal(198),
		 * 201000006, 1, new BigDecimal(72), 31001538805804L)); items.add(new
		 * GpCartItemVo(31001538805804L, 1538805804L, 4, new BigDecimal(198),
		 * 201000008, 1, new BigDecimal(0), 31001538805804L)); items.add(new
		 * GpCartItemVo(31030008718001L, 30008718001L, 3, new BigDecimal(200),
		 * 2011000001, 1, new BigDecimal(21), 31030008718001L)); items.add(new
		 * GpCartItemVo(31030008718001L, 30008718001L, 3, new BigDecimal(200),
		 * 2011000003, 1, new BigDecimal(174), 31030008718001L)); items.add(new
		 * GpCartItemVo(31030008718001L, 30008718001L, 3, new BigDecimal(200),
		 * 2011000004, 1, new BigDecimal(101), 31030008718001L)); items.add(new
		 * GpCartItemVo(31030008718001L, 30008718001L, 3, new BigDecimal(200),
		 * 2011000005, 1, new BigDecimal(114), 31030008718001L)); items.add(new
		 * GpCartItemVo(31030008718001L, 30008718001L, 3, new BigDecimal(200),
		 * 2011000006, 1, new BigDecimal(39), 31030008718001L)); items.add(new
		 * GpCartItemVo(31030008718001L, 30008718001L, 3, new BigDecimal(200),
		 * 2011000008, 1, new BigDecimal(63), 31030008718001L));
		 * createAndValidateOrder(orderParameter, items);
		 */
		// // //////////////////////////////////////////////////////
		// 111多GP商品下单(itemA触发边界)+(itemB3触发边界)
		/*
		 * orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31001538805804L, 4, storeId9,
		 * orderParameter); addOrderLineByProductId(31691462121086L, 3,
		 * storeId9, orderParameter); items = new ArrayList<GpCartItemVo>();
		 * items.add(new GpCartItemVo(31001538805804L, 1538805804L, 4, new
		 * BigDecimal(198), 201000001, 1, new BigDecimal(40), 31001538805804L));
		 * items.add(new GpCartItemVo(31001538805804L, 1538805804L, 4, new
		 * BigDecimal(198), 201000002, 1, new BigDecimal(0), 31001538805804L));
		 * items.add(new GpCartItemVo(31001538805804L, 1538805804L, 4, new
		 * BigDecimal(198), 201000003, 1, new BigDecimal(237.6).setScale(2,
		 * RoundingMode.HALF_UP), 31001538805804L)); items.add(new
		 * GpCartItemVo(31001538805804L, 1538805804L, 4, new BigDecimal(198),
		 * 201000004, 1, new BigDecimal(210), 31001538805804L)); items.add(new
		 * GpCartItemVo(31001538805804L, 1538805804L, 4, new BigDecimal(198),
		 * 201000005, 1, new BigDecimal(198), 31001538805804L)); items.add(new
		 * GpCartItemVo(31001538805804L, 1538805804L, 4, new BigDecimal(198),
		 * 201000006, 1, new BigDecimal(72), 31001538805804L)); items.add(new
		 * GpCartItemVo(31001538805804L, 1538805804L, 4, new BigDecimal(198),
		 * 201000008, 1, new BigDecimal(0), 31001538805804L)); items.add(new
		 * GpCartItemVo(31691462121086L, 691462121086L, 3, new BigDecimal(200),
		 * 2011000001, 1, new BigDecimal(21), 31691462121086L)); items.add(new
		 * GpCartItemVo(31691462121086L, 691462121086L, 3, new BigDecimal(200),
		 * 2011000003, 1, new BigDecimal(174), 31691462121086L)); items.add(new
		 * GpCartItemVo(31691462121086L, 691462121086L, 3, new BigDecimal(200),
		 * 2011000004, 1, new BigDecimal(101), 31691462121086L)); items.add(new
		 * GpCartItemVo(31691462121086L, 691462121086L, 3, new BigDecimal(200),
		 * 2011000005, 1, new BigDecimal(114), 31691462121086L)); items.add(new
		 * GpCartItemVo(31691462121086L, 691462121086L, 3, new BigDecimal(200),
		 * 2011000006, 1, new BigDecimal(39), 31691462121086L)); items.add(new
		 * GpCartItemVo(31691462121086L, 691462121086L, 3, new BigDecimal(200),
		 * 2012000008, 1, new BigDecimal(0), 31691462121086L));
		 * createAndValidateOrder(orderParameter, items);
		 */
		// // //////////////////////////////////////////////////////
		// 112多GP商品下单(itemA触发边界)
		/*
		 * orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31001538805804L, 4, storeId9,
		 * orderParameter); items = new ArrayList<GpCartItemVo>(); items.add(new
		 * GpCartItemVo(31001538805804L, 1538805804L, 4, new BigDecimal(198),
		 * 201000001, 1, new BigDecimal(40), 31001538805804L)); items.add(new
		 * GpCartItemVo(31001538805804L, 1538805804L, 4, new BigDecimal(198),
		 * 201000002, 1, new BigDecimal(0), 31001538805804L)); items.add(new
		 * GpCartItemVo(31001538805804L, 1538805804L, 4, new BigDecimal(198),
		 * 201000003, 1, new BigDecimal(237.6).setScale(2,
		 * RoundingMode.HALF_UP), 31001538805804L)); items.add(new
		 * GpCartItemVo(31001538805804L, 1538805804L, 4, new BigDecimal(198),
		 * 201000004, 1, new BigDecimal(210), 31001538805804L)); items.add(new
		 * GpCartItemVo(31001538805804L, 1538805804L, 4, new BigDecimal(198),
		 * 201000005, 1, new BigDecimal(198), 31001538805804L)); items.add(new
		 * GpCartItemVo(31001538805804L, 1538805804L, 4, new BigDecimal(198),
		 * 201000006, 1, new BigDecimal(72), 31001538805804L)); items.add(new
		 * GpCartItemVo(31001538805804L, 1538805804L, 4, new BigDecimal(198),
		 * 201000008, 1, new BigDecimal(0), 31001538805804L));
		 * createAndValidateOrder(orderParameter, items);
		 */
		// // //////////////////////////////////////////////////////
		// 113 多GP异常测试(itemA满足)
		/*
		 * orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9);
		 * addOrderLineByProductId(31001538805804L, 3, storeId9,
		 * orderParameter); items = new ArrayList<GpCartItemVo>(); items.add(new
		 * GpCartItemVo(31001538805804L, 1538805804L, 3, new BigDecimal(198),
		 * 201000001, 1, new BigDecimal(20), 31001538805804L)); items.add(new
		 * GpCartItemVo(31001538805804L, 1538805804L, 3, new BigDecimal(198),
		 * 201000002, 1, new BigDecimal(0), 31001538805804L)); items.add(new
		 * GpCartItemVo(31001538805804L, 1538805804L, 3, new BigDecimal(198),
		 * 201000003, 1, new BigDecimal(178.2).setScale(2,
		 * RoundingMode.HALF_UP), 31001538805804L)); items.add(new
		 * GpCartItemVo(31001538805804L, 1538805804L, 3, new BigDecimal(198),
		 * 201000004, 1, new BigDecimal(100), 31001538805804L)); items.add(new
		 * GpCartItemVo(31001538805804L, 1538805804L, 3, new BigDecimal(198),
		 * 201000005, 1, new BigDecimal(118.8).setScale(2,
		 * RoundingMode.HALF_UP), 31001538805804L)); items.add(new
		 * GpCartItemVo(31001538805804L, 1538805804L, 3, new BigDecimal(198),
		 * 201000006, 1, new BigDecimal(36), 31001538805804L)); items.add(new
		 * GpCartItemVo(31001538805804L, 1538805804L, 3, new BigDecimal(198),
		 * 201000008, 1, new BigDecimal(60), 31001538805804L));
		 * createAndValidateOrder(orderParameter, items);
		 */

		// 称重商品 无gp
		/*
		 * orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9); itemAmount = new
		 * BigDecimal("21.3"); addbarCodeOrderLineByProductId(1212222300000L, 3,
		 * storeId9, orderParameter,212222302130L,0L,itemAmount); items = new
		 * ArrayList<GpCartItemVo>(); items.add(new GpCartItemVo(1212222300000L,
		 * 212222300000L, 3, new BigDecimal("12.1"), 0, 0, new BigDecimal(0),
		 * 0L)); createAndValidateOrder(orderParameter, items);
		 */
		// 称重商品与非称重商品混合

		/*
		 * orderParameter = null; orderParameter =
		 * getInitialCreateOrderParameter(1, storeId9); itemAmount = new
		 * BigDecimal("21.3"); addOrderLineByProductId(31000002600222L, 2,
		 * storeId9, orderParameter);
		 * addbarCodeOrderLineByProductId(1212222300000L, 3, storeId9,
		 * orderParameter,212222302130L,0L,itemAmount); items = new
		 * ArrayList<GpCartItemVo>(); items.add(new
		 * GpCartItemVo(31000002600222L, 2600222L, 2, new BigDecimal(38),
		 * 20845993, 1, new BigDecimal(0), 31000002600222L)); items.add(new
		 * GpCartItemVo(1212222300000L, 212222300000L, 3, new
		 * BigDecimal("12.1"), 0, 0, new BigDecimal(0), 0L));
		 * createAndValidateOrder(orderParameter, items);
		 */

		// 称重商品有gp

		orderParameter = null;
		orderParameter = getInitialCreateOrderParameter(1, storeId9);
		itemAmount = new BigDecimal("20.80");
		addbarCodeOrderLineByProductId(12122222000000L, 1, storeId9, orderParameter, 212222202080L, 0L, itemAmount);
		addbarCodeOrderLineByProductId(12122222000000L, 1, storeId9, orderParameter, 212222202080L, 1L, itemAmount);
		items = new ArrayList<GpCartItemVo>();
		items.add(new GpCartItemVo(12122222000000L, 212222200000L, 1, new BigDecimal("20.80"), 2011000020, 1, new BigDecimal("5.00"), 0L));
		items.add(new GpCartItemVo(12122222000000L, 212222200000L, 1, new BigDecimal("20.80"), 2011000020, 1, new BigDecimal("5.00"), 1L));
		createAndValidateOrder(orderParameter, items);

	}

	private void createAndValidateOrder(OrderParameter orderParameter, List<GpCartItemVo> items) throws GlobalErrorInfoException {

		calcAmountAndGpDiscount(orderParameter, items);
		final List<Long> productIds = orderParameter.buildProductIdList();
		orderParameter.setProductDetails(orderValidationService.getProductByProductIds(productIds));
		int storeId = orderParameter.getStoreId();

		OrderItemMap orderItemMap = orderValidationService.getInventoryPriceByProductIds(storeId, productIds);
		orderParameter.setInventoryPrices(orderItemMap.getInventoryPriceMap());
		orderParameter.setProductIdAndItemNumberMap(orderItemMap.getProductIdAndItemNumberMap());

		orderParameter.setGpOffers(orderValidationService.getGpOfferMap(orderParameter.getOrderLines()));
		orderParameter.setUserId("test");
		orderValidationService.checkOrderParameter(orderParameter);

		LOG.info("开始校验");
		orderValidationService.verify(orderParameter);
		LOG.info("orderparmater is:{}", JSON.toJSONString(orderParameter));
		LOG.info("校验end");
		OrderCreateResult createOrderResult = orderService.create(orderParameter);
		Assert.isTrue(createOrderResult.getOrderId() != null, "");
	}

	/*
	 * private void changeAmountAndValidateOrder(OrderParameter orderParameter,
	 * List<GpCartItemVo> items, String errorCode) {
	 * calcAmountAndGpDiscount(orderParameter, items);
	 * orderParameter.setAmount(orderParameter.getAmount().add(new
	 * BigDecimal("0.01"))); String code = ""; try { final List<Long> productIds
	 * = orderParameter.buildProductIdList();
	 * orderParameter.setProductDetails(orderValidationService
	 * .getProductByProductIds(productIds)); int storeId =
	 * orderParameter.getStoreId();
	 * 
	 * OrderItemMap orderItemMap =
	 * orderValidationService.getInventoryPriceByProductIds(storeId,
	 * productIds);
	 * orderParameter.setInventoryPrices(orderItemMap.getInventoryPriceMap());
	 * orderParameter
	 * .setProductIdAndItemNumberMap(orderItemMap.getProductIdAndItemNumberMap
	 * ());
	 * 
	 * 
	 * orderParameter.setGpOffers(orderValidationService.getGpOfferMap(
	 * orderParameter.getOrderLines())); orderParameter.setUserId("test");
	 * orderValidationService.checkOrderParameter(orderParameter);
	 * orderValidationService.verify(orderParameter);
	 * LOG.info("orderparmater is:{}", JSON.toJSONString(orderParameter)); }
	 * catch (GlobalErrorInfoException e) { code = e.getErrorInfo().getCode();
	 * LOG.info("code is:{}", code);
	 * Assert.isTrue(code.equals((String.valueOf(errorCode))), ""); } if
	 * (StringUtils.isEmpty(code)) { OrderCreateResult createOrderResult =
	 * orderService.create(orderParameter);
	 * Assert.isTrue(createOrderResult.getOrderId() != null, ""); }
	 * 
	 * }
	 */
	/*
	 * private void createAndValidateOrder(OrderParameter orderParameter,
	 * List<GpCartItemVo> items, String errorCode) {
	 * calcAmountAndGpDiscount(orderParameter, items); String code = ""; try {
	 * final List<Long> productIds = orderParameter.buildProductIdList();
	 * orderParameter
	 * .setProductDetails(orderValidationService.getProductByProductIds
	 * (productIds)); int storeId = orderParameter.getStoreId();
	 * 
	 * OrderItemMap orderItemMap =
	 * orderValidationService.getInventoryPriceByProductIds(storeId,
	 * productIds);
	 * orderParameter.setInventoryPrices(orderItemMap.getInventoryPriceMap());
	 * orderParameter
	 * .setProductIdAndItemNumberMap(orderItemMap.getProductIdAndItemNumberMap
	 * ());
	 * 
	 * orderParameter.setGpOffers(orderValidationService.getGpOfferMap(
	 * orderParameter.getOrderLines())); orderParameter.setUserId("test");
	 * orderValidationService.checkOrderParameter(orderParameter);
	 * orderValidationService.verify(orderParameter);
	 * LOG.info("orderparmater is:{}", JSON.toJSONString(orderParameter)); }
	 * catch (GlobalErrorInfoException e) { code = e.getErrorInfo().getCode();
	 * LOG.info("code is:{}", code);
	 * Assert.isTrue(code.equals((String.valueOf(errorCode))), "");
	 * 
	 * } if (StringUtils.isEmpty(code)) { OrderCreateResult createOrderResult =
	 * orderService.create(orderParameter);
	 * Assert.isTrue(createOrderResult.getOrderId() != null, "");
	 * 
	 * }
	 * 
	 * }
	 */

	private void updateGpofferStatus() {
		offerIdList = Arrays.asList(20899635, 20832981, 20899715, 20846231, 20846270, 20709073, 20899960, 20914521, 20671060, 20778009, 20914000, 20914283, 20900104, 20778007, 2015, 20779530,
				20900100, 20899807, 20899845, 20845798, 20914012, 20807753, 20845993, 201000003, 201000004, 201000005, 20991580, 201000006, 201000001, 2028, 20778830, 201000002, 201000007, 201000008,
				20846212, 20778829, 20778828, 20914185, 20900049, 2011000008, 20777895, 20900088, 2011000006, 2011000007, 20762874, 2011000004, 2011000005, 20899707, 2011000003, 2011000001, 20991849,
				2100000012, 20914954, 2100000015, 20846063, 2100000016, 20846140, 20647409, 20885758, 20914597, 20991646, 20959184, 20778019, 20778817, 2011000015, 2011000020);
		List<GpOfferVo> offerList = gpOfferServiceClient.findByGpOfferIdInAndStatus(offerIdList, 1);
		for (GpOfferVo gpOffer : offerList) {
			gpOffer.setStatus(0);
		}
		gpOfferServiceClient.gpOfferListsave(offerList);
	}

	/**
	 * private void buildStore() {
	 * 
	 * StoreVo store9 = storeServiceClient.findByStoreId(9999); if(store9 ==
	 * null){ StoreVo store1 = storeServiceClient.findByStoreId(1059);
	 * store1.setId(null); store1.setStoreId(storeId9);
	 * storeServiceClient.save(store1); }
	 * 
	 * StoreVo store8 = storeServiceClient.findByStoreId(8888); if(store8 ==
	 * null){ StoreVo store2 = storeServiceClient.findByStoreId(2179);
	 * store2.setId(null); store2.setStoreId(storeId8);
	 * storeServiceClient.save(store2); }
	 * 
	 * StoreVo store7 = storeServiceClient.findByStoreId(7777); if(store7 ==
	 * null){ StoreVo store3 = storeServiceClient.findByStoreId(3404);
	 * store3.setId(null); store3.setStoreId(storeId7);
	 * storeServiceClient.save(store3); } }
	 */

}
