package order;


import java.math.BigDecimal;

import org.easymock.EasyMock;
import org.easymock.IMocksControl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;

import com.alibaba.fastjson.JSON;
import com.walmart.mobile.checkout.config.MainConfig;
import com.walmart.mobile.checkout.domain.order.Order;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.mapper.OrderMapper;
import com.walmart.mobile.checkout.service.OrderService;
import com.walmart.mobile.checkout.service.OrderStatusService;
import com.walmart.mobile.checkout.statemachine.OrderEventTypeEnum;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MainConfig.class })
@WebAppConfiguration
public class OrderStatemachineMockTest {
	@Autowired
	private OrderService orderService;
	
	@Autowired
	OrderStatusService orderStatusService;


	@Test
	public void orderServiceUpdateOrderStatusByOrderIdTest() throws GlobalErrorInfoException {
		IMocksControl mocksControl = EasyMock.createControl();

		OrderMapper mockOrderMapper = mocksControl.createMock(OrderMapper.class);
		// 创建虚拟对象方法期望的返回值
		String orderJson = " {\"amount\":559.00,\"cancelReason\":0,\"createdTime\":1499323184437,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000066701\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":1,\"storeId\":9999,\"timeout\":false,\"totalGpDiscount\":38.00,\"userId\":\"test\",\"version\":1513,\"voucherDiscount\":0.00}";
		Order order = JSON.parseObject(orderJson, Order.class);
		// 录制动作
		EasyMock.expect(mockOrderMapper.selectByPrimaryKey("099991700100000066701")).andReturn(order);
		EasyMock.expect(mockOrderMapper.updateOrderStatusByOrderIdAndVersion(EasyMock.anyObject(),EasyMock.anyObject(),EasyMock.anyObject(),EasyMock.anyObject(),EasyMock.anyObject(),EasyMock.anyObject())).andReturn(1);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(orderStatusService, "orderMapper", mockOrderMapper, OrderMapper.class);
		// 执行测试方法
		orderStatusService.updateOrderStatusByOrderId("099991700100000066701", order.getVersion(),
				OrderEventTypeEnum.PAY.getCode(),new BigDecimal("0.0"), 2);
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockOrderMapper);
		mocksControl.reset();
	}
	
	@Test
	public void orderServiceUpdateOrderStatusTest() throws GlobalErrorInfoException {
		IMocksControl mocksControl = EasyMock.createControl();

		OrderMapper mockOrderMapper = mocksControl.createMock(OrderMapper.class);
		// 创建虚拟对象方法期望的返回值
		String orderJson = " {\"amount\":559.00,\"cancelReason\":0,\"createdTime\":1499323184437,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000066701\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":1,\"storeId\":9999,\"timeout\":false,\"totalGpDiscount\":38.00,\"userId\":\"test\",\"version\":1513,\"voucherDiscount\":0.00}";
		Order order = JSON.parseObject(orderJson, Order.class);
		// 录制动作
		EasyMock.expect(mockOrderMapper.updateOrderStatus(EasyMock.anyObject())).andReturn(1);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(orderStatusService, "orderMapper", mockOrderMapper, OrderMapper.class);
		// 执行测试方法
		orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.PAY.getCode());
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockOrderMapper);
		mocksControl.reset();
	}
	
	
	@Test
	public void orderServiceUpdateOrderStatusTimeOutTest() throws GlobalErrorInfoException {
		IMocksControl mocksControl = EasyMock.createControl();

		OrderMapper mockOrderMapper = mocksControl.createMock(OrderMapper.class);
		// 创建虚拟对象方法期望的返回值
		String orderJson = " {\"amount\":559.00,\"cancelReason\":0,\"createdTime\":1499323184437,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000066701\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":1,\"storeId\":9999,\"timeout\":false,\"totalGpDiscount\":38.00,\"userId\":\"test\",\"version\":1513,\"voucherDiscount\":0.00}";
		Order order = JSON.parseObject(orderJson, Order.class);
		// 录制动作
		EasyMock.expect(mockOrderMapper.updateOrderStatus(EasyMock.anyObject())).andReturn(1);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(orderStatusService, "orderMapper", mockOrderMapper, OrderMapper.class);
		// 执行测试方法
		orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.TIMEOUT.getCode());
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockOrderMapper);
		mocksControl.reset();
	}

	@Test
	public void orderServiceUpdateOrderStatusPayRollbackTest() throws GlobalErrorInfoException {
		IMocksControl mocksControl = EasyMock.createControl();

		OrderMapper mockOrderMapper = mocksControl.createMock(OrderMapper.class);
		// 创建虚拟对象方法期望的返回值
		String orderJson = " {\"amount\":559.00,\"cancelReason\":0,\"createdTime\":1499323184437,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000066701\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":1,\"storeId\":9999,\"timeout\":false,\"totalGpDiscount\":38.00,\"userId\":\"test\",\"version\":1513,\"voucherDiscount\":0.00}";
		Order order = JSON.parseObject(orderJson, Order.class);
		// 录制动作
		EasyMock.expect(mockOrderMapper.updateOrderStatus(EasyMock.anyObject())).andReturn(1);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(orderStatusService, "orderMapper", mockOrderMapper, OrderMapper.class);
		// 执行测试方法
		orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.PAYROLLBACK.getCode());
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockOrderMapper);
		mocksControl.reset();
	}

	@Test
	public void orderServiceUpdateOrderStatusScanTest() throws GlobalErrorInfoException {
		IMocksControl mocksControl = EasyMock.createControl();

		OrderMapper mockOrderMapper = mocksControl.createMock(OrderMapper.class);
		// 创建虚拟对象方法期望的返回值
		String orderJson = " {\"amount\":559.00,\"cancelReason\":0,\"createdTime\":1499323184437,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000066701\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":30,\"storeId\":9999,\"timeout\":false,\"totalGpDiscount\":38.00,\"userId\":\"test\",\"version\":1513,\"voucherDiscount\":0.00}";
		Order order = JSON.parseObject(orderJson, Order.class);
		// 录制动作
		EasyMock.expect(mockOrderMapper.updateOrderStatus(EasyMock.anyObject())).andReturn(1);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(orderStatusService, "orderMapper", mockOrderMapper, OrderMapper.class);
		// 执行测试方法
		orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.SCAN.getCode());
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockOrderMapper);
		mocksControl.reset();
	}

	@Test
	public void orderServiceUpdateOrderStatusUnpaidToUnpaidCancellTest() throws GlobalErrorInfoException {
		IMocksControl mocksControl = EasyMock.createControl();

		OrderMapper mockOrderMapper = mocksControl.createMock(OrderMapper.class);
		// 创建虚拟对象方法期望的返回值
		String orderJson = " {\"amount\":559.00,\"cancelReason\":0,\"createdTime\":1499323184437,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000066701\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":1,\"storeId\":9999,\"timeout\":false,\"totalGpDiscount\":38.00,\"userId\":\"test\",\"version\":1513,\"voucherDiscount\":0.00}";
		Order order = JSON.parseObject(orderJson, Order.class);
		// 录制动作
		EasyMock.expect(mockOrderMapper.updateOrderStatus(EasyMock.anyObject())).andReturn(1);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(orderStatusService, "orderMapper", mockOrderMapper, OrderMapper.class);
		// 执行测试方法
		orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.UNPAID_CANCELL.getCode());
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockOrderMapper);
		mocksControl.reset();
	}

	@Test
	public void orderServiceUpdateOrderStatusUnpaidcancelToPayrollbackTest() throws GlobalErrorInfoException {
		IMocksControl mocksControl = EasyMock.createControl();

		OrderMapper mockOrderMapper = mocksControl.createMock(OrderMapper.class);
		// 创建虚拟对象方法期望的返回值
		String orderJson = " {\"amount\":559.00,\"cancelReason\":0,\"createdTime\":1499323184437,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000066701\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":20,\"storeId\":9999,\"timeout\":false,\"totalGpDiscount\":38.00,\"userId\":\"test\",\"version\":1513,\"voucherDiscount\":0.00}";
		Order order = JSON.parseObject(orderJson, Order.class);
		// 录制动作
		EasyMock.expect(mockOrderMapper.updateOrderStatus(EasyMock.anyObject())).andReturn(1);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(orderStatusService, "orderMapper", mockOrderMapper, OrderMapper.class);
		// 执行测试方法
		orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.PAYROLLBACK.getCode());
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockOrderMapper);
		mocksControl.reset();
	}

	@Test
	public void orderServiceUpdateOrderStatusUnpaidcancelToPayTest() throws GlobalErrorInfoException {
		IMocksControl mocksControl = EasyMock.createControl();

		OrderMapper mockOrderMapper = mocksControl.createMock(OrderMapper.class);
		// 创建虚拟对象方法期望的返回值
		String orderJson = " {\"amount\":559.00,\"cancelReason\":0,\"createdTime\":1499323184437,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000066701\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":20,\"storeId\":9999,\"timeout\":false,\"totalGpDiscount\":38.00,\"userId\":\"test\",\"version\":1513,\"voucherDiscount\":0.00}";
		Order order = JSON.parseObject(orderJson, Order.class);
		// 录制动作
		EasyMock.expect(mockOrderMapper.updateOrderStatus(EasyMock.anyObject())).andReturn(1);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(orderStatusService, "orderMapper", mockOrderMapper, OrderMapper.class);
		// 执行测试方法
		orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.PAY.getCode());
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockOrderMapper);
		mocksControl.reset();
	}

	@Test
	public void orderServiceUpdateOrderStatusTimeOutToPayrollbackTest() throws GlobalErrorInfoException {
		IMocksControl mocksControl = EasyMock.createControl();

		OrderMapper mockOrderMapper = mocksControl.createMock(OrderMapper.class);
		// 创建虚拟对象方法期望的返回值
		String orderJson = " {\"amount\":559.00,\"cancelReason\":0,\"createdTime\":1499323184437,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000066701\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":10,\"storeId\":9999,\"timeout\":false,\"totalGpDiscount\":38.00,\"userId\":\"test\",\"version\":1513,\"voucherDiscount\":0.00}";
		Order order = JSON.parseObject(orderJson, Order.class);
		// 录制动作
		EasyMock.expect(mockOrderMapper.updateOrderStatus(EasyMock.anyObject())).andReturn(1);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(orderStatusService, "orderMapper", mockOrderMapper, OrderMapper.class);
		// 执行测试方法
		orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.PAYROLLBACK.getCode());
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockOrderMapper);
		mocksControl.reset();
	}

	@Test(expected = GlobalErrorInfoException.class)
	public void orderServiceUpdateOrderStatusUnpaidToScanTest() throws GlobalErrorInfoException {
		IMocksControl mocksControl = EasyMock.createControl();

		OrderMapper mockOrderMapper = mocksControl.createMock(OrderMapper.class);
		// 创建虚拟对象方法期望的返回值
		String orderJson = " {\"amount\":559.00,\"cancelReason\":0,\"createdTime\":1499323184437,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000066701\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":1,\"storeId\":9999,\"timeout\":false,\"totalGpDiscount\":38.00,\"userId\":\"test\",\"version\":1513,\"voucherDiscount\":0.00}";
		Order order = JSON.parseObject(orderJson, Order.class);
		// 录制动作
		EasyMock.expect(mockOrderMapper.updateOrderStatus(EasyMock.anyObject())).andReturn(1);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(orderStatusService, "orderMapper", mockOrderMapper, OrderMapper.class);
		// 执行测试方法
		orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.SCAN.getCode());
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockOrderMapper);
		mocksControl.reset();
	}

	@Test(expected = GlobalErrorInfoException.class)
	public void orderServiceUpdateOrderStatusPayingToScanTest() throws GlobalErrorInfoException {
		IMocksControl mocksControl = EasyMock.createControl();

		OrderMapper mockOrderMapper = mocksControl.createMock(OrderMapper.class);
		// 创建虚拟对象方法期望的返回值
		String orderJson = " {\"amount\":559.00,\"cancelReason\":0,\"createdTime\":1499323184437,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000066701\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":28,\"storeId\":9999,\"timeout\":false,\"totalGpDiscount\":38.00,\"userId\":\"test\",\"version\":1513,\"voucherDiscount\":0.00}";
		Order order = JSON.parseObject(orderJson, Order.class);
		// 录制动作
		EasyMock.expect(mockOrderMapper.updateOrderStatus(EasyMock.anyObject())).andReturn(1);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(orderStatusService, "orderMapper", mockOrderMapper, OrderMapper.class);
		// 执行测试方法
		orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.SCAN.getCode());
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockOrderMapper);
		mocksControl.reset();
	}

	@Test(expected = GlobalErrorInfoException.class)
	public void orderServiceUpdateOrderStatusUnpaidCancellToScanTest() throws GlobalErrorInfoException {
		IMocksControl mocksControl = EasyMock.createControl();

		OrderMapper mockOrderMapper = mocksControl.createMock(OrderMapper.class);
		// 创建虚拟对象方法期望的返回值
		String orderJson = " {\"amount\":559.00,\"cancelReason\":0,\"createdTime\":1499323184437,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000066701\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":20,\"storeId\":9999,\"timeout\":false,\"totalGpDiscount\":38.00,\"userId\":\"test\",\"version\":1513,\"voucherDiscount\":0.00}";
		Order order = JSON.parseObject(orderJson, Order.class);
		// 录制动作
		EasyMock.expect(mockOrderMapper.updateOrderStatus(EasyMock.anyObject())).andReturn(1);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(orderStatusService, "orderMapper", mockOrderMapper, OrderMapper.class);
		// 执行测试方法
		orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.SCAN.getCode());
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockOrderMapper);
		mocksControl.reset();
	}

	@Test(expected = GlobalErrorInfoException.class)
	public void orderServiceUpdateOrderStatusUnpaidCancelledToScanTest() throws GlobalErrorInfoException {
		IMocksControl mocksControl = EasyMock.createControl();

		OrderMapper mockOrderMapper = mocksControl.createMock(OrderMapper.class);
		// 创建虚拟对象方法期望的返回值
		String orderJson = " {\"amount\":559.00,\"cancelReason\":0,\"createdTime\":1499323184437,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000066701\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":25,\"storeId\":9999,\"timeout\":false,\"totalGpDiscount\":38.00,\"userId\":\"test\",\"version\":1513,\"voucherDiscount\":0.00}";
		Order order = JSON.parseObject(orderJson, Order.class);
		// 录制动作
		EasyMock.expect(mockOrderMapper.updateOrderStatus(EasyMock.anyObject())).andReturn(1);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(orderStatusService, "orderMapper", mockOrderMapper, OrderMapper.class);
		// 执行测试方法
		orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.SCAN.getCode());
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockOrderMapper);
		mocksControl.reset();
	}

	@Test(expected = GlobalErrorInfoException.class)
	public void orderServiceUpdateOrderStatusCompeletedToScanTest() throws GlobalErrorInfoException {
		IMocksControl mocksControl = EasyMock.createControl();

		OrderMapper mockOrderMapper = mocksControl.createMock(OrderMapper.class);
		// 创建虚拟对象方法期望的返回值
		String orderJson = " {\"amount\":559.00,\"cancelReason\":0,\"createdTime\":1499323184437,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"099991700100000066701\",\"packagingFee\":0,\"payType\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":80,\"storeId\":9999,\"timeout\":false,\"totalGpDiscount\":38.00,\"userId\":\"test\",\"version\":1513,\"voucherDiscount\":0.00}";
		Order order = JSON.parseObject(orderJson, Order.class);
		// 录制动作
		EasyMock.expect(mockOrderMapper.updateOrderStatus(EasyMock.anyObject())).andReturn(1);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(orderStatusService, "orderMapper", mockOrderMapper, OrderMapper.class);
		// 执行测试方法
		orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.SCAN.getCode());
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockOrderMapper);
		mocksControl.reset();
	}

}
