package order;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.util.Assert;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.constant.order.OrderStatus;
import com.walmart.mobile.checkout.dag.DagHost;
import com.walmart.mobile.checkout.dag.HostData;
import com.walmart.mobile.checkout.datasource.DynamicDataSource;
import com.walmart.mobile.checkout.domain.order.Order;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.service.OrderService;
import com.walmart.mobile.checkout.service.OrderStatusService;
import com.walmart.mobile.checkout.statemachine.OrderEventTypeEnum;
import com.walmart.mobile.checkout.utils.ThreadLocalContextHolder;

/*@RunWith(SpringJUnit4ClassRunner.class)
 @ContextConfiguration(classes = { MainConfig.class })
 @WebAppConfiguration*/
public class OrderStatemachineTest {

	@Autowired
	private OrderService orderService;

	@Autowired
	private OrderStatusService orderStatusService;

	@Autowired
	@Qualifier("dynamicDataSource")
	public DynamicDataSource dynamicDataSource;

	@Value("${ddr.request.param}")
	private String ddrParam;

	@Value("${ddr.request.url}")
	private String ddrUrl;

	@Autowired
	private RestTemplate restTemplate;


	private void initDatasourceRouter() {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<>(ddrParam, headers);
		String result = restTemplate.postForObject(ddrUrl, entity, String.class);
		List<DagHost> dss = JSONObject.parseObject(result, HostData.class).getData();
		Map<Object, Object> dataSources = new HashMap<>(3);
		for (int i = 0; i < dss.size(); i++) {
			DagHost dh = dss.get(i);
			String key = dh.getDagId();
			// dagId = dh.getDagId();
			dataSources.put(key, dh.getDataSource());
			if (i == 0) {
				dynamicDataSource.setDefaultTargetDataSource(dh.getDataSource());
			}
		}
		dynamicDataSource.setTargetDataSources(dataSources);
		dynamicDataSource.afterPropertiesSet();

	}

	@PostConstruct
	private void init() {
		initDatasourceRouter();
	}

	// @Test
	public void orderUpdateTest() throws Exception {
		ThreadLocalContextHolder.put("dagId", "001");

		Order order = orderService.getOrderByOrderId("099991700100000066701");
		order.setStatus(OrderStatus.UNPAID);
		orderService.updateByPrimaryKeySelective(order);
		order = orderService.getOrderByOrderId("099991700100000066701");
		Assert.isTrue(order.getStatus() == OrderStatus.UNPAID, "");

		orderStatusService.updateOrderStatusByOrderId("099991700100000066701", order.getVersion(),
				OrderEventTypeEnum.PAY.getCode(),new BigDecimal("0.0"), 2);
		order = orderService.getOrderByOrderId("099991700100000066701");

		Assert.isTrue(order.getStatus() == OrderStatus.PAYING, "");
		order.setStatus(OrderStatus.UNPAID);
		orderService.updateByPrimaryKeySelective(order);
		order = orderService.getOrderByOrderId("099991700100000066701");
		Assert.isTrue(order.getStatus() == OrderStatus.UNPAID, "");

		orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.PAY.getCode());
		order = orderService.getOrderByOrderId("099991700100000066701");
		Assert.isTrue(order.getStatus() == OrderStatus.PAYING, "");
		
		
		orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.TIMEOUT.getCode());
		order = orderService.getOrderByOrderId("099991700100000066701");
		Assert.isTrue(order.getStatus() == OrderStatus.TIMEOUT, "");
		
		order.setStatus(OrderStatus.UNPAID);
		orderService.updateByPrimaryKeySelective(order);
		order = orderService.getOrderByOrderId("099991700100000066701");
		Assert.isTrue(order.getStatus() == OrderStatus.UNPAID, "");
		
		orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.PAY.getCode());
		order = orderService.getOrderByOrderId("099991700100000066701");
		Assert.isTrue(order.getStatus() == OrderStatus.PAYING, "");
		
		orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.PAYROLLBACK.getCode());
		order = orderService.getOrderByOrderId("099991700100000066701");
		Assert.isTrue(order.getStatus() == OrderStatus.PAID, "");
		
		orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.SCAN.getCode());
		order = orderService.getOrderByOrderId("099991700100000066701");
		Assert.isTrue(order.getStatus() == OrderStatus.COMPLETE, "");
		
		order.setStatus(OrderStatus.UNPAID);
		orderService.updateByPrimaryKeySelective(order);
		order = orderService.getOrderByOrderId("099991700100000066701");
		Assert.isTrue(order.getStatus() == OrderStatus.UNPAID, "");
		
		orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.TIMEOUT.getCode());
		order = orderService.getOrderByOrderId("099991700100000066701");
		Assert.isTrue(order.getStatus() == OrderStatus.TIMEOUT, "");
		
		order.setStatus(OrderStatus.UNPAID);
		orderService.updateByPrimaryKeySelective(order);
		order = orderService.getOrderByOrderId("099991700100000066701");
		Assert.isTrue(order.getStatus() == OrderStatus.UNPAID, "");
		
		orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.PAYROLLBACK.getCode());
		order = orderService.getOrderByOrderId("099991700100000066701");
		Assert.isTrue(order.getStatus() == OrderStatus.PAID, "");
		
		order.setStatus(OrderStatus.UNPAID);
		orderService.updateByPrimaryKeySelective(order);
		order = orderService.getOrderByOrderId("099991700100000066701");
		Assert.isTrue(order.getStatus() == OrderStatus.UNPAID, "");
		
		orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.UNPAID_CANCELL.getCode());
		order = orderService.getOrderByOrderId("099991700100000066701");
		Assert.isTrue(order.getStatus() == OrderStatus.UNPAID_CANCELLED, "");
		
		orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.PAYROLLBACK.getCode());
		order = orderService.getOrderByOrderId("099991700100000066701");
		Assert.isTrue(order.getStatus() == OrderStatus.PAID, "");
		
		
		order.setStatus(OrderStatus.UNPAID_CANCELLED);
		orderService.updateByPrimaryKeySelective(order);
		order = orderService.getOrderByOrderId("099991700100000066701");
		Assert.isTrue(order.getStatus() == OrderStatus.UNPAID_CANCELLED, "");
		
		orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.PAY.getCode());
		order = orderService.getOrderByOrderId("099991700100000066701");
		Assert.isTrue(order.getStatus() == OrderStatus.PAYING, "");
		
		
		
		order.setStatus(OrderStatus.TIMEOUT);
		orderService.updateByPrimaryKeySelective(order);
		order = orderService.getOrderByOrderId("099991700100000066701");
		Assert.isTrue(order.getStatus() == OrderStatus.TIMEOUT, "");
		
		
		orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.PAYROLLBACK.getCode());
		order = orderService.getOrderByOrderId("099991700100000066701");
		Assert.isTrue(order.getStatus() == OrderStatus.PAID, "");
		
		
		order.setStatus(OrderStatus.UNPAID);
		orderService.updateByPrimaryKeySelective(order);
		order = orderService.getOrderByOrderId("099991700100000066701");
		Assert.isTrue(order.getStatus() == OrderStatus.UNPAID, "");
		
		try{
		orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.SCAN.getCode());
		}catch(GlobalErrorInfoException e){
			Assert.isTrue(("-212").equals( e.getErrorInfo().getCode()),"");
		}
		order = orderService.getOrderByOrderId("099991700100000066701");
		Assert.isTrue(order.getStatus() == OrderStatus.UNPAID, "");
		
		order.setStatus(OrderStatus.PAYING);
		orderService.updateByPrimaryKeySelective(order);
		order = orderService.getOrderByOrderId("099991700100000066701");
		Assert.isTrue(order.getStatus() == OrderStatus.PAYING, "");
		
		try{
			orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.SCAN.getCode());
			}catch(GlobalErrorInfoException e){
				Assert.isTrue(("-212").equals( e.getErrorInfo().getCode()),"");
		}
		order = orderService.getOrderByOrderId("099991700100000066701");
		Assert.isTrue(order.getStatus() == OrderStatus.PAYING, "");
		
		order.setStatus(OrderStatus.UNPAID_CANCELLED);
		orderService.updateByPrimaryKeySelective(order);
		order = orderService.getOrderByOrderId("099991700100000066701");
		Assert.isTrue(order.getStatus() == OrderStatus.UNPAID_CANCELLED, "");
		try{
			orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.SCAN.getCode());
			}catch(GlobalErrorInfoException e){
				Assert.isTrue(("-212").equals( e.getErrorInfo().getCode()),"");
		}
		order = orderService.getOrderByOrderId("099991700100000066701");
		Assert.isTrue(order.getStatus() == OrderStatus.UNPAID_CANCELLED, "");
		
		
		order.setStatus(OrderStatus.PAID_CANCELLED);
		orderService.updateByPrimaryKeySelective(order);
		order = orderService.getOrderByOrderId("099991700100000066701");
		Assert.isTrue(order.getStatus() == OrderStatus.PAID_CANCELLED, "");
		
		try{
			orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.SCAN.getCode());
			}catch(GlobalErrorInfoException e){
				Assert.isTrue(("-212").equals( e.getErrorInfo().getCode()),"");
		}
		order = orderService.getOrderByOrderId("099991700100000066701");
		Assert.isTrue(order.getStatus() == OrderStatus.PAID_CANCELLED, "");
		
		
		order.setStatus(OrderStatus.COMPLETE);
		orderService.updateByPrimaryKeySelective(order);
		order = orderService.getOrderByOrderId("099991700100000066701");
		Assert.isTrue(order.getStatus() == OrderStatus.COMPLETE, "");
		
		try{
			orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.SCAN.getCode());
			}catch(GlobalErrorInfoException e){
				Assert.isTrue(("-212").equals( e.getErrorInfo().getCode()),"");
		}
		order = orderService.getOrderByOrderId("099991700100000066701");
		Assert.isTrue(order.getStatus() == OrderStatus.COMPLETE, "");
		
		order.setStatus(OrderStatus.UNPAID);
		orderService.updateByPrimaryKeySelective(order);
		order = orderService.getOrderByOrderId("099991700100000066701");
		Assert.isTrue(order.getStatus() == OrderStatus.UNPAID, "");
		
	}

}
