package order;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.util.Assert;

import com.walmart.mobile.checkout.config.MainConfig;
import com.walmart.mobile.checkout.entity.GateMac;
import com.walmart.mobile.checkout.service.GateMacService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MainConfig.class })
@WebAppConfiguration
public class GateMacServiceTest {
	@Autowired
	GateMacService gateMacService;

	@Test
	public void gateMacServiceTest() {

		/*
		 * GateMac gatemac = gateMacService.findByMac("008139961511");
		 * Assert.isTrue(gatemac != null ,"");
		 */

		List<GateMac> list = gateMacService.findByStoreId(1059);
		Assert.isTrue(list != null, "");

	}

}
