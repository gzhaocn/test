package order;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.bo.order.OrderCreateResult;
import com.walmart.mobile.checkout.bo.order.OrderParameter;
import com.walmart.mobile.checkout.dag.DagHost;
import com.walmart.mobile.checkout.dag.HostData;
import com.walmart.mobile.checkout.datasource.DynamicDataSource;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.mapper.OrderLineMapper;
import com.walmart.mobile.checkout.rest.order.ItemServiceClient;
import com.walmart.mobile.checkout.service.OrderService;
import com.walmart.mobile.checkout.service.OrderStatusService;
import com.walmart.mobile.checkout.service.OrderValidationService;
import com.walmart.mobile.checkout.utils.ThreadLocalContextHolder;

/*@RunWith(SpringJUnit4ClassRunner.class)
 @ContextConfiguration(classes = { MainConfig.class })
 @WebAppConfiguration*/
public class OrderServiceTest {

	@Autowired
	private OrderService orderService;

	@Autowired
	private OrderValidationService orderValidationService;
	@Autowired
	private OrderLineMapper orderLineMapper;

	@Autowired
	private OrderStatusService orderStatusService;

	@Autowired
	@Qualifier("dynamicDataSource")
	public DynamicDataSource dynamicDataSource;

	@Value("${ddr.request.param}")
	private String ddrParam;

	@Value("${ddr.request.url}")
	private String ddrUrl;

	@Autowired
	ItemServiceClient itemServiceClient;

	@Autowired
	private RestTemplate restTemplate;

	private static final Logger LOG = LoggerFactory.getLogger(OrderServiceTest.class);

	private void initDatasourceRouter() {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<>(ddrParam, headers);
		String result = restTemplate.postForObject(ddrUrl, entity, String.class);
		List<DagHost> dss = JSONObject.parseObject(result, HostData.class).getData();
		Map<Object, Object> dataSources = new HashMap<>(3);
		for (int i = 0; i < dss.size(); i++) {
			DagHost dh = dss.get(i);
			String key = dh.getDagId();
			// dagId = dh.getDagId();
			dataSources.put(key, dh.getDataSource());
			if (i == 0) {
				dynamicDataSource.setDefaultTargetDataSource(dh.getDataSource());
			}
		}
		dynamicDataSource.setTargetDataSources(dataSources);
		dynamicDataSource.afterPropertiesSet();

	}

	// @PostConstruct
	private void init() {
		initDatasourceRouter();

	}

	// @Test
	/*
	 * @Transactional
	 * 
	 * @Rollback(true)
	 */
	// 事务自动回滚，默认是true。可以不写
	public void orderServiceCreateTest() throws GlobalErrorInfoException {
		ThreadLocalContextHolder.put("dagId", "001");
		String orderParamJson = "{\"amount\":77.4,\"dagId\":\"001\",\"deliveryMethod\":0,\"deliveryPeriod\":0,\"ewsPriceList\":[{\"category\":\"小家电\",\"desc\":\"置换1年\",\"endPrice\":200,\"ewsBarcode\":40021582322,\"extendedWarrantyPrice\":25.0,\"itemNumber\":21582322,\"startPrice\":0,\"timeSlot\":1},{\"category\":\"小家电\",\"desc\":\"置换1年\",\"endPrice\":400,\"ewsBarcode\":40021582323,\"extendedWarrantyPrice\":50.0,\"itemNumber\":21582323,\"startPrice\":200,\"timeSlot\":1},{\"category\":\"小家电\",\"desc\":\"置换1年\",\"endPrice\":800,\"ewsBarcode\":40021582324,\"extendedWarrantyPrice\":70.0,\"itemNumber\":21582324,\"startPrice\":400,\"timeSlot\":1},{\"category\":\"通用电器\",\"desc\":\"延保1年\",\"endPrice\":1500,\"ewsBarcode\":40021582325,\"extendedWarrantyPrice\":80.0,\"itemNumber\":21582325,\"startPrice\":800,\"timeSlot\":1},{\"category\":\"通用电器\",\"desc\":\"延保2年\",\"endPrice\":1500,\"ewsBarcode\":40021582326,\"extendedWarrantyPrice\":120.0,\"itemNumber\":21582326,\"startPrice\":800,\"timeSlot\":2},{\"category\":\"通用电器\",\"desc\":\"延保1年\",\"endPrice\":3000,\"ewsBarcode\":40021582327,\"extendedWarrantyPrice\":100.0,\"itemNumber\":21582327,\"startPrice\":1500,\"timeSlot\":1},{\"category\":\"通用电器\",\"desc\":\"延保2年\",\"endPrice\":3000,\"ewsBarcode\":40021582328,\"extendedWarrantyPrice\":150.0,\"itemNumber\":21582328,\"startPrice\":1500,\"timeSlot\":2},{\"category\":\"通用电器\",\"desc\":\"延保1年\",\"endPrice\":5000,\"ewsBarcode\":40021582329,\"extendedWarrantyPrice\":140.0,\"itemNumber\":21582329,\"startPrice\":3000,\"timeSlot\":1},{\"category\":\"通用电器\",\"desc\":\"延保2年\",\"endPrice\":5000,\"ewsBarcode\":40021582330,\"extendedWarrantyPrice\":210.0,\"itemNumber\":21582330,\"startPrice\":3000,\"timeSlot\":2},{\"category\":\"通用电器\",\"desc\":\"延保1年\",\"endPrice\":8000,\"ewsBarcode\":40021582331,\"extendedWarrantyPrice\":220.0,\"itemNumber\":21582331,\"startPrice\":5000,\"timeSlot\":1},{\"category\":\"通用电器\",\"desc\":\"延保2年\",\"endPrice\":8000,\"ewsBarcode\":40021582332,\"extendedWarrantyPrice\":330.0,\"itemNumber\":21582332,\"startPrice\":5000,\"timeSlot\":2},{\"category\":\"通用电器\",\"desc\":\"延保1年\",\"endPrice\":50000,\"ewsBarcode\":40021582333,\"extendedWarrantyPrice\":420.0,\"itemNumber\":21582333,\"startPrice\":8000,\"timeSlot\":1},{\"category\":\"通用电器\",\"desc\":\"延保2年\",\"endPrice\":50000,\"ewsBarcode\":40021582334,\"extendedWarrantyPrice\":630.0,\"itemNumber\":21582334,\"startPrice\":8000,\"timeSlot\":2}],\"gpOfferIdAndLinkSaveIdMap\":{1405567:176},\"gpOfferIdMinTimesMap\":{1405567:1},\"gpOffers\":{1405567:{\"beginDate\":1509552000608,\"discountFactor\":1.0,\"discountTimes\":1,\"endDate\":1510675200608,\"gpOfferId\":1405567,\"gpTypeCode\":6,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":3.0,\"thresholdQty\":0}],\"id\":27842094027084766278499286066,\"promotionDesc\":\"满3元立减1元\",\"promotionDescCn\":\"满3元立减1元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满3元减1元\",\"status\":0}},\"inventoryPrices\":{20166656:{\"clientStockStatus\":1,\"descOnline\":\"创维55电视.\",\"ewsFlag\":1,\"gpOfferIds\":[1405567],\"gpOffers\":[{\"gpDiscount\":0,\"gpGroupSeq\":1,\"gpOfferId\":1405567,\"gpTypeCode\":6,\"linkSaveId\":176,\"promotionDescCn\":\"满3元立减1元\",\"promotionTitleCn\":\"满3元减1元\"}],\"id\":27645821389563515523978442724,\"inStock\":1,\"inventory\":1,\"itemNumber\":20166656,\"magneticFlag\":0,\"posDescOnline\":\"创维\",\"priceWithTax\":1.0,\"priceWithoutTax\":1,\"productId\":3456118219370,\"reportCode\":0,\"restrictionQty\":300,\"stockStatus\":1,\"storeId\":1059,\"taxRate\":0.17,\"unitCost\":2651.33,\"upc\":691953802233,\"wasPrice\":0.0},20645361:{\"clientStockStatus\":1,\"descOnline\":\"中号购物袋.\",\"ewsFlag\":0,\"gpOfferIds\":[],\"gpOffers\":[],\"id\":27645797482583195996398384921,\"inStock\":1,\"inventory\":0,\"itemNumber\":20645361,\"magneticFlag\":0,\"posDescOnline\":\"塑料购物袋\",\"priceWithTax\":0.2,\"priceWithoutTax\":0.17,\"productId\":3834875682406,\"reportCode\":0,\"restrictionQty\":300,\"stockStatus\":1,\"storeId\":1059,\"taxRate\":0.17,\"unitCost\":0.1037,\"upc\":40020645361,\"wasPrice\":0.0}},\"invoiceEmail\":\"\",\"invoiceTitle\":\"\",\"invoiceType\":0,\"magneticFlag\":0,\"mobilePhone\":\"18664322886\",\"orderEwsLineList\":[{\"cartItemId\":2,\"department\":58,\"descOnline\":\"置换1年.\",\"gpDiscount\":0,\"itemNumber\":21582322,\"itemType\":0,\"orderQuantity\":3,\"posDescOnline\":\"置换1年.\",\"priceWithTax\":25.0,\"priceWithoutTax\":21.37,\"productId\":3835041291238,\"reportCode\":0,\"returnBy\":1516685992524,\"storeId\":1059,\"taxRate\":0.17,\"unitCost\":13.25,\"upc\":40021582322,\"wasPrice\":0.0}],\"orderLines\":[{\"barCode\":691953802233,\"cartItemId\":2,\"descOnline\":\"创维55电视\",\"ewsOptFlag\":1,\"ewsPrice\":{\"category\":\"小家电\",\"desc\":\"置换1年\",\"endPrice\":200,\"ewsAmount\":75,\"ewsBarcode\":40021582322,\"ewsQuantity\":3,\"extendedWarrantyPrice\":25,\"itemNumber\":21582322,\"startPrice\":0,\"timeSlot\":1},\"gpDiscount\":1.00,\"gpOffers\":[{\"gpDiscount\":1,\"gpGroupSeq\":1,\"gpOfferId\":1405567,\"gpTypeCode\":6,\"linkSaveId\":176,\"promotionDescCn\":\"满3元立减1元\",\"promotionTitleCn\":\"满3元减1元\"}],\"itemAmount\":0,\"itemType\":0,\"orderQuantity\":3,\"orderWeight\":0,\"priceWithTax\":1,\"productId\":3456118219370,\"thumbnailUrl\":\"\",\"unitPriceItemFlag\":0,\"upc\":0},{\"barCode\":40020645361,\"cartItemId\":100009,\"descOnline\":\"中号\",\"ewsOptFlag\":0,\"gpDiscount\":0.00,\"gpOffers\":[],\"itemAmount\":0,\"itemType\":0,\"orderQuantity\":2,\"orderWeight\":0,\"priceWithTax\":0.2,\"productId\":3834875682406,\"thumbnailUrl\":\"\",\"unitPriceItemFlag\":0,\"upc\":0}],\"orderType\":1,\"packagingFee\":0,\"productDetails\":{20166656:{\"departmentWmInternal\":5,\"descOnline\":\"创维.                  \",\"id\":27842072499734432259451466030,\"itemNumber\":20166656,\"itemType\":0,\"status\":0,\"upc\":691953802233},20645361:{\"departmentWmInternal\":82,\"descOnline\":\"中号购物袋.            \",\"id\":27842075727914645158623610242,\"itemNumber\":20645361,\"itemType\":0,\"status\":0,\"upc\":40020645361}},\"productIdAndItemNumberMap\":{3456118219370:20166656,3834875682406:20645361},\"productIds\":[3456118219370,3834875682406],\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"storeId\":1059,\"taxCode\":\"\",\"totalGpDiscount\":1,\"upcAndSpecialItemMap\":{},\"userId\":\"C708D20B1DF84826B954A736DA1EE2C4\"}";
		OrderParameter orderParameter = JSON.parseObject(orderParamJson, OrderParameter.class);
		OrderCreateResult createOrderResult = orderService.create(orderParameter);
		LOG.info("orderId is {}", createOrderResult.getOrderId());

	}
	/*
	 * @Test public void selectOrderTest() throws GlobalErrorInfoException {
	 * ThreadLocalContextHolder.put("dagId","001");
	 * 
	 * Order order = orderService.selectOrderByUserIdAndOrderId("test",
	 * "099991700100000033581"); Assert.isTrue(order != null, ""); OrderBo
	 * orderDetail = orderService.requestOrderDetailByUserIdAndOrderId("test",
	 * "099991700100000034761"); Assert.isTrue(orderDetail != null, "");
	 * 
	 * List<OrderBo> orderDetailList = orderService.getOrderListByPagination(0,
	 * 10, "test"); Assert.isTrue(orderDetailList != null, "");
	 * 
	 * orderService.selectOrderListbyUserIdAndstatusAndChangeStatus("test",
	 * OrderStatus.PAID,9999); String[] orderIdArray = {"099991700100000060661",
	 * "099991700100000061341", "099991700100000062601",
	 * "099991700100000063841", "099991700100000064441",
	 * "099991700100000065241"};
	 * 
	 * List<Order> orderBoLists =
	 * orderService.selectOrderListByUserIdAndOrderIds("test",
	 * Arrays.asList(orderIdArray)); Assert.isTrue(orderBoLists != null, "");
	 * 
	 * OrderBo orderBo = orderService.requestOrderDetailByOrder(order);
	 * Assert.isTrue(orderBo != null, "");
	 * 
	 * List<OrderBo> listbo= orderService.getOrderBoList(orderBoLists);
	 * Assert.isTrue(listbo != null, "");
	 * 
	 * Order order1 = orderService.selectOrderByUserIdAndOrderId("test",
	 * "099991700100000033581"); order1.setStatus(OrderStatus.PAID);
	 * orderService.updateByPrimaryKeySelective(order1); List<String> list =
	 * orderService.selectOrderListbyUserIdAndstatusAndChangeStatus("test",
	 * OrderStatus.PAID,9999); Assert.isTrue(list != null ,""); Order order2 =
	 * orderService.selectOrderByUserIdAndOrderId("test",
	 * "099991700100000033581"); order2.setStatus(OrderStatus.PAID);
	 * orderService.updateByPrimaryKeySelective(order2);
	 * 
	 * }
	 */

	/*
	 * @Test public void unPaidCancelTest() throws GlobalErrorInfoException {
	 * ThreadLocalContextHolder.put("dagId","001"); Order order =
	 * orderService.selectOrderByUserIdAndOrderId("test",
	 * "099991700100000050561"); order.setStatus(OrderStatus.UNPAID);
	 * orderService.updateByPrimaryKeySelective(order); order =
	 * orderService.getOrderByOrderId("099991700100000050561");
	 * Assert.isTrue(order.getStatus() == OrderStatus.UNPAID, "");
	 * 
	 * orderService.unPaidCancel(order, 0); order =
	 * orderService.selectOrderByUserIdAndOrderId("test",
	 * "099991700100000050561"); Assert.isTrue(order.getStatus() ==
	 * OrderStatus.UNPAID_CANCELLED, "");
	 * 
	 * order.setStatus(OrderStatus.UNPAID);
	 * orderService.updateByPrimaryKeySelective(order); order =
	 * orderService.getOrderByOrderId("099991700100000050561");
	 * Assert.isTrue(order.getStatus() == OrderStatus.UNPAID, "");
	 * 
	 * }
	 */

	/*
	 * @Test public void prepareValidateHandlerTest() throws
	 * GlobalErrorInfoException { ThreadLocalContextHolder.put("dagId", "001");
	 * String orderParam =
	 * "{\"amount\":77.4,\"dagId\":\"001\",\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceEmail\":\"\",\"invoiceTitle\":\"\",\"invoiceType\":0,\"mobilePhone\":\"18664322886\",\"orderLines\":[{\"barCode\":691953802233,\"cartItemId\":2,\"descOnline\":\"创维55电视\",\"ewsOptFlag\":1,\"ewsPrice\":{\"category\":\"小家电\",\"desc\":\"置换1年\",\"endPrice\":200,\"ewsAmount\":75,\"ewsBarcode\":40021582322,\"ewsQuantity\":3,\"extendedWarrantyPrice\":25,\"itemNumber\":21582322,\"startPrice\":0,\"timeSlot\":1},\"gpDiscount\":1.00,\"gpOffers\":[{\"gpDiscount\":1,\"gpGroupSeq\":1,\"gpOfferId\":1405567,\"gpTypeCode\":6,\"linkSaveId\":176,\"promotionDescCn\":\"满3元立减1元\",\"promotionTitleCn\":\"满3元减1元\"}],\"itemAmount\":0,\"itemType\":0,\"orderQuantity\":3,\"orderWeight\":0,\"priceWithTax\":1,\"productId\":3456118219370,\"thumbnailUrl\":\"\",\"unitPriceItemFlag\":0,\"upc\":0},{\"barCode\":40020645361,\"cartItemId\":100009,\"descOnline\":\"中号\",\"ewsOptFlag\":0,\"gpDiscount\":0.00,\"gpOffers\":[],\"itemAmount\":0,\"itemType\":0,\"orderQuantity\":2,\"orderWeight\":0,\"priceWithTax\":0.2,\"productId\":3834875682406,\"thumbnailUrl\":\"\",\"unitPriceItemFlag\":0,\"upc\":0}],\"orderType\":1,\"packagingFee\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"storeId\":1059,\"taxCode\":\"\",\"totalGpDiscount\":1,\"userId\":\"C708D20B1DF84826B954A736DA1EE2C4\"}"
	 * ; OrderParameter orderParameter = JSON.parseObject(orderParam,
	 * OrderParameter.class);
	 * orderValidationService.prepareValidateHandler(orderParameter);
	 * orderValidationService.verify(orderParameter);
	 * orderValidationService.prepareEwsOrderLineList(orderParameter);
	 * OrderCreateResult createOrderResult =
	 * orderService.create(orderParameter);
	 * 
	 * }
	 * 
	 * @Test public void prepareEwsOrderLineListTest() throws
	 * GlobalErrorInfoException { ThreadLocalContextHolder.put("dagId", "001");
	 * String orderParam =
	 * "{\"amount\":77.4,\"dagId\":\"001\",\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceEmail\":\"\",\"invoiceTitle\":\"\",\"invoiceType\":0,\"mobilePhone\":\"18664322886\",\"orderLines\":[{\"barCode\":691953802233,\"cartItemId\":2,\"descOnline\":\"创维55电视\",\"ewsOptFlag\":1,\"ewsPrice\":{\"category\":\"小家电\",\"desc\":\"置换1年\",\"endPrice\":200,\"ewsAmount\":75,\"ewsBarcode\":40021582322,\"ewsQuantity\":3,\"extendedWarrantyPrice\":25,\"itemNumber\":21582322,\"startPrice\":0,\"timeSlot\":1},\"gpDiscount\":1.00,\"gpOffers\":[{\"gpDiscount\":1,\"gpGroupSeq\":1,\"gpOfferId\":1405567,\"gpTypeCode\":6,\"linkSaveId\":176,\"promotionDescCn\":\"满3元立减1元\",\"promotionTitleCn\":\"满3元减1元\"}],\"itemAmount\":0,\"itemType\":0,\"orderQuantity\":3,\"orderWeight\":0,\"priceWithTax\":1,\"productId\":3456118219370,\"thumbnailUrl\":\"\",\"unitPriceItemFlag\":0,\"upc\":0},{\"barCode\":40020645361,\"cartItemId\":100009,\"descOnline\":\"中号\",\"ewsOptFlag\":0,\"gpDiscount\":0.00,\"gpOffers\":[],\"itemAmount\":0,\"itemType\":0,\"orderQuantity\":2,\"orderWeight\":0,\"priceWithTax\":0.2,\"productId\":3834875682406,\"thumbnailUrl\":\"\",\"unitPriceItemFlag\":0,\"upc\":0}],\"orderType\":1,\"packagingFee\":0,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"storeId\":1059,\"taxCode\":\"\",\"totalGpDiscount\":1,\"userId\":\"C708D20B1DF84826B954A736DA1EE2C4\"}"
	 * ; OrderParameter orderParameter = JSON.parseObject(orderParam,
	 * OrderParameter.class);
	 * orderValidationService.prepareEwsOrderLineList(orderParameter);
	 * 
	 * }
	 */

}
