package order;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.util.Assert;

import com.walmart.mobile.checkout.bo.order.OrderScanParameter;
import com.walmart.mobile.checkout.config.MainConfig;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.utils.crypto.SHA1Util;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MainConfig.class })
@WebAppConfiguration
public class SHA1UtilTest {

	@Test
	public void testSHA1UtilTest() throws GlobalErrorInfoException {
		OrderScanParameter orderScanParameter = new OrderScanParameter();
		orderScanParameter.setAppKey("123456789ABD1234kfmv34&$");
		orderScanParameter.setFormat("json");
		orderScanParameter.setMac("008139921539");
		orderScanParameter.setOrderId("21059170030000043729");
		orderScanParameter.setTimeStamp("2017-07-29 19:38:02");
		orderScanParameter.setVersion("1.0");
		StringBuilder sb = new StringBuilder();
		String signString = sb.append(orderScanParameter.getAppKey()).append(orderScanParameter.getVersion()).append(orderScanParameter.getFormat()).append(orderScanParameter.getTimeStamp())
				.append(orderScanParameter.getOrderId()).append(orderScanParameter.getMac()).toString();
		

		String s = SHA1Util.getSha1(signString);
		Assert.isTrue(
				"829ead79a4c2488f49e5e88314d8a66fb56828fa".equals(s),
				"");
		

	}

}
