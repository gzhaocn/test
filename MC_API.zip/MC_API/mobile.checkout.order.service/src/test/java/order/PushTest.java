package order;

import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.walmart.mobile.checkout.config.MainConfig;
import com.walmart.mobile.checkout.service.PushService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MainConfig.class })
@WebAppConfiguration
public class PushTest {
	@Autowired
	PushService pushService;

	private String json;

	@Before
	public void before() {
		json = readFile();
	}

	@Test
	public void testPushTest() {
		// for (int i = 0; i < 100; i++) {
		pushService.pushByMpns(json);
		// }
	}

	public String readFile() {
		String json = "";
		byte[] buffer = new byte[10240];
		InputStream stream = null;
		try {
			stream = this.getClass().getResourceAsStream("/push.json");
			final int actual = IOUtils.read(stream, buffer);
			json = new String(buffer, 0, actual);

		} catch (IOException e) {
			json = "gp offer  file is not found";
		} finally {
			IOUtils.closeQuietly(stream);
		}
		return json;
	}

}
