package com.walmart.mobile.checkout.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.walmart.mobile.checkout.domain.check.CheckHistory;
import com.walmart.mobile.checkout.mapper.CheckHistoryMapper;
import com.walmart.mobile.checkout.service.CheckHistoryService;
import com.walmart.mobile.checkout.service.IdService;

@Service("checkHistoryService")
public class CheckHistoryServiceImpl implements CheckHistoryService {
	@Autowired
	private IdService orderSerialNumberService;
	@Autowired
	CheckHistoryMapper checkHistoryMapper;

	@Override
	public void create(Integer storeId, String dagId, CheckHistory checkHistory) {
		String checkId = orderSerialNumberService.buildCheckHistoryId(storeId, dagId);
		checkHistory.setCheckId(checkId);
		checkHistoryMapper.insert(checkHistory);
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public void createBatch(Integer storeId, String dagId, List<CheckHistory> checkHistoryList) {
		for (CheckHistory checkHistory : checkHistoryList) {
			this.create(storeId, dagId, checkHistory);
		}
	}

	@Override
	public List<CheckHistory> selectCheckHistoryListByBatchNo(String batchNo) {
		return checkHistoryMapper.selectCheckHistoryListByBatchNo(batchNo);
	}

	@Override
	public CheckHistory selectCheckHistoryByUserIdAndOrderId(String userId, String orderId) {
		return checkHistoryMapper.selectCheckHistoryByUserIdAndOrderId(userId, orderId);
	}

}
