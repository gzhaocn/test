package com.walmart.mobile.checkout.entity;

import java.math.BigInteger;
import java.util.Date;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.walmart.mobile.checkout.entity.document.BaseDocument;

@Document(collection = "exit_rule")
public class ExitRule extends BaseDocument<BigInteger> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4463539566634124401L;

	@Indexed
	@Field("rule_type")
	private String ruleType;
	@Field("rule_value")
	private String ruleValue;

	@Field("update_time")
	private Date updateTime;

	@Field("create_time")
	private Date createTime;

	public String getRuleId() {
		return String.valueOf(this.getId());
	}

	public void setRuleId(BigInteger ruleId) {
		this.setId(ruleId);
	}

	@Override
	public int hashCode() {
		return this.getRuleValue() == null ? 0 : this.getRuleValue().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (!(obj instanceof ExitRule)) {
			return false;
		}
		ExitRule other = (ExitRule) obj;
		return this.getRuleValue().equals(other.getRuleValue());
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getRuleValue() {
		return ruleValue;
	}

	public void setRuleValue(String ruleValue) {
		this.ruleValue = ruleValue;
	}

	public String getRuleType() {
		return ruleType;
	}

	public void setRuleType(String ruleType) {
		this.ruleType = ruleType;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

}