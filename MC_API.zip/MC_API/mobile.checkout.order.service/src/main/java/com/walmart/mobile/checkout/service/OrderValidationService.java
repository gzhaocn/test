package com.walmart.mobile.checkout.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.walmart.mobile.checkout.bo.order.OrderBo;
import com.walmart.mobile.checkout.bo.order.OrderItemMap;
import com.walmart.mobile.checkout.bo.order.OrderLineParameter;
import com.walmart.mobile.checkout.bo.order.OrderParameter;
import com.walmart.mobile.checkout.bo.order.OrderScanParameter;
import com.walmart.mobile.checkout.domain.order.Order;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.rest.vo.GpOfferVo;
import com.walmart.mobile.checkout.rest.vo.ProductDetailVo;

public interface OrderValidationService {
	/**
	 * check 订单参数
	 * 
	 * @param orderParam
	 * @throws GlobalErrorInfoException
	 */
	public void checkOrderParameter(OrderParameter orderParam) throws GlobalErrorInfoException;

	/**
	 * 组装订单数据
	 * 
	 * @param orderParam
	 * @throws GlobalErrorInfoException
	 */
	public void prepareValidateHandler(OrderParameter orderParam) throws GlobalErrorInfoException;

	/**
	 * 组装延保数据
	 * 
	 * @param orderParam
	 * @throws GlobalErrorInfoException
	 */
	public void prepareEwsOrderLineList(OrderParameter orderParam) throws GlobalErrorInfoException;

	/**
	 * 组装运费商品信息
	 * 
	 * @param orderParameter
	 * @throws GlobalErrorInfoException
	 */
	public void prepareShippingFeeItem(OrderParameter orderParameter) throws GlobalErrorInfoException;

	/**
	 * 订单校验
	 * 
	 * @param orderParam
	 * @throws GlobalErrorInfoException
	 */
	public void verify(OrderParameter orderParam) throws GlobalErrorInfoException;

	/**
	 * 组装productDetail数据
	 * 
	 * @param productIds
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	public Map<Long, ProductDetailVo> getProductByProductIds(List<Long> productIds) throws GlobalErrorInfoException;

	/**
	 * 组装inventoryPrice数据
	 * 
	 * @param storeId
	 * @param productIds
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	public OrderItemMap getInventoryPriceByProductIds(int storeId, List<Long> productIds) throws GlobalErrorInfoException;

	/**
	 * 组装gp数据
	 * 
	 * @param orderLineParameters
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	public Map<Integer, GpOfferVo> getGpOfferMap(List<OrderLineParameter> orderLineParameters) throws GlobalErrorInfoException;

	/**
	 * 闸机数据加密校验
	 * 
	 * @param orderScanParameter
	 * @throws GlobalErrorInfoException
	 */
	public void validateCheckSum(OrderScanParameter orderScanParameter) throws GlobalErrorInfoException;

	/**
	 * 检查订单
	 * 
	 * @param order
	 * @throws GlobalErrorInfoException
	 */
	public void checkOrder(Order order) throws GlobalErrorInfoException;

	/**
	 * 已支付订单，定时查询接口加密校验
	 * 
	 * @param queryOrderRecordSalesParamter
	 * @throws GlobalErrorInfoException
	 */
	public void queryOrderInformationCheckSum(String appKey, String version, String format, Date timeStamp, String orderId, String sign) throws GlobalErrorInfoException;

	/**
	 * 重新生成发票校验
	 * 
	 * @param orderInvoiceInfoParamter
	 * @param userId
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	void generateInvoiceVerify(OrderBo order) throws GlobalErrorInfoException;

	/**
	 * 部分退货校验
	 * 
	 * @param order
	 * @throws GlobalErrorInfoException
	 */
	void rejectItemApplyVerify(Order order, Date returnBy) throws GlobalErrorInfoException;

	/**
	 * monitor 加密
	 * 
	 * @param appKey
	 * @param version
	 * @param format
	 * @param timeStamp
	 * @param orderId
	 * @param sign
	 * @param mac
	 * @param mobilePhone
	 * @throws GlobalErrorInfoException
	 */
	void monitorCheckSum(String appKey, String version, String format, Long timeStamp, String orderId, String sign, String mac, String mobilePhone) throws GlobalErrorInfoException;

	void macCheckSum(String appKey, String version, String format, Long timeStamp, String sign, String mac) throws GlobalErrorInfoException;

}
