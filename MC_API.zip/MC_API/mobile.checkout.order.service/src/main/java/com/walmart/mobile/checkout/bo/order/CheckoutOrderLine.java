package com.walmart.mobile.checkout.bo.order;

import java.math.BigDecimal;
import java.util.List;

import com.walmart.mobile.checkout.rest.vo.EwsPriceVo;
import com.walmart.mobile.checkout.rest.vo.InventoryPriceVo;
import com.walmart.mobile.checkout.rest.vo.OfferVo;
import com.walmart.mobile.checkout.rest.vo.ProductDetailVo;


public class CheckoutOrderLine {
 
	private Long upc;
	private BigDecimal priceWithTax;
	private Long productId;

	private InventoryPriceVo invePrice;
	private ProductDetailVo productDetail;
	private List<OfferVo> gpOffers;
	private Long barCode;
	private BigDecimal itemAmount;
	private int itemType;
	private int orderQuantity;
	
	private List<EwsPriceVo> ewsPriceList;
	private EwsPriceVo ewsPrice;
	
	private Integer ewsOptFlag;

	public CheckoutOrderLine() {
		// 构造函数
	}

	public CheckoutOrderLine(OrderLineParameter orderLine) {
		this.priceWithTax = orderLine.getPriceWithTax();
		this.upc = orderLine.getUpc();
		this.productId = orderLine.getProductId();
		this.gpOffers = orderLine.getGpOffers();
		this.barCode = orderLine.getBarCode();
		this.itemAmount = orderLine.getItemAmount();
		this.itemType = orderLine.getItemType();
		this.orderQuantity = orderLine.getOrderQuantity();
	}

	public Long getUpc() {
		return upc;
	}

	public void setUpc(Long upc) {
		this.upc = upc;
	}

	public BigDecimal getPriceWithTax() {
		if (priceWithTax != null) {
			return new BigDecimal(priceWithTax.toString()).setScale(2, BigDecimal.ROUND_HALF_UP);
		}
		return priceWithTax;
	}

	public void setPriceWithTax(BigDecimal taxPrice) {
		this.priceWithTax = taxPrice;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public InventoryPriceVo getInvePrice() {
		return invePrice;
	}

	public void setInvePrice(InventoryPriceVo invePrice) {
		this.invePrice = invePrice;
	}

	public ProductDetailVo getProductDetail() {
		return productDetail;
	}

	public void setProductDetail(ProductDetailVo productDetail) {
		this.productDetail = productDetail;
	}

	public List<OfferVo> getGpOffers() {
		return gpOffers;
	}

	public void setGpOffers(List<OfferVo> gpOffers) {
		this.gpOffers = gpOffers;
	}

	public Long getBarCode() {
		return barCode;
	}

	public void setBarCode(Long barCode) {
		this.barCode = barCode;
	}

	public BigDecimal getItemAmount() {
		return itemAmount;
	}

	public void setItemAmount(BigDecimal itemAmount) {
		this.itemAmount = itemAmount;
	}

	public int getItemType() {
		return itemType;
	}

	public void setItemType(int itemType) {
		this.itemType = itemType;
	}

	public int getOrderQuantity() {
		return orderQuantity;
	}

	public void setOrderQuantity(int orderQuantity) {
		this.orderQuantity = orderQuantity;
	}

	public List<EwsPriceVo> getEwsPriceList() {
		return ewsPriceList;
	}

	public void setEwsPriceList(List<EwsPriceVo> ewsPriceList) {
		this.ewsPriceList = ewsPriceList;
	}

	public EwsPriceVo getEwsPrice() {
		return ewsPrice;
	}

	public void setEwsPrice(EwsPriceVo ewsPrice) {
		this.ewsPrice = ewsPrice;
	}

	public Integer getEwsOptFlag() {
		return ewsOptFlag;
	}

	public void setEwsOptFlag(Integer ewsOptFlag) {
		this.ewsOptFlag = ewsOptFlag;
	}

}