package com.walmart.mobile.checkout.rest.order;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient("deliveryService")
public interface DeliveryServiceClient {

	@RequestMapping(method = RequestMethod.GET, value = "/cancelDelivery")
	boolean cancelDelivery(@RequestParam(value = "orderId") String orderId);

	@RequestMapping(method = RequestMethod.GET, value = "/paidDelivery")
	boolean paidDelivery(@RequestParam(value = "orderId") String orderId);

}
