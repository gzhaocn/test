package com.walmart.mobile.checkout.entity;

import java.math.BigInteger;
import java.util.Date;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.walmart.mobile.checkout.entity.document.BaseDocument;

@Document(collection = "gate_mac")
public class GateMac extends BaseDocument<BigInteger> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4463539566634124401L;
	@Indexed
	@Field("mac")
	private String mac;
	@Field("sequence_Number")
	private String sequenceNumber;
	@Field("store_id")
	private Integer storeId;

	@Field("create_time")
	private Date createTime;

	@Field("update_time")
	private Date updateTime;

	public String getGateMacId() {
		return String.valueOf(this.getId());
	}

	public void setGateMacId(BigInteger gateMacId) {
		this.setId(gateMacId);
	}

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	@Override
	public int hashCode() {
		return this.getMac() == null ? 0 : this.getMac().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (!(obj instanceof GateMac)) {
			return false;
		}
		GateMac other = (GateMac) obj;
		return this.getMac().equals(other.getMac());
	}

	public String getMac() {
		return mac;
	}

	public void setMac(String mac) {
		this.mac = mac;
	}

	public String getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(String sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

}