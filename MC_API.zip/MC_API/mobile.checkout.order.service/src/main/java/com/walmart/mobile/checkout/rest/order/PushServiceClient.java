package com.walmart.mobile.checkout.rest.order;

import java.util.List;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.walmart.mobile.checkout.bo.order.MonitorRedisInformation;
import com.walmart.mobile.checkout.bo.order.OrderPushMsg;
import com.walmart.mobile.checkout.domain.order.Order;

@FeignClient("pushService")
public interface PushServiceClient {

	@RequestMapping(method = RequestMethod.GET, value = "/pushMsg")
	void pushMsg(@RequestParam(value = "orderPushMsg") OrderPushMsg orderPushMsg, @RequestParam(value = "messageType") Integer messageType);

	@RequestMapping(method = RequestMethod.GET, value = "/shortPushMsg")
	void shortPushMsg(@RequestParam(value = "messageType") Integer messageType, @RequestParam(value = "ldapUserId") String ldapUserId, @RequestParam(value = "sequenceNumber") String sequenceNumber,
			@RequestParam(value = "storeId") Integer storeId, @RequestParam(value = "monitorRedisInformation") MonitorRedisInformation monitorRedisInformation);

	@RequestMapping(method = RequestMethod.GET, value = "/commonComfirmPushMsg")
	void commonComfirmPushMsg(@RequestParam(value = "messageType") Integer messageType, @RequestParam(value = "ldapUserId") String ldapUserId,
			@RequestParam(value = "sequenceNumber") String sequenceNumber, @RequestParam(value = "storeId") Integer storeId, @RequestParam(value = "order") Order order);

	@RequestMapping(method = RequestMethod.GET, value = "/commonComfirmAllPushMsg")
	void commonComfirmAllPushMsg(@RequestParam(value = "messageType") Integer messageType, @RequestParam(value = "ldapUserId") String ldapUserId,
			@RequestParam(value = "sequenceNumber") String sequenceNumber, @RequestParam(value = "storeId") Integer storeId, @RequestParam(value = "orderList") List<Order> orderList);
}