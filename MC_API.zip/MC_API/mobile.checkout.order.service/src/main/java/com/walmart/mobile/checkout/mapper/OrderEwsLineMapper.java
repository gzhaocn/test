package com.walmart.mobile.checkout.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.walmart.mobile.checkout.bo.order.OrderLineBo;
import com.walmart.mobile.checkout.domain.order.OrderEwsLine;
import com.walmart.mobile.checkout.domain.order.OrderEwsLineKey;
import com.walmart.mobile.checkout.domain.order.OrderLine;

public interface OrderEwsLineMapper {
	int deleteByPrimaryKey(OrderEwsLineKey key);

	int insert(OrderEwsLine record);

	int insertByBatch(List<OrderEwsLine> orderEwsLineList);

	int insertSelective(OrderEwsLine record);

	OrderEwsLine selectByPrimaryKey(OrderEwsLineKey key);

	int updateByPrimaryKeySelective(OrderEwsLine record);

	int updateByPrimaryKey(OrderEwsLine record);

	List<OrderLineBo> selectOrderEwsLineListByOrderId(String orderId);

	OrderLine selectOrderLineByOrderIdAndItemNumber(@Param("orderId") String orderId, @Param("itemNumber") Long itemNumber);

	List<OrderLine> selectOrderLineByOrderId(@Param("orderId") String orderId);

	OrderLine selectOrderLineByOrderIdAndCartItemIdAndItemNumber(@Param("orderId") String orderId, @Param("cartItemId") Long cartItemId, @Param("itemNumber") Long itemNumber);

	Integer selectProductCountByOrderId(@Param("orderId") String orderId);
}