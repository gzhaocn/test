package com.walmart.mobile.checkout.service.impl;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.kie.api.runtime.KieSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSON;
import com.walmart.mobile.checkout.bo.order.CheckPersonAndTransation;
import com.walmart.mobile.checkout.bo.order.DeliveryOrder;
import com.walmart.mobile.checkout.bo.order.DeliveryParameter;
import com.walmart.mobile.checkout.bo.order.ExitCheckResult;
import com.walmart.mobile.checkout.bo.order.ExitRuleParameter;
import com.walmart.mobile.checkout.bo.order.MonitorExitParameter;
import com.walmart.mobile.checkout.bo.order.MonitorOrderAmount;
import com.walmart.mobile.checkout.bo.order.MonitorRedisInformation;
import com.walmart.mobile.checkout.bo.order.OrderBo;
import com.walmart.mobile.checkout.bo.order.OrderCreateResult;
import com.walmart.mobile.checkout.bo.order.OrderDelivery;
import com.walmart.mobile.checkout.bo.order.OrderLineBo;
import com.walmart.mobile.checkout.bo.order.OrderLineParameter;
import com.walmart.mobile.checkout.bo.order.OrderParameter;
import com.walmart.mobile.checkout.bo.order.OrderPushMsg;
import com.walmart.mobile.checkout.bo.order.OrderRefundBo;
import com.walmart.mobile.checkout.bo.order.TransactionRuleParamter;
import com.walmart.mobile.checkout.constant.AppConstants;
import com.walmart.mobile.checkout.constant.GlobalErrorInfoEnum;
import com.walmart.mobile.checkout.constant.order.MessageTypeCons;
import com.walmart.mobile.checkout.constant.order.OrderErrorInfoEnum;
import com.walmart.mobile.checkout.constant.order.OrderStatus;
import com.walmart.mobile.checkout.domain.StoreVo;
import com.walmart.mobile.checkout.domain.check.CheckHistory;
import com.walmart.mobile.checkout.domain.order.Order;
import com.walmart.mobile.checkout.domain.order.OrderDiscount;
import com.walmart.mobile.checkout.domain.order.OrderEws;
import com.walmart.mobile.checkout.domain.order.OrderEwsLine;
import com.walmart.mobile.checkout.domain.order.OrderLine;
import com.walmart.mobile.checkout.domain.order.OrderRefund;
import com.walmart.mobile.checkout.domain.order.OrderShippingLine;
import com.walmart.mobile.checkout.domain.route.Route;
import com.walmart.mobile.checkout.entity.GateMac;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.handler.send.DeliveryOrderSendHandler;
import com.walmart.mobile.checkout.handler.send.InvoiceSendHandler;
import com.walmart.mobile.checkout.mapper.OrderDiscountMapper;
import com.walmart.mobile.checkout.mapper.OrderEwsLineMapper;
import com.walmart.mobile.checkout.mapper.OrderEwsMapper;
import com.walmart.mobile.checkout.mapper.OrderLineMapper;
import com.walmart.mobile.checkout.mapper.OrderMapper;
import com.walmart.mobile.checkout.mapper.OrderShippingLineMapper;
import com.walmart.mobile.checkout.redis.RedisOperationRepo;
import com.walmart.mobile.checkout.redis.vo.RedisBean;
import com.walmart.mobile.checkout.rest.StoreServiceClient;
import com.walmart.mobile.checkout.rest.order.DeliveryServiceClient;
import com.walmart.mobile.checkout.rest.order.GateMacServiceClient;
import com.walmart.mobile.checkout.rest.order.PushServiceClient;
import com.walmart.mobile.checkout.rest.order.RefundServiceClient;
import com.walmart.mobile.checkout.rest.order.RouteServiceClient;
import com.walmart.mobile.checkout.rest.order.ScanShoppingBagClient;
import com.walmart.mobile.checkout.rest.vo.CheckCreditVo;
import com.walmart.mobile.checkout.rest.vo.EwsPriceVo;
import com.walmart.mobile.checkout.rest.vo.GpOfferVo;
import com.walmart.mobile.checkout.rest.vo.InventoryPriceVo;
import com.walmart.mobile.checkout.rest.vo.OfferVo;
import com.walmart.mobile.checkout.rest.vo.ProductDetailVo;
import com.walmart.mobile.checkout.rest.vo.SpecialItemVo;
import com.walmart.mobile.checkout.rest.vo.StoreShoppingBagForItemVo;
import com.walmart.mobile.checkout.service.CheckHistoryService;
import com.walmart.mobile.checkout.service.IdService;
import com.walmart.mobile.checkout.service.OrderService;
import com.walmart.mobile.checkout.service.OrderStatusService;
import com.walmart.mobile.checkout.statemachine.OrderEventTypeEnum;
import com.walmart.mobile.checkout.utils.DateUtil;
import com.walmart.mobile.checkout.utils.KieUtils;
import com.walmart.mobile.checkout.utils.ThreadLocalContextHolder;
import com.walmart.mobile.checkout.utils.order.OrderUtils;

/**
 * 订单实现类，用来创建与查询订单等
 * 
 * @author lliao2
 *
 */
@Service("orderService")
public class OrderServiceImpl implements OrderService {

	private static final Logger LOG = LoggerFactory.getLogger(OrderServiceImpl.class);

	@Autowired
	private OrderMapper orderMapper;
	@Autowired
	private OrderLineMapper orderLineMapper;
	@Autowired
	private OrderDiscountMapper orderDiscountMapper;
	@Autowired
	private OrderEwsMapper orderEwsMapper;
	@Autowired
	private OrderEwsLineMapper orderEwsLineMapper;
	@Autowired
	private OrderShippingLineMapper orderShippingLineMapper;
	@Autowired
	OrderStatusService orderStatusService;

	@Autowired
	private IdService orderSerialNumberService;
	@Autowired
	private RefundServiceClient refundServiceClient;
	@Autowired
	private DeliveryOrderSendHandler deliveryOrderSendHandler;
	@Autowired
	private PushServiceClient pushServiceClient;
	@Autowired
	private DeliveryServiceClient deliveryServiceClient;

	@Autowired
	private InvoiceSendHandler invoiceSendHandler;

	@Autowired
	private RedisOperationRepo<MonitorRedisInformation> redisOperationRepo;

	@Autowired
	StoreServiceClient storeServiceClient;

	@Autowired
	ScanShoppingBagClient scanShoppingBagClient;

	@Autowired
	RouteServiceClient routeServiceClient;

	@Value("${order.timeout.minutes}")
	private int orderTimeoutMinutes;

	@Value("${reject.item.overtime}")
	private int rejectItemOverTime;

	@Value("${scan.between.paid.time}")
	private int scanBetweenPaidTime;

	@Autowired
	GateMacServiceClient gateMacServiceClient;

	@Autowired
	CheckHistoryService checkHistoryService;

	/**
	 * 创建订单
	 */
	@Override
	@Transactional(rollbackFor = Exception.class)
	public OrderCreateResult create(final OrderParameter orderParam) {
		LOG.info("build order paramter");
		final Order order = createOrderObject(orderParam);
		final List<OrderLine> orderLines = createOrderLineList(order, orderParam);
		final List<OrderDiscount> orderDiscounts = createOrderDiscountList(order, orderParam);
		final List<OrderEws> orderEws = createOrderEwsList(order, orderParam);
		final List<OrderEwsLine> orderEwsList = createOrderEwsLineList(order, orderParam);
		final OrderShippingLine orderShippingLine = createOrderShippingLine(orderParam, order);
		saveOrder(order, orderLines, orderDiscounts, orderEws, orderEwsList, orderShippingLine);
		LOG.info("save order information,orderId:{}", order.getOrderId());
		return new OrderCreateResult(order, orderLines);
	}

	/**
	 * 组装运费商品对象
	 * 
	 * @param orderParam
	 * @param order
	 * @return
	 */
	private OrderShippingLine createOrderShippingLine(final OrderParameter orderParam, final Order order) {
		OrderShippingLine orderShippingLine = orderParam.getOrderShippingLine();
		if (orderShippingLine != null) {
			orderShippingLine.setOrderId(order.getOrderId());
		}
		return orderShippingLine;
	}

	/**
	 * 组装order 对象
	 * 
	 * @param orderParam
	 * @return
	 */
	private Order createOrderObject(OrderParameter orderParam) {
		int storeId = orderParam.getStoreId();
		String dagId = orderParam.getDagId();
		String orderId = orderSerialNumberService.buildOrderId(storeId, dagId);

		return new Order(orderParam, orderId);
	}

	/**
	 * 组装OrderEwsLine对象
	 * 
	 * @param order
	 * @param orderParam
	 * @return
	 */
	private List<OrderEwsLine> createOrderEwsLineList(Order order, OrderParameter orderParam) {

		List<OrderEwsLine> orderEwsLineList = orderParam.getOrderEwsLineList();
		if (CollectionUtils.isEmpty(orderEwsLineList)) {
			return Collections.emptyList();
		}
		for (OrderEwsLine orderEwsLine : orderEwsLineList) {
			orderEwsLine.setOrderId(order.getOrderId());
		}

		return orderEwsLineList;
	}

	/**
	 * 组装orderline对象
	 * 
	 * @param order
	 * @param orderParam
	 * @return
	 */
	private List<OrderLine> createOrderLineList(Order order, OrderParameter orderParam) {
		// prepare initialized variables
		Map<Long, ProductDetailVo> productDetails = orderParam.getProductDetails();
		Map<Long, InventoryPriceVo> invePrices = orderParam.getInventoryPrices();

		Map<Long, Long> productIdAndItemNumberMap = orderParam.getProductIdAndItemNumberMap();
		List<OrderLine> orderLineList = new ArrayList<>(10);
		Date returnBy = OrderUtils.getReturnBy(rejectItemOverTime);

		for (OrderLineParameter orderLineParam : orderParam.getOrderLines()) {
			Long itemNumber = productIdAndItemNumberMap.get(orderLineParam.getProductId());
			ProductDetailVo productDetail = productDetails.get(itemNumber);
			InventoryPriceVo dbInvenPrice = invePrices.get(itemNumber);
			List<OfferVo> offers = orderLineParam.getGpOffers();
			BigDecimal lineGpDiscount = BigDecimal.ZERO;

			if (!CollectionUtils.isEmpty(offers)) {
				for (OfferVo offer : offers) {
					lineGpDiscount = offer.getGpDiscount() != null ? lineGpDiscount.add(offer.getGpDiscount()) : lineGpDiscount;
				}
			}
			orderLineParam.setGpDiscount(lineGpDiscount);
			orderLineParam.setThumbnailUrl(productDetail.getThumbnailUrl());
			orderLineParam.setOrderLineParameter(dbInvenPrice);

			OrderLine ol = new OrderLine(orderLineParam, order, productDetail, dbInvenPrice, orderParam, returnBy);

			Map<Long, SpecialItemVo> specialItemMap = orderParam.getUpcAndSpecialItemMap();
			Integer specialItemFlag = specialItemMap != null && !specialItemMap.isEmpty() && specialItemMap.containsKey(dbInvenPrice.getUpc()) ? 1 : 0;
			ol.setSpecialItemFlag(specialItemFlag);

			orderLineList.add(ol);
		}
		return orderLineList;
	}

	/**
	 * 获取gp描述信息
	 * 
	 * @param gpOfferId
	 * @param gpOfferMap
	 * @return
	 */
	private String getCNPromotionDesc(int gpOfferId, Map<Integer, GpOfferVo> gpOfferMap) {
		String promotionDescCn = StringUtils.EMPTY;

		if (MapUtils.isEmpty(gpOfferMap)) {
			return promotionDescCn;
		}

		GpOfferVo gpOffer = gpOfferMap.get(gpOfferId);
		if ((gpOffer != null) && (gpOffer.getPromotionDesc() != null)) {
			promotionDescCn = gpOffer.getPromotionDesc();
		}

		return promotionDescCn;
	}

	/**
	 * 组装orderDiscountList 对象
	 * 
	 * @param order
	 * @param orderParam
	 * @return
	 */
	private List<OrderDiscount> createOrderDiscountList(Order order, OrderParameter orderParam) {
		// prepare initialized variables

		List<OrderDiscount> orderDiscountList = new ArrayList<>();

		Map<Integer, GpOfferVo> gpOffers = orderParam.getGpOffers();

		String orderId = order.getOrderId();
		Integer storeId = order.getStoreId();

		Map<Integer, Integer> map = orderParam.getGpOfferIdMinTimesMap();

		Map<Integer, Integer> gpOfferIdAndLinkSaveIdMap = orderParam.getGpOfferIdAndLinkSaveIdMap();

		for (OrderLineParameter orderLineParam : orderParam.getOrderLines()) {
			Long productId = orderLineParam.getProductId();
			List<OfferVo> offers = orderLineParam.getGpOffers();
			if (CollectionUtils.isEmpty(offers)) {
				continue;
			}
			for (OfferVo offer : offers) {
				OrderDiscount orderDiscount = new OrderDiscount();
				if (gpOfferIdAndLinkSaveIdMap != null && gpOfferIdAndLinkSaveIdMap.containsKey(offer.getGpOfferId())) {
					orderDiscount.setLinkSaveId(gpOfferIdAndLinkSaveIdMap.get(offer.getGpOfferId()));
				}
				orderDiscount.setOrderId(orderId);
				orderDiscount.setProductId(productId);
				orderDiscount.setStoreId(storeId);
				orderDiscount.setGpOfferId(offer.getGpOfferId());
				orderDiscount.setGpTypeCode(offer.getGpTypeCode());
				orderDiscount.setPromotionDescCn(getCNPromotionDesc(offer.getGpOfferId(), gpOffers));
				orderDiscount.setGpDiscount(offer.getGpDiscount() == null ? BigDecimal.ZERO : offer.getGpDiscount().setScale(2, RoundingMode.HALF_UP));
				orderDiscount.setGpGroupSeq(Long.parseLong(offer.getGpGroupSeq().toString()));
				orderDiscount.setCartItemId(orderLineParam.getCartItemId());
				setGpDiscountTimes(map, offer, orderDiscount);
				orderDiscountList.add(orderDiscount);

			}

		}
		return orderDiscountList;
	}

	/**
	 * 组装orderEws 对象
	 * 
	 * @param order
	 * @param orderParam
	 * @return
	 */
	private List<OrderEws> createOrderEwsList(Order order, OrderParameter orderParam) {
		// prepare initialized variables

		List<OrderEws> orderEwsList = new ArrayList<>();
		String orderId = order.getOrderId();

		for (OrderLineParameter orderLineParam : orderParam.getOrderLines()) {
			EwsPriceVo ewsPrice = orderLineParam.getEwsPrice();
			if (orderLineParam.getEwsOptFlag() == null || orderLineParam.getEwsOptFlag() == 0 || ewsPrice == null) {
				continue;
			}
			OrderEws orderEws = new OrderEws();
			orderEws.setOrderId(orderId);
			orderEws.setCartItemId(orderLineParam.getCartItemId());
			orderEws.setEwsBarcode(ewsPrice.getEwsBarcode());
			orderEws.setEwsCategory(ewsPrice.getCategory());
			orderEws.setEwsDesc(ewsPrice.getDesc());
			orderEws.setEwsEndPrice(ewsPrice.getEndPrice());
			orderEws.setEwsItemNumber(ewsPrice.getItemNumber());
			orderEws.setEwsPrice(ewsPrice.getExtendedWarrantyPrice());
			orderEws.setEwsQuantity(ewsPrice.getEwsQuantity());
			orderEws.setEwsStartPrice(ewsPrice.getStartPrice());
			orderEws.setEwsTimeSlot(ewsPrice.getTimeSlot());
			orderEws.setProductId(orderLineParam.getProductId());
			orderEws.setEwsAmount(ewsPrice.getExtendedWarrantyPrice().multiply(new BigDecimal(ewsPrice.getEwsQuantity())));
			orderEwsList.add(orderEws);
		}
		return orderEwsList;
	}

	private void setGpDiscountTimes(Map<Integer, Integer> map, OfferVo offer, OrderDiscount orderDiscount) {
		if (map.containsKey(offer.getGpOfferId())) {
			orderDiscount.setGpDiscountTimes(map.get(offer.getGpOfferId()));
		}
	}

	/**
	 * 保存订单数据
	 * 
	 * @param order
	 * @param orderLineList
	 * @param orderDiscounts
	 */
	private void saveOrder(Order order, List<OrderLine> orderLineList, List<OrderDiscount> orderDiscountList, List<OrderEws> orderEwsList, List<OrderEwsLine> orderEwsLineList,
			OrderShippingLine orderShippingLine) {
		orderMapper.insert(order);

		List<OrderLine> orderLineListTemp = new ArrayList<>();
		for (OrderLine orderLine : orderLineList) {
			orderLineListTemp.add(orderLine);
			if (orderLineListTemp.size() == 30) {
				orderLineMapper.insertByBatch(orderLineListTemp);
				orderLineListTemp.clear();
			}
		}

		if (!orderLineListTemp.isEmpty()) {
			orderLineMapper.insertByBatch(orderLineListTemp);
			orderLineListTemp.clear();
		}
		if (CollectionUtils.isNotEmpty(orderDiscountList)) {
			orderDiscountMapper.insertByBatch(orderDiscountList);
		}
		if (CollectionUtils.isNotEmpty(orderEwsList)) {
			orderEwsMapper.insertByBatch(orderEwsList);
		}
		if (CollectionUtils.isNotEmpty(orderEwsLineList)) {
			orderEwsLineMapper.insertByBatch(orderEwsLineList);
		}
		if (orderShippingLine != null) {
			orderShippingLineMapper.insert(orderShippingLine);
		}

	}

	/**
	 * 查询订单信息
	 */
	@Override
	public Order getOrderByOrderId(String orderId) {
		return orderMapper.selectByPrimaryKey(orderId);
	}

	/**
	 * 查询orderLine信息
	 */
	@Override
	public List<OrderLine> selectOrderLineListByOrderId(String orderId) {
		return orderLineMapper.selectOrderLineListByOrderId(orderId);
	}

	/**
	 * 修改订单信息
	 */
	@Override
	public int updateByPrimaryKeySelective(Order record) {
		return orderMapper.updateByPrimaryKeySelective(record);
	}

	/**
	 * 修改订单信息
	 */
	@Override
	public int updateTcNumber(String orderId, Date tcTransTime, Integer tcSequenceNumber, Integer tcRegisterNumber, String tcNumber, Integer version) throws GlobalErrorInfoException {
		int i = orderMapper.updateTcNumber(orderId, tcTransTime, tcSequenceNumber, tcRegisterNumber, tcNumber, version);
		if (i == 0) {
			throw new GlobalErrorInfoException(GlobalErrorInfoEnum.SQL_NOT_UPDATE);
		}
		return i;
	}

	/**
	 * 修改订单发票信息
	 */
	@Override
	public int updateInvoicePdfUrl(String orderId, String invoicePdfUrl, Integer version, String invoiceNo, String invoiceCode, String reverseInvoiceUrl) {
		return orderMapper.updateInvoicePdfUrl(orderId, invoicePdfUrl, version, invoiceNo, invoiceCode, reverseInvoiceUrl);
	}

	/**
	 * 分页查询订单列表
	 * 
	 * @throws GlobalErrorInfoException
	 */
	@Override
	public List<OrderBo> getOrderListByPaginationV2(int start, int row, String userId) throws GlobalErrorInfoException {
		List<Order> orderDetails = orderMapper.selectOrderPageByUserId(userId, start, row);
		if (CollectionUtils.isEmpty(orderDetails)) {
			return Collections.emptyList();
		}

		List<String> orderIds = OrderUtils.getOrderIdList(orderDetails);
		List<OrderLineBo> orderLineList = orderLineMapper.selectTopThreeOrderLineBosByOrderIds(orderIds);
		// 按orderId分组
		Map<String, List<OrderLineBo>> map = orderLineList.stream().collect(Collectors.groupingBy(OrderLineBo::getOrderId));

		List<OrderBo> orderBoList = new ArrayList<>();
		OrderBo orderBo;
		setItemSize(orderDetails);
		for (Order order : orderDetails) {
			setTimeOut(order);
			orderBo = new OrderBo();
			BeanUtils.copyProperties(order, orderBo);
			if (map.containsKey(order.getOrderId())) {
				orderBo.setOrderLineBoList(map.get(order.getOrderId()));
			}
			orderBoList.add(orderBo);
		}

		return orderBoList;
	}

	/**
	 * 分页查询订单列表
	 * 
	 * @throws GlobalErrorInfoException
	 */
	@Override
	public List<OrderBo> getOrderListByPagination(int start, int row, String userId) throws GlobalErrorInfoException {
		List<Order> orderDetails = orderMapper.selectOrderPageByUserId(userId, start, row);
		if (CollectionUtils.isEmpty(orderDetails)) {
			return Collections.emptyList();
		}

		List<String> orderIds = OrderUtils.getOrderIdList(orderDetails);
		List<OrderLineBo> orderLineList = orderLineMapper.selectOrderLineBosByOrderIds(orderIds);
		// 按orderId分组
		Map<String, List<OrderLineBo>> map = orderLineList.stream().collect(Collectors.groupingBy(OrderLineBo::getOrderId));

		List<OrderBo> orderBoList = new ArrayList<>();
		OrderBo orderBo;
		for (Order order : orderDetails) {
			setTimeOut(order);
			orderBo = new OrderBo();
			BeanUtils.copyProperties(order, orderBo);
			if (map.containsKey(order.getOrderId())) {
				orderBo.setOrderLineBoList(map.get(order.getOrderId()));
			}
			orderBoList.add(orderBo);
		}

		return orderBoList;
	}

	/**
	 * 设置超时时间
	 * 
	 * @param order
	 * @throws GlobalErrorInfoException
	 */
	private void setTimeOut(Order order) {
		long currentTimeMillis = System.currentTimeMillis();
		// 设置超时
		int status = order.getStatus();
		if (OrderStatus.UNPAID != status && OrderStatus.PAYING != status) {
			return;
		}
		long timeoutInterval = currentTimeMillis - order.getCreatedTime().getTime();
		if (timeoutInterval <= orderTimeoutMinutes * 60 * 1000 || order.isTimeout()) {
			return;
		}

		int updatedCnt = 0;
		try {
			updatedCnt = orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.TIMEOUT.getCode());
		} catch (GlobalErrorInfoException e) {
			LOG.error("order status change to time error", e);
		}

		if (updatedCnt > 0) {
			order.setStatus(OrderStatus.TIMEOUT);
		}
	}

	/**
	 * 查询订单详情
	 */
	@Override
	public OrderBo requestOrderDetailByUserIdAndOrderId(String userId, String orderId) {

		Order order = orderMapper.selectOrderByUserIdAndOrderId(userId, orderId);
		if (order == null) {
			return null;
		}
		return buildOrderDetail(order);
	}

	/**
	 * 查询订单详情
	 */
	@Override
	public OrderBo requestOrderDetailByUserIdAndOrderIdForPassMachine(String userId, String orderId) {

		Order order = orderMapper.selectOrderByUserIdAndOrderId(userId, orderId);
		if (order == null) {
			return null;
		}
		return buildOrderDetailForPassMachine(order);
	}

	private OrderBo buildOrderDetailForPassMachine(Order order) {
		setTimeOut(order);
		OrderBo orderDetail = new OrderBo();
		BeanUtils.copyProperties(order, orderDetail);
		List<OrderLine> orderLines = orderLineMapper.selectOrderLineListByOrderId(order.getOrderId());
		List<Long> cartItemIds = OrderUtils.getCartItemIdList(orderLines);
		List<OrderDiscount> orderDiscountList = orderDiscountMapper.selectOrderDiscountListByCartItemId(order.getOrderId(), cartItemIds);
		Map<Long, List<OrderDiscount>> map = new HashMap<>(16);
		if (orderDiscountList != null && !orderDiscountList.isEmpty()) {
			// 按cartItemId分组
			map = orderDiscountList.stream().collect(Collectors.groupingBy(OrderDiscount::getCartItemId));
		}
		List<OrderLineBo> orderLineBoList = new ArrayList<>();
		OrderLineBo orderLineBo;
		for (OrderLine orderLine : orderLines) {
			orderLineBo = new OrderLineBo();
			BeanUtils.copyProperties(orderLine, orderLineBo);
			if (map != null && map.containsKey(orderLine.getCartItemId())) {
				orderLineBo.setOrderDiscountList(map.get(orderLine.getCartItemId()));
			}

			orderLineBoList.add(orderLineBo);
		}

		List<OrderLineBo> orderEwsLine = orderEwsLineMapper.selectOrderEwsLineListByOrderId(order.getOrderId());
		if (CollectionUtils.isNotEmpty(orderEwsLine)) {
			orderLineBoList.addAll(orderEwsLine);
		}

		List<OrderLineBo> orderShippingLine = orderShippingLineMapper.selectOrderShippingLineListByOrderId(order.getOrderId());
		if (CollectionUtils.isNotEmpty(orderShippingLine)) {
			orderLineBoList.addAll(orderShippingLine);
		}
		orderDetail.setOrderLineBoList(orderLineBoList);
		return orderDetail;
	}

	private void buildOrderLineBo(String orderId, Integer orderStatus, List<OrderLineBo> orderLineBoList) {
		if (OrderStatus.COMPLETE == orderStatus) {
			List<OrderRefund> refundList = refundServiceClient.getOrderRefundList(orderId);
			if (refundList != null) {
				Map<Long, List<OrderRefund>> refundMap = new HashMap<>(10);
				refundList.forEach(refund -> {
					Long upc = refund.getUpc();
					Long cartId = refund.getCartItemId();
					Long key = upc * 100 + cartId;
					if (!refundMap.containsKey(key)) {
						refundMap.put(key, new ArrayList<>());
					}
					refundMap.get(key).add(refund);
				});

				orderLineBoList.forEach(orderLineBo -> orderLineBo.setOrderRefundList(refundMap.get(orderLineBo.getUpc() * 100 + orderLineBo.getCartItemId())));
			}
		}
	}

	private OrderBo buildOrderDetail(Order order) {
		setTimeOut(order);
		OrderBo orderDetail = new OrderBo();
		BeanUtils.copyProperties(order, orderDetail);
		List<OrderLine> orderLines = orderLineMapper.selectOrderLineListByOrderId(order.getOrderId());
		List<Long> cartItemIds = OrderUtils.getCartItemIdList(orderLines);
		List<OrderDiscount> orderDiscountList = orderDiscountMapper.selectOrderDiscountListByCartItemId(order.getOrderId(), cartItemIds);
		Map<Long, List<OrderDiscount>> map = new HashMap<>(16);
		if (orderDiscountList != null && !orderDiscountList.isEmpty()) {
			// 按cartItemId分组
			map = orderDiscountList.stream().collect(Collectors.groupingBy(OrderDiscount::getCartItemId));
		}

		Map<Long, OrderEws> orderEwsMap = new HashMap<>(16);
		List<OrderEws> orderEwsList = orderEwsMapper.selectOrderEwsList(order.getOrderId());
		if (CollectionUtils.isNotEmpty(orderEwsList)) {
			orderEwsMap = orderEwsList.stream().collect(Collectors.toMap(OrderEws::getCartItemId, a -> a, (k1, k2) -> k1));
		}

		List<OrderLineBo> orderLineBoList = new ArrayList<>();
		OrderLineBo orderLineBo;
		for (OrderLine orderLine : orderLines) {
			orderLineBo = new OrderLineBo();
			BeanUtils.copyProperties(orderLine, orderLineBo);

			if (orderEwsMap != null && orderEwsMap.containsKey(orderLine.getCartItemId())) {
				orderLineBo.setOrderEws(orderEwsMap.get(orderLine.getCartItemId()));
			}
			/**
			 * if (orderDiscountList == null || orderDiscountList.isEmpty()) {
			 * orderLineBoList.add(orderLineBo); continue; }
			 */
			if (map != null && map.containsKey(orderLine.getCartItemId())) {
				orderLineBo.setOrderDiscountList(map.get(orderLine.getCartItemId()));
			}

			orderLineBoList.add(orderLineBo);
		}
		buildOrderLineBo(order.getOrderId(), order.getStatus(), orderLineBoList);
		orderDetail.setOrderLineBoList(orderLineBoList);
		return orderDetail;
	}

	/**
	 * 查询订单详情
	 */
	@Override
	public OrderBo requestOrderDetailByOrder(Order order) {
		return buildOrderDetail(order);
	}

	/**
	 * 检查用户是否有订单权限
	 */
	@Override
	public Order selectOrderByUserIdAndOrderId(String userId, String orderId) {

		return orderMapper.selectOrderByUserIdAndOrderId(userId, orderId);
	}

	/**
	 * 未支付订单取消
	 * 
	 * @param order
	 * @param reasonId
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	@Override
	public void unPaidCancel(Order order, int reasonId) throws GlobalErrorInfoException {
		order.setCancelReason(reasonId);
		int updatedCnt = orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.UNPAID_CANCELL.getCode());
		if (updatedCnt == 0) {
			// 没有取消成功，抛出异常
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDER_STATUS_CANT_CHANGE);
		}
	}

	/**
	 * 出场扫码二维码
	 */
	@Override
	public List<String> selectOrderListbyUserIdAndstatusAndChangeStatus(String userId, Integer status, Integer storeId) throws GlobalErrorInfoException {

		List<OrderBo> orderBoList = orderMapper.selectOrderListbyUserIdAndstatusAndStoreId(userId, status, storeId);

		if (CollectionUtils.isEmpty(orderBoList)) {
			return Collections.emptyList();
		}

		/**
		 * 修改状态到 complete
		 */
		List<String> orderIds = new ArrayList<>();
		for (OrderBo orderBo : orderBoList) {
			/**
			 * orderBo.setCompletedTime(new Date());
			 * orderStatusService.updateOrderStatus(orderBo,
			 * OrderEventTypeEnum.SCAN.getCode());
			 */
			orderIds.add(orderBo.getOrderId());
		}

		return orderIds;

	}

	/**
	 * 根据userID\STATUS\STOREID查询订单信息
	 */
	@Override
	public List<Order> exitSelectOrderListbyUserIdAndstatusAndStoreId(String userId, Integer status, Integer storeId) throws GlobalErrorInfoException {
		return orderMapper.queryOrderListbyUserIdAndstatusAndStoreId(userId, status, storeId);
	}

	/**
	 * 组装orderLine对象
	 * 
	 * @param orderBoList
	 * @return
	 */
	private Map<String, List<OrderLineBo>> buildOrderLines(List<OrderBo> orderBoList) {
		List<String> orderIds = OrderUtils.getOrderIdBoList(orderBoList);
		List<OrderLineBo> orderLineList = orderLineMapper.selectOrderLineBosByOrderIds(orderIds);
		// 按orderId分组
		Map<String, List<OrderLineBo>> map = orderLineList.stream().collect(Collectors.groupingBy(OrderLineBo::getOrderId));
		setOrderDiscountList(orderIds, orderLineList);
		setOrderEwsList(orderIds, orderLineList);

		return map;
	}

	private void setOrderEwsList(List<String> orderIds, List<OrderLineBo> orderLineList) {
		List<OrderEws> orderEwsList = orderEwsMapper.selectOrderEwsListByOrderIds(orderIds);
		if (CollectionUtils.isNotEmpty(orderEwsList)) {
			// 按orderId,cartItemId分组
			Map<String, Map<Long, OrderEws>> orderEwsMap = orderEwsList.stream()
					.collect(Collectors.groupingBy(OrderEws::getOrderId, Collectors.toMap(OrderEws::getCartItemId, a -> a, (k1, k2) -> k1)));
			for (OrderLineBo orderLine : orderLineList) {
				if (orderEwsMap != null && orderEwsMap.containsKey(orderLine.getOrderId())) {
					Map<Long, OrderEws> ewsMap = orderEwsMap.get(orderLine.getOrderId());
					buildOrderEws(orderLine, ewsMap);

				}
			}
		}
	}

	private void buildOrderEws(OrderLineBo orderLine, Map<Long, OrderEws> ewsMap) {
		if (ewsMap != null && ewsMap.containsKey(orderLine.getCartItemId())) {
			orderLine.setOrderEws(ewsMap.get(orderLine.getCartItemId()));
		}
	}

	private void setOrderDiscountList(List<String> orderIds, List<OrderLineBo> orderLineList) {
		List<OrderDiscount> orderDiscountList = orderDiscountMapper.selectOrderDiscountListByOrderIds(orderIds);
		if (orderDiscountList != null && !orderDiscountList.isEmpty()) {
			// 按orderId,cartItemId分组
			Map<String, Map<Long, List<OrderDiscount>>> orderDiscountMap = orderDiscountList.stream().collect(
					Collectors.groupingBy(OrderDiscount::getOrderId, Collectors.groupingBy(OrderDiscount::getCartItemId)));
			for (OrderLineBo orderLine : orderLineList) {
				if (orderDiscountMap.containsKey(orderLine.getOrderId())) {
					buildOrderDiscount(orderDiscountMap, orderLine);
				}
			}
		}
	}

	/**
	 * 构建orderDiscunt
	 * 
	 * @param orderDiscountMap
	 * @param orderLine
	 */
	private void buildOrderDiscount(Map<String, Map<Long, List<OrderDiscount>>> orderDiscountMap, OrderLineBo orderLine) {
		Map<Long, List<OrderDiscount>> discountMap = orderDiscountMap.get(orderLine.getOrderId());
		if (discountMap.containsKey(orderLine.getCartItemId())) {
			orderLine.setOrderDiscountList(discountMap.get(orderLine.getCartItemId()));
		}
	}

	/**
	 * 批量修改订单状态
	 * 
	 * @throws GlobalErrorInfoException
	 */
	@Override
	@Transactional(rollbackFor = Exception.class)
	public void updateStatusByOrderIds(List<Order> orderList, Integer cancelReason, String cancelRemark) throws GlobalErrorInfoException {
		for (Order order : orderList) {
			order.setCompletedTime(new Date());
			order.setCancelReason(cancelReason);
			order.setCancelRemark(cancelRemark);
			orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.SCAN.getCode());
		}
	}

	/**
	 * 修改订单状态到完成状态
	 * 
	 * @throws GlobalErrorInfoException
	 */
	@Override
	public int updateStatusByOrder(Order order) throws GlobalErrorInfoException {
		order.setCompletedTime(new Date());
		return orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.SCAN.getCode());
	}

	/**
	 * 批量查询订单信息
	 */
	@Override
	public List<Order> selectOrderListByUserIdAndOrderIds(String userId, List<String> orderIds) {
		return orderMapper.selectOrderListByUserIdAndOrderIds(userId, orderIds);
	}

	@Override
	public List<Order> selectOrderListByUserIdAndOrderIdsAndStoreId(String userId, List<String> orderIds, Integer storeId) {
		return orderMapper.selectOrderListByUserIdAndOrderIdsAndStoreId(userId, orderIds, storeId);
	}

	/**
	 * 批量设置订单完成时间和完成状态
	 */
	@Override
	public void completeOrderList(List<Order> orderList) throws GlobalErrorInfoException {
		Date completeDate = new Date();
		orderList.forEach(upOrder -> {
			upOrder.setCompletedTime(completeDate);
			orderLineMapper.selectOrderLineListByOrderId(upOrder.getOrderId()).forEach(orderLine -> upOrder.setItemSize(orderLine.getOrderQuantity()));
		});
	}

	/**
	 * 获取订单详情
	 */
	@Override
	public List<OrderBo> getOrderBoList(List<Order> orderList) {
		List<OrderBo> orderBoList = new ArrayList<>();
		orderList.forEach(order -> {
			OrderBo orderBo = new OrderBo();
			BeanUtils.copyProperties(order, orderBo);
			orderBoList.add(orderBo);
		});
		Map<String, List<OrderLineBo>> map = buildOrderLines(orderBoList);
		orderBoList.forEach(orderBo -> orderBo.setOrderLineBoList(map.get(orderBo.getOrderId())));
		return orderBoList;
	}

	@Override
	public List<OrderLine> selectOrderLineDetailsByOrderIds(List<String> orderIds) {
		return orderLineMapper.selectOrderLineDetailsByOrderIds(orderIds);
	}

	public List<Order> queryOrderListByUserId(String userId) {
		return orderMapper.queryOrderListByUserId(userId);
	}

	@Override
	public List<OrderBo> selectOrderListByUserId(String userId) throws GlobalErrorInfoException {
		List<Order> orderList = queryOrderListByUserId(userId);
		if (CollectionUtils.isEmpty(orderList)) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDER_NOT_EXIST);
		}
		return getOrderBoList(queryOrderListByUserId(userId));
	}

	@Override
	public List<OrderBo> selectOrderListbyUserIdAndstatusAndStoreId(String userId, Integer status, Integer storeId) throws GlobalErrorInfoException {

		List<Order> orderList = orderMapper.queryOrderListbyUserIdAndstatusAndStoreId(userId, status, storeId);

		if (CollectionUtils.isEmpty(orderList)) {
			return Collections.emptyList();
		}
		return getOrderBoList(orderList);

	}

	@Override
	public void setItemSize(List<Order> orderList) throws GlobalErrorInfoException {
		orderList.forEach(upOrder -> {
			/** upOrder.setScanTime(new Date()); */
			orderLineMapper.selectOrderLineListByOrderId(upOrder.getOrderId()).forEach(orderLine -> upOrder.setItemSize(orderLine.getOrderQuantity()));
		});

	}

	@Override
	public void updateStatusByOrderCancelling(Order order) throws GlobalErrorInfoException {
		orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.PAID_CANCELL.getCode());
	}

	@Override
	public void updateScanTimeByOrderList(List<Order> orderList) throws GlobalErrorInfoException {
		orderMapper.updateScanTimeByOrderList(orderList);
	}

	@Override
	public Order selectOrderByUserIdAndOrderIdAndStoreId(String userId, String orderId, Integer storeId) {
		return orderMapper.selectOrderByUserIdAndOrderIdAndStoreId(userId, orderId, storeId);
	}

	@Override
	public List<Order> queryOrderListbyUserIdAndstatusAndStoreId(String userId, Integer status, Integer storeId) throws GlobalErrorInfoException {
		List<Order> orderList = orderMapper.queryOrderListbyUserIdAndstatusAndStoreId(userId, status, storeId);

		if (CollectionUtils.isEmpty(orderList)) {
			return Collections.emptyList();
		}
		return orderList;

	}

	@Override
	public OrderLine selectOrderLineByOrderIdAndProductIdAndCartItemId(String orderId, Long productId, Long cartItemId) {
		return orderLineMapper.selectOrderLineByOrderIdAndProductIdAndCartItemId(orderId, productId, cartItemId);
	}

	@Override
	public Integer selectProductCountByOrderId(String orderId) {
		return orderLineMapper.selectProductCountByOrderId(orderId);
	}

	@Override
	public OrderLine selectOrderLineByOrderIdAndItemNumber(String orderId, Long itemNumber) {
		return orderEwsLineMapper.selectOrderLineByOrderIdAndItemNumber(orderId, itemNumber);
	}

	@Override
	public List<OrderLine> selectOrderEwsLineByOrderId(String orderId) {
		return orderEwsLineMapper.selectOrderLineByOrderId(orderId);
	}

	@Override
	public BigDecimal calcOrderAmount(Order order) {
		BigDecimal shippingFee = order.getShippingFee() == null ? BigDecimal.ZERO : order.getShippingFee();
		BigDecimal packagingFee = order.getPackagingFee() == null ? BigDecimal.ZERO : order.getPackagingFee();
		BigDecimal orderAmount = order.getAmount().subtract(shippingFee).subtract(packagingFee);
		// 减去运费为负数时，可退金额就为0
		orderAmount = orderAmount.compareTo(BigDecimal.ZERO) > 0 ? orderAmount : BigDecimal.ZERO;
		return orderAmount;
	}

	@Override
	public int updatePaperInvoiceInvoiceNo(String orderId, String invoiceNo) {
		return orderMapper.updatePaperInvoiceInvoiceNo(orderId, invoiceNo);
	}

	@Override
	public OrderPushMsg buildOrderPushMsg(Integer storeId, String sequenceNumber, List<Order> orderList, Integer messageType, CheckCreditVo checkCredit, String mobilePhone, String seqId,
			String screenFlag) {
		OrderPushMsg orderPushMsg = new OrderPushMsg();
		orderPushMsg.setOrderList(orderList);
		orderPushMsg.setStoreId(storeId);
		orderPushMsg.setSequenceNumber(sequenceNumber);
		orderPushMsg.setCheckFlag(checkCredit.getCheckFlag());
		orderPushMsg.setUserName(checkCredit.getUserName());
		orderPushMsg.setMagneticFlag(checkCredit.getMagneticFlag());
		orderPushMsg.setMobilePhone(mobilePhone);
		orderPushMsg.setMessageType(messageType);
		orderPushMsg.setSeqId(seqId);
		orderPushMsg.setScreenFlag(screenFlag);
		return orderPushMsg;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public void updateBatchOrderStatusAndScanTime(List<Order> orderList, int eventType, Integer checkFlag, String sequenceNumber) throws GlobalErrorInfoException {

		List<Order> orderListTemp = new ArrayList<>();
		for (Order order : orderList) {
			orderListTemp.add(order);
			if (orderListTemp.size() == 50) {
				orderStatusService.updateBatchOrderStatusAndScanTime(orderListTemp, eventType, checkFlag, sequenceNumber);
				orderListTemp.clear();
			}
		}
		if (!orderListTemp.isEmpty()) {
			orderStatusService.updateBatchOrderStatusAndScanTime(orderListTemp, eventType, checkFlag, sequenceNumber);
			orderListTemp.clear();
		}

	}

	@Override
	public Map<Long, OrderLine> getOrderLineMap(String orderId, OrderRefundBo orderRefundBo, Map<Long, Long> itemNumberAndCartItemIdMap) {
		List<String> orderIdList = new ArrayList<>(16);
		orderIdList.add(orderId);
		List<OrderLine> orderLineList = this.selectOrderLineDetailsByOrderIds(orderIdList);
		Map<Long, OrderLine> orderLineMap = new HashMap<>(16);
		orderLineList.forEach(orderLine -> {
			Long upc = orderLine.getUpc();
			Long cartId = orderLine.getCartItemId();
			Long key = upc * 100 + cartId;
			orderLineMap.put(key, orderLine);
			orderRefundBo.addOrderQuantity(orderLine.getOrderQuantity());
		});

		List<OrderLine> orderEwsLineList = this.selectOrderEwsLineByOrderId(orderId);
		if (orderEwsLineList != null) {
			orderEwsLineList.forEach(orderLine -> {
				Long upc = orderLine.getUpc();
				Long cartId = orderLine.getCartItemId();
				/**
				 * 兼容历史数据
				 */
				if (cartId == 0 && itemNumberAndCartItemIdMap != null && itemNumberAndCartItemIdMap.containsKey(orderLine.getItemNumber())) {
					cartId = itemNumberAndCartItemIdMap.get(orderLine.getItemNumber());
				}
				Long key = upc * 100 + cartId;
				orderLineMap.put(key, orderLine);
			});
		}
		return orderLineMap;
	}

	@Override
	public List<OrderEws> selectOrderEwsList(String orderId) {
		return orderEwsMapper.selectOrderEwsList(orderId);
	}

	@Override
	public void sendOrderDeliveryMessage(OrderCreateResult createOrderResult, OrderParameter orderParameter) {
		// 发送配送单记录
		DeliveryParameter delivery = orderParameter.getDelivery();
		List<OrderLine> orderLineList = createOrderResult.getOrderLineList();
		if (orderParameter.getDeliveryFlag() == 1 && delivery != null) {
			delivery.setShippingFee(orderParameter.getShippingFee());
			delivery.setStoreId(orderParameter.getStoreId());
			delivery.setOrderId(createOrderResult.getOrderId());
			delivery.setUserId(orderParameter.getUserId());
			OrderDelivery orderDelivery = new OrderDelivery(delivery, orderLineList);
			try {
				LOG.info("send delivery message userId is {},orderId is {}", orderParameter.getUserId(), createOrderResult.getOrderId());
				deliveryOrderSendHandler.sendMessage(JSON.toJSON(orderDelivery).toString());
			} catch (Exception e) {
				LOG.error("delivery order send message error,the msg is {},exception is {}", JSON.toJSON(orderDelivery).toString(), e);
			}
		}
	}

	@Override
	public void batchSendPushMsg(Integer storeId, String sequenceNumber, List<Order> orderList, Integer messageType, CheckCreditVo checkCredit, String seqId, String mobilePhone, String screenFlag) {
		if (!CollectionUtils.isEmpty(orderList)) {
			List<Order> orderListTemp = new ArrayList<>();
			for (Order order : orderList) {
				orderListTemp.add(order);
				if (orderListTemp.size() == 30) {
					sendPush(storeId, sequenceNumber, messageType, checkCredit, mobilePhone, orderListTemp, seqId, screenFlag);
					orderListTemp.clear();
				}
			}
			if (!orderListTemp.isEmpty()) {
				sendPush(storeId, sequenceNumber, messageType, checkCredit, mobilePhone, orderListTemp, seqId, screenFlag);
				orderListTemp.clear();
			}

		} else {
			sendPush(storeId, sequenceNumber, messageType, checkCredit, mobilePhone, orderList, seqId, screenFlag);
		}
	}

	private void sendPush(Integer storeId, String sequenceNumber, Integer messageType, CheckCreditVo checkCredit, String mobilePhone, List<Order> orderListTemp, String seqId, String screenFlag) {
		OrderPushMsg orderPushMsg = this.buildOrderPushMsg(storeId, sequenceNumber, orderListTemp, messageType, checkCredit, mobilePhone, seqId, screenFlag);
		pushServiceClient.pushMsg(orderPushMsg, messageType);
	}

	@Override
	public void paidDelivery(List<Order> orderList) {
		for (Order order2 : orderList) {
			if (order2.getDeliveryFlag() != null && order2.getDeliveryFlag() == 1) {
				boolean deliveryStatus = deliveryServiceClient.paidDelivery(order2.getOrderId());
				LOG.info("orderid : {} , deliveryStatus is {}", order2.getOrderId(), deliveryStatus);
			}
		}
	}

	@Override
	public void updateOrderAndBuildOrderDelivery(List<Order> orderList, CheckCreditVo checkCredit, String sequenceNumber) throws GlobalErrorInfoException {
		this.updateBatchOrderStatusAndScanTime(orderList, OrderEventTypeEnum.SCAN.getCode(), checkCredit.getCheckFlag(), sequenceNumber);
		this.setItemSize(orderList);

		Order magneticOrder = orderList.stream().filter(x -> x.getMagneticFlag() == 1).findAny().orElse(null);
		checkCredit.setMagneticFlag(magneticOrder == null ? 0 : magneticOrder.getMagneticFlag());

		Order orderDelivery = orderList.stream().sorted(Comparator.comparing(Order::getCreatedTime).reversed()).filter(x -> x.getDeliveryFlag() != null && x.getDeliveryFlag() == 1).findAny()
				.orElse(null);
		if (orderDelivery != null) {
			DeliveryOrder deliveryOrder = new DeliveryOrder(orderDelivery.getStoreId(), orderDelivery.getOrderId(), orderDelivery.getDeliveryFlag());
			checkCredit.setDeliveryOrder(deliveryOrder);
		}

		this.paidDelivery(orderList);
	}

	@Override
	public List<Order> selectOrderListByOrderIdsAndStoreId(List<String> orderIds, Integer storeId) {
		return orderMapper.selectOrderListByOrderIdsAndStoreId(orderIds, storeId);
	}

	@Override
	public void shortPushMsg(Integer messageType, String ldapUserId, String sequenceNumber, Integer storeId, MonitorRedisInformation monitorRedisInformation) {
		pushServiceClient.shortPushMsg(messageType, ldapUserId, sequenceNumber, storeId, monitorRedisInformation);
	}

	@Override
	public void commonComfirmPushMsg(Integer messageType, String ldapUserId, String sequenceNumber, Integer storeId, Order order) {
		pushServiceClient.commonComfirmPushMsg(messageType, ldapUserId, sequenceNumber, storeId, order);

	}

	@Override
	public void commonComfirmAllPushMsg(Integer messageType, String ldapUserId, String sequenceNumber, Integer storeId, List<Order> orderList) {
		pushServiceClient.commonComfirmAllPushMsg(messageType, ldapUserId, sequenceNumber, storeId, orderList);

	}

	@Override
	public void buildMonitorOrderAmount(List<Order> orderList, MonitorOrderAmount monitorOrderAmount) {
		for (Order order : orderList) {
			if (StringUtils.equals(monitorOrderAmount.getOrderId(), order.getOrderId())) {
				monitorOrderAmount.setStatus(order.getStatus());
			}
		}
	}

	@Override
	public void commonAllConfirmPush(String ldapUserId, Integer storeId, List<Order> orderList) {
		String sequenceNumber = orderList.get(0).getSequenceNumber();
		String storeIdAndSequenceNumber = storeId + "_" + sequenceNumber;
		if (redisOperationRepo.exists(storeIdAndSequenceNumber)) {
			RedisBean<MonitorRedisInformation> redisBean = redisOperationRepo.findOne(storeIdAndSequenceNumber);
			if (redisBean != null) {
				MonitorRedisInformation monitorRedisInformation = redisBean.getValue(MonitorRedisInformation.class);
				List<MonitorOrderAmount> redisMonitorOrderAmountList = monitorRedisInformation.getMonitorOrderAmountList();
				for (MonitorOrderAmount monitorOrderAmount : redisMonitorOrderAmountList) {
					this.buildMonitorOrderAmount(orderList, monitorOrderAmount);
				}
				MonitorOrderAmount monitorOrderAmount = redisMonitorOrderAmountList.stream().filter(x -> x.getStatus() == OrderStatus.PAID).findAny().orElse(null);
				if (monitorOrderAmount == null) {
					redisOperationRepo.delete(storeIdAndSequenceNumber);
				} else {
					redisBean.setValue(monitorRedisInformation);
					redisOperationRepo.save(redisBean);
				}
			}
		}
		StoreVo storeVo = storeServiceClient.findByStoreId(storeId);
		if (storeVo.getScanFlag() != null && storeVo.getScanFlag() == 0) {
			this.commonComfirmAllPushMsg(MessageTypeCons.COMMON_COMFIREM_ALL_PUSH, ldapUserId, sequenceNumber, storeId, orderList);
		}
	}

	@Override
	public StoreVo checkRedis(String orderId, Integer storeId, Order order, String storeIdAndSequenceNumber) {
		LOG.info("storeIdAndSequenceNumber is {}", storeIdAndSequenceNumber);
		StoreVo storeVo = storeServiceClient.findByStoreId(storeId);
		if (!redisOperationRepo.exists(storeIdAndSequenceNumber)) {
			LOG.info("redisOperationRepo is not exists,storeIdAndSequenceNumber is {}", storeIdAndSequenceNumber);
			return storeVo;
		}
		RedisBean<MonitorRedisInformation> redisBean = redisOperationRepo.findOne(storeIdAndSequenceNumber);
		if (redisBean == null) {
			LOG.info("redisBean is null  storeIdAndSequenceNumber is {}", storeIdAndSequenceNumber);
			return storeVo;
		}
		MonitorRedisInformation monitorRedisInformation = redisBean.getValue(MonitorRedisInformation.class);
		List<MonitorOrderAmount> redisMonitorOrderAmountList = monitorRedisInformation.getMonitorOrderAmountList();
		for (MonitorOrderAmount monitorOrderAmount : redisMonitorOrderAmountList) {
			if (StringUtils.equals(monitorOrderAmount.getOrderId(), orderId)) {
				LOG.info("orderId is  {}", orderId);
				monitorOrderAmount.setStatus(order.getStatus());
				redisBean.setValue(monitorRedisInformation);
				// 保存redis
				redisOperationRepo.save(redisBean);
				break;
			}
		}
		String json = JSON.toJSONString(redisMonitorOrderAmountList);
		LOG.info("redisMonitorOrderAmountList is {}", json);
		MonitorOrderAmount monitorOrderAmount = redisMonitorOrderAmountList.stream().filter(x -> x.getStatus() == OrderStatus.PAID).findAny().orElse(null);
		if (monitorOrderAmount == null) {
			// 删除redis
			redisOperationRepo.delete(storeIdAndSequenceNumber);
		}

		return storeVo;
	}

	@Override
	public void monitorRedisSave(MonitorExitParameter monitorExitParameter, String userId, List<Order> orderList, String sequenceNumber, String dagId, Integer storeId, String screenFlag) {
		/**
		 * 存储通道号，店号，userId,orderID,dagId信息，存redis
		 */
		MonitorRedisInformation monitorRedisInformation = new MonitorRedisInformation();
		monitorRedisInformation.setOrderId(monitorExitParameter.getOrderId());
		monitorRedisInformation.setUserId(userId);
		monitorRedisInformation.setDagId(dagId);
		monitorRedisInformation.setSequenceNumber(sequenceNumber);
		monitorRedisInformation.setStoreId(storeId);
		monitorRedisInformation.setSeqId(monitorExitParameter.getSeqId());
		monitorRedisInformation.setScreenFlag(screenFlag);

		List<MonitorOrderAmount> monitorOrderAmountList = new ArrayList<>();
		for (Order order : orderList) {
			MonitorOrderAmount monitorOrderAmount = new MonitorOrderAmount();
			monitorOrderAmount.setOrderId(order.getOrderId());
			monitorOrderAmount.setAmount(order.getAmount());
			monitorOrderAmount.setStatus(order.getStatus());
			monitorOrderAmount.setItemSize(order.getItemSize());
			monitorOrderAmountList.add(monitorOrderAmount);
		}
		monitorRedisInformation.setMonitorOrderAmountList(monitorOrderAmountList);

		RedisBean<MonitorRedisInformation> redisBean = new RedisBean<>();
		redisBean.setId(storeId + "_" + sequenceNumber);
		redisBean.setValue(monitorRedisInformation);
		redisBean.setLiveDate(DateUtil.currentEndDate());
		redisOperationRepo.save(redisBean);
	}

	@Override
	public void rulecheckItem(String batchNo, Date createTime, List<CheckHistory> checkHistoryList, OrderBo orderBo, OrderLineBo orderLineBo) {
		ExitRuleParameter exitRule = new ExitRuleParameter();
		exitRule.setOrderId(orderBo.getOrderId());
		exitRule.setProductId(orderLineBo.getProductId());
		exitRule.setUnitFlag(orderLineBo.getUnitFlag());
		exitRule.setDepartment(String.valueOf(orderLineBo.getDepartment()));
		exitRule.setItemAmount(orderLineBo.getItemType() == 0 ? orderLineBo.getPriceWithTax().multiply(new BigDecimal(orderLineBo.getOrderQuantity())).doubleValue() : orderLineBo.getItemAmount()
				.doubleValue());
		exitRule.setMagneticFlag(orderLineBo.getMagneticFlag());

		ExitCheckResult result = new ExitCheckResult();
		KieSession kieSession = KieUtils.getKieContainer().newKieSession();
		kieSession.insert(exitRule);
		kieSession.insert(result);
		int ruleFiredCount = kieSession.fireAllRules();
		LOG.info("rulecheckItem 触发了{} 条规则 {}屏幕代码 {}", ruleFiredCount, result.getRuleName(), result.getScreenFlag());
		if (result.isPostCodeResult()) {
			CheckHistory checkHistory = new CheckHistory();
			checkHistory.setOrderId(orderBo.getOrderId());
			checkHistory.setScreenFlag(result.getScreenFlag());
			checkHistory.setProductId(orderLineBo.getProductId());
			checkHistory.setSubScreenFlag(result.getRuleName());
			checkHistory.setUserId(orderBo.getUserId());
			checkHistory.setBatchNo(batchNo);
			checkHistory.setCreateTime(createTime);
			checkHistoryList.add(checkHistory);
		}
		kieSession.dispose();
	}

	@Override
	public Map<Long, StoreShoppingBagForItemVo> selectShoppingBag(Integer storeId) {
		// 查询购物袋
		List<StoreShoppingBagForItemVo> storeShoppingBagList = scanShoppingBagClient.getShoppingBagByStoreId(storeId);
		Map<Long, StoreShoppingBagForItemVo> storeShoppingBagForItemMap = new HashMap<>(10);
		for (StoreShoppingBagForItemVo storeShoppingBagForItemVo : storeShoppingBagList) {
			storeShoppingBagForItemMap.put(storeShoppingBagForItemVo.getUpc(), storeShoppingBagForItemVo);
		}
		return storeShoppingBagForItemMap;
	}

	@Override
	public void ruleCheckPersonAndTransation(CheckPersonAndTransation checkPersonAndTransation) {
		KieSession kieSession = KieUtils.getKieContainer().newKieSession();
		ExitRuleParameter exitRule = new ExitRuleParameter();
		exitRule.setEmptyOrRepeatScanFlag(CollectionUtils.isEmpty(checkPersonAndTransation.getOrderList()) ? 1 : 0);

		Long minute = 0L;
		Map<String, Long> minuteMap = checkPersonAndTransation.getMinuteMap();
		if (minuteMap != null) {
			for (Map.Entry<String, Long> entry : minuteMap.entrySet()) {
				minute = entry.getValue();
				break;
			}
		}
		exitRule.setTimeBetweenScanAndPaid(minute.intValue());
		exitRule.setOrderQuantity(checkPersonAndTransation.getOtherItemQuantity());
		exitRule.setAverageAmount(checkPersonAndTransation.getAverageAmount().doubleValue());
		exitRule.setPackageBagNumber(checkPersonAndTransation.getShoppingBagQuantity());
		exitRule.setOtherItemNumber(checkPersonAndTransation.getOtherItemQuantity());
		exitRule.setMonthlyAverageTransactionAmount(checkPersonAndTransation.getCheckCredit().getAvgAmount().doubleValue());
		exitRule.setMonthlyAverageTransactionNumber(checkPersonAndTransation.getCheckCredit().getTransCount());
		exitRule.setOrderAmount(checkPersonAndTransation.getItemAllAmount().doubleValue());

		exitRule.setUserId(checkPersonAndTransation.getUserId());
		exitRule.setBlackFlag(checkPersonAndTransation.getCheckCredit().getBlackFlag());
		exitRule.setRandomNumber(new Random().nextInt(100));

		ExitCheckResult result = new ExitCheckResult();
		kieSession.insert(exitRule);
		kieSession.insert(result);
		int ruleFiredCount = kieSession.fireAllRules();
		LOG.info("ruleCheckPersonAndTransation 触发了{} 条规则 {}屏幕代码 {}", ruleFiredCount, result.getRuleName(), result.getScreenFlag());
		if (result.isPostCodeResult()) {
			buildCheckListLoop(checkPersonAndTransation.getBatchNo(), checkPersonAndTransation.getCreateTime(), checkPersonAndTransation.getUserId(), checkPersonAndTransation.getOrderList(),
					checkPersonAndTransation.getCheckHistoryList(), checkPersonAndTransation.getMinuteMap(), result);
		}
		kieSession.dispose();
	}

	private void buildCheckListLoop(String batchNo, Date createTime, String userId, List<Order> orderList, List<CheckHistory> checkHistoryList, Map<String, Long> minuteMap, ExitCheckResult result) {
		for (Order order : orderList) {
			if (("T2").equals(result.getRuleName())) {
				if (minuteMap.containsKey(order.getOrderId())) {
					buildCheckList(batchNo, createTime, userId, checkHistoryList, result, order);
				}
			} else {
				buildCheckList(batchNo, createTime, userId, checkHistoryList, result, order);
			}
		}
	}

	private void buildCheckList(String batchNo, Date createTime, String userId, List<CheckHistory> checkHistoryList, ExitCheckResult result, Order order) {
		CheckHistory checkHistory = new CheckHistory();
		checkHistory.setOrderId(order.getOrderId());
		checkHistory.setScreenFlag(result.getScreenFlag());
		checkHistory.setUserId(userId);
		checkHistory.setBatchNo(batchNo);
		checkHistory.setCreateTime(createTime);
		checkHistory.setSubScreenFlag(result.getRuleName());
		checkHistoryList.add(checkHistory);
	}

	@Override
	public CheckPersonAndTransation buildCheckPersonAndTransaction(String batchNo, Date createTime, String userId, List<Order> orderList, List<CheckHistory> checkHistoryList,
			CheckCreditVo checkCredit, BigDecimal itemAllAmount, Integer shoppingBagQuantity, BigDecimal averageAmount, Integer otherItemQuantity, Map<String, Long> minuteMap) {
		CheckPersonAndTransation checkPersonAndTransation = new CheckPersonAndTransation();
		checkPersonAndTransation.setBatchNo(batchNo);
		checkPersonAndTransation.setCreateTime(createTime);
		checkPersonAndTransation.setUserId(userId);
		checkPersonAndTransation.setOrderList(orderList);
		checkPersonAndTransation.setCheckHistoryList(checkHistoryList);
		checkPersonAndTransation.setCheckCredit(checkCredit);
		checkPersonAndTransation.setItemAllAmount(itemAllAmount);
		checkPersonAndTransation.setShoppingBagQuantity(shoppingBagQuantity);
		checkPersonAndTransation.setAverageAmount(averageAmount);
		checkPersonAndTransation.setOtherItemQuantity(otherItemQuantity);
		checkPersonAndTransation.setMinuteMap(minuteMap);
		return checkPersonAndTransation;
	}

	@Override
	public void buildTransactionRuleParamter(String batchNo, Date createTime, Integer storeId, List<CheckHistory> checkHistoryList, List<OrderBo> orderBoList, Integer itemAllQuantity,
			BigDecimal itemAllAmount, Integer shoppingBagQuantity, BigDecimal shoppingBagAmount, TransactionRuleParamter transactionRuleParamter, Map<String, Long> minuteMap) {
		BigDecimal averageAmount;
		Integer otherItemQuantity;
		Map<Long, StoreShoppingBagForItemVo> storeShoppingBagForItemMap = this.selectShoppingBag(storeId);
		// 物品规则校验
		for (OrderBo orderBo : orderBoList) {
			Long minute = DateUtil.getMinutePoor(new Date(), orderBo.getPaidTime());
			if (minute.longValue() > scanBetweenPaidTime) {
				minuteMap.put(orderBo.getOrderId(), minute);
			}
			List<OrderLineBo> orderLineBoList = orderBo.getOrderLineBoList();
			for (OrderLineBo orderLineBo : orderLineBoList) {
				BigDecimal itemAmount = orderLineBo.getPriceWithTax().multiply(new BigDecimal(orderLineBo.getOrderQuantity()));
				itemAllQuantity = itemAllQuantity + orderLineBo.getOrderQuantity();
				itemAllAmount = itemAllAmount.add(orderLineBo.getItemType() == 0 ? itemAmount : orderLineBo.getItemAmount());
				if (storeShoppingBagForItemMap.containsKey(orderLineBo.getUpc())) {
					shoppingBagQuantity = shoppingBagQuantity + orderLineBo.getOrderQuantity();
					shoppingBagAmount = shoppingBagAmount.add(itemAmount);
				}
				this.rulecheckItem(batchNo, createTime, checkHistoryList, orderBo, orderLineBo);
			}
		}
		otherItemQuantity = itemAllQuantity - shoppingBagQuantity;
		averageAmount = (itemAllAmount.subtract(shoppingBagAmount)).divide(new BigDecimal(otherItemQuantity), 2, BigDecimal.ROUND_HALF_UP);

		transactionRuleParamter.setItemAllAmount(itemAllAmount);
		transactionRuleParamter.setShoppingBagQuantity(shoppingBagQuantity);
		transactionRuleParamter.setAverageAmount(averageAmount);
		transactionRuleParamter.setOtherItemQuantity(otherItemQuantity);

	}

	@Override
	public String getScreenFlag(List<CheckHistory> checkHistoryList) {
		String screenFlag = StringUtils.EMPTY;
		for (CheckHistory checkHistory : checkHistoryList) {
			if ("W".equals(checkHistory.getScreenFlag())) {
				screenFlag = "W";
				break;
			}
			if ("T".equals(checkHistory.getScreenFlag())) {
				screenFlag = "T";
				break;
			}
			if ("M".equals(checkHistory.getScreenFlag())) {
				screenFlag = "M";
				break;
			}
		}
		return screenFlag;
	}

	@Override
	public Map<String, String> getUserIdAndMobilePhone(MonitorExitParameter monitorExitParameter) throws GlobalErrorInfoException {
		Map<String, String> userIdAndMobilePhoneMap = new HashMap<>(3);
		if (StringUtils.isNotBlank(monitorExitParameter.getOrderId())) {
			ThreadLocalContextHolder.put(AppConstants.DAGID, OrderUtils.getDagId(monitorExitParameter.getOrderId()));
			Order order = this.getOrderByOrderId(monitorExitParameter.getOrderId());
			checkOrder(order);
			userIdAndMobilePhoneMap.put(AppConstants.DAGID, OrderUtils.getDagId(monitorExitParameter.getOrderId()));
			userIdAndMobilePhoneMap.put(AppConstants.USERID, order.getUserId());
			userIdAndMobilePhoneMap.put(AppConstants.MOBILE_PHONE, order.getMobilePhone());
		} else if (StringUtils.isBlank(monitorExitParameter.getOrderId()) && StringUtils.isNotBlank(monitorExitParameter.getMobilePhone())) {
			Route phoneRoute = routeServiceClient.getRouteByMobilePhone(monitorExitParameter.getMobilePhone());
			if (phoneRoute == null) {
				throw new GlobalErrorInfoException(OrderErrorInfoEnum.MOBILEPHONE_MATCH_USER_IS_NOT_EXIST);
			}
			userIdAndMobilePhoneMap.put(AppConstants.DAGID, phoneRoute.getDagId());
			userIdAndMobilePhoneMap.put(AppConstants.USERID, phoneRoute.getUserId());
			userIdAndMobilePhoneMap.put(AppConstants.MOBILE_PHONE, monitorExitParameter.getMobilePhone());
			ThreadLocalContextHolder.put(AppConstants.DAGID, phoneRoute.getDagId());
		}
		return userIdAndMobilePhoneMap;
	}

	private void checkOrder(Order order) throws GlobalErrorInfoException {
		if (order == null) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.USER_ORDER_NOT_EXIST);
		}
		if (order.getScanTime() != null || order.getStatus() == OrderStatus.COMPLETE) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.SCAN_ORDER_HAS_COMPLETED);
		}
	}

	@Override
	public GateMac checkGateMac(String mac) throws GlobalErrorInfoException {
		GateMac gateMac = gateMacServiceClient.findByMac(mac);
		if (gateMac == null) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.GATEMAC_NOT_CONFIGURED);
		}
		return gateMac;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public String saveCheckHistoryAndUpdateOrder(Integer storeId, String dagId, List<Order> orderList, List<CheckHistory> checkHistoryList, CheckCreditVo checkCredit, String sequenceNumber)
			throws GlobalErrorInfoException {
		// 保存记录
		checkHistoryService.createBatch(storeId, dagId, checkHistoryList);
		String screenFlag = this.getScreenFlag(checkHistoryList);
		checkCredit.setCheckFlag(CollectionUtils.isNotEmpty(orderList) && StringUtils.isEmpty(screenFlag) ? 0 : 1);
		this.updateOrderAndBuildOrderDelivery(orderList, checkCredit, sequenceNumber);
		return screenFlag;
	}

	@Override
	public List<CheckHistory> selectCheckHistoryList(OrderBo orderBo) {
		List<CheckHistory> checkHistoryList = null;
		CheckHistory checkHistory = checkHistoryService.selectCheckHistoryByUserIdAndOrderId(orderBo.getUserId(), orderBo.getOrderId());
		if (checkHistory != null) {
			String batchNo = checkHistory.getBatchNo();
			checkHistoryList = checkHistoryService.selectCheckHistoryListByBatchNo(batchNo);
		}
		return checkHistoryList;
	}

}
