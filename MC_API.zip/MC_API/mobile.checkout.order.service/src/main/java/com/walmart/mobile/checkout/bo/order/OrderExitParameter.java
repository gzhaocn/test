package com.walmart.mobile.checkout.bo.order;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 出场二维码扫码参数
 * 
 * @author lliao2
 *
 */
@ApiModel(description = "出场二维码扫码扫描参数模型")
public class OrderExitParameter {
	@ApiModelProperty(value = "订单ID", required = true)
	private String orderId;
	@ApiModelProperty(value = "门店ID", required = true)
	private Integer storeId;
	@ApiModelProperty(value = "通道序号", required = true)
	private String sequenceNumber;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(String sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

}
