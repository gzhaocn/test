package com.walmart.mobile.checkout.service;

import java.math.BigInteger;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.walmart.mobile.checkout.entity.GateMac;
import com.walmart.mobile.checkout.repo.GateMacRepository;

/**
 * 
 * @author lliao2
 *
 */
@Service("gateMacService")
public class GateMacService {
	@Autowired
	GateMacRepository gateMacRepository;

	public GateMac findByMac(String mac) {
		return gateMacRepository.findByMac(mac);
	}

	public GateMac findByMacAndSequenceNumber(String mac, String sequenceNumber) {
		return gateMacRepository.findBySequenceNumberAndMac(sequenceNumber, mac);
	}

	public GateMac findOne(BigInteger id) {
		return gateMacRepository.findOne(id);
	}

	public GateMac findBySequenceNumberAndStoreIdAndMac(String sequenceNumber, Integer storeId, String mac) {
		return gateMacRepository.findBySequenceNumberAndStoreIdAndMac(sequenceNumber, storeId, mac);
	}

	public GateMac findBySequenceNumberAndStoreId(String sequenceNumber, Integer storeId) {
		return gateMacRepository.findBySequenceNumberAndStoreId(sequenceNumber, storeId);
	}

	public List<GateMac> findByStoreId(Integer storeId) {
		return gateMacRepository.findByStoreId(storeId);
	}

	public void saveGateMac(GateMac gateMac) {
		gateMacRepository.save(gateMac);
	}

	public void deleteGateMac(GateMac gateMac) {
		gateMacRepository.delete(gateMac.getId());
	}
}
