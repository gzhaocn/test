package com.walmart.mobile.checkout.bo.order;

import java.util.Date;
import java.util.List;

import com.walmart.mobile.checkout.domain.order.Order;
import com.walmart.mobile.checkout.domain.order.OrderLine;

public class OrderCreateResult {

	private String orderId;
	private Date orderDate;
	private List<OrderLine> orderLineList;

	public OrderCreateResult(Order order,List<OrderLine> orderLineList) {
		this.orderId = order.getOrderId();
		this.orderDate = order.getCreatedTime();
		this.orderLineList = orderLineList;
	}
	
	public OrderCreateResult(String orderId,Date orderDate) {
		this.orderId = orderId;
		this.orderDate = orderDate;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public List<OrderLine> getOrderLineList() {
		return orderLineList;
	}

	public void setOrderLineList(List<OrderLine> orderLineList) {
		this.orderLineList = orderLineList;
	}
}
