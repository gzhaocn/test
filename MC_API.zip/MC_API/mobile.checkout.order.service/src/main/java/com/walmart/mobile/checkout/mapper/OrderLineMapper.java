package com.walmart.mobile.checkout.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.walmart.mobile.checkout.bo.order.OrderLineBo;
import com.walmart.mobile.checkout.domain.order.OrderLine;

public interface OrderLineMapper {

	int insert(OrderLine record);

	int insertByBatch(List<OrderLine> orderLineList);

	List<OrderLine> selectOrderLineDetailsByOrderIds(List<String> orderId);

	List<OrderLineBo> selectOrderLineBosByOrderIds(List<String> orderId);

	List<OrderLineBo> selectTopThreeOrderLineBosByOrderIds(List<String> orderId);

	List<OrderLine> selectOrderLineListByOrderId(String orderId);

	OrderLine selectOrderLineByOrderIdAndProductIdAndCartItemId(@Param("orderId") String orderId, @Param("productId") Long productId, @Param("cartItemId") Long cartItemId);

	Integer selectProductCountByOrderId(@Param("orderId") String orderId);

}