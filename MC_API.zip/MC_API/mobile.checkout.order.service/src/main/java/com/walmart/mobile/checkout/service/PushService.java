package com.walmart.mobile.checkout.service;

import java.util.List;

import com.walmart.mobile.checkout.bo.order.MonitorRedisInformation;
import com.walmart.mobile.checkout.bo.order.OrderPushMsg;
import com.walmart.mobile.checkout.domain.order.Order;

public interface PushService {

	/** public void push(PushMessage pushMessage); */
	/**
	 * 推送消息
	 * 
	 * @param pushMessage
	 */
	public void pushByMpns(String pushMessage);

	public void pushMsg(OrderPushMsg orderPushMsg, Integer messageType);

	public void shortPushMsg(Integer messageType, String ldapUserId, String sequenceNumber, Integer storeId, MonitorRedisInformation monitorRedisInformation);

	public void commonComfirmPushMsg(Integer messageType, String ldapUserId, String sequenceNumber, Integer storeId, Order order);

	public void commonComfirmAllPushMsg(Integer messageType, String ldapUserId, String sequenceNumber, Integer storeId, List<Order> orderList);

}
