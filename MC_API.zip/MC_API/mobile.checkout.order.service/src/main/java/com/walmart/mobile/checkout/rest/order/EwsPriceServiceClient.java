package com.walmart.mobile.checkout.rest.order;

import java.util.List;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.walmart.mobile.checkout.domain.StoreVo;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.rest.vo.EwsPriceVo;

@FeignClient("ewsPriceService")
@FunctionalInterface
public interface EwsPriceServiceClient {
	@RequestMapping(method = RequestMethod.GET, value = "/getAllEwsPrice")
	public List<EwsPriceVo> getAllEwsPrice(StoreVo store) throws GlobalErrorInfoException;

}
