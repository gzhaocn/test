package com.walmart.mobile.checkout.bo.order;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * 快捷方式指令参数模型
 * 
 * @author lliao2
 *
 */
@ApiModel(description = "快捷方式指令参数模型")
public class OrderExitActionParameter {
	@ApiModelProperty(value = "门店ID", required = true)
	private Integer storeId;
	@ApiModelProperty(value = "通道序号", required = true)
	private String sequenceNumber;
	@ApiModelProperty(value = "通过原因", required = false)
	private Integer cancelReason;
	@ApiModelProperty(value = "通过文字描述", required = false)
	private String cancelRemark;
	@ApiModelProperty(value = "订单和金额列表", required = true)
	private List<MonitorOrderAmount> monitorOrderAmountList;

	public String getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(String sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public Integer getCancelReason() {
		return cancelReason;
	}

	public void setCancelReason(Integer cancelReason) {
		this.cancelReason = cancelReason;
	}

	public String getCancelRemark() {
		return cancelRemark;
	}

	public void setCancelRemark(String cancelRemark) {
		this.cancelRemark = cancelRemark;
	}

	public List<MonitorOrderAmount> getMonitorOrderAmountList() {
		return monitorOrderAmountList;
	}

	public void setMonitorOrderAmountList(List<MonitorOrderAmount> monitorOrderAmountList) {
		this.monitorOrderAmountList = monitorOrderAmountList;
	}

}
