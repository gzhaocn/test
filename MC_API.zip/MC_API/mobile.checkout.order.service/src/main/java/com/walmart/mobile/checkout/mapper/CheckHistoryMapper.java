package com.walmart.mobile.checkout.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.walmart.mobile.checkout.domain.check.CheckHistory;

public interface CheckHistoryMapper {
	int deleteByPrimaryKey(String checkId);

	int insert(CheckHistory record);

	int insertSelective(CheckHistory record);

	CheckHistory selectByPrimaryKey(String checkId);

	int updateByPrimaryKeySelective(CheckHistory record);

	int updateByPrimaryKey(CheckHistory record);

	List<CheckHistory> selectCheckHistoryListByBatchNo(String batchNo);

	CheckHistory selectCheckHistoryByUserIdAndOrderId(@Param("userId") String userId, @Param("orderId") String orderId);
}