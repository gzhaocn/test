package com.walmart.mobile.checkout.statemachine;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.walmart.mobile.checkout.constant.order.OrderErrorInfoEnum;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;

/**
 * 描述订单 状态。同时作为订单状态机
 * 
 * @author lliao2
 */
public enum OrderStatusEnum {

	/**
	 * 未支付。incorporate(合并) OrderEventType.UNPAID_CANCELL 事件后，订单状态变为
	 * UNPAID_CANCELLED incorporate(合并) OrderEventType.PAY 事件后，订单状态变为 PAYING
	 * incorporate(合并) OrderEventType.TIMEOUT 事件后，订单状态变为 TIMEOUT incorporate(合并)
	 * OrderEventType.PAYROLLBACK 事件后，订单状态变为 PAID
	 */
	UNPAID(1) {
	@Override
	public int nextStatus(int orderEvent) throws GlobalErrorInfoException {
		if (orderEvent == OrderEventTypeEnum.UNPAID_CANCELL.getCode()) {
			// 表示订单状态回退：UNPAID -> UNPAID_CANCELLED
			return OrderStatusEnum.UNPAID_CANCELLED.getValue();
		} else if (orderEvent == OrderEventTypeEnum.PAY.getCode()) {
			// 表示订单状态前进：UNPAID -> PAY
			return OrderStatusEnum.PAYING.getValue();
		} else if (orderEvent == OrderEventTypeEnum.TIMEOUT.getCode()) {
			// 表示订单状态回退：UNPAID -> TIMEOUT
			return OrderStatusEnum.TIMEOUT.getValue();
		} else if (orderEvent == OrderEventTypeEnum.PAYROLLBACK.getCode()) {
			// 表示订单状态回退：UNPAID -> PAID
			return OrderStatusEnum.PAID.getValue();
		} else {
			LOG.error("unpaid Illegal order event type:{} . only accept:{}  or {}", orderEvent, OrderEventTypeEnum.UNPAID_CANCELL, OrderEventTypeEnum.PAY);
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDER_STATUS_CANT_CHANGE);
		}
	}
	},
	/**
	 * 订单支付中。incorporate(合并) OrderEventType.PAYROLLBACK 事件后，订单状态变为 PAID，
	 * incorporate(合并) OrderEventType.TIMEOUT 事件后，订单状态变为 TIMEOUT
	 */
	PAYING(28) {
	@Override
	public int nextStatus(int orderEvent) throws GlobalErrorInfoException {
		if (orderEvent == OrderEventTypeEnum.PAYROLLBACK.getCode()) {
			// 表示订单状态前进：PAYING -> PAID
			return OrderStatusEnum.PAID.getValue();
		} else if (orderEvent == OrderEventTypeEnum.TIMEOUT.getCode()) {
			// 表示订单状态回退：PAYING -> TIMEOUT
			return OrderStatusEnum.TIMEOUT.getValue();
		} else {
			LOG.error("paying Illegal order event type:{} . only accept:{}  or {}", orderEvent, OrderEventTypeEnum.PAY, OrderEventTypeEnum.TIMEOUT);
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDER_STATUS_CANT_CHANGE);
		}
	}
	},

	/**
	 * 订单已支付。incorporate(合并) OrderEventType.PAID_CANCELL 事件后，订单状态变为
	 * PAID_CANCELLED。 incorporate(合并) OrderEventType.SCAN 事件后，订单状态变为 COMPELETE
	 */
	PAID(30) {
	@Override
	public int nextStatus(int orderEvent) throws GlobalErrorInfoException {
		if (orderEvent == OrderEventTypeEnum.PAID_CANCELL.getCode()) {
			// 表示订单状态前进：PAID -> PAID_CANCELLING
			return OrderStatusEnum.PAID_CANCELLING.getValue();
		} else if (orderEvent == OrderEventTypeEnum.SCAN.getCode()) {
			// 表示订单状态回退：PAID -> COMPLETE
			return OrderStatusEnum.COMPLETE.getValue();
		} else {
			LOG.error("paid Illegal order event type:{} . only accept:{}  or {}", orderEvent, OrderEventTypeEnum.PAID_CANCELL, OrderEventTypeEnum.SCAN);
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDER_STATUS_CANT_CHANGE);
		}
	}
	},
	UNPAID_CANCELLED(20) {
	// 允许从20状态变更为28和30状态，覆盖异常情况：用户在没有等到状态变更为28和30时取消了订单，而后paidSyncNotify和支付回调
	// 达到服务器端
	@Override
	public int nextStatus(int orderEvent) throws GlobalErrorInfoException {
		if (orderEvent == OrderEventTypeEnum.PAYROLLBACK.getCode()) {
			// 表示订单状态前进：UNPAID_CANCELLED -> PAID
			return OrderStatusEnum.PAID.getValue();
		} else if (orderEvent == OrderEventTypeEnum.PAY.getCode()) {
			// 表示订单状态前进：UNPAID_CANCELLED -> PAY
			return OrderStatusEnum.PAYING.getValue();
		} else {
			LOG.error("UNPAID_CANCELLED Illegal order event type:{} . only accept:{} or {} ", orderEvent, OrderEventTypeEnum.PAYROLLBACK, OrderEventTypeEnum.PAY);
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDER_STATUS_CANT_CHANGE);
		}
	}
	},
	PAID_CANCELLING(18) {
	@Override
	public int nextStatus(int orderEvent) throws GlobalErrorInfoException {
		// 表示订单状态前进：PAID_CANCELLING -> PAID_CANCELLED
		if (orderEvent == OrderEventTypeEnum.PAID_CANCELL_ROLLBACK.getCode()) {
			return OrderStatusEnum.PAID_CANCELLED.getValue();
		} else {
			LOG.error("PAID_CANCELLING Illegal order event type:{} . only accept:{} ", orderEvent, OrderEventTypeEnum.PAID_CANCELL_ROLLBACK);
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDER_STATUS_CANT_CHANGE);
		}
	}
	}

	,
	PAID_CANCELLED(25) {
	@Override
	public int nextStatus(int orderEvent) throws GlobalErrorInfoException {
		LOG.error("PAID_CANCELLED is the end status ,can't change");
		throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDER_STATUS_CANT_CHANGE);
	}
	},
	COMPLETE(80) {
	@Override
	public int nextStatus(int orderEvent) throws GlobalErrorInfoException {
		LOG.error("COMPLETE is the end status ,can't change");
		throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDER_STATUS_CANT_CHANGE);
	}
	},
	TIMEOUT(10) {
	@Override
	public int nextStatus(int orderEvent) throws GlobalErrorInfoException {
		if (orderEvent == OrderEventTypeEnum.PAYROLLBACK.getCode()) {
			// 表示订单状态前进：TIMEOUT -> PAID
			return OrderStatusEnum.PAID.getValue();
		} else {
			LOG.error("TIMEOUT Illegal order event type:{} . only accept:{} ", orderEvent, OrderEventTypeEnum.PAYROLLBACK);
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDER_STATUS_CANT_CHANGE);
		}
	}
	};

	private static final Logger LOG = LoggerFactory.getLogger(OrderStatusEnum.class);
	private int value;

	private OrderStatusEnum(int value) {
		this.value = value;
	}

	/**
	 * get next order status according to order event
	 *
	 * @param orderEvent
	 *            order event
	 * @return next order status, according to order event, next status maybe
	 *         forward or rollback
	 */
	public abstract int nextStatus(int eventType) throws GlobalErrorInfoException;

	public int getValue() {
		return value;
	}

}