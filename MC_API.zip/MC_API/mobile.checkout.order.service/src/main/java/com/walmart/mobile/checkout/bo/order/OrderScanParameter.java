package com.walmart.mobile.checkout.bo.order;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 出场二维码扫码参数
 * @author lliao2
 *
 */
@ApiModel(description = "出场二维码扫码确认参数模型")
public class OrderScanParameter {
	@ApiModelProperty(value = "应用key", required = true,hidden = true)
	private String appKey;
	@ApiModelProperty(value = "版本号", required = true,hidden = true)
	private String version;
	@ApiModelProperty(value = "数据格式", required = true,hidden = true)
	private String format;
	@ApiModelProperty(value = "时间戳", required = true,hidden = true)
	private String timeStamp;
	@ApiModelProperty(value = "校验码", required = true,hidden = true)
	private String sign;
	@ApiModelProperty(value = "订单ID", required = true)
	private String orderId;
	@ApiModelProperty(value = "MAC地址", required = true,hidden = true)
	private String mac;
	
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getFormat() {
		return format;
	}
	public void setFormat(String format) {
		this.format = format;
	}
	public String getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
	public String getSign() {
		return sign;
	}
	public void setSign(String sign) {
		this.sign = sign;
	}
	public String getAppKey() {
		return appKey;
	}
	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}
	public String getMac() {
		return mac;
	}
	public void setMac(String mac) {
		this.mac = mac;
	}


}
