package com.walmart.mobile.checkout.utils.order;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.walmart.mobile.checkout.bo.order.OrderBo;
import com.walmart.mobile.checkout.domain.order.Order;
import com.walmart.mobile.checkout.domain.order.OrderLine;


public class OrderUtils {
	
	private static final  int DAGSTARTWITH = 7;
	private static final  int STORESTARTWITH = 1;
	private OrderUtils(){}
	
	public static List<String> getOrderIdList(List<Order> orderDetailList) {
		List<String> orderIdList = new ArrayList<>();

		for (Order orderDetail : orderDetailList) {
			orderIdList.add(orderDetail.getOrderId());
		}

		return orderIdList;
	}
	
	public static List<String> getOrderIdBoList(List<OrderBo> orderDetailList) {
		List<String> orderIdList = new ArrayList<>();

		for (OrderBo orderDetail : orderDetailList) {
			orderIdList.add(orderDetail.getOrderId());
		}

		return orderIdList;
	}
	
	
	public static List<Long> getCartItemIdList(List<OrderLine> orderLineList) {
		List<Long> orderIdList = new ArrayList<>();

		for (OrderLine orderDetail : orderLineList) {
			orderIdList.add(orderDetail.getCartItemId());
		}
		return orderIdList;
	}
	
	
	public static String getDagId(String orderId){
		return orderId.substring(DAGSTARTWITH, DAGSTARTWITH+3);
	}
	
	public static int getStoreId(String orderId){
		return Integer.valueOf(orderId.substring(STORESTARTWITH, STORESTARTWITH+4));
	}
	
	public  static Date getReturnBy(int returnWithinDays) {
		Calendar cd = Calendar.getInstance();
		cd.add(Calendar.DATE, returnWithinDays);
		return cd.getTime();
	}

}
