package com.walmart.mobile.checkout.mapper;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.walmart.mobile.checkout.bo.order.OrderBo;
import com.walmart.mobile.checkout.domain.order.Order;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;

public interface OrderMapper {

	int insert(Order order);

	Order selectByPrimaryKey(String orderId);

	int updateByPrimaryKeySelective(Order order);

	int updateOrderStatus(Order order);

	Order selectOrderByOrderId(@Param("orderId") String orderId);

	Order selectOrderByUserIdAndOrderId(@Param("userId") String userId, @Param("orderId") String orderId);

	Order selectOrderByUserIdAndOrderIdAndStoreId(@Param("userId") String userId, @Param("orderId") String orderId, @Param("storeId") Integer storeId);

	List<Order> selectOrderPageByUserId(@Param("userId") String userId, @Param("start") int start, @Param("row") int row);

	int updateOrderStatusByOrderIdAndVersion(@Param("orderId") String orderId, @Param("version") Integer version, @Param("status") Integer status, @Param("payType") Integer payType,
			@Param("paymentCouponFee") BigDecimal paymentCouponFee, @Param("paidTime") Date paidTime);

	public List<OrderBo> selectOrderListbyUserIdAndstatusAndStoreId(@Param("userId") String userId, @Param("status") Integer status, @Param("storeId") Integer storeId);

	public List<Order> queryOrderListbyUserIdAndstatusAndStoreId(@Param("userId") String userId, @Param("status") Integer status, @Param("storeId") Integer storeId);

	int updateTcNumber(@Param("orderId") String orderId, @Param("tcTransTime") Date tcTransTime, @Param("tcSequenceNumber") Integer tcSequenceNumber,
			@Param("tcRegisterNumber") Integer tcRegisterNumber, @Param("tcNumber") String tcNumber, @Param("version") Integer version);

	int updateInvoicePdfUrl(@Param("orderId") String orderId, @Param("invoicePdfUrl") String invoicePdfUrl, @Param("version") Integer version, @Param("invoiceNo") String invoiceNo,
			@Param("invoiceCode") String invoiceCode, @Param("reverseInvoiceUrl") String reverseInvoiceUrl);

	List<Order> selectOrderListByUserIdAndOrderIds(@Param("userId") String userId, @Param("orderIds") List<String> orderIds);

	List<Order> selectOrderListByUserIdAndOrderIdsAndStoreId(@Param("userId") String userId, @Param("orderIds") List<String> orderIds, @Param("storeId") Integer storeId);

	List<Order> selectOrderListByOrderIdsAndStoreId(@Param("orderIds") List<String> orderIds, @Param("storeId") Integer storeId);

	List<Order> queryOrderListByUserId(@Param("userId") String userId);

	int updateScanTimeByOrderList(@Param("orderList") List<Order> orderList) throws GlobalErrorInfoException;

	int updatePaperInvoiceInvoiceNo(@Param("orderId") String orderId, @Param("invoiceNo") String invoiceNo);

	int updateBatchOrderStatusAndScanTime(@Param("orderList") List<Order> orderList) throws GlobalErrorInfoException;

}