package com.walmart.mobile.checkout.repo;

import java.math.BigInteger;
import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.walmart.mobile.checkout.entity.GateMac;

public interface GateMacRepository extends CrudRepository<GateMac, BigInteger> {

	GateMac findByMac(String mac);

	List<GateMac> findByStoreId(Integer storeId);

	GateMac findBySequenceNumberAndStoreIdAndMac(String sequenceNumber, Integer storeId, String mac);

	GateMac findBySequenceNumberAndMac(String sequenceNumber, String mac);

	GateMac findBySequenceNumberAndStoreId(String sequenceNumber, Integer storeId);

}
