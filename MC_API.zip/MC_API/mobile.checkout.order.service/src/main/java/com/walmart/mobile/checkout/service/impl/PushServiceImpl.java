package com.walmart.mobile.checkout.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSON;
import com.walmart.mobile.checkout.bo.order.MonitorRedisInformation;
import com.walmart.mobile.checkout.bo.order.OrderPushMsg;
import com.walmart.mobile.checkout.bo.order.PushMessage;
import com.walmart.mobile.checkout.constant.order.MessageTypeCons;
import com.walmart.mobile.checkout.domain.order.Order;
import com.walmart.mobile.checkout.handler.send.PushSendHandler;
import com.walmart.mobile.checkout.kafka.MsgProducer;
import com.walmart.mobile.checkout.rest.order.LdapServiceClient;
import com.walmart.mobile.checkout.rest.vo.PushMessageVo;
import com.walmart.mobile.checkout.service.PushService;

@Service("pushService")
public class PushServiceImpl implements PushService {
	@Autowired
	RestTemplate restTemplate;

	@Value("${push.url}")
	private String pushUrl;

	@Value("${mpns.push.url}")
	private String mpnsPushUrl;

	@Value("${push.type}")
	private int pushType;

	@Autowired
	PushSendHandler pushSendHandler;

	@Autowired
	LdapServiceClient ldapServiceClient;

	private final AtomicLong msgIdSeq = new AtomicLong(1);
	@Autowired
	private MsgProducer msgProducer;
	@Value("${kafka.enable}")
	private boolean kafkaEnable;

	private static final Logger LOG = LoggerFactory.getLogger(PushServiceImpl.class);
	private static final String SEQUENECE_NUMBER = "sequenceNumber";
	private static final String LDAP_USER_ID = "ldapUserId";
	private static final String STORE_ID = "storeId";

	@Override
	@Async
	public void pushByMpns(String pushMessage) {

		LOG.info("the url is {},msg is {}", mpnsPushUrl, pushMessage);

		PushMessage pushMessage2 = JSON.parseObject(pushMessage, PushMessage.class);
		List<String> userIds = pushMessage2.getUserIds();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

		for (String userId : userIds) {
			PushMessageVo pushMessageVo = new PushMessageVo();
			pushMessageVo.setUserId(userId);
			pushMessageVo.setContent(pushMessage2.getContent());
			pushMessageVo.setBroadcast(pushMessage2.getBroadcast());
			String json = JSON.toJSON(pushMessageVo).toString();

			HttpEntity<String> entity = new HttpEntity<>(json, headers);
			restTemplate.postForObject(mpnsPushUrl, entity, String.class);
		}

	}

	/**
	 * send pushmsg
	 * 
	 * @param orderList
	 * @param storeId
	 * @param sequenceNumber
	 */
	@Override
	public void pushMsg(OrderPushMsg orderPushMsg, Integer messageType) {
		Map<String, Object> map = new HashMap<>(16);
		map.put("mobilePhone", orderPushMsg.getMobilePhone());
		map.put("checkFlag", orderPushMsg.getCheckFlag());
		map.put("userName", orderPushMsg.getUserName());
		map.put(SEQUENECE_NUMBER, orderPushMsg.getSequenceNumber());
		if (messageType == MessageTypeCons.ORDERLIST_EXIST_PUSH) {
			map.put("orderList", orderPushMsg.getOrderList());
			map.put("magneticFlag", orderPushMsg.getMagneticFlag());
		}
		Map<String, Object> messageTypeMap = new HashMap<>(16);
		messageTypeMap.put("data", map);
		messageTypeMap.put("msgKey", UUID.randomUUID().toString().replaceAll("-", "") + Long.toString(msgIdSeq.incrementAndGet()));
		messageTypeMap.put("msgFlag", messageType);
		messageTypeMap.put("sendTime", System.currentTimeMillis());
		messageTypeMap.put("seqId", orderPushMsg.getSeqId());
		messageTypeMap.put("screenFlag", orderPushMsg.getScreenFlag());

		PushMessage pushMessage = new PushMessage();
		List<String> userIds = ldapServiceClient.getUserIds(orderPushMsg.getStoreId());
		String msg = JSON.toJSON(orderPushMsg.getOrderList()).toString();
		String users = JSON.toJSON(userIds).toString();
		LOG.info("the pushMsg userIds is {} ,msg  is {},sequenceNumber is {},checkFlag is {}", users, msg, orderPushMsg.getSequenceNumber(), orderPushMsg.getCheckFlag());
		if (CollectionUtils.isNotEmpty(userIds)) {
			pushMessage.setUserIds(userIds);
			pushMessage.setContent(messageTypeMap);
			pushMessage.setBroadcast("false");
			String json = JSON.toJSON(pushMessage).toString();
			if (pushType == 1) {
				this.pushByMpns(json);
			} else {
				pushSendHandler.sendMessage(json);
			}

			/**
			 * 推送消息发送大数据
			 */
			if (kafkaEnable && messageType == MessageTypeCons.ORDERLIST_NOT_EXIST_PUSH) {
				try {
					msgProducer.send(json);
				} catch (Exception e) {
					LOG.error("kafka send error ,{}", e);
				}
			}

		}

	}

	/**
	 * send pushmsg
	 * 
	 * @param orderList
	 * @param storeId
	 * @param sequenceNumber
	 */
	@Override
	public void shortPushMsg(Integer messageType, String ldapUserId, String sequenceNumber, Integer storeId, MonitorRedisInformation monitorRedisInformation) {
		Map<String, Object> map = new HashMap<>(16);

		map.put(LDAP_USER_ID, ldapUserId);
		map.put(SEQUENECE_NUMBER, sequenceNumber);
		map.put(STORE_ID, storeId);
		map.put("monitorRedisInformation", monitorRedisInformation);

		sendPush(messageType, sequenceNumber, storeId, map);

	}

	@Override
	public void commonComfirmPushMsg(Integer messageType, String ldapUserId, String sequenceNumber, Integer storeId, Order order) {
		Map<String, Object> map = new HashMap<>(16);

		map.put(LDAP_USER_ID, ldapUserId);
		map.put(SEQUENECE_NUMBER, sequenceNumber);
		map.put(STORE_ID, storeId);
		map.put("order", order);

		sendPush(messageType, sequenceNumber, storeId, map);

	}

	@Override
	public void commonComfirmAllPushMsg(Integer messageType, String ldapUserId, String sequenceNumber, Integer storeId, List<Order> orderList) {
		Map<String, Object> map = new HashMap<>(16);

		map.put(LDAP_USER_ID, ldapUserId);
		map.put(SEQUENECE_NUMBER, sequenceNumber);
		map.put(STORE_ID, storeId);
		map.put("orderList", orderList);

		sendPush(messageType, sequenceNumber, storeId, map);

	}

	private void sendPush(Integer messageType, String sequenceNumber, Integer storeId, Map<String, Object> map) {
		Map<String, Object> messageTypeMap = new HashMap<>(16);
		messageTypeMap.put("data", map);
		messageTypeMap.put("msgKey", UUID.randomUUID().toString().replaceAll("-", "") + Long.toString(msgIdSeq.incrementAndGet()));
		messageTypeMap.put("msgFlag", messageType);
		messageTypeMap.put("sendTime", System.currentTimeMillis());

		PushMessage pushMessage = new PushMessage();
		List<String> userIds = new ArrayList<>();
		String pushUserId = storeId + "_" + sequenceNumber;
		userIds.add(pushUserId);
		pushMessage.setUserIds(userIds);
		pushMessage.setContent(messageTypeMap);
		pushMessage.setBroadcast("false");
		String json = JSON.toJSON(pushMessage).toString();

		LOG.info("the pushMsg userId is {} ,sequenceNumber is {},message is {}", pushUserId, sequenceNumber, json);
		if (pushType == 1) {
			this.pushByMpns(json);
		} else {
			pushSendHandler.sendMessage(json);
		}
	}

}
