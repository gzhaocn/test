package com.walmart.mobile.checkout.bo.order;

import java.math.BigDecimal;

public class TransactionRuleParamter {

	private BigDecimal itemAllAmount;
	private Integer shoppingBagQuantity;
	private BigDecimal averageAmount;
	private Integer otherItemQuantity;

	public BigDecimal getItemAllAmount() {
		return itemAllAmount == null ? BigDecimal.ZERO : itemAllAmount;
	}

	public void setItemAllAmount(BigDecimal itemAllAmount) {
		this.itemAllAmount = itemAllAmount;
	}

	public Integer getShoppingBagQuantity() {
		return shoppingBagQuantity == null ? 0 : shoppingBagQuantity;
	}

	public void setShoppingBagQuantity(Integer shoppingBagQuantity) {
		this.shoppingBagQuantity = shoppingBagQuantity;
	}

	public BigDecimal getAverageAmount() {
		return averageAmount == null ? BigDecimal.ZERO : averageAmount;
	}

	public void setAverageAmount(BigDecimal averageAmount) {
		this.averageAmount = averageAmount;
	}

	public Integer getOtherItemQuantity() {
		return otherItemQuantity == null ? 0 : otherItemQuantity;
	}

	public void setOtherItemQuantity(Integer otherItemQuantity) {
		this.otherItemQuantity = otherItemQuantity;
	}

}
