package com.walmart.mobile.checkout.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.walmart.mobile.checkout.domain.order.OrderDiscount;

public interface OrderDiscountMapper {

	int insert(OrderDiscount record);
	
	int insertByBatch(List<OrderDiscount> orderDiscountList);
	
	List<OrderDiscount> selectOrderDiscountList(@Param("productId")Long productId,@Param("orderId")String orderId);
	
	List<OrderDiscount> selectOrderDiscountListByCartItemId(@Param("orderId")String orderId,@Param("cartItemIds") List<Long> cartItemId);
	
	List<OrderDiscount> selectOrderDiscountListByOrderIds(@Param("orderIds") List<String> orderIds);

}