package com.walmart.mobile.checkout.constant.order;

import com.walmart.mobile.checkout.exception.handler.ErrorInfoInterface;

/**
 * 系统及业务级别的错误码
 */
public enum OrderErrorInfoEnum implements ErrorInfoInterface{
    GP_DATA_NOT_EXIST("-200","no promotion info"),
    PRODUCT_DATA_NOT_EXIST("-201","No product info"),
    AMOUNT_NOT_MATCH("-203","order amount not match"),
    DISCOUNT_NOT_MATCH("-204","discount not match"),
    ITEM_NOTSOLD("-205","item notslod"),
    ITEM_OFFER_CHANGE("-206","item offer change"),
    ITEM_PRICE_CHANGE("-207","item price change"),
    INVENTORY_SHORTAGE("-208","item inventory shortage"),
    DISCOUNT_NOT_COMPARE("-209", "clientDiscount not equals serverGpDiscount"),
    GP_GROUP_NOT_ONLYONE("-210", "There can be only one group, but find more than one"),
    BARCODE_AMOUNT_CHANGE("-211", "barcode item amount change"),
    
    ORDER_STATUS_CANT_CHANGE("-212", "order status can't change"),
    ORDER_STATUS_NOT_EXIST("-213", "order status not exist"),
    ORDER_NOT_EXIST("-214", "order or user not exist"),
    CHECKSUM_NOT_COMPARE("-215", "client check sum not equals server check sum"),
    ORDERID_IS_BLANK("-216", "orderId is blank"),
    MAP_NOT_CONTAINSKEY_PRODUCTID("-217", "productIdAndItemNumberMap no containsKey  productId"),
    OVER_RESTRICTIONQTY("-218", "the orderLine qty over the restrictionQty"),
    LDAP_USER_NOT_CONFIGURED_STOREIDGROUP("-219", "ldap user not configured storeId group"),
    GATEMAC_NOT_CONFIGURED("-220", "gate mac not configured"),
    USER_ORDER_NOT_EXIST("-221", "user's order not exist or status is not paid"),
    ORDERPARAM_IS_NULL("-222", "orderParam is null"),
    ORDERLINES_IS_NULL("-223", "orderlines is null"),
    ORDER_AMOUNT_IS_NULL("-224", "order amount is null"),
    CHECKSUM_CRYPTO_FAILED("-225", "check sum crypto failed"),
    SCAN_ORDER_HAS_COMPLETED("-226", "the order has completed or scan_time is not null"),
	ORDERLINE_QUANTITY_LESS_OR_EQUALS_ZERO("-227", "orderline quantity is less or equals zero"),
	PAPER_INVOICE_HAS_CREATE("-228", "paper invoice has create"),
	ORDERS_STATUS_NOT_PAID("-229", "orders status not paid"),
    
    
    TC_NUMBER_NOT_EXIST("-250", "tc number not exist"),
    EGIFT_CARD_CANT_GENERATE_INVOICE("-251", "egiftcard can't generate invoice"),
    MOBILEPHONE_IS_NOT_EXIST("-252", "mobilePhone is not exist"),
    MOBILEPHONE_MATCH_USER_IS_NOT_EXIST("-253", "mobilePhone  match user is not exist"),
    STORE_NOT_SUPPOERT_E_INVOICE("-254", "store not support e_invoice"),
    OVER_TIMNE("-255", "generate invoice over time"),
    ALL_ITEM_HAS_REFUND("-256", "all item has refund"),
    SOME_ITEM_IS_APPLY_REFUND("-257", "some item is apply refund"),
    
    
    
    EWS_PRICE_NOT_EXIST("-260", "ews price not exist"),
    SERVER_EWS_PRICE_NOT_COMPARE_TO_CLIENT_EWS_PRICE("-261", "server ews price not compare to client ews price"),
    EWS_PRICE_CHANGE("-262", "ews price change"),
    
    
    REJECT_ITEM_LIST_IS_EMPTY("-263", "rejectItemList is empty"),
    REJECT_ITEM_OVER_TIME("-264", "reject item over time"),
    REJECT_ITEM_REQYEST_QUANTITY_IS_ZERO("-265", "reject item quailty is zero"),
    REJECT_ITEM_REQYEST_QUANTITY_OVER_ORDER_QUANTITY("-266", "reject all item quailty over order quantity"),
    
    REJECT_ITEM_APPROVE_USER_UNAUTHORIZED("-267", "reject item approve user unAuthorized"),
    REJECT_ITEM_APPROVE_LIST_ISEMPTY("-268", "reject item approve list is empty"),
    REFUND_NOT_FOUND("-269", "not found refund order"),
    PAD_CANCEL_ORDER_NOT_ALLOW_REJECT_APPROVE("-270", "pad reject order not allow reject approve"),
    CURRENT_ORDER_STATUS_NOT_ALLOW_REJECT_APPROVE("-271", "current order status not allow reject approve"),
    ORDER_HAVE_REFUND_RECORD("-272", "order have refund record"),
    ORDER_SHIPPING_FEE_NOT_COMPARE("-273", "order shipping fee not compare"),
    SOME_ITEM_CANT_DELIVERY("-274", "some item cant delivery"),
    DELIVERY_IS_NULL("-275", "delivery  is null"),
    DELIVERYTHRESHOLD_IS_NOT_CONFIG("-276", "deliveryThreShold is not config"),
    SHIPPING_FEE_ITEMLINE_OR_ORDER_SHIPPING_LINE_IS_NULL("-277", "shippingFeeItemLine or ordershippingLine is null"),
    DELIVERYFLAG_IS_ZERO_AND_SHIPPINGFEE_ITEM_LINE_IS_NOT_NULL("-278", "deliveryFlag is zero but shippingFeeItemLine is not null"),
    DELIVERY_STATUS_CANT_REJECT("-279", "delivery status not allow order reject"),
    
    PARAMTER_CONTIANIS_NULL("-280", "paramter contains null"),
    REDIS_OPERATION_NULL("-281", "redis operation is null"),
    ORDERID_AND_MOBILEPHONE_BOTH_NULL("-282", "orderId and mobilePhone both null"),
    OPERATION_ORDER_IS_NOT_MONITOR_ORDER("-283", "operation order is not monitor order"),
    SHORT_CUT_REJECT_SEQNUMBERNUMBER_IS_MUST("-284", "short cut reject sequenceNumber is must"),
    STORE_AND_SEQ_IS_CONFIG("-285", "store and sequnceNumber is config"),
    MAC_IS_CONFIG("-286", "mac is config"),
    MAC_AND_SEQNUMBER_CANT_QUERY("-287", "mac and sequenceNumber can't query result"),
    ALL_ORDER_HAS_DEAL_WITH("-288", "all order has deal with"),
    PARAMTER_NOT_EQUALS("-289", "paramter not equals")
  

    ;


    private String code;

    private String message;

    OrderErrorInfoEnum(String code, String message) {
        this.code = code;
        this.message = message;
    }
    @Override
    public String getCode(){
        return this.code;
    }
    @Override
    public String getMessage(){
        return this.message;
    }
}
