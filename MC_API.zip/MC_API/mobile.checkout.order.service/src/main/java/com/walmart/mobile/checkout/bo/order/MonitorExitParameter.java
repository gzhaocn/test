package com.walmart.mobile.checkout.bo.order;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * monitor二维码扫码参数
 * 
 * @author lliao2
 *
 */
@ApiModel(description = "monitor二维码扫码扫描参数模型")
public class MonitorExitParameter {
	@ApiModelProperty(value = "订单ID", required = true)
	private String orderId;
	@ApiModelProperty(value = "手机号码", required = true)
	private String mobilePhone;
	@ApiModelProperty(value = "消息序号", required = true)
	private String seqId;
	@ApiModelProperty(value = "mac", required = true)
	private String mac;

	@ApiModelProperty(value = "通道号", required = true)
	private String sequnceNumber;

	@ApiModelProperty(value = "调用程序key", required = true)
	private String appKey;
	@ApiModelProperty(value = "调用时间", required = true)
	private Long timeStamp;
	@ApiModelProperty(value = "签名", required = true)
	private String sign;
	@ApiModelProperty(value = "参数格式（如：json）", required = true)
	private String format;
	@ApiModelProperty(value = "版本", required = true)
	private String version;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getAppKey() {
		return appKey;
	}

	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getSeqId() {
		return seqId;
	}

	public void setSeqId(String seqId) {
		this.seqId = seqId;
	}

	public String getMac() {
		return mac;
	}

	public void setMac(String mac) {
		this.mac = mac;
	}

	public String getMobilePhone() {
		return mobilePhone;
	}

	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}

	public Long getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(Long timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getSequnceNumber() {
		return sequnceNumber;
	}

	public void setSequnceNumber(String sequnceNumber) {
		this.sequnceNumber = sequnceNumber;
	}

}
