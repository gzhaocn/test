package com.walmart.mobile.checkout.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.walmart.mobile.checkout.bo.order.OrderLineBo;
import com.walmart.mobile.checkout.domain.order.OrderLine;
import com.walmart.mobile.checkout.domain.order.OrderShippingLine;
import com.walmart.mobile.checkout.domain.order.OrderShippingLineKey;

public interface OrderShippingLineMapper {
	int deleteByPrimaryKey(OrderShippingLineKey key);

	int insert(OrderShippingLine record);

	int insertByBatch(List<OrderShippingLine> orderShippingFeeLineList);

	int insertSelective(OrderShippingLine record);

	OrderShippingLine selectByPrimaryKey(OrderShippingLineKey key);

	int updateByPrimaryKeySelective(OrderShippingLine record);

	int updateByPrimaryKey(OrderShippingLine record);

	List<OrderLineBo> selectOrderShippingLineListByOrderId(String orderId);

	OrderLine selectOrderLineByOrderIdAndItemNumber(@Param("orderId") String orderId, @Param("itemNumber") Long itemNumber);

	List<OrderLine> selectOrderLineByOrderId(@Param("orderId") String orderId);

	OrderLine selectOrderLineByOrderIdAndCartItemIdAndItemNumber(@Param("orderId") String orderId, @Param("cartItemId") Long cartItemId, @Param("itemNumber") Long itemNumber);

	Integer selectProductCountByOrderId(@Param("orderId") String orderId);
}