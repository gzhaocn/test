package com.walmart.mobile.checkout.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.walmart.mobile.checkout.domain.order.OrderEws;
import com.walmart.mobile.checkout.domain.order.OrderEwsKey;


public interface OrderEwsMapper {
    int deleteByPrimaryKey(OrderEwsKey key);

    int insert(OrderEws record);
    
	int insertByBatch(List<OrderEws> orderEwsList);

    int insertSelective(OrderEws record);

    OrderEws selectByPrimaryKey(OrderEwsKey key);

    int updateByPrimaryKeySelective(OrderEws record);

    int updateByPrimaryKey(OrderEws record);
    
	List<OrderEws> selectOrderEwsList(@Param("orderId")String orderId);
	
	List<OrderEws> selectOrderEwsListByOrderIds(@Param("orderIds") List<String> orderIds);
}