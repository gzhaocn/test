package com.walmart.mobile.checkout.service;

import java.util.List;

import com.walmart.mobile.checkout.domain.check.CheckHistory;

public interface CheckHistoryService {
	/**
	 * 创建检查订单历史
	 * 
	 * @param orderParam
	 * @return
	 */
	void create(Integer storeId, String dagId, CheckHistory checkHistory);

	/**
	 * 批量插入
	 * 
	 * @param storeId
	 * @param dagId
	 * @param checkHistoryList
	 */
	void createBatch(Integer storeId, String dagId, List<CheckHistory> checkHistoryList);

	/**
	 * selectCheckHistoryListByBatchNo
	 * 
	 * @param batchNo
	 * @return
	 */
	List<CheckHistory> selectCheckHistoryListByBatchNo(String batchNo);

	/**
	 * selectCheckHistoryByUserIdAndOrderId
	 * 
	 * @param userId
	 * @param orderId
	 * @return
	 */
	CheckHistory selectCheckHistoryByUserIdAndOrderId(String userId, String orderId);

}
