package com.walmart.mobile.checkout.service.impl;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.walmart.mobile.checkout.constant.order.OrderStatus;
import com.walmart.mobile.checkout.domain.order.Order;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.mapper.OrderMapper;
import com.walmart.mobile.checkout.service.OrderStatusService;
import com.walmart.mobile.checkout.statemachine.OrderStatusFactory;
import com.walmart.mobile.checkout.statemachine.OrderStatusIncorporate;

/**
 * orderstatus实现类，用于状态转换校验和保存
 * 
 * @author lliao2 evenType类型 OrderEventTypeEnum { PAY(1), // 支付 TIMEOUT(2), //
 *         超时 PAYROLLBACK(3) , // 支付回调 SCAN(4),//出场扫二维码 PAID_CANCELL(5),//支付取消
 *         UNPAID_CANCELL(6);//未支付取消
 *
 */
@Service("orderStatusService")
public class OrderStatusServiceImpl implements OrderStatusService {
	@Autowired
	OrderMapper orderMapper;
	private static final Logger LOG = LoggerFactory.getLogger(OrderStatusServiceImpl.class);

	@Override
	public int updateOrderStatus(Order order, int eventType) throws GlobalErrorInfoException {

		OrderStatusIncorporate orderStatusIncorporate = new OrderStatusIncorporate(OrderStatusFactory.createOrderStatus(order));
		int status = orderStatusIncorporate.incorporate(eventType);
		order.setStatus(status);

		LOG.info("updateOrderStatus function orderId is {},status is {}", order.getOrderId(), order.getStatus());

		return orderMapper.updateOrderStatus(order);
	}

	@Override
	public int updateOrderStatusByOrderId(String orderId, Integer version, int eventType, BigDecimal paymentCouponFee, Integer payType) throws GlobalErrorInfoException {

		Order order = orderMapper.selectByPrimaryKey(orderId);
		OrderStatusIncorporate orderStatusIncorporate = new OrderStatusIncorporate(OrderStatusFactory.createOrderStatus(order));
		int status = orderStatusIncorporate.incorporate(eventType);
		Date paidTime = null;
		if (status == OrderStatus.PAID) {
			paidTime = new Date();
		}
		LOG.info("updateOrderStatusByOrderId function orderId is {},status is {}", order.getOrderId(), order.getStatus());
		return orderMapper.updateOrderStatusByOrderIdAndVersion(orderId, version, status, payType, paymentCouponFee, paidTime);
	}

	@Override
	public int updateBatchOrderStatusAndScanTime(List<Order> orderList, int eventType, Integer checkFlag, String sequenceNumber) throws GlobalErrorInfoException {
		Date time = new Date();
		for (Order order : orderList) {
			if (checkFlag == 0) {
				OrderStatusIncorporate orderStatusIncorporate = new OrderStatusIncorporate(OrderStatusFactory.createOrderStatus(order));
				int status = orderStatusIncorporate.incorporate(eventType);
				order.setStatus(status);
				order.setCompletedTime(time);

			}
			order.setScanTime(time);
			order.setSequenceNumber(sequenceNumber);
			LOG.info("updateBatchOrderStatusAndScanTime function orderList is {},status is {}", order.getOrderId(), order.getStatus());
		}
		return orderMapper.updateBatchOrderStatusAndScanTime(orderList);
	}

}
