package com.walmart.mobile.checkout.bo.order;

import java.util.List;

import com.walmart.mobile.checkout.domain.order.Order;

public class OrderPushMsg {

	private List<Order> orderList;
	private Integer storeId;
	private String sequenceNumber;
	private Integer checkFlag;
	private String userName;
	private Integer magneticFlag;
	private String mobilePhone;
	private Integer messageType;
	private String seqId;
	private String screenFlag;

	public List<Order> getOrderList() {
		return orderList;
	}

	public void setOrderList(List<Order> orderList) {
		this.orderList = orderList;
	}

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public String getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(String sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public Integer getCheckFlag() {
		return checkFlag;
	}

	public void setCheckFlag(Integer checkFlag) {
		this.checkFlag = checkFlag;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Integer getMagneticFlag() {
		return magneticFlag == null ? 0 : magneticFlag;
	}

	public void setMagneticFlag(Integer magneticFlag) {
		this.magneticFlag = magneticFlag;
	}

	public String getMobilePhone() {
		return mobilePhone;
	}

	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}

	public Integer getMessageType() {
		return messageType;
	}

	public void setMessageType(Integer messageType) {
		this.messageType = messageType;
	}

	public String getSeqId() {
		return seqId;
	}

	public void setSeqId(String seqId) {
		this.seqId = seqId;
	}

	public String getScreenFlag() {
		return screenFlag;
	}

	public void setScreenFlag(String screenFlag) {
		this.screenFlag = screenFlag;
	}

}
