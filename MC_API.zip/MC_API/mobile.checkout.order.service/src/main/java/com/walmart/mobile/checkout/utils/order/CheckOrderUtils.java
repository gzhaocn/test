package com.walmart.mobile.checkout.utils.order;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.walmart.mobile.checkout.bo.order.CheckoutOrderLine;
import com.walmart.mobile.checkout.constant.order.OrderErrorInfoEnum;
import com.walmart.mobile.checkout.constant.order.ValidateOrderResult;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.rest.vo.EwsPriceVo;
import com.walmart.mobile.checkout.rest.vo.InventoryPriceVo;
import com.walmart.mobile.checkout.rest.vo.OfferVo;
import com.walmart.mobile.checkout.rest.vo.ProductDetailVo;
import com.walmart.mobile.checkout.service.impl.OrderServiceImpl;
import com.walmart.mobile.checkout.utils.ScanItemUtil;

public class CheckOrderUtils {
	private static final Logger LOG = LoggerFactory.getLogger(OrderServiceImpl.class);
	public static final int EWS_FLAG = 1;

	private CheckOrderUtils() {
	}

	public static void checkItemStatus(CheckoutOrderLine line) throws GlobalErrorInfoException {
		ProductDetailVo productDetail = line.getProductDetail();
		if (productDetail == null || productDetail.getStatus() != ProductDetailVo.PRODUCT_STATUS_ACTIVE) {

			LOG.info("checkItemStatus upc:{},productId:{},status:{}", line.getUpc(), line.getProductId(), ValidateOrderResult.NOTSOLD);
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ITEM_NOTSOLD);

		}
	}

	/**
	 * 称重商品条码与价格是否一致
	 * 
	 * @param line
	 * @throws GlobalErrorInfoException
	 */
	public static void checkBarCodeAmountChange(CheckoutOrderLine line) throws GlobalErrorInfoException {

		BigDecimal itemAmount = line.getItemAmount();
		Long barCode = line.getBarCode();

		if (itemAmount.subtract(new BigDecimal(String.valueOf(ScanItemUtil.getScanItemPriceWithTaxFormBarCode(barCode)))).compareTo(BigDecimal.ZERO) != 0) {
			LOG.info("checkItemStatus upc:{},productId:{},status:{}", line.getUpc(), line.getProductId(), ValidateOrderResult.BARCODE_AMOUNT_CHANGE);
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.BARCODE_AMOUNT_CHANGE);
		}

	}

	public static void checkItemOfferChange(CheckoutOrderLine line) throws GlobalErrorInfoException {
		List<OfferVo> dbOffers = line.getInvePrice().getGpOffers();
		if (dbOffers == null) {
			dbOffers = new ArrayList<>();
		}

		List<OfferVo> lineOffers = line.getGpOffers();

		if (lineOffers == null) {
			lineOffers = new ArrayList<>();
		}

		if (dbOffers.size() != lineOffers.size()) {
			LOG.info("upc:{},productId:{},status:{}", line.getUpc(), line.getProductId(), ValidateOrderResult.OFFER_CHANGE);
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ITEM_OFFER_CHANGE);
		}

		Collections.sort(dbOffers);
		Collections.sort(lineOffers);
		for (int i = 0; i < lineOffers.size(); i++) {
			if (lineOffers.get(i).getGpOfferId().intValue() != dbOffers.get(i).getGpOfferId().intValue()) {
				LOG.info("upc:{},productId:{},status:{}", line.getUpc(), line.getProductId(), ValidateOrderResult.OFFER_CHANGE);
				throw new GlobalErrorInfoException(OrderErrorInfoEnum.ITEM_OFFER_CHANGE);
			}
		}

	}

	public static void checkEwsPriceChange(CheckoutOrderLine checkOrderLine) throws GlobalErrorInfoException {
		/**
		 * 延保商品必须有ewsPrice记录
		 */
		List<EwsPriceVo> ewsPriceList = checkOrderLine.getEwsPriceList();
		if (CollectionUtils.isEmpty(ewsPriceList)) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.EWS_PRICE_NOT_EXIST);
		}
		// 延保数据比较
		EwsPriceVo ewsPrice = checkOrderLine.getEwsPrice();
		for (EwsPriceVo ewsPriceVo : ewsPriceList) {
			boolean ewsPriceCompare = ewsPriceVo.getItemNumber().equals(ewsPrice.getItemNumber())
					&& (ewsPriceVo.getStartPrice().compareTo(ewsPrice.getStartPrice()) != 0 || ewsPriceVo.getEndPrice().compareTo(ewsPrice.getEndPrice()) != 0 || ewsPriceVo.getExtendedWarrantyPrice()
							.compareTo(ewsPrice.getExtendedWarrantyPrice()) != 0);
			if (ewsPriceCompare) {
				throw new GlobalErrorInfoException(OrderErrorInfoEnum.EWS_PRICE_CHANGE);

			}
		}
	}

	/**
	 * 金额比较
	 * 
	 * @param line
	 * @param invePrice
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	public static void checkItemPriceChange(CheckoutOrderLine line) throws GlobalErrorInfoException {
		InventoryPriceVo invePrice = line.getInvePrice();
		BigDecimal appPriceWithTax = line.getPriceWithTax();

		BigDecimal dbPriceWithTax = new BigDecimal(invePrice.getPriceWithTax().toString());

		if ((line.getPriceWithTax() == null) || (invePrice.getPriceWithTax() == null)) {
			LOG.info("upc:{},productId:{},status:{},orderPrice:{},currentPrice:{},inventory:{}, itemNumber:{}", line.getUpc(), line.getProductId(), ValidateOrderResult.PRICE_CHANGE, appPriceWithTax,
					dbPriceWithTax, invePrice.getInventory(), invePrice.getItemNumber());
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ITEM_PRICE_CHANGE);
		}

		if (appPriceWithTax.compareTo(dbPriceWithTax) != 0) {
			LOG.info("upc:{},productId:{},status:{},orderPrice:{},currentPrice:{},inventory:{}, itemNumber:{}", line.getUpc(), line.getProductId(), ValidateOrderResult.PRICE_CHANGE, appPriceWithTax,
					dbPriceWithTax, invePrice.getInventory(), invePrice.getItemNumber());
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ITEM_PRICE_CHANGE);
		}

	}

	/**
	 * 检查是否限制购买或者不在该门店售卖
	 * 
	 * @param line
	 * @throws GlobalErrorInfoException
	 */

	public static void checkItemInventory(CheckoutOrderLine line) throws GlobalErrorInfoException {
		InventoryPriceVo dbItem = line.getInvePrice();
		if (dbItem.getStockStatus() == InventoryPriceVo.CLIENT_STOCK_RESTRICTED_PURCHASE) {
			LOG.info("upc:{},productId:{},status:{},stockStatus:{}", line.getUpc(), line.getProductId(), ValidateOrderResult.INVENTORY_SHORTAGE, InventoryPriceVo.STOCK_STATUS_NOT_AVAILIABLE_IN_STORE);
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.INVENTORY_SHORTAGE);
		}

	}

	/**
	 * 数量限制
	 * 
	 * @param line
	 * @param invePrice
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	public static void checkItemQuantity(CheckoutOrderLine line) throws GlobalErrorInfoException {
		int orderQuantity = line.getOrderQuantity();
		InventoryPriceVo invePrice = line.getInvePrice();
		if (orderQuantity > invePrice.getRestrictionQty().intValue()) {
			LOG.error("upc:{}, itemNumber:{},status:{}", line.getUpc(), invePrice.getItemNumber(), ValidateOrderResult.OVER_RESTRICTIONQTY);
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.OVER_RESTRICTIONQTY);
		}
	}

}
