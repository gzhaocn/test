package com.walmart.mobile.checkout.rest.order;

import java.util.List;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.walmart.mobile.checkout.rest.vo.GpOfferVo;

@FeignClient("gpOfferService")
public interface GpOfferServiceClient {

	@RequestMapping(method = RequestMethod.GET, value = "/findByGpOfferIdInAndStatus")
	List<GpOfferVo>  findByGpOfferIdInAndStatus(@RequestParam(value = "offerIdList") List<Integer> offerIdList,
			 @RequestParam(value = "status")  Integer status)  ;

	@RequestMapping(method = RequestMethod.GET, value = "/findByGpOfferIdAndStatus")
	GpOfferVo findByGpOfferIdAndStatus(@RequestParam(value = "gpOfferId")int gpOfferId, @RequestParam(value = "status")Integer status);
	
	
	@RequestMapping(method = RequestMethod.GET, value = "/gpOfferSave")
	 void gpOfferSave(@RequestParam(value = "gpOffer") GpOfferVo gpOffer);
	
	
	@RequestMapping(method = RequestMethod.GET, value = "/gpOfferListsave")
	 void gpOfferListsave(@RequestParam(value = "gpOfferList") List<GpOfferVo> gpOfferList);
}


