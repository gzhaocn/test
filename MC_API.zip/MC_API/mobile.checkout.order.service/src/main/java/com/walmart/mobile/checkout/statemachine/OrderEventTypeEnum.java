package com.walmart.mobile.checkout.statemachine;

/**
 * 订单事件类型
 */
public enum OrderEventTypeEnum {
	/**
	 * 支付
	 */
    PAY(1),   
    /**
     * 超时
     */
    TIMEOUT(2),   
    /**
     * 支付回调
     */
    PAYROLLBACK(3) ,  
    /**
     * 出场扫二维码通过动作
     */
    SCAN(4),
    /**
     * 支付取消
     */
    PAID_CANCELL(5),
    /**
     * 未支付取消
     */
    UNPAID_CANCELL(6),
    /**
     * 支付取消回调
     */
    PAID_CANCELL_ROLLBACK(7);
    
    private int code;
	
	OrderEventTypeEnum(int code) {
		this.code = code;
	}

	public int getCode() {
		return this.code;
	}

    
}