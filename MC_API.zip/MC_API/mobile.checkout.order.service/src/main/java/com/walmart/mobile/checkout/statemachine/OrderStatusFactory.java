package com.walmart.mobile.checkout.statemachine;

import com.walmart.mobile.checkout.constant.order.OrderErrorInfoEnum;
import com.walmart.mobile.checkout.constant.order.OrderStatus;
import com.walmart.mobile.checkout.domain.order.Order;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;

/**
 * 订单状态工厂类，根据订单状态找到对应的enum值
 * 
 * @author lliao2
 *
 */
public class OrderStatusFactory {

	private OrderStatusFactory() {
	}

	public static OrderStatusEnum createOrderStatus(Order order) throws GlobalErrorInfoException {
		switch (order.getStatus()) {
		case OrderStatus.UNPAID:
			return OrderStatusEnum.UNPAID;
		case OrderStatus.PAYING:
			return OrderStatusEnum.PAYING;
		case OrderStatus.TIMEOUT:
			return OrderStatusEnum.TIMEOUT;
		case OrderStatus.PAID:
			return OrderStatusEnum.PAID;
		case OrderStatus.COMPLETE:
			return OrderStatusEnum.COMPLETE;
		case OrderStatus.PAID_CANCELLED:
			return OrderStatusEnum.PAID_CANCELLED;
		case OrderStatus.UNPAID_CANCELLED:
			return OrderStatusEnum.UNPAID_CANCELLED;
		case OrderStatus.PAID_CANCELLING:
			return OrderStatusEnum.PAID_CANCELLING;
		default:
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDER_STATUS_NOT_EXIST);
		}
	}

}
