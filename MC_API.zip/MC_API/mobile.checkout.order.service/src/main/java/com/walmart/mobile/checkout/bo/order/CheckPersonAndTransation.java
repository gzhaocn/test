package com.walmart.mobile.checkout.bo.order;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.walmart.mobile.checkout.domain.check.CheckHistory;
import com.walmart.mobile.checkout.domain.order.Order;
import com.walmart.mobile.checkout.rest.vo.CheckCreditVo;

public class CheckPersonAndTransation {
	private String batchNo;
	private Date createTime;
	private String userId;
	private List<Order> orderList;
	private List<CheckHistory> checkHistoryList;
	private CheckCreditVo checkCredit;
	private BigDecimal itemAllAmount;
	private Integer shoppingBagQuantity;
	private BigDecimal averageAmount;
	private Integer otherItemQuantity;
	private Map<String, Long> minuteMap;

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public List<Order> getOrderList() {
		return orderList;
	}

	public void setOrderList(List<Order> orderList) {
		this.orderList = orderList;
	}

	public List<CheckHistory> getCheckHistoryList() {
		return checkHistoryList;
	}

	public void setCheckHistoryList(List<CheckHistory> checkHistoryList) {
		this.checkHistoryList = checkHistoryList;
	}

	public CheckCreditVo getCheckCredit() {
		return checkCredit;
	}

	public void setCheckCredit(CheckCreditVo checkCredit) {
		this.checkCredit = checkCredit;
	}

	public BigDecimal getItemAllAmount() {
		return itemAllAmount;
	}

	public void setItemAllAmount(BigDecimal itemAllAmount) {
		this.itemAllAmount = itemAllAmount;
	}

	public Integer getShoppingBagQuantity() {
		return shoppingBagQuantity;
	}

	public void setShoppingBagQuantity(Integer shoppingBagQuantity) {
		this.shoppingBagQuantity = shoppingBagQuantity;
	}

	public BigDecimal getAverageAmount() {
		return averageAmount;
	}

	public void setAverageAmount(BigDecimal averageAmount) {
		this.averageAmount = averageAmount;
	}

	public Integer getOtherItemQuantity() {
		return otherItemQuantity;
	}

	public void setOtherItemQuantity(Integer otherItemQuantity) {
		this.otherItemQuantity = otherItemQuantity;
	}

	public Map<String, Long> getMinuteMap() {
		return minuteMap;
	}

	public void setMinuteMap(Map<String, Long> minuteMap) {
		this.minuteMap = minuteMap;
	}

}
