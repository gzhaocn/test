package com.walmart.mobile.checkout.service;

import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.walmart.mobile.checkout.mapper.SequenceMapper;

@Service
public class IdService {

	@Autowired
	private SequenceMapper sequenceMapper;

	private static final String STORE_NO_FORMAT = "%04d";
	private static final String ORDER_SEQ_NAME = "order_seq";
	private static final String REFUND_SEQ_NAME = "refund_seq";
	private static final String BATCHNO_SEQ_NAME = "batchno_seq";

	private static final String CHECK_HISTORY_SEQ_NAME = "check_history_seq";

	private static final String ORDERS_ID_FORMAT = "%08d";
	private static final String ORDERS_ID_RND_FORMAT = "%02d";

	private static final int MAX_SEQUENCE_VALUE = 100000000;

	@Value("${orderId.seq}")
	private String orderIdSeq;

	private String fixStoreNum(int storeNbr) {
		return String.format(STORE_NO_FORMAT, storeNbr);
	}

	/**
	 * 构造订单号(20位)，格式为：5为店号(01059)+2位年(yy)+3为DAG(001)+10位SEQ(其中8位是MSSQLServer SEQ
	 * +两位随机数)+1位系统编号（系统环境编号1：开发、2：QA、3：STAGE、8：生产）
	 * 
	 * @param storeNbr
	 * @param dagid
	 * @return
	 */
	public String buildOrderId(int storeNbr, String dagId) {
		StringBuilder builder = new StringBuilder();
		long seq = getNextOrderSeq();
		String storeId;
		if (String.valueOf(storeNbr).length() < 5) {
			storeId = orderIdSeq + fixStoreNum(storeNbr);
		} else {
			storeId = String.valueOf(storeNbr);
		}
		builder.append(storeId).append(new SimpleDateFormat("yy").format(new Date())).append(dagId).append(String.format(ORDERS_ID_FORMAT, seq))
				.append(String.format(ORDERS_ID_RND_FORMAT, new SecureRandom().nextInt(100)));

		return builder.toString();
	}

	/**
	 * 获取下一个可用的订单Sequence值.
	 * 
	 * @return
	 */
	private long getNextOrderSeq() {
		long seq = sequenceMapper.getSeq(ORDER_SEQ_NAME);
		if (seq >= MAX_SEQUENCE_VALUE) {
			seq = seq % MAX_SEQUENCE_VALUE;
		}
		return seq;
	}

	/**
	 * 构造退货号， 格式为：5为店号(01059)+2位年(yy)+3为DAG(001)+10位SEQ(其中8位是MSSQLServer SEQ
	 * +两位随机数)+1位系统编号（系统环境编号1：开发、2：QA、3：STAGE、8：生产）
	 * 
	 * @param storeNbr
	 * @param dagid
	 * @return
	 */
	public String buildRefundId(int storeNbr, String dagId) {
		StringBuilder builder = new StringBuilder();
		long seq = getNextRefundSeq();
		String storeId;
		if (String.valueOf(storeNbr).length() < 5) {
			storeId = orderIdSeq + fixStoreNum(storeNbr);
		} else {
			storeId = String.valueOf(storeNbr);
		}
		builder.append(storeId).append(new SimpleDateFormat("yy").format(new Date())).append(dagId).append(String.format(ORDERS_ID_FORMAT, seq))
				.append(String.format(ORDERS_ID_RND_FORMAT, new SecureRandom().nextInt(100)));
		return builder.toString();
	}

	/**
	 * 构造checkHistory 格式为：5为店号(01059)+2位年(yy)+3为DAG(001)+10位SEQ(其中8位是MSSQLServer
	 * SEQ +两位随机数)+1位系统编号（系统环境编号1：开发、2：QA、3：STAGE、8：生产）
	 * 
	 * @param storeNbr
	 * @param dagid
	 * @return
	 */
	public String buildCheckHistoryId(int storeNbr, String dagId) {
		StringBuilder builder = new StringBuilder();
		long seq = getNextCheckHistorySeq();
		String storeId;
		if (String.valueOf(storeNbr).length() < 5) {
			storeId = orderIdSeq + fixStoreNum(storeNbr);
		} else {
			storeId = String.valueOf(storeNbr);
		}
		builder.append(storeId).append(new SimpleDateFormat("yyMM").format(new Date())).append(dagId).append(String.format(ORDERS_ID_FORMAT, seq))
				.append(String.format(ORDERS_ID_RND_FORMAT, new SecureRandom().nextInt(100)));
		return builder.toString();
	}

	/**
	 * 获取下一个可用的checkHistory Sequence值.
	 * 
	 * @return
	 */
	private long getNextCheckHistorySeq() {
		return sequenceMapper.getSeq(CHECK_HISTORY_SEQ_NAME);
	}

	/**
	 * 获取下一个可用的退货Sequence值.
	 * 
	 * @return
	 */
	private long getNextRefundSeq() {
		long seq = sequenceMapper.getSeq(REFUND_SEQ_NAME);
		if (seq >= MAX_SEQUENCE_VALUE) {
			seq = seq % MAX_SEQUENCE_VALUE;
		}
		return seq;
	}

	/**
	 * 构造退货批次号， 格式为：5为店号(01059)+2位年(yy)+3为DAG(001)+10位SEQ(其中8位是MSSQLServer SEQ
	 * +两位随机数)+1位系统编号（系统环境编号1：开发、2：QA、3：STAGE、8：生产）
	 * 
	 * @param storeNbr
	 * @param dagid
	 * @return
	 */
	public String buildBatchNo(int storeNbr, String dagId) {
		StringBuilder builder = new StringBuilder();
		long seq = getNextBatchNoSeq();
		String storeId;
		if (String.valueOf(storeNbr).length() < 5) {
			storeId = orderIdSeq + fixStoreNum(storeNbr);
		} else {
			storeId = String.valueOf(storeNbr);
		}
		builder.append(storeId).append(new SimpleDateFormat("yy").format(new Date())).append(dagId).append(String.format(ORDERS_ID_FORMAT, seq))
				.append(String.format(ORDERS_ID_RND_FORMAT, new SecureRandom().nextInt(100)));
		return builder.toString();
	}

	/**
	 * 获取下一个可用的退货Sequence值.
	 * 
	 * @return
	 */
	private long getNextBatchNoSeq() {
		long seq = sequenceMapper.getSeq(BATCHNO_SEQ_NAME);
		if (seq >= MAX_SEQUENCE_VALUE) {
			seq = seq % MAX_SEQUENCE_VALUE;
		}
		return seq;
	}

}
