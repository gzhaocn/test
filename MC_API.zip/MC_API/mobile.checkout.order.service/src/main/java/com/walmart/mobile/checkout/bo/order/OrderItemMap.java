package com.walmart.mobile.checkout.bo.order;

import java.util.List;
import java.util.Map;

import com.walmart.mobile.checkout.rest.vo.InventoryPriceVo;
import com.walmart.mobile.checkout.rest.vo.NoDeliverItemVo;
import com.walmart.mobile.checkout.rest.vo.SpecialItemVo;

public class OrderItemMap {

	private Map<Long, InventoryPriceVo> inventoryPriceMap;

	private List<Long> itemNumberList;

	private Map<Long, Long> productIdAndItemNumberMap;
	private Map<Integer, Integer> gpOfferIdAndLinkSaveIdMap;

	private Map<Long, SpecialItemVo> upcAndSpecialItemMap;

	private Integer magneticFlag;

	private Map<Long, NoDeliverItemVo> noDeliverItemMap;

	public List<Long> getItemNumberList() {
		return itemNumberList;
	}

	public void setItemNumberList(List<Long> itemNumberList) {
		this.itemNumberList = itemNumberList;
	}

	public Map<Long, InventoryPriceVo> getInventoryPriceMap() {
		return inventoryPriceMap;
	}

	public void setInventoryPriceMap(Map<Long, InventoryPriceVo> inventoryPriceMap) {
		this.inventoryPriceMap = inventoryPriceMap;
	}

	public Map<Long, Long> getProductIdAndItemNumberMap() {
		return productIdAndItemNumberMap;
	}

	public void setProductIdAndItemNumberMap(Map<Long, Long> productIdAndItemNumberMap) {
		this.productIdAndItemNumberMap = productIdAndItemNumberMap;
	}

	public Map<Integer, Integer> getGpOfferIdAndLinkSaveIdMap() {
		return gpOfferIdAndLinkSaveIdMap;
	}

	public void setGpOfferIdAndLinkSaveIdMap(Map<Integer, Integer> gpOfferIdAndLinkSaveIdMap) {
		this.gpOfferIdAndLinkSaveIdMap = gpOfferIdAndLinkSaveIdMap;
	}

	public Map<Long, SpecialItemVo> getUpcAndSpecialItemMap() {
		return upcAndSpecialItemMap;
	}

	public void setUpcAndSpecialItemMap(Map<Long, SpecialItemVo> upcAndSpecialItemMap) {
		this.upcAndSpecialItemMap = upcAndSpecialItemMap;
	}

	public Integer getMagneticFlag() {
		return magneticFlag == null ? 0 : magneticFlag;
	}

	public void setMagneticFlag(Integer magneticFlag) {
		this.magneticFlag = magneticFlag;
	}

	public Map<Long, NoDeliverItemVo> getNoDeliverItemMap() {
		return noDeliverItemMap;
	}

	public void setNoDeliverItemMap(Map<Long, NoDeliverItemVo> noDeliverItemMap) {
		this.noDeliverItemMap = noDeliverItemMap;
	}

}
