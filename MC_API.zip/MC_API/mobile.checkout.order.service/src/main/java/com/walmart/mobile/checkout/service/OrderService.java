package com.walmart.mobile.checkout.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.walmart.mobile.checkout.bo.order.CheckPersonAndTransation;
import com.walmart.mobile.checkout.bo.order.MonitorExitParameter;
import com.walmart.mobile.checkout.bo.order.MonitorOrderAmount;
import com.walmart.mobile.checkout.bo.order.MonitorRedisInformation;
import com.walmart.mobile.checkout.bo.order.OrderBo;
import com.walmart.mobile.checkout.bo.order.OrderCreateResult;
import com.walmart.mobile.checkout.bo.order.OrderLineBo;
import com.walmart.mobile.checkout.bo.order.OrderParameter;
import com.walmart.mobile.checkout.bo.order.OrderPushMsg;
import com.walmart.mobile.checkout.bo.order.OrderRefundBo;
import com.walmart.mobile.checkout.bo.order.TransactionRuleParamter;
import com.walmart.mobile.checkout.domain.StoreVo;
import com.walmart.mobile.checkout.domain.check.CheckHistory;
import com.walmart.mobile.checkout.domain.order.Order;
import com.walmart.mobile.checkout.domain.order.OrderEws;
import com.walmart.mobile.checkout.domain.order.OrderLine;
import com.walmart.mobile.checkout.entity.GateMac;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.rest.vo.CheckCreditVo;
import com.walmart.mobile.checkout.rest.vo.StoreShoppingBagForItemVo;

public interface OrderService {
	/**
	 * 创建订单
	 * 
	 * @param orderParam
	 * @return
	 */
	OrderCreateResult create(OrderParameter orderParam);

	/**
	 * 根据订单ID查询订单信息
	 * 
	 * @param orderId
	 * @return
	 */
	Order getOrderByOrderId(String orderId);

	/**
	 * 根据订单ID查询orderLine信息
	 * 
	 * @param orderId
	 * @return
	 */
	List<OrderLine> selectOrderLineListByOrderId(String orderId);

	/**
	 * 修改订单信息
	 * 
	 * @param record
	 * @return
	 */
	int updateByPrimaryKeySelective(Order record);

	/**
	 * 跟新TCNUMBER
	 * 
	 * @param orderId
	 * @param tcTransTime
	 * @param tcSequenceNumber
	 * @param tcRegisterNumber
	 * @param tcNumber
	 * @param version
	 * @return
	 */
	int updateTcNumber(String orderId, Date tcTransTime, Integer tcSequenceNumber, Integer tcRegisterNumber, String tcNumber, Integer version) throws GlobalErrorInfoException;

	/**
	 * 跟新pdfurl
	 * 
	 * @param orderId
	 * @param invoicePdfUrl
	 * @param version
	 * @param invoiceNo
	 * @param invoiceCode
	 * @param reverseInvoiceUrl
	 * @return
	 */
	int updateInvoicePdfUrl(String orderId, String invoicePdfUrl, Integer version, String invoiceNo, String invoiceCode, String reverseInvoiceUrl);

	/**
	 * 纸质发票提交记录
	 * 
	 * @param orderId
	 * @param invoiceNo
	 * @return
	 */
	int updatePaperInvoiceInvoiceNo(String orderId, String invoiceNo);

	/**
	 * 分页查询订单信息
	 * 
	 * @param start
	 * @param row
	 * @param userId
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	List<OrderBo> getOrderListByPagination(int start, int row, String userId) throws GlobalErrorInfoException;

	/**
	 * 分页查询订单信息
	 * 
	 * @param start
	 * @param row
	 * @param userId
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	List<OrderBo> getOrderListByPaginationV2(int start, int row, String userId) throws GlobalErrorInfoException;

	/**
	 * 批量查询订单信息
	 * 
	 * @param orderList
	 * @return
	 */
	List<OrderBo> getOrderBoList(List<Order> orderList);

	/**
	 * 根据orderId和userId查询订单信息,组装的是orderEws的信息
	 * 
	 * @param userId
	 * @param orderId
	 * @return
	 */
	OrderBo requestOrderDetailByUserIdAndOrderId(String userId, String orderId);

	/**
	 * 根据orderId和userId查询订单信息,组装的是orderEwsLine的信息,过机和发票使用
	 * 
	 * @param userId
	 * @param orderId
	 * @return
	 */
	OrderBo requestOrderDetailByUserIdAndOrderIdForPassMachine(String userId, String orderId);

	/**
	 * 根据userId查询对应的多个订单信息
	 * 
	 * @param userId
	 * @param orderIds
	 * @return
	 */
	List<Order> selectOrderListByUserIdAndOrderIds(String userId, List<String> orderIds);

	/**
	 * 根据userId和门店Id查询对应的多个订单信息
	 * 
	 * @param userId
	 * @param orderIds
	 * @param storeId
	 * @return
	 */
	List<Order> selectOrderListByUserIdAndOrderIdsAndStoreId(String userId, List<String> orderIds, Integer storeId);

	/**
	 * 根据门店Id查询对应的多个订单信息
	 * 
	 * @param orderIds
	 * @param storeId
	 * @return
	 */
	List<Order> selectOrderListByOrderIdsAndStoreId(List<String> orderIds, Integer storeId);

	/**
	 * 根据userId和orderId查询订单信息
	 * 
	 * @param userId
	 * @param orderId
	 * @return
	 */
	Order selectOrderByUserIdAndOrderId(String userId, String orderId);

	/**
	 * 根据userId和orderId、storeId查询订单信息
	 * 
	 * @param userId
	 * @param orderId
	 * @param storeId
	 * @return
	 */
	Order selectOrderByUserIdAndOrderIdAndStoreId(String userId, String orderId, Integer storeId);

	/**
	 * 未支付取消订单
	 * 
	 * @param order
	 * @param reasonId
	 * @throws GlobalErrorInfoException
	 */
	void unPaidCancel(Order order, int reasonId) throws GlobalErrorInfoException;

	/**
	 * 根据userId和status、storeId查询订单信息
	 * 
	 * @param userId
	 * @param status
	 * @param storeId
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	List<String> selectOrderListbyUserIdAndstatusAndChangeStatus(String userId, Integer status, Integer storeId) throws GlobalErrorInfoException;

	/**
	 * List<OrderBo> selectOrderListbyUserIdAndstatusNoChangeStatus(String
	 * userId, Integer status, Integer storeId) throws GlobalErrorInfoException;
	 */
	/**
	 * 批量修改订单信息
	 * 
	 * @param orderList
	 * @throws GlobalErrorInfoException
	 */
	void updateStatusByOrderIds(List<Order> orderList, Integer cancelReason, String cancelRemark) throws GlobalErrorInfoException;

	/**
	 * 批量修改订单状态到完成
	 * 
	 * @param orderList
	 * @throws GlobalErrorInfoException
	 */
	void completeOrderList(List<Order> orderList) throws GlobalErrorInfoException;

	/**
	 * 计算订单item数量
	 * 
	 * @param orderList
	 * @throws GlobalErrorInfoException
	 */

	void setItemSize(List<Order> orderList) throws GlobalErrorInfoException;

	/**
	 * 查询订单信息
	 * 
	 * @param order
	 * @return
	 */
	OrderBo requestOrderDetailByOrder(Order order);

	/**
	 * 批量查询orderLine信息，根据orderIds
	 * 
	 * @param orderIds
	 * @return
	 */
	List<OrderLine> selectOrderLineDetailsByOrderIds(List<String> orderIds);

	/**
	 * 修改订单状态
	 * 
	 * @param order
	 * @throws GlobalErrorInfoException
	 */
	int updateStatusByOrder(Order order) throws GlobalErrorInfoException;

	/**
	 * 更新订单扫描时间
	 * 
	 * @param orderList
	 * @throws GlobalErrorInfoException
	 */
	void updateScanTimeByOrderList(List<Order> orderList) throws GlobalErrorInfoException;

	/**
	 * 修改订单状态到支付取消中
	 * 
	 * @param order
	 * @throws GlobalErrorInfoException
	 */
	void updateStatusByOrderCancelling(Order order) throws GlobalErrorInfoException;

	/**
	 * 根据userId查询订单详情
	 * 
	 * @param userId
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	List<OrderBo> selectOrderListByUserId(String userId) throws GlobalErrorInfoException;

	/**
	 * 根据userId和status、storeId查询订单详情
	 * 
	 * @param userId
	 * @param status
	 * @param storeId
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	List<OrderBo> selectOrderListbyUserIdAndstatusAndStoreId(String userId, Integer status, Integer storeId) throws GlobalErrorInfoException;

	/**
	 * 根据userId和status、storeId查询订单详情
	 * 
	 * @param userId
	 * @param status
	 * @param storeId
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	List<Order> queryOrderListbyUserIdAndstatusAndStoreId(String userId, Integer status, Integer storeId) throws GlobalErrorInfoException;

	/**
	 * 根据orderId,ProductId,cartItemId查询orderline信息
	 * 
	 * @param orderId
	 * @param productId
	 * @param cartItemId
	 * @return
	 */
	OrderLine selectOrderLineByOrderIdAndProductIdAndCartItemId(String orderId, Long productId, Long cartItemId);

	/**
	 * 根据orderId,itemNumber查询orderEwsline信息
	 * 
	 * @param orderId
	 * @param itemNumber
	 * @return
	 */
	OrderLine selectOrderLineByOrderIdAndItemNumber(String orderId, Long itemNumber);

	/**
	 * 根据orderId查询orderEwsline信息
	 * 
	 * @param orderId
	 * @param itemNumber
	 * @return
	 */
	List<OrderLine> selectOrderEwsLineByOrderId(String orderId);

	/**
	 * 统计订单中所有的商品数量
	 * 
	 * @param orderId
	 * @return
	 */
	Integer selectProductCountByOrderId(String orderId);

	/**
	 * 计算orderAmount
	 * 
	 * @param order
	 * @return
	 */
	BigDecimal calcOrderAmount(Order order);

	/**
	 * 构建orderPushMsg
	 * 
	 * @param orderExitParameter
	 * @param orderList
	 * @param orderScanTime
	 * @param messageType
	 * @param checkCredit
	 * @param mobilePhone
	 * @return
	 */
	OrderPushMsg buildOrderPushMsg(Integer storeId, String sequenceNumber, List<Order> orderList, Integer messageType, CheckCreditVo checkCredit, String mobilePhone, String seqId, String screenFlag);

	/**
	 * 批量修改订单扫描时间和状态
	 * 
	 * @param orderList
	 * @param eventType
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	void updateBatchOrderStatusAndScanTime(List<Order> orderList, int eventType, Integer checkFlag, String sequenceNumber) throws GlobalErrorInfoException;

	/**
	 * 构建orderLineMap
	 * 
	 * @param orderId
	 * @param orderRefundBo
	 * @return
	 */
	Map<Long, OrderLine> getOrderLineMap(String orderId, OrderRefundBo orderRefundBo, Map<Long, Long> itemNumberAndCartItemIdMap);

	/**
	 * 查询延保关联关系
	 * 
	 * @param orderId
	 * @return
	 */
	List<OrderEws> selectOrderEwsList(String orderId);

	/**
	 * 发送配送单创建信息
	 * 
	 * @param orderParameter
	 * @param createOrderResult
	 */
	void sendOrderDeliveryMessage(OrderCreateResult createOrderResult, OrderParameter orderParameter);

	/**
	 * 防止消息过大，修改为30单发送一次
	 * 
	 * @param orderExitParameter
	 * @param orderList
	 * @param messageType
	 * @param checkCredit
	 */
	void batchSendPushMsg(Integer storeId, String sequenceNumber, List<Order> orderList, Integer messageType, CheckCreditVo checkCredit, String seqId, String mobilePhone, String screenFlag);

	/**
	 * 修改运单状态到已支付
	 * 
	 * @param orderList
	 */
	void paidDelivery(List<Order> orderList);

	/**
	 * 根据userID\STATUS\STOREID查询订单信息
	 */
	List<Order> exitSelectOrderListbyUserIdAndstatusAndStoreId(String userId, Integer status, Integer storeId) throws GlobalErrorInfoException;

	void updateOrderAndBuildOrderDelivery(List<Order> orderList, CheckCreditVo checkCredit, String sequenceNumber) throws GlobalErrorInfoException;

	/**
	 * 快捷方式推送
	 * 
	 * @param messageType
	 * @param ldapUserId
	 * @param sequenceNumber
	 * @param storeId
	 * @param redisMonitorOrderAmountList
	 */
	void shortPushMsg(Integer messageType, String ldapUserId, String sequenceNumber, Integer storeId, MonitorRedisInformation monitorRedisInformation);

	/**
	 * 常规方式推送
	 * 
	 * @param messageType
	 * @param ldapUserId
	 * @param sequenceNumber
	 * @param storeId
	 * @param redisMonitorOrderAmountList
	 */
	void commonComfirmPushMsg(Integer messageType, String ldapUserId, String sequenceNumber, Integer storeId, Order order);

	/**
	 * 常规方式全部通过推送
	 * 
	 * @param messageType
	 * @param ldapUserId
	 * @param sequenceNumber
	 * @param storeId
	 * @param redisMonitorOrderAmountList
	 */
	void commonComfirmAllPushMsg(Integer messageType, String ldapUserId, String sequenceNumber, Integer storeId, List<Order> order);

	/**
	 * 设置monitorOrderAmount的状态
	 * 
	 * @param orderList
	 * @param monitorOrderAmount
	 */
	void buildMonitorOrderAmount(List<Order> orderList, MonitorOrderAmount monitorOrderAmount);

	/**
	 * 普通方式全部通过redis对照
	 * 
	 * @param ldapUserId
	 * @param storeId
	 * @param orderList
	 */
	void commonAllConfirmPush(String ldapUserId, Integer storeId, List<Order> orderList);

	/**
	 * 单个通过不通过redis对照
	 * 
	 * @param orderId
	 * @param storeId
	 * @param order
	 * @param storeIdAndSequenceNumber
	 * @return
	 */
	StoreVo checkRedis(String orderId, Integer storeId, Order order, String storeIdAndSequenceNumber);

	/**
	 * 保存redis
	 * 
	 * @param monitorExitParameter
	 * @param userId
	 * @param orderList
	 * @param sequenceNumber
	 * @param dagId
	 * @param storeId
	 */
	void monitorRedisSave(MonitorExitParameter monitorExitParameter, String userId, List<Order> orderList, String sequenceNumber, String dagId, Integer storeId, String screenFlag);

	/**
	 * rule check item
	 * 
	 * @param batchNo
	 * @param createTime
	 * @param checkHistoryList
	 * @param orderBo
	 * @param orderLineBo
	 */
	void rulecheckItem(String batchNo, Date createTime, List<CheckHistory> checkHistoryList, OrderBo orderBo, OrderLineBo orderLineBo);

	/**
	 * 查询门店购物袋
	 * 
	 * @param storeId
	 * @return
	 */
	Map<Long, StoreShoppingBagForItemVo> selectShoppingBag(Integer storeId);

	/**
	 * 检查用户和交易
	 * 
	 * @param batchNo
	 * @param createTime
	 * @param userId
	 * @param orderList
	 * @param checkHistoryList
	 * @param checkCredit
	 * @param itemAllAmount
	 * @param shoppingBagQuantity
	 * @param averageAmount
	 * @param otherItemQuantity
	 * @param minute
	 * @param minuteMap
	 */
	void ruleCheckPersonAndTransation(CheckPersonAndTransation checkPersonAndTransation);

	/**
	 * buildCheckPersonAndTransaction
	 * 
	 * @param batchNo
	 * @param createTime
	 * @param userId
	 * @param orderList
	 * @param checkHistoryList
	 * @param checkCredit
	 * @param itemAllAmount
	 * @param shoppingBagQuantity
	 * @param averageAmount
	 * @param otherItemQuantity
	 * @param minute
	 * @param minuteMap
	 * @return
	 */
	CheckPersonAndTransation buildCheckPersonAndTransaction(String batchNo, Date createTime, String userId, List<Order> orderList, List<CheckHistory> checkHistoryList, CheckCreditVo checkCredit,
			BigDecimal itemAllAmount, Integer shoppingBagQuantity, BigDecimal averageAmount, Integer otherItemQuantity, Map<String, Long> minuteMap);

	/**
	 * buildTransactionRuleParamter
	 * 
	 * @param batchNo
	 * @param createTime
	 * @param storeId
	 * @param checkHistoryList
	 * @param orderBoList
	 * @param itemAllQuantity
	 * @param itemAllAmount
	 * @param shoppingBagQuantity
	 * @param shoppingBagAmount
	 * @param minute
	 * @param transactionRuleParamter
	 * @param minuteMap
	 * @return
	 */
	void buildTransactionRuleParamter(String batchNo, Date createTime, Integer storeId, List<CheckHistory> checkHistoryList, List<OrderBo> orderBoList, Integer itemAllQuantity,
			BigDecimal itemAllAmount, Integer shoppingBagQuantity, BigDecimal shoppingBagAmount, TransactionRuleParamter transactionRuleParamter, Map<String, Long> minuteMap);

	/**
	 * getScreenFlag
	 * 
	 * @param checkHistoryList
	 * @return
	 */
	String getScreenFlag(List<CheckHistory> checkHistoryList);

	/**
	 * userIdAndMobilePhoneMap
	 * 
	 * @param monitorExitParameter
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	Map<String, String> getUserIdAndMobilePhone(MonitorExitParameter monitorExitParameter) throws GlobalErrorInfoException;

	/**
	 * checkGateMac
	 * 
	 * @param mac
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	GateMac checkGateMac(String mac) throws GlobalErrorInfoException;

	/**
	 * saveCheckHistoryAndUpdateOrder
	 * 
	 * @param storeId
	 * @param dagId
	 * @param orderList
	 * @param checkHistoryList
	 * @param checkCredit
	 * @param sequenceNumber
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	String saveCheckHistoryAndUpdateOrder(Integer storeId, String dagId, List<Order> orderList, List<CheckHistory> checkHistoryList, CheckCreditVo checkCredit, String sequenceNumber)
			throws GlobalErrorInfoException;

	/**
	 * selectCheckHistoryList
	 * 
	 * @param orderBo
	 * @return
	 */
	List<CheckHistory> selectCheckHistoryList(OrderBo orderBo);

}
