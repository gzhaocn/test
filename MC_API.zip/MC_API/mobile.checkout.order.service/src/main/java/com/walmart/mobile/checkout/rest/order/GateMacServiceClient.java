package com.walmart.mobile.checkout.rest.order;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.walmart.mobile.checkout.entity.GateMac;

@FeignClient("gateMacService")
@FunctionalInterface
public interface GateMacServiceClient {

	@RequestMapping(method = RequestMethod.GET, value = "/findByMac")
	GateMac findByMac(@RequestParam(value = "mac") String mac);
}
