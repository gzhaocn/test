package com.walmart.mobile.checkout.bo.order;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * monitor刷新订单状态参数
 * 
 * @author lliao2
 *
 */
@ApiModel(description = "monitor刷新订单状态参数")
public class MonitorRefreshParameter {
	@ApiModelProperty(value = "订单ID列表", required = true)
	List<String> orderIds;
	@ApiModelProperty(value = "mac", required = true)
	private String mac;
	@ApiModelProperty(value = "调用程序key", required = true)
	private String appKey;
	@ApiModelProperty(value = "调用时间", required = true)
	private Long timeStamp;
	@ApiModelProperty(value = "签名", required = true)
	private String sign;
	@ApiModelProperty(value = "参数格式（如：json）", required = true)
	private String format;
	@ApiModelProperty(value = "版本", required = true)
	private String version;

	public String getAppKey() {
		return appKey;
	}

	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public Long getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(Long timeStamp) {
		this.timeStamp = timeStamp;
	}

	public List<String> getOrderIds() {
		return orderIds;
	}

	public void setOrderIds(List<String> orderIds) {
		this.orderIds = orderIds;
	}

	public String getMac() {
		return mac;
	}

	public void setMac(String mac) {
		this.mac = mac;
	}

}
