package com.walmart.mobile.checkout.service;

import java.math.BigDecimal;
import java.util.List;

import com.walmart.mobile.checkout.domain.order.Order;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;

public interface OrderStatusService {
	/**
	 * 根据eventType修改Order状态
	 * 
	 * @param record
	 * @param eventType
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	int updateOrderStatus(Order record, int eventType) throws GlobalErrorInfoException;

	/**
	 * 根据eventType驱动修改order状态及其他信息
	 * 
	 * @param orderId
	 * @param version
	 * @param eventType
	 * @param paymentCouponFee
	 * @param payType
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	int updateOrderStatusByOrderId(String orderId, Integer version, int eventType, BigDecimal paymentCouponFee, Integer payType) throws GlobalErrorInfoException;

	/**
	 * 批量修改订单状态和scanTime
	 * 
	 * @param orderList
	 * @return
	 * @throws GlobalErrorInfoException
	 */

	public int updateBatchOrderStatusAndScanTime(List<Order> orderList, int eventType, Integer checkFlag, String sequenceNumber) throws GlobalErrorInfoException;
}
