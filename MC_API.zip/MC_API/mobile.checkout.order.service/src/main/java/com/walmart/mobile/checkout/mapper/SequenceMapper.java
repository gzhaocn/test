package com.walmart.mobile.checkout.mapper;


import org.apache.ibatis.annotations.Param;

@FunctionalInterface
public interface SequenceMapper {
	/**
	 * orderId序列号
	 * @param key
	 * @return
	 */
	long getSeq(@Param("key") String key);
}