package com.walmart.mobile.checkout.statemachine;

import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;



/**
 * 订单状态领域类
 * @author lliao2
 */
public class OrderStatusIncorporate  {
	// 订单状态是对事件聚合产生的
    private OrderStatusEnum orderStatus; 
    
    

    public OrderStatusIncorporate() {
        this.orderStatus = OrderStatusEnum.UNPAID;
    }
    
    
    public OrderStatusIncorporate(OrderStatusEnum orderStatus) {
        this.orderStatus =orderStatus;
    }


    /**
     * incorporate 方法通过一个针对订单状态的简单的状态机(state machine) ，使用事件源(event sourcing)
     * 和聚合(aggregation)来生成订单的当前状态
     * 每个状态只对应两个操作：前进/后退。
     * UNPAID状态没有回退 ，UNPAID_CANCELLED\PAID_CANCELLED\COMPELETE\TIMEOUT状态没有前进也没有回退
     * @param orderEvent 是将要被合并进状态机的事件
     * @return 有着聚合的订单状态的 聚合
     * @throws GlobalErrorInfoException 
     */
    
    public int incorporate(  int eventType) throws GlobalErrorInfoException {
        if(orderStatus == null){
            orderStatus = OrderStatusEnum.UNPAID;
        }
        return orderStatus.nextStatus(eventType);
    }

    public OrderStatusEnum getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(OrderStatusEnum orderStatus) {
        this.orderStatus = orderStatus;
    }

}

