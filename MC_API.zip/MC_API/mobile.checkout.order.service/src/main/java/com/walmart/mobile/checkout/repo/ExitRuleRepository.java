package com.walmart.mobile.checkout.repo;

import java.math.BigInteger;

import org.springframework.data.repository.CrudRepository;

import com.walmart.mobile.checkout.entity.ExitRule;

public interface ExitRuleRepository extends CrudRepository<ExitRule, BigInteger> {

	ExitRule findByRuleType(String ruleType);

}
