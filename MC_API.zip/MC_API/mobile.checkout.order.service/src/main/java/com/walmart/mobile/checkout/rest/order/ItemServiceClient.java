package com.walmart.mobile.checkout.rest.order;

import java.util.List;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.walmart.mobile.checkout.rest.vo.InventoryPriceVo;
import com.walmart.mobile.checkout.rest.vo.NoDeliverItemVo;
import com.walmart.mobile.checkout.rest.vo.ProductDetailVo;
import com.walmart.mobile.checkout.rest.vo.SpecialItemVo;

@FeignClient("itemService")
public interface ItemServiceClient {

	@RequestMapping(method = RequestMethod.GET, value = "/selectInventoryPriceByStoreAndProductIds")
	List<InventoryPriceVo> selectInventoryPriceByStoreAndProductIds(@RequestParam(value = "storeId") int storeId, @RequestParam(value = "productIds") List<Long> productIds);

	/**
	 * @RequestMapping(method = RequestMethod.GET, value = "/findByProductIdIn")
	 *                        List<ProductDetailVo>
	 *                        findByProductIdIn(@RequestParam(value =
	 *                        "productIds") List<Long> productIds) ;
	 */

	@RequestMapping(method = RequestMethod.GET, value = "/findByItemNumberIn")
	List<ProductDetailVo> findByItemNumberIn(@RequestParam(value = "itemNumbers") List<Long> itemNumbers);

	@RequestMapping(method = RequestMethod.GET, value = "/findByStoreIdAndProductId")
	InventoryPriceVo findByStoreIdAndProductId(@RequestParam(value = "storeId") Integer storeId, @RequestParam(value = "productId") Long productId);

	@RequestMapping(method = RequestMethod.GET, value = "/findByStoreIdAndItemNumberIn")
	List<InventoryPriceVo> findByStoreIdAndItemNumberIn(@RequestParam(value = "storeId") Integer storeId, @RequestParam(value = "itemNumbers") List<Long> itemNumbers);

	@RequestMapping(method = RequestMethod.GET, value = "/findByStoreIdAndItemNumber")
	InventoryPriceVo findByStoreIdAndItemNumber(@RequestParam(value = "storeId") Integer storeId, @RequestParam(value = "itemNumber") Long itemNumber);

	@RequestMapping(method = RequestMethod.GET, value = "/findByStoreIdAndUpc")
	InventoryPriceVo findByStoreIdAndUpc(@RequestParam(value = "storeId") Integer storeId, @RequestParam(value = "upc") Long upc);

	/**
	 * @RequestMapping(method = RequestMethod.GET, value = "/findByProductId")
	 *                        ProductDetailVo
	 *                        findByProductId(@RequestParam(value =
	 *                        "productId")Long productId) ;
	 */

	@RequestMapping(method = RequestMethod.GET, value = "/findByItemNumber")
	ProductDetailVo findByItemNumber(@RequestParam(value = "itemNumber") Long itemNumber);

	/**
	 * @RequestMapping(method = RequestMethod.GET, value = "/productDetailSave")
	 *                        void productDetailSave(@RequestParam(value =
	 *                        "productDetail") ProductDetailVo productDetail);
	 * 
	 * @RequestMapping(method = RequestMethod.GET, value =
	 *                        "/inventoryPriceSave") void
	 *                        inventoryPriceSave(@RequestParam(value =
	 *                        "inventoryPrice") InventoryPriceVo
	 *                        inventoryPrice);
	 */

	@RequestMapping(method = RequestMethod.GET, value = "/findByUpcIn")
	List<SpecialItemVo> findByUpcIn(@RequestParam(value = "upcs") List<Long> upcs);

	@RequestMapping(method = RequestMethod.GET, value = "/findByNoDeliveryItemUpcIn")
	List<NoDeliverItemVo> findByNoDeliveryItemUpcIn(@RequestParam(value = "upcs") List<Long> upcs);

}
