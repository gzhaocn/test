package com.walmart.mobile.checkout.service.impl;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.walmart.mobile.checkout.bo.order.CheckoutOrderLine;
import com.walmart.mobile.checkout.bo.order.OrderBo;
import com.walmart.mobile.checkout.bo.order.OrderItemMap;
import com.walmart.mobile.checkout.bo.order.OrderLineParameter;
import com.walmart.mobile.checkout.bo.order.OrderParameter;
import com.walmart.mobile.checkout.bo.order.OrderScanParameter;
import com.walmart.mobile.checkout.bo.order.ShippingFeeItemParameter;
import com.walmart.mobile.checkout.constant.AppConstants;
import com.walmart.mobile.checkout.constant.GlobalErrorInfoEnum;
import com.walmart.mobile.checkout.constant.order.ItemType;
import com.walmart.mobile.checkout.constant.order.OrderCons;
import com.walmart.mobile.checkout.constant.order.OrderErrorInfoEnum;
import com.walmart.mobile.checkout.constant.order.OrderStatus;
import com.walmart.mobile.checkout.constant.order.ValidateOrderResult;
import com.walmart.mobile.checkout.domain.StoreVo;
import com.walmart.mobile.checkout.domain.order.Order;
import com.walmart.mobile.checkout.domain.order.OrderEwsLine;
import com.walmart.mobile.checkout.domain.order.OrderShippingLine;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.rest.StoreServiceClient;
import com.walmart.mobile.checkout.rest.order.EwsPriceServiceClient;
import com.walmart.mobile.checkout.rest.order.GpOfferServiceClient;
import com.walmart.mobile.checkout.rest.order.ItemServiceClient;
import com.walmart.mobile.checkout.rest.order.PromotionServiceClient;
import com.walmart.mobile.checkout.rest.vo.CalcDiscountResultVo;
import com.walmart.mobile.checkout.rest.vo.EwsPriceVo;
import com.walmart.mobile.checkout.rest.vo.GpCartItemVo;
import com.walmart.mobile.checkout.rest.vo.GpOfferVo;
import com.walmart.mobile.checkout.rest.vo.InventoryPriceVo;
import com.walmart.mobile.checkout.rest.vo.NoDeliverItemVo;
import com.walmart.mobile.checkout.rest.vo.OfferVo;
import com.walmart.mobile.checkout.rest.vo.ProductDetailVo;
import com.walmart.mobile.checkout.rest.vo.SpecialItemVo;
import com.walmart.mobile.checkout.service.OrderValidationService;
import com.walmart.mobile.checkout.utils.DateUtil;
import com.walmart.mobile.checkout.utils.ThreadLocalContextHolder;
import com.walmart.mobile.checkout.utils.crypto.SHA1Util;
import com.walmart.mobile.checkout.utils.crypto.SHA512;
import com.walmart.mobile.checkout.utils.order.CheckOrderUtils;
import com.walmart.mobile.checkout.utils.order.OrderUtils;

/**
 * 订单校验service
 * 
 * @author lliao2
 *
 */
@Service("orderValidationService")
public class OrderValidationServiceImpl implements OrderValidationService {
	@Autowired
	GpOfferServiceClient gpOfferServiceClient;

	@Autowired
	ItemServiceClient itemServiceClient;
	@Autowired
	PromotionServiceClient promotionServiceClient;
	@Autowired
	StoreServiceClient storeServiceClient;
	@Autowired
	EwsPriceServiceClient ewsPriceServiceClient;

	@Value("${generate.invoice.overtime}")
	private int overTime;

	@Value("${reject.item.overtime}")
	private int rejectItemOverTime;

	private static final Logger LOG = LoggerFactory.getLogger(OrderValidationServiceImpl.class);

	private static final String USER_ID = ThreadLocalContextHolder.getUserId();

	/**
	 * 校验order参数
	 * 
	 * @throws GlobalErrorInfoException
	 */
	@Override
	public void checkOrderParameter(OrderParameter orderParam) throws GlobalErrorInfoException {
		if (orderParam == null) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDERPARAM_IS_NULL);
		}
		if (orderParam.getOrderLines() == null) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDERLINES_IS_NULL);
		}
		if (orderParam.getAmount() == null) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDER_AMOUNT_IS_NULL);
		}
	}

	/**
	 * 准备商品、gp数据，供后续校验使用
	 */
	@Override
	public void prepareValidateHandler(OrderParameter orderParam) throws GlobalErrorInfoException {
		List<Long> productIds = orderParam.buildProductIdList();
		int storeId = orderParam.getStoreId();
		queryStoreShippingFee(orderParam, storeId);
		OrderItemMap orderItemMap = getInventoryPriceByProductIds(storeId, productIds);
		orderParam.setProductIdAndItemNumberMap(orderItemMap.getProductIdAndItemNumberMap());
		orderParam.setInventoryPrices(orderItemMap.getInventoryPriceMap());
		orderParam.setProductDetails(getProductByProductIds(orderItemMap.getItemNumberList()));
		orderParam.setGpOffers(getGpOfferMap(orderParam.getOrderLines()));
		orderParam.setGpOfferIdAndLinkSaveIdMap(orderItemMap.getGpOfferIdAndLinkSaveIdMap());
		orderParam.setEwsPriceList(getEwsPriceList(orderParam.getStoreId()));
		orderParam.setUpcAndSpecialItemMap(orderItemMap.getUpcAndSpecialItemMap());
		orderParam.setMagneticFlag(orderItemMap.getMagneticFlag());
		orderParam.setNoDeliverItemMap(orderItemMap.getNoDeliverItemMap());
	}

	private void queryStoreShippingFee(OrderParameter orderParam, int storeId) {
		StoreVo storeVo = storeServiceClient.findByStoreId(storeId);
		if (storeVo.getDeliveryThreshold() == null) {
			orderParam.setDbShippingFee(BigDecimal.ZERO);
		} else {
			orderParam.setDeliveryThreshold(new BigDecimal(String.valueOf(storeVo.getDeliveryThreshold())));
		}
		if (storeVo.getDeliveryItemUpc() == null) {
			orderParam.setDbShippingFee(BigDecimal.ZERO);
		} else {
			InventoryPriceVo inventoryPriceVo = itemServiceClient.findByStoreIdAndUpc(storeId, storeVo.getDeliveryItemUpc());
			orderParam.setDbShippingFee(new BigDecimal(inventoryPriceVo == null ? "0" : String.valueOf(inventoryPriceVo.getPriceWithTax())));
		}
	}

	/**
	 * 查询延保商品规则
	 * 
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	private List<EwsPriceVo> getEwsPriceList(Integer storeId) throws GlobalErrorInfoException {
		StoreVo store = new StoreVo();
		store.setStoreId(storeId);
		return ewsPriceServiceClient.getAllEwsPrice(store);
	}

	/**
	 * 组装gp map
	 */
	@Override
	public Map<Integer, GpOfferVo> getGpOfferMap(List<OrderLineParameter> orderLineParameters) throws GlobalErrorInfoException {
		List<Integer> offerIdList = new ArrayList<>();

		for (OrderLineParameter olr : orderLineParameters) {
			if (CollectionUtils.isEmpty(olr.getGpOffers())) {
				continue;
			}
			for (OfferVo offer : olr.getGpOffers()) {
				if (offer.getGpOfferId() == 0) {
					continue;
				}
				offerIdList.add(offer.getGpOfferId());
			}
		}

		if (offerIdList.isEmpty()) {
			return Collections.emptyMap();
		}

		List<GpOfferVo> gpOfferList = gpOfferServiceClient.findByGpOfferIdInAndStatus(offerIdList, AppConstants.OFFER_STATUS_EFFECTIVE);
		if (CollectionUtils.isEmpty(gpOfferList)) {
			if (LOG.isInfoEnabled()) {
				LOG.info("gp information:{},is empty or status is 1", JSON.toJSONString(gpOfferList));
			}
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.GP_DATA_NOT_EXIST);
		}

		return convertListToMap(gpOfferList);
	}

	private Map<Integer, GpOfferVo> convertListToMap(List<GpOfferVo> offerList) {
		Map<Integer, GpOfferVo> offerMap = new ConcurrentHashMap<>(16);
		if (CollectionUtils.isNotEmpty(offerList)) {
			for (GpOfferVo gpOffer : offerList) {
				offerMap.put(gpOffer.getGpOfferId(), gpOffer);
			}
		}
		return offerMap;
	}

	/**
	 * 组装inventoryPrice map
	 */
	@Override
	public OrderItemMap getInventoryPriceByProductIds(int storeId, List<Long> productIds) throws GlobalErrorInfoException {
		List<InventoryPriceVo> ipList = itemServiceClient.selectInventoryPriceByStoreAndProductIds(storeId, productIds);
		if (CollectionUtils.isEmpty(ipList)) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.PRODUCT_DATA_NOT_EXIST);
		}
		Map<Long, InventoryPriceVo> invePriceMap = new HashMap<>(16);
		Map<Long, Long> productIdAndItemNumberMap = new HashMap<>(16);
		Map<Integer, Integer> gpOfferIdAndLinkSaveIdMap = new HashMap<>(16);
		List<Long> itemNumberList = new ArrayList<>();
		List<Long> upcList = new ArrayList<>();
		int inventoryPriceMagneticFlag = 0;
		for (InventoryPriceVo ip : ipList) {
			upcList.add(ip.getUpc());
			invePriceMap.put(ip.getItemNumber(), ip);
			itemNumberList.add(ip.getItemNumber());
			productIdAndItemNumberMap.put(ip.getProductId(), ip.getItemNumber());
			if (ip.getMagneticFlag() != null && ip.getMagneticFlag() == 1) {
				inventoryPriceMagneticFlag = inventoryPriceMagneticFlag + 1;
			}
			if (ip.getGpOffers() == null || ip.getGpOffers().isEmpty()) {
				continue;
			}
			for (OfferVo offer : ip.getGpOffers()) {
				gpOfferIdAndLinkSaveIdMap.put(offer.getGpOfferId(), offer.getLinkSaveId());
			}
		}
		int specialItemFlag = 0;
		Map<Long, SpecialItemVo> specialItemMap = new HashMap<>(16);
		List<SpecialItemVo> spcialItemList = itemServiceClient.findByUpcIn(upcList);
		if (CollectionUtils.isNotEmpty(spcialItemList)) {
			specialItemFlag = 1;
			specialItemMap = spcialItemList.stream().collect(Collectors.toMap(SpecialItemVo::getUpc, a -> a, (k1, k2) -> k1));
		}
		// 判断是否消磁商品
		int magneticFlag = 0;
		if (inventoryPriceMagneticFlag > 0 || specialItemFlag == 1) {
			magneticFlag = 1;
		}
		/**
		 * 查询不可配送的商品
		 */
		Map<Long, NoDeliverItemVo> noDeliverItemMap = new HashMap<>(16);
		List<NoDeliverItemVo> noDeliverItemList = itemServiceClient.findByNoDeliveryItemUpcIn(upcList);
		if (CollectionUtils.isNotEmpty(noDeliverItemList)) {
			noDeliverItemMap = noDeliverItemList.stream().collect(Collectors.toMap(NoDeliverItemVo::getUpc, a -> a, (k1, k2) -> k1));
		}

		OrderItemMap orderItemMap = new OrderItemMap();
		orderItemMap.setInventoryPriceMap(invePriceMap);
		orderItemMap.setItemNumberList(itemNumberList);
		orderItemMap.setProductIdAndItemNumberMap(productIdAndItemNumberMap);
		orderItemMap.setGpOfferIdAndLinkSaveIdMap(gpOfferIdAndLinkSaveIdMap);
		orderItemMap.setUpcAndSpecialItemMap(specialItemMap);
		orderItemMap.setMagneticFlag(magneticFlag);
		orderItemMap.setNoDeliverItemMap(noDeliverItemMap);
		return orderItemMap;
	}

	/**
	 * 组装product map
	 */
	@Override
	public Map<Long, ProductDetailVo> getProductByProductIds(List<Long> itemNumbers) throws GlobalErrorInfoException {

		List<ProductDetailVo> productList = itemServiceClient.findByItemNumberIn(itemNumbers);
		/** .findByProductIdIn(productIds); */

		if (CollectionUtils.isEmpty(productList)) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.PRODUCT_DATA_NOT_EXIST);
		}

		Map<Long, ProductDetailVo> productMap = new HashMap<>(16);
		for (ProductDetailVo product : productList) {
			productMap.put(product.getItemNumber(), product);
		}

		return productMap;
	}

	/**
	 * orderLine和orderAmount等校验
	 */
	@Override
	public void verify(OrderParameter orderParam) throws GlobalErrorInfoException {
		int storeId = orderParam.getStoreId();

		verifyOrderLines(orderParam);
		BigDecimal itemAmount = calcItemAmount(orderParam);
		// check discount for total
		if (!checkOrderDiscount(orderParam)) {
			if (LOG.isInfoEnabled()) {
				LOG.info("storeId {},uid {} create order faild,cause of order discount not match", storeId, USER_ID);
			}
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.DISCOUNT_NOT_MATCH);
		}

		checkEwsAmount(orderParam, storeId);
		checkShippingFee(orderParam, storeId);

		if (!orderParam.checkOrderAmount(itemAmount, orderParam.getOrderLines())) {
			if (LOG.isInfoEnabled()) {
				LOG.info(
						"storeId {},uid {} create order faild,cause of order payment amount not match,client payment amount {} ,server amount with discount {},discount {},package fee {},shipping fee {}",
						storeId, USER_ID, orderParam.getAmount(), itemAmount, orderParam.getTotalGpDiscount(), orderParam.getPackagingFee(), orderParam.getShippingFee());
			}
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.AMOUNT_NOT_MATCH);
		}

	}

	/**
	 * 判断运费是否一致
	 * 
	 * @param orderParam
	 * @param storeId
	 * @throws GlobalErrorInfoException
	 */
	private void checkShippingFee(OrderParameter orderParam, int storeId) throws GlobalErrorInfoException {
		// 选择了派送的情况下，判断运单金额是否相等
		if (orderParam.getDeliveryFlag() == 0) {
			orderParam.setShippingFee(BigDecimal.ZERO);
			return;
		}
		if (orderParam.getDeliveryThreshold() == null) {
			LOG.info("storeId {},uid {} create order faild,cause of the deliveryThreshold is not config by cms", storeId, USER_ID);
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.DELIVERYTHRESHOLD_IS_NOT_CONFIG);
		}
		BigDecimal serverShippingFee = (orderParam.getAmount().subtract(orderParam.getShippingFee())).compareTo(orderParam.getDeliveryThreshold()) < 0 ? orderParam.getDbShippingFee()
				: BigDecimal.ZERO;
		if (orderParam.getDelivery() == null) {
			LOG.info("storeId {},uid {} create order faild,cause of when delivery flag is 1,but delivery  is null", storeId, USER_ID);
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.DELIVERY_IS_NULL);
		}

		if (serverShippingFee.compareTo(BigDecimal.ZERO) > 0 && orderParam.getShippingFeeItemLine() == null) {
			LOG.info("storeId {},uid {} create order faild,cause of when delivery flag is 1 and have shippingfee,but ShippingFeeItemLine or ordershippingline is null", storeId, USER_ID);
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.SHIPPING_FEE_ITEMLINE_OR_ORDER_SHIPPING_LINE_IS_NULL);
		}

		ShippingFeeItemParameter shippingFeeItemParameter = orderParam.getShippingFeeItemLine();
		BigDecimal shippingFee = shippingFeeItemParameter == null ? BigDecimal.ZERO : shippingFeeItemParameter.getPriceWithTax().multiply(new BigDecimal(shippingFeeItemParameter.getOrderQuantity()));
		if (serverShippingFee.compareTo(orderParam.getShippingFee()) != 0 || shippingFee.compareTo(orderParam.getShippingFee()) != 0) {
			LOG.info("storeId {},uid {} create order faild,cause of order shippingfee not match, server shippingfee is {},client shippingfee is {},delivery shippingfee is {}", storeId, USER_ID,
					serverShippingFee, orderParam.getShippingFee(), shippingFee);
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDER_SHIPPING_FEE_NOT_COMPARE);
		}

	}

	/**
	 * 延保范围校验
	 * 
	 * @param orderParam
	 * @param storeId
	 * @throws GlobalErrorInfoException
	 */
	private void checkEwsAmount(OrderParameter orderParam, int storeId) throws GlobalErrorInfoException {

		List<OrderLineParameter> orderLineParamters = orderParam.getOrderLines();

		for (OrderLineParameter orderLineParameter : orderLineParamters) {
			if (orderLineParameter.getEwsOptFlag() != null && orderLineParameter.getEwsOptFlag() == CheckOrderUtils.EWS_FLAG) {
				EwsPriceVo ewsPrice = orderLineParameter.getEwsPrice();
				BigDecimal clientEwsAmount = ewsPrice.getEwsAmount();

				BigDecimal orderLineItemAmount = calcOrderLineItemAmount(orderLineParameter);
				BigDecimal serverEwsPrice = calcServerEwsPrice(orderParam, orderLineItemAmount, ewsPrice.getTimeSlot());
				/**
				 * 计算出来的延保价格不一致，抛出异常
				 */
				BigDecimal serverEwsAmount = serverEwsPrice.multiply(new BigDecimal(ewsPrice.getEwsQuantity()));
				if (clientEwsAmount.compareTo(serverEwsAmount) != 0) {
					LOG.info("storeId {},uid {} create order faild,cause of ews price not match,client ews amount {},server ews amount with {}", storeId, USER_ID, clientEwsAmount, serverEwsAmount);
					throw new GlobalErrorInfoException(OrderErrorInfoEnum.SERVER_EWS_PRICE_NOT_COMPARE_TO_CLIENT_EWS_PRICE);
				}
			}
		}
	}

	/**
	 * 计算item金额,用于计算延保金额范围
	 * 
	 * @param orderLineParameter
	 * @return
	 */
	private BigDecimal calcOrderLineItemAmount(OrderLineParameter orderLineParameter) {
		BigDecimal orderLineItemAmount;
		if (orderLineParameter.getItemType() == ItemType.WEGITH_ITEM) {
			orderLineItemAmount = orderLineParameter.getItemAmount().subtract(orderLineParameter.getGpDiscount());
		} else {
			orderLineItemAmount = (orderLineParameter.getPriceWithTax().multiply(new BigDecimal(orderLineParameter.getOrderQuantity())).subtract(orderLineParameter.getGpDiscount())).divide(
					new BigDecimal(orderLineParameter.getOrderQuantity()), 2, BigDecimal.ROUND_HALF_UP);
		}
		return orderLineItemAmount;
	}

	/**
	 * 计算延保金额
	 * 
	 * @param orderParam
	 * @param orderLineItemAmount
	 * @return
	 */
	private BigDecimal calcServerEwsPrice(OrderParameter orderParam, BigDecimal orderLineItemAmount, Integer clientTimeSlot) {
		BigDecimal serverEwsPrice = BigDecimal.ZERO;
		List<EwsPriceVo> ewsPriceList = orderParam.getEwsPriceList();
		for (EwsPriceVo ewsPriceVo : ewsPriceList) {
			if (ewsPriceVo.getEndPrice().compareTo(orderLineItemAmount) >= 0 && ewsPriceVo.getStartPrice().compareTo(orderLineItemAmount) < 0 && ewsPriceVo.getTimeSlot().equals(clientTimeSlot)) {
				serverEwsPrice = ewsPriceVo.getExtendedWarrantyPrice();
				break;
			}

		}
		return serverEwsPrice;
	}

	/**
	 * check global promotion
	 * 
	 * @param createDiscount
	 * @param gpOfferMap
	 * @return true if passed, false if not passed
	 */

	private boolean checkOrderDiscount(OrderParameter orderParam) {

		// construct Cart Item for calculate GP
		List<GpCartItemVo> cartItems = new ArrayList<>();
		for (OrderLineParameter line : orderParam.getOrderLines()) {
			bulidCartItems(cartItems, line);
		}
		if (CollectionUtils.isEmpty(cartItems)) {
			return true;
		}
		// gp分组并分摊gp到item,计算商品的多gp之和
		CalcDiscountResultVo calcDiscountResult = promotionServiceClient.calculateInItemLevel(cartItems);
		Map<Integer, Integer> gpOfferIdMinTimesMap = calcDiscountResult.getGpOfferIdMinTimesMap();
		orderParam.setGpOfferIdMinTimesMap(gpOfferIdMinTimesMap);

		if (!calcDiscountResult.isItemLevelDisocuntCompareFlag()) {
			return false;
		}
		return totalDiscountCompare(orderParam, calcDiscountResult);
	}

	/**
	 * 比较客户端与服务端计算的gp是否一致
	 * 
	 * @param orderParam
	 * @param calcDiscountResult
	 * @return
	 */
	private boolean totalDiscountCompare(OrderParameter orderParam, CalcDiscountResultVo calcDiscountResult) {
		// check by order total level
		double serverGPDiscount = calcDiscountResult.getTotalDiscount().doubleValue();
		double clientGPDiscount = orderParam.getTotalGpDiscount() == null ? 0 : orderParam.getTotalGpDiscount().doubleValue();
		if (LOG.isDebugEnabled()) {
			LOG.debug(String.format("Order validation - GP: Total GP discount: Server: %f, Client: %f", serverGPDiscount, clientGPDiscount));
		}
		return Math.abs(serverGPDiscount - clientGPDiscount) < 0.01;
	}

	/**
	 * 构造购物车数组
	 * 
	 * @param cartItems
	 * @param line
	 */
	private void bulidCartItems(List<GpCartItemVo> cartItems, OrderLineParameter line) {
		List<OfferVo> offers = line.getGpOffers();
		int itemType = line.getItemType();
		if (offers == null) {
			return;
		}
		for (OfferVo offer : offers) {

			GpCartItemVo cartItem = new GpCartItemVo();
			cartItem.setGpOfferId(offer.getGpOfferId());
			cartItem.setGroupSeq(offer.getGpGroupSeq());
			cartItem.setQty(line.getOrderQuantity());
			// 称重商品计算区分
			if (itemType == ItemType.NO_WEGITH_ITEM) {
				cartItem.setTaxPrice(line.getPriceWithTax());
			} else {
				cartItem.setTaxPrice(line.getItemAmount());
			}
			cartItem.setUpc(line.getUpc());
			cartItem.setProductId(line.getProductId());
			cartItem.setClientDiscount(offer.getGpDiscount());
			cartItem.setCartItemId(line.getCartItemId());
			cartItems.add(cartItem);
		}

	}

	/**
	 * 计算item amount
	 * 
	 * @param orderParam
	 * @param results
	 * @param invePrices
	 * @return
	 */
	private BigDecimal calcItemAmount(OrderParameter orderParam) {
		Map<Long, InventoryPriceVo> invePrices = orderParam.getInventoryPrices();

		Map<Long, Long> productIdAndItemNumberMap = orderParam.getProductIdAndItemNumberMap();

		BigDecimal itemAmount = BigDecimal.ZERO;
		for (OrderLineParameter orderLine : orderParam.getOrderLines()) {
			BigDecimal tempItemAmount = BigDecimal.ZERO;
			if (orderLine.getItemType() == ItemType.WEGITH_ITEM) {
				tempItemAmount = orderLine.getItemAmount();
			} else {
				Long productId = orderLine.getProductId();
				if (productIdAndItemNumberMap.containsKey(productId)) {
					Long itemNumber = productIdAndItemNumberMap.get(productId);
					InventoryPriceVo invePrice = invePrices.get(itemNumber);
					BigDecimal priceWithTax = new BigDecimal(invePrice.getPriceWithTax().toString());
					tempItemAmount = priceWithTax.multiply(new BigDecimal(orderLine.getOrderQuantity()));
				}
			}

			itemAmount = itemAmount.add(tempItemAmount).setScale(2, RoundingMode.HALF_UP);
		}
		return itemAmount;
	}

	/**
	 * 校验orderLine
	 * 
	 * @param orderParam
	 * @throws GlobalErrorInfoException
	 */
	private void verifyOrderLines(OrderParameter orderParam) throws GlobalErrorInfoException {
		Map<Long, ProductDetailVo> productDetails = orderParam.getProductDetails();
		Map<Long, InventoryPriceVo> invePrices = orderParam.getInventoryPrices();

		Map<Long, Long> productIdAndItemNumberMap = orderParam.getProductIdAndItemNumberMap();
		Map<Long, NoDeliverItemVo> noDeliverItemVoMap = orderParam.getNoDeliverItemMap();
		int i = 0;
		for (OrderLineParameter orderLine : orderParam.getOrderLines()) {
			int orderQuantity = orderLine.getOrderQuantity();
			if (orderQuantity <= 0) {
				LOG.info("storeId {},uid {} create order faild,cause of orderQuantity is less zero ,the upc is {}", orderParam.getStoreId(), USER_ID, orderLine.getUpc());
				throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDERLINE_QUANTITY_LESS_OR_EQUALS_ZERO);
			}

			Long productId = orderLine.getProductId();
			if (!productIdAndItemNumberMap.containsKey(productId)) {
				throw new GlobalErrorInfoException(OrderErrorInfoEnum.MAP_NOT_CONTAINSKEY_PRODUCTID);
			}
			if (orderLine.getDeliveryFlag() != null && orderLine.getDeliveryFlag() == 1) {
				i = i + 1;
				if (noDeliverItemVoMap.containsKey(orderLine.getUpc())) {
					// 查询商品是否可以配送
					LOG.info("storeId {},uid {} create order faild,cause of some item cant delivery ,the upc is {}", orderParam.getStoreId(), USER_ID, orderLine.getUpc());
					throw new GlobalErrorInfoException(OrderErrorInfoEnum.SOME_ITEM_CANT_DELIVERY);
				}
			}

			Long itemNumber = productIdAndItemNumberMap.get(productId);
			InventoryPriceVo invePrice = invePrices.get(itemNumber);
			ProductDetailVo productDetail = productDetails.get(itemNumber);
			CheckoutOrderLine checkOrderLine = setCheckOrderLine(orderLine, invePrice, productDetail, orderParam.getEwsPriceList(), orderLine.getEwsPrice(), orderLine.getEwsOptFlag());
			verifyOrderLineParam(checkOrderLine);
		}
		orderParam.setDeliveryFlag(i > 0 ? 1 : 0);
		if (orderParam.getDeliveryFlag() == 0 && orderParam.getShippingFeeItemLine() != null) {
			LOG.info("storeId {},uid {} create order faild,cause of  deliveryFlag is 0 ,but ShippingFeeItemLine has value ", orderParam.getStoreId(), USER_ID);
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.DELIVERYFLAG_IS_ZERO_AND_SHIPPINGFEE_ITEM_LINE_IS_NOT_NULL);
		}

	}

	/**
	 * 拼装校验数据
	 * 
	 * @param orderLine
	 * @param invePrice
	 * @param productDetail
	 * @param ewsPriceList
	 * @param ewsPrice
	 * @return
	 */
	private CheckoutOrderLine setCheckOrderLine(OrderLineParameter orderLine, InventoryPriceVo invePrice, ProductDetailVo productDetail, List<EwsPriceVo> ewsPriceList, EwsPriceVo ewsPrice,
			Integer ewsOptFlag) {
		CheckoutOrderLine checkOrderLine = new CheckoutOrderLine(orderLine);
		checkOrderLine.setProductDetail(productDetail);
		checkOrderLine.setInvePrice(invePrice);
		checkOrderLine.setEwsPriceList(ewsPriceList);
		checkOrderLine.setEwsPrice(ewsPrice);
		checkOrderLine.setEwsOptFlag(ewsOptFlag);
		return checkOrderLine;
	}

	/**
	 * 校验gp status\item status\price change\库存等信息
	 * 
	 * @param checkOrderLine
	 * @throws GlobalErrorInfoException
	 */
	private void verifyOrderLineParam(CheckoutOrderLine checkOrderLine) throws GlobalErrorInfoException {
		/*
		 * check item with follow order OFFER_CHANGE = 4, NOTSOLD = 1,
		 * INVENTORY_SHORTAGE = 2, PRICE_CHANGE = 3, PURCHASING_LIMIT = 5
		 */
		InventoryPriceVo invePrice = checkOrderLine.getInvePrice();
		if (invePrice == null) {
			LOG.info("upc:{},productId:{},validateOrderResult:{}", checkOrderLine.getUpc(), checkOrderLine.getProductId(), ValidateOrderResult.NOTSOLD);
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ITEM_NOTSOLD);

		}

		CheckOrderUtils.checkItemOfferChange(checkOrderLine);
		CheckOrderUtils.checkItemStatus(checkOrderLine);
		CheckOrderUtils.checkItemPriceChange(checkOrderLine);
		CheckOrderUtils.checkItemInventory(checkOrderLine);
		CheckOrderUtils.checkItemQuantity(checkOrderLine);

		if (checkOrderLine.getItemType() == ItemType.WEGITH_ITEM) {
			CheckOrderUtils.checkBarCodeAmountChange(checkOrderLine);
		}
		if (invePrice.getEwsFlag() != null && invePrice.getEwsFlag() == CheckOrderUtils.EWS_FLAG && checkOrderLine.getEwsOptFlag() == OrderCons.EWS_ITEM_SELECTED) {
			CheckOrderUtils.checkEwsPriceChange(checkOrderLine);
		}

	}

	/**
	 * 扫描加密规则校验
	 */
	@Override
	public void validateCheckSum(OrderScanParameter orderScanParameter) throws GlobalErrorInfoException {

		StringBuilder sb = new StringBuilder();
		String signString = sb.append(orderScanParameter.getAppKey()).append(orderScanParameter.getVersion()).append(orderScanParameter.getFormat()).append(orderScanParameter.getTimeStamp())
				.append(orderScanParameter.getOrderId()).append(orderScanParameter.getMac()).toString();
		LOG.info("signString:{}", signString);
		String checkSign = StringUtils.EMPTY;
		try {
			checkSign = SHA1Util.getSha1(signString);
		} catch (GlobalErrorInfoException e) {
			LOG.error("can't build checkSum", e);
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.CHECKSUM_CRYPTO_FAILED);
		}
		LOG.info("checkSign:{}", checkSign);
		if (!StringUtils.equals(checkSign, orderScanParameter.getSign())) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.CHECKSUM_NOT_COMPARE);
		}

	}

	@Override
	public void checkOrder(Order order) throws GlobalErrorInfoException {
		if (order == null) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.USER_ORDER_NOT_EXIST);
		}
		if (order.getScanTime() != null || order.getStatus() == OrderStatus.COMPLETE) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.SCAN_ORDER_HAS_COMPLETED);
		}
		/**
		 * if (order.getScanTime() != null) { throw new
		 * GlobalErrorInfoException(
		 * OrderErrorInfoEnum.SCAN_ORDER_HAS_COMPLETED); }
		 */
	}

	/**
	 * 查询延保商品信息
	 * 
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	@Override
	public void prepareEwsOrderLineList(OrderParameter orderParam) throws GlobalErrorInfoException {
		List<OrderLineParameter> orderLines = orderParam.getOrderLines();
		List<OrderEwsLine> orderEwsLineList = new ArrayList<>();

		List<Long> itemNumberList = buildItemNumberList(orderLines);
		if (CollectionUtils.isEmpty(itemNumberList)) {
			orderParam.setOrderEwsLineList(orderEwsLineList);
			return;
		}

		List<InventoryPriceVo> inventoryPriceList = itemServiceClient.findByStoreIdAndItemNumberIn(orderParam.getStoreId(), itemNumberList);
		Map<Long, InventoryPriceVo> invePriceMap = new HashMap<>(16);
		for (InventoryPriceVo inventoryPriceVo : inventoryPriceList) {
			invePriceMap.put(inventoryPriceVo.getItemNumber(), inventoryPriceVo);
		}
		Map<Long, ProductDetailVo> productDetailMap = getProductByProductIds(itemNumberList);

		buildOrderEwsLine(orderParam, orderLines, orderEwsLineList, invePriceMap, productDetailMap);
		orderParam.setOrderEwsLineList(orderEwsLineList);
	}

	/**
	 * 组装orderEwsLine
	 * 
	 * @param orderParam
	 * @param orderLines
	 * @param orderEwsLineList
	 * @param invePriceMap
	 * @param productDetailMap
	 */
	private void buildOrderEwsLine(OrderParameter orderParam, List<OrderLineParameter> orderLines, List<OrderEwsLine> orderEwsLineList, Map<Long, InventoryPriceVo> invePriceMap,
			Map<Long, ProductDetailVo> productDetailMap) {
		Date returnBy = OrderUtils.getReturnBy(rejectItemOverTime);
		for (OrderLineParameter orderLineParameter : orderLines) {
			Long cartItemId = orderLineParameter.getCartItemId();
			OrderEwsLine orderEwsLine;
			EwsPriceVo ewsPrice = orderLineParameter.getEwsPrice();
			if (ewsPrice != null) {
				orderEwsLine = new OrderEwsLine();
				InventoryPriceVo inventoryPriceVo = invePriceMap.get(ewsPrice.getItemNumber());
				ProductDetailVo productDetailVo = productDetailMap.get(ewsPrice.getItemNumber());
				if (productDetailMap.containsKey(ewsPrice.getItemNumber())) {
					orderEwsLine.setThumbnailUrl(productDetailVo.getThumbnailUrl());
					orderEwsLine.setDepartment(inventoryPriceVo.getDepartmentWmInternal() != null ? inventoryPriceVo.getDepartmentWmInternal() : productDetailVo.getDepartmentWmInternal());
					orderEwsLine.setUpc(productDetailVo.getUpc());
				}
				orderEwsLine.setOrderQuantity(ewsPrice.getEwsQuantity());
				orderEwsLine.setCartItemId(cartItemId);
				orderEwsLine.setOrderId(orderParam.getOrderId());
				orderEwsLine.setPosDescOnline(inventoryPriceVo.getPosDescOnline());
				orderEwsLine.setItemNumber(inventoryPriceVo.getItemNumber());
				orderEwsLine.setItemType(0);
				orderEwsLine.setReturnBy(returnBy);
				orderEwsLine.setPriceWithoutTax(inventoryPriceVo.getPriceWithoutTax());
				orderEwsLine.setPriceWithTax(new BigDecimal(String.valueOf(inventoryPriceVo.getPriceWithTax())));
				orderEwsLine.setProductId(inventoryPriceVo.getProductId());
				orderEwsLine.setReportCode(inventoryPriceVo.getReportCode());
				orderEwsLine.setStoreId(inventoryPriceVo.getStoreId());
				orderEwsLine.setTaxRate(inventoryPriceVo.getTaxRate());
				orderEwsLine.setUnitCost(inventoryPriceVo.getUnitCost());
				orderEwsLine.setWasPrice(new BigDecimal(String.valueOf(inventoryPriceVo.getWasPrice())));
				orderEwsLine.setDescOnline(inventoryPriceVo.getDescOnline());
				orderEwsLineList.add(orderEwsLine);
			}
		}
	}

	private List<Long> buildItemNumberList(List<OrderLineParameter> orderLines) {
		List<Long> itemNumberList = new ArrayList<>();
		for (OrderLineParameter orderLineParameter : orderLines) {
			EwsPriceVo ewsPrice = orderLineParameter.getEwsPrice();
			if (ewsPrice == null) {
				continue;
			}

			itemNumberList.add(ewsPrice.getItemNumber());
		}
		return itemNumberList;

	}

	@Override
	public void queryOrderInformationCheckSum(String appKey, String version, String format, Date timeStamp, String orderId, String sign) throws GlobalErrorInfoException {
		StringBuilder sb = new StringBuilder();
		String signString = sb.append(appKey).append(version).append(format).append(timeStamp).append(orderId).append(OrderCons.APPSECUERT).toString();
		commonCheckSum(sign, signString);
	}

	@Override
	public void monitorCheckSum(String appKey, String version, String format, Long timeStamp, String orderId, String sign, String mac, String mobilePhone) throws GlobalErrorInfoException {
		StringBuilder sb = new StringBuilder();
		String signString = sb.append(appKey).append(version).append(format).append(timeStamp).append(orderId).append(mobilePhone).append(mac).append(OrderCons.APPSECUERT).toString();
		commonCheckSum(sign, signString);
	}

	@Override
	public void macCheckSum(String appKey, String version, String format, Long timeStamp, String sign, String mac) throws GlobalErrorInfoException {
		StringBuilder sb = new StringBuilder();
		String signString = sb.append(appKey).append(version).append(format).append(timeStamp).append(mac).append(OrderCons.APPSECUERT).toString();
		commonCheckSum(sign, signString);
	}

	private void commonCheckSum(String sign, String signString) throws GlobalErrorInfoException {
		LOG.info("signString:{}", signString);
		String checkSign = StringUtils.EMPTY;
		try {
			checkSign = SHA512.hashValue(signString);
		} catch (NoSuchAlgorithmException e) {
			LOG.error("can't build checkSum", e);
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.CHECKSUM_CRYPTO_FAILED);
		}
		LOG.info("checkSign:{}", checkSign);
		if (!StringUtils.equals(checkSign, sign)) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.CHECKSUM_NOT_COMPARE);
		}
	}

	@Override
	public void generateInvoiceVerify(OrderBo order) throws GlobalErrorInfoException {
		if (order == null) {
			throw new GlobalErrorInfoException(GlobalErrorInfoEnum.USER_UNAUTHORIZED);
		}
		if (StringUtils.isEmpty(order.getTcNumber())) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.TC_NUMBER_NOT_EXIST);
		}
		if (order.getPayType() == OrderCons.EGIFTCARD) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.EGIFT_CARD_CANT_GENERATE_INVOICE);
		}
		/**
		 * pad 整单不通过订单，不允许申请
		 */
		if (order.getStatus() == OrderStatus.PAID_CANCELLING || order.getStatus() == OrderStatus.PAID_CANCELLED) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.PAD_CANCEL_ORDER_NOT_ALLOW_REJECT_APPROVE);
		}
		int day = DateUtil.daysBetween(order.getPaidTime(), new Date());
		if (day > overTime) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.OVER_TIMNE);
		}

		/**
		 * 判断订单是否已经开具纸质发票
		 */
		if (order.getInvoiceNo() != null && "-1".equals(order.getInvoiceNo())) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.PAPER_INVOICE_HAS_CREATE);
		}
	}

	@Override
	public void rejectItemApplyVerify(Order order, Date returnBy) throws GlobalErrorInfoException {
		if (order == null) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDER_NOT_EXIST);
		}
		/**
		 * pad 整单不通过订单，不允许申请
		 */
		if (order.getStatus() == OrderStatus.PAID_CANCELLING || order.getStatus() == OrderStatus.PAID_CANCELLED) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.PAD_CANCEL_ORDER_NOT_ALLOW_REJECT_APPROVE);
		}

		/**
		 * 不是支付或者完成状态的不允许退货
		 */
		if (order.getStatus() != OrderStatus.PAID && order.getStatus() != OrderStatus.COMPLETE) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.CURRENT_ORDER_STATUS_NOT_ALLOW_REJECT_APPROVE);
		}
		/**
		 * 当前时间不能大于returnBy时间
		 */
		if (DateUtil.daysBetween(returnBy, new Date()) > 0) {
			LOG.info("the rejecttime over returnBy ,returnBy is {}", returnBy);
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.REJECT_ITEM_OVER_TIME);
		}
	}

	@Override
	public void prepareShippingFeeItem(OrderParameter orderParameter) throws GlobalErrorInfoException {
		Date returnBy = OrderUtils.getReturnBy(rejectItemOverTime);
		ShippingFeeItemParameter shippingFeeItemParameter = orderParameter.getShippingFeeItemLine();
		if (orderParameter.getDeliveryFlag() == 0 || shippingFeeItemParameter == null) {
			LOG.info("the delivery flag is 0 or shippingFeeItemParameter is null");
			return;
		}
		Long productId = shippingFeeItemParameter.getProductId();
		InventoryPriceVo inventoryPrice = itemServiceClient.findByStoreIdAndProductId(orderParameter.getStoreId(), productId);
		ProductDetailVo productDetail = itemServiceClient.findByItemNumber(inventoryPrice.getItemNumber());

		OrderShippingLine orderShippingLine = new OrderShippingLine();

		orderShippingLine.setThumbnailUrl(productDetail.getThumbnailUrl());
		orderShippingLine.setDepartment(inventoryPrice.getDepartmentWmInternal() != null ? inventoryPrice.getDepartmentWmInternal() : productDetail.getDepartmentWmInternal());
		orderShippingLine.setUpc(productDetail.getUpc());
		orderShippingLine.setOrderQuantity(shippingFeeItemParameter.getOrderQuantity());
		orderShippingLine.setCartItemId(shippingFeeItemParameter.getCartItemId());
		/** orderShippingLine.setOrderId(orderParam.getOrderId()); */
		orderShippingLine.setPosDescOnline(inventoryPrice.getPosDescOnline());
		orderShippingLine.setItemNumber(inventoryPrice.getItemNumber());
		orderShippingLine.setItemType(productDetail.getItemType());
		orderShippingLine.setReturnBy(returnBy);
		orderShippingLine.setPriceWithoutTax(inventoryPrice.getPriceWithoutTax());
		orderShippingLine.setPriceWithTax(new BigDecimal(String.valueOf(inventoryPrice.getPriceWithTax())));
		orderShippingLine.setProductId(inventoryPrice.getProductId());
		orderShippingLine.setReportCode(inventoryPrice.getReportCode());
		orderShippingLine.setStoreId(inventoryPrice.getStoreId());
		orderShippingLine.setTaxRate(inventoryPrice.getTaxRate());
		orderShippingLine.setUnitCost(inventoryPrice.getUnitCost());
		orderShippingLine.setWasPrice(new BigDecimal(String.valueOf(inventoryPrice.getWasPrice())));
		orderShippingLine.setDescOnline(inventoryPrice.getDescOnline());

		orderParameter.setOrderShippingLine(orderShippingLine);
	}

}
