package com.walmart.mobile.checkout.domain.route;

public class DagDomain {
	private String dagId;
	private String host;

	public String getDagId() {
		return dagId;
	}

	public void setDagId(String dagId) {
		this.dagId = dagId;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}
}
