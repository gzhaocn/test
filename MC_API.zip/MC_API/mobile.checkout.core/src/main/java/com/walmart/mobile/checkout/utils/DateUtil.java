package com.walmart.mobile.checkout.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import org.springframework.data.redis.core.TimeoutUtils;

public class DateUtil {

	private static final DateFormat DEFAULT_DATE_FORMART = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	public static final String PATTERN_FPRMART = "yyyy-MM-dd";
	public static final String PATTERN_YYYYMMDD = "yyyyMMdd";
	/** UTC time zone. */
	private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

	/** Default locale. */
	private static final Locale DEFAULT_LOCALE = Locale.getDefault();

	/**
	 * Number of milliseconds between standard Unix era (1/1/1970) and filetime
	 * start (1/1/1601).
	 */
	private static final long ERA_OFFSET = 11644473600000L;

	/**
	 * File time uses 100-nanosecond intervals. For conversion purposes this is
	 * 1x10^6 / 100.
	 */
	private static final long ONE_HUNDRED_NANOSECOND_INTERVAL = 10000L;

	private DateUtil() {
	}

	public static final String getDefaultDateString() {
		return getDateString(new Date());
	}

	public static final String getDateString(Date date) {
		return DEFAULT_DATE_FORMART.format(date);
	}

	public static Calendar decodeStringValue(final String value) {
		final Calendar calendar = Calendar.getInstance(UTC, DEFAULT_LOCALE);
		calendar.setTimeInMillis(Long.parseLong(value) / ONE_HUNDRED_NANOSECOND_INTERVAL - ERA_OFFSET);
		return calendar;
	}

	/**
	 * 格式化日期为yyyy-MM-dd
	 * 
	 * @param date
	 * @return
	 */
	public static String formateDate(Date date) {
		return dateToString(date, PATTERN_FPRMART);
	}

	/**
	 * @param 将指定日期
	 *            ,以指定pattern格式,输出String值
	 * @return
	 */
	public static String dateToString(Date date, String pattern) {
		if (date == null) {
			return "";
		} else {
			SimpleDateFormat format = new SimpleDateFormat(pattern);
			return format.format(date);
		}
	}

	/**
	 * @param 将指定字符型日期转为日期型
	 *            ,指定格式为yyyy-MM-dd
	 * @return
	 */
	public static Date stringToDate(String string) {
		return stringToDate(string, PATTERN_FPRMART);
	}

	/**
	 * @param 将指定字符型日期转为日期型
	 *            ,,格式为指定的pattern
	 * @return
	 */
	public static Date stringToDate(String string, String pattern) {
		SimpleDateFormat format = (SimpleDateFormat) DateFormat.getDateInstance();
		format.applyPattern(pattern);
		try {
			return format.parse(string);
		} catch (ParseException e) {
			return null;
		}
	}

	public static Date currentAddDate(Integer add) {
		return new Date(System.currentTimeMillis() + TimeoutUtils.toMillis(add, TimeUnit.SECONDS));
	}

	public static Date currentEndDate() {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 59);
		calendar.set(Calendar.SECOND, 59);
		calendar.set(Calendar.MILLISECOND, 999);
		return calendar.getTime();
	}

	public static final int daysBetween(Date early, Date late) {

		Calendar calst = Calendar.getInstance();
		Calendar caled = Calendar.getInstance();
		calst.setTime(early);
		caled.setTime(late);
		// 设置时间为0时
		calst.set(java.util.Calendar.HOUR_OF_DAY, 0);
		calst.set(java.util.Calendar.MINUTE, 0);
		calst.set(java.util.Calendar.SECOND, 0);
		caled.set(java.util.Calendar.HOUR_OF_DAY, 0);
		caled.set(java.util.Calendar.MINUTE, 0);
		caled.set(java.util.Calendar.SECOND, 0);
		// 得到两个日期相差的天数
		return ((int) (caled.getTime().getTime() / 1000) - (int) (calst.getTime().getTime() / 1000)) / 3600 / 24;

	}

	/**
	 * 计算差多少分钟
	 * 
	 * @param endDate
	 * @param nowDate
	 * @return
	 */
	public static long getMinutePoor(Date endDate, Date nowDate) {
		// 获得两个时间的毫秒时间差异
		long diff = endDate.getTime() - nowDate.getTime();
		// 计算差多少分钟
		return diff / 1000 / 60;
	}

}
