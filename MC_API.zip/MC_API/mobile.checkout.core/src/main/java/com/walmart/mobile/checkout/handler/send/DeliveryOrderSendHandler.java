package com.walmart.mobile.checkout.handler.send;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import com.walmart.mobile.checkout.annotation.JmsHandler;

@JmsHandler
public class DeliveryOrderSendHandler {

	@Autowired
	private JmsTemplate jmsTemplate;

	@Value("${deliveryOrder.queue.name}")
	private String deliveryOrderQueueName;

	private static final Logger LOG = LoggerFactory.getLogger(DeliveryOrderSendHandler.class);
	
	public void sendMessage(final String msg) {

		LOG.info("delivery order msg is {}",msg);
		jmsTemplate.send(deliveryOrderQueueName, new MessageCreator() {
			@Override
			public Message createMessage(Session session) throws JMSException {
				return session.createTextMessage(msg);
			}
		});

	}
	

}
