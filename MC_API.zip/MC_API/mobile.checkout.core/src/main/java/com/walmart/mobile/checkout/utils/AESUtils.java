package com.walmart.mobile.checkout.utils;

import java.security.Key;
import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import com.walmart.mobile.checkout.constant.GlobalErrorInfoEnum;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;

public class AESUtils {

	private static final Logger LOG = LoggerFactory.getLogger(AESUtils.class);

	// 密钥
	private static Key key;
	// KEY种子
	public static String keySTR = "ISD.Jenkins@email.wal-mart.com/cn";
	// 常量
	public static final String UTF_8 = "UTF-8";
	public static final String AES = "AES";

	private static final String ENCRYPT_STR = " encrypt:";

	private AESUtils() {

	}

	/**
	 * 设置加密的key种子
	 * 
	 * @param keyStr
	 *            加密解密的key种子
	 * @throws GlobalErrorInfoException
	 */
	public static void setKey(String keyStr) throws GlobalErrorInfoException {
		try {
			keySTR = keyStr;
			// KEY 生成�?
			KeyGenerator generator = KeyGenerator.getInstance(AES);
			// 初始�?,安全随机算子
			SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
			random.setSeed(keyStr.getBytes(UTF_8));
			generator.init(random);
			// 生成密钥
			key = generator.generateKey();
		} catch (Exception e) {
			throw new GlobalErrorInfoException(GlobalErrorInfoEnum.AES_UTILS_EXCEPTION, e);
		}
	}

	/**
	 * 对源字符串加�?,返回 BASE64编码后的加密字符�? 若调用此方法前尚未对其加密的key进行初始化，�?要调用setKey(String
	 * keyStr)方法，或encode(String source, String keyStr)
	 * 
	 * @param source
	 *            源字符串,明文
	 * @return 密文字符�?
	 */
	public static String encode(String source) {
		try {
			// 根据编码格式获取字节数组
			byte[] sourceBytes = source.getBytes(UTF_8);
			// DES 加密模式
			Cipher cipher = Cipher.getInstance("AES");
			cipher.init(Cipher.ENCRYPT_MODE, key);
			// 加密后的字节数组
			byte[] encryptSourceBytes = cipher.doFinal(sourceBytes);
			// Base64编码�?
			BASE64Encoder base64Encoder = new BASE64Encoder();
			return base64Encoder.encode(encryptSourceBytes);
		} catch (Exception e) {
			// throw 也算是一�? return 路径
			LOG.error(e.getMessage() + ENCRYPT_STR + source, e);
		}
		return source;
	}

	/**
	 * 对源字符串加�?,返回 BASE64编码后的加密字符�?
	 * 
	 * @param source
	 *            源字符串,明文
	 * @param keyStr
	 *            KEY种子
	 * @return 密文字符�?
	 */
	public static String encode(String source, String keyStr) {
		try {
			if (key == null || !keySTR.equals(keyStr)) {
				setKey(keyStr);
			}
			// 根据编码格式获取字节数组
			byte[] sourceBytes = source.getBytes(UTF_8);
			// DES 加密模式
			Cipher cipher = Cipher.getInstance("AES");
			cipher.init(Cipher.ENCRYPT_MODE, key);
			// 加密后的字节数组
			byte[] encryptSourceBytes = cipher.doFinal(sourceBytes);
			// Base64编码�?
			BASE64Encoder base64Encoder = new BASE64Encoder();
			return base64Encoder.encode(encryptSourceBytes);
		} catch (Exception e) {
			// throw 也算是一�? return 路径
			LOG.error(e.getMessage() + ENCRYPT_STR + source, e);
		}
		return source;
	}

	/**
	 * 对本工具�? encode() 方法加密后的字符串进行解�?/解密
	 * 若调用此方法前尚未对其加密解密的key进行初始化，�?要调用setKey(String keyStr)方法，或decode(String
	 * encrypted, String keyStr)
	 * 
	 * @param encrypted
	 *            被加密过的字符串,即密�?
	 * @return 明文字符�?
	 */
	public static String decode(String encrypted) {
		// Base64解码�?
		BASE64Decoder base64Decoder = new BASE64Decoder();
		try {
			// 先进行base64解码
			byte[] cryptedBytes = base64Decoder.decodeBuffer(encrypted);
			// DES 解密模式
			Cipher cipher = Cipher.getInstance("AES");
			cipher.init(Cipher.DECRYPT_MODE, key);
			// 解码后的字节数组
			byte[] decryptStrBytes = cipher.doFinal(cryptedBytes);
			// 采用给定编码格式将字节数组变成字符串
			return new String(decryptStrBytes, UTF_8);
		} catch (Exception e) {
			// 这种形式确实适合处理工具�?
			LOG.error(e.getMessage() + ENCRYPT_STR + encrypted, e);
		}
		return encrypted;
	}

	/**
	 * 对本工具�? encode() 方法加密后的字符串进行解�?/解密
	 * 
	 * @param encrypted
	 *            被加密过的字符串,即密�?
	 * @param keyStr
	 *            KEY种子
	 * @return 明文字符�?
	 */
	public static String decode(String encrypted, String keyStr) {
		// Base64解码�?
		BASE64Decoder base64Decoder = new BASE64Decoder();
		try {
			if (key == null || !keySTR.equals(keyStr)) {
				setKey(keyStr);
			}
			// 先进行base64解码
			byte[] cryptedBytes = base64Decoder.decodeBuffer(encrypted);
			// DES 解密模式
			Cipher cipher = Cipher.getInstance("AES");
			cipher.init(Cipher.DECRYPT_MODE, key);
			// 解码后的字节数组
			byte[] decryptStrBytes = cipher.doFinal(cryptedBytes);
			// 采用给定编码格式将字节数组变成字符串
			return new String(decryptStrBytes, UTF_8);
		} catch (Exception e) {
			// 这种形式确实适合处理工具�?
			LOG.error(e.getMessage() + ENCRYPT_STR + encrypted, e);
		}
		return encrypted;
	}
}
