package com.walmart.mobile.checkout.constant;

import com.walmart.mobile.checkout.utils.PropertyUtils;

public class AlipayConstants {

	public static final String PARTNER = PropertyUtils.getConfigValue("alipay.partner");
	public static final String PARTNER_FOREX = PropertyUtils.getConfigValue("alipay.forex.partner");

	public static final String SELLRR = PropertyUtils.getConfigValue("alipay.seller");
	public static final String SELLRR_FOREX = PropertyUtils.getConfigValue("alipay.forex.seller");
	public static final String CURRENCY_FOREX = PropertyUtils.getConfigValue("alipay.forex.currency");

	public static final String PRIVATE_KEY = PropertyUtils.getConfigValue("alipay.private_key");
	public static final String PRIVATE_KEY_FOREX = PropertyUtils.getConfigValue("alipay.forex.private_key");
	public static final String PUBLIC_KEY = PropertyUtils.getConfigValue("alipay.public_key");

	public static final String ALI_PUBLIC_KEY = PropertyUtils.getConfigValue("alipay.ali_public_key");

	public static final String INPUT_CHARSET = PropertyUtils.getConfigValue("alipay.input_charset");

	public static final String SIGN_TYPE = PropertyUtils.getConfigValue("alipay.sign_type");

	public static final String HTTPS_UTL = PropertyUtils.getConfigValue("alipay.HTTPS_URL");

	/**
	 * Response parameter name.
	 */
	public static final String RESPONSE_PARAMETER_OUT_TRADE_NO = "out_trade_no";
	/**
	 * Response parameter name.
	 */
	public static final String RESPONSE_PARAMETER_TRADE_STATUS = "trade_status";

	/**
	 * 交易成功且结束，即不可再做任何操作。
	 */
	public static final String TRADE_STATUS_TRADE_FINISHED = "TRADE_FINISHED";
	/**
	 * 交易成功，且可对该交易做操作，如：多级分润、退款等。
	 */
	public static final String TRADE_STATUS_TRADE_SUCCESS = "TRADE_SUCCESS";
	/**
	 * 交易创建，等待买家付款。
	 */
	public static final String TRADE_STATUS_WAIT_BUYER_PAY = "WAIT_BUYER_PAY";
	/**
	 * 在指定时间段内未支付时关闭的交易； 在交易完成全额退款成功时关闭的交易。
	 */
	public static final String TRADE_STATUS_TRADE_CLOSED = "TRADE_CLOSED";

	/**
	 * Successfully pay, return this string
	 */
	public static final String PAY_SUCCESS_RESPONSE_TEXT = "SUCCESS";

	/**
	 * Failed to pay, return this string.
	 */
	public static final String PAY_FAILED_RESPONSE_TEXT = "FAILED";

	private AlipayConstants() {
	};

}
