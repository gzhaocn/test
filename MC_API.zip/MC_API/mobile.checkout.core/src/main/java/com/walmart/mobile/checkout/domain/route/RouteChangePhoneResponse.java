
package com.walmart.mobile.checkout.domain.route;

public class RouteChangePhoneResponse {
	private int errorCode;

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
}
