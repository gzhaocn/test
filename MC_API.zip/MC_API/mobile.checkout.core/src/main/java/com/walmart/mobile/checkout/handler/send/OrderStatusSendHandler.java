package com.walmart.mobile.checkout.handler.send;

import java.util.Calendar;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.apache.activemq.ScheduledMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import com.walmart.mobile.checkout.annotation.JmsHandler;

@JmsHandler
public class OrderStatusSendHandler {
   
	@Autowired
	private JmsTemplate jmsTemplate;

	@Value("${order.status.queue.name}")
	private String orderStatusQueueName;
	
	@Value("${invoice.delay.time}")
	private String orderCompleteTime;

	public void sendMessage(final String msg) {
		jmsTemplate.send(orderStatusQueueName, new MessageCreator() {
			@Override
			public Message createMessage(Session session) throws JMSException {
				Message message = session.createTextMessage(msg);
			    message.setLongProperty(ScheduledMessage.AMQ_SCHEDULED_DELAY, getNearNextDayTime());
				return message;
			}
		});
	}
	
	
	private long getNearNextDayTime(){
		final Calendar cal = Calendar.getInstance(); 
	    cal.set(Calendar.DAY_OF_MONTH, cal.get(Calendar.DAY_OF_MONTH)); 
	    cal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(orderCompleteTime)); 
	    cal.set(Calendar.MINUTE, 0); 
	    cal.set(Calendar.SECOND, 0); 
	    cal.set(Calendar.MILLISECOND, 0); 
	   return  cal.getTimeInMillis() - System.currentTimeMillis();  
	}
}
