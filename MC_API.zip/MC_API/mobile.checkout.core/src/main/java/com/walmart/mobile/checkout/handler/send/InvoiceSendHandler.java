package com.walmart.mobile.checkout.handler.send;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.apache.activemq.ScheduledMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import com.walmart.mobile.checkout.annotation.JmsHandler;

@JmsHandler
public class InvoiceSendHandler {

	@Autowired
	private JmsTemplate jmsTemplate;

	@Value("${invoice.send.queue.name}")
	private String invoiceSendQueueName;

	public void invoiceSendMessage(final String msg) {
		jmsTemplate.send(invoiceSendQueueName, new MessageCreator() {
			@Override
			public Message createMessage(Session session) throws JMSException {
				return session.createTextMessage(msg);
			}
		});
	}
	
	public void invoiceDelaySendMessage(final String msg) {
		jmsTemplate.send(invoiceSendQueueName, new MessageCreator() {
			@Override
			public Message createMessage(Session session) throws JMSException {
				Message message = session.createTextMessage(msg);
			    message.setLongProperty(ScheduledMessage.AMQ_SCHEDULED_DELAY, 300000L);
				return message;
			}
		});
	}

}
