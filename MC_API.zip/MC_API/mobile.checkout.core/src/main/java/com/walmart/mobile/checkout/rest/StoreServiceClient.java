package com.walmart.mobile.checkout.rest;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.walmart.mobile.checkout.domain.StoreVo;

@FeignClient("storeService")
@FunctionalInterface
public interface StoreServiceClient {

	@RequestMapping(method = RequestMethod.GET, value = "/findByStoreId")
	StoreVo findByStoreId(@RequestParam(value = "storeId") Integer storeId);

	/**
	 * @RequestMapping(method = RequestMethod.GET, value = "/save") void
	 *                        save(@RequestParam(value = "storeVo")StoreVo
	 *                        storeVo);
	 */

}
