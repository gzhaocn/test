package com.walmart.mobile.checkout.redis;

import org.springframework.data.repository.CrudRepository;

import com.walmart.mobile.checkout.redis.vo.RedisBean;

public interface RedisOperationRepo<T> extends CrudRepository<RedisBean<T>, String> {
}
