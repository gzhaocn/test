package com.walmart.mobile.checkout.dag;

public class RequestMethod {
	private String method;

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}
}
