package com.walmart.mobile.checkout.constant;

/**
 * 登录类型定义.
 *
 */
public class LoginType {

	/**
	 * 当前未使用
	 */
	public static final int EMAIL = 1;
	/**
	 * 手机登录
	 */
	public static final int PHONE = 2;
	/**
	 * 微信
	 */
	public static final int WECHAT = 3;
	/**
	 * 腾讯QQ
	 */
	public static final int QQ = 4;
	/**
	 * 微博
	 */
	public static final int WEIBO = 5;

	/**
	 * 微信
	 */
	public static final int WECHAT_CHECKOUT = 6;
	
	private LoginType() {

	}
}
