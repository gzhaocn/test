package com.walmart.mobile.checkout.domain;

public class TokenAuth {
	
	private String token;
	private String dagId;
	private String appType;
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getDagId() {
		return dagId;
	}
	public void setDagId(String dagId) {
		this.dagId = dagId;
	}
	public String getAppType() {
		return appType;
	}
	public void setAppType(String appType) {
		this.appType = appType;
	}

}
