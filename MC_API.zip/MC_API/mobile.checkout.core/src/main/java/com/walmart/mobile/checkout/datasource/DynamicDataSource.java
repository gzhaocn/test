package com.walmart.mobile.checkout.datasource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

import com.walmart.mobile.checkout.utils.ThreadLocalContextHolder;

public class DynamicDataSource extends AbstractRoutingDataSource {

	private static final Logger LOG = LoggerFactory.getLogger(DynamicDataSource.class);

	private boolean isBoot = false;

	@Override
	protected Object determineCurrentLookupKey() {
		return ThreadLocalContextHolder.get("dagId", String.class);
	}

	@Override
	public void afterPropertiesSet() {
		try {
			super.afterPropertiesSet();
		} catch (IllegalArgumentException e) {
			if (isBoot) {
				LOG.error("no error in initializing the dynamicDatasource,cause:{}", e);
			} else {
				isBoot = true;
			}
		}
	}
}
