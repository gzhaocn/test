package com.walmart.mobile.checkout.config;

import java.io.IOException;

import javax.sql.DataSource;

import org.mybatis.spring.SqlSessionFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.web.client.RestTemplate;

import com.walmart.mobile.checkout.constant.GlobalErrorInfoEnum;
import com.walmart.mobile.checkout.datasource.DynamicDataSource;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoRuntimeException;

@Configuration
public class UserDynamicConfig {

	@Value("${ddr.request.param}")
	private String ddrParam;

	@Value("${ddr.request.url}")
	private String ddrUrl;

	@Value("${check.user.url}")
	private String checkUserUrl;

	@Autowired
	private RestTemplate restTemplate;

	@Bean(name = "userDynamicDataSource")
	public DataSource userDynamicDataSource() {
		return new DynamicDataSource();
	}

	public Resource[] getXmlResource() {
		String packageSearchPath = "classpath*:userMapper/**/*.xml";
		Resource[] resources = null;
		try {
			resources = new PathMatchingResourcePatternResolver().getResources(packageSearchPath);
		} catch (IOException e) {
			throw new GlobalErrorInfoRuntimeException(GlobalErrorInfoEnum.RESOURCE_NOT_EXIST, e);
		}
		return resources;
	}

	@Bean(name = "userDynamicSqlServerSessionFactory")
	public SqlSessionFactoryBean userDynamicSqlServerSessionFactory() {
		SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
		bean.setDataSource(userDynamicDataSource());
		bean.setMapperLocations(getXmlResource());
		return bean;
	}

	@Bean(name = "userDynamicSqlServerTransactionManager")
	public DataSourceTransactionManager userDynamicSqlServerTransactionManager() {
		return new DataSourceTransactionManager(userDynamicDataSource());
	}
}
