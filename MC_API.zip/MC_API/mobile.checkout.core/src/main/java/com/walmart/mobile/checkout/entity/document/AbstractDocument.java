/*
 * Copyright 2012 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.walmart.mobile.checkout.entity.document;

import java.io.Serializable;

/**
 * 抽象实体基类
 * <p>
 * User: feixuhui
 * <p>
 * Date: 15-1-12
 * <p>
 * Version: 1.0
 */
public abstract class AbstractDocument<I extends Serializable> implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Returns the identifier of the document.
	 * 
	 * @return the id
	 */
	public abstract I getId();

	/**
	 * Sets the id of the document.
	 *
	 * @param id
	 *            the id to set
	 */
	public abstract void setId(final I id);

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {

		if (this == obj) {
			return true;
		}

		if (this.getId() == null || obj == null || !(this.getClass().equals(obj.getClass()))) {
			return false;
		}

		AbstractDocument<?> that = (AbstractDocument<?>) obj;

		return this.getId().equals(that.getId());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.data.domain.Persistable#isNew()
	 */
	// public boolean isNew() {
	//
	// return null == getId();
	// }
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return this.getId() == null ? 0 : this.getId().hashCode();
	}
}
