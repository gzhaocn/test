package com.walmart.mobile.checkout.exception.handler;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.constant.GlobalErrorInfoEnum;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoRuntimeException;
import com.walmart.mobile.checkout.kafka.MsgProducer;
import com.walmart.mobile.checkout.utils.ThreadLocalContextHolder;

/**
 * 统一错误码异常处理
 * 
 * @author lliao2
 */
@ControllerAdvice
public class GlobalErrorInfoHandler {
	private static final Logger LOGGER = LoggerFactory.getLogger(GlobalErrorInfoHandler.class);
	@Autowired
	private MsgProducer msgProducer;
	@Autowired
	private HttpServletRequest request;

	@Value("${kafka.enable}")
	private boolean kafkaEnable;

	@ExceptionHandler(Throwable.class)
	@ResponseBody
	public ResultBody handleThrowable(Throwable ex) {
		return getResultBody(GlobalErrorInfoEnum.FAILED, ex, false);
	}

	@ExceptionHandler(IllegalArgumentException.class)
	@ResponseBody
	public ResultBody illegalArgumentExceptionhandleThrowable(IllegalArgumentException ex) {
		return getResultBody(GlobalErrorInfoEnum.FAILED, ex, false);
	}

	@ExceptionHandler(RuntimeException.class)
	@ResponseBody
	public ResultBody runtimeExceptionhandleThrowable(RuntimeException ex) {
		return getResultBody(GlobalErrorInfoEnum.FAILED, ex, false);
	}

	@ExceptionHandler(value = GlobalErrorInfoException.class)
	@ResponseBody
	public ResultBody errorHandlerOverJson(HttpServletRequest request, GlobalErrorInfoException ex) {
		ResultBody ret = getResultBody(ex.getErrorInfo(), ex, ex.isPrint());
		ret.setResult(ex.getDate());
		return ret;
	}

	@ExceptionHandler(value = GlobalErrorInfoRuntimeException.class)
	@ResponseBody
	public ResultBody runtimeEerrorHandlerOverJson(HttpServletRequest request, GlobalErrorInfoRuntimeException ex) {
		return getResultBody(ex.getErrorInfo(), ex, ex.isPrint());
	}

	private ResultBody getResultBody(ErrorInfoInterface errorInfo, Throwable ex, boolean bool) {
		if (bool) {
			LOGGER.error("don't print error stack.request url:{},{}", request.getServletPath(), ex.getMessage());
		} else {
			LOGGER.error("print error stack.request url:{}", request.getServletPath(), ex);
		}
		ResultBody ret = new ResultBody(errorInfo);

		Long begin = ThreadLocalContextHolder.get("begin", Long.class);
		Long time = null;
		if (begin != null) {
			time = System.currentTimeMillis() - begin;
		}
		ret.setResponseTime(time);

		String result = JSON.toJSON(ret).toString();
		LOGGER.info("RESPONSE: {}, SPEND TIME: {}", result, time);

		JSONObject json = new JSONObject();
		json.put("traceId", ThreadLocalContextHolder.get("traceId", String.class));
		json.put("respBody", result);
		json.put("reqBody", ThreadLocalContextHolder.get("reqBody", String.class));
		json.put("url", ThreadLocalContextHolder.get("url", String.class));
		json.put("usedTime", time);
		json.put("clientInfo", ThreadLocalContextHolder.get("clientInfo", String.class));
		json.put("sendTime", System.currentTimeMillis());

		setUserAndIdToThread();

		if (kafkaEnable) {
			try {
				msgProducer.send(json.toJSONString());
			} catch (Exception e) {
				LOGGER.error("kafka send error ,{}", e);
			}
		}

		return ret;
	}

	private void setUserAndIdToThread() {
		String threadName = ThreadLocalContextHolder.get("threadName", String.class);
		if (StringUtils.isNotBlank(threadName)) {
			Thread.currentThread().setName(threadName);
		}
	}
}
