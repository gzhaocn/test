package com.walmart.mobile.checkout.restConfig;

import java.lang.reflect.Proxy;

import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

public class RestFactoryBean<T> implements FactoryBean<T> {
  private Class<T> mapperInterface;

  private boolean addToConfig = true;
  
  @Autowired
  private ApplicationContext application;
  
  public RestFactoryBean() {
	  //构造函数
  }


  public RestFactoryBean(Class<T> mapperInterface) {
    this.mapperInterface = mapperInterface;
  }


  @SuppressWarnings("unchecked")
  private T newInstance(RestMapper<T> restMapper) {
	  return (T) Proxy.newProxyInstance(mapperInterface.getClassLoader(), new Class[] { mapperInterface }, restMapper);
  }
  
  @Override
  public T getObject() throws Exception {
    return newInstance(new RestMapper<>(application,mapperInterface));
  }

  @Override
  public Class<T> getObjectType() {
    return this.mapperInterface;
  }

  @Override
  public boolean isSingleton() {
    return true;
  }

  public void setMapperInterface(Class<T> mapperInterface) {
    this.mapperInterface = mapperInterface;
  }

  public Class<T> getMapperInterface() {
    return mapperInterface;
  }

  public void setAddToConfig(boolean addToConfig) {
    this.addToConfig = addToConfig;
  }

  public boolean isAddToConfig() {
    return addToConfig;
  }
}

