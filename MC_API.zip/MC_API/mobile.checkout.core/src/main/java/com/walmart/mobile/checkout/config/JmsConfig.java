package com.walmart.mobile.checkout.config;

import javax.jms.ConnectionFactory;
import javax.jms.DeliveryMode;
import javax.jms.JMSException;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Role;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.support.destination.DestinationResolver;
import org.springframework.jms.support.destination.DynamicDestinationResolver;

import com.walmart.mobile.checkout.handler.exp.JmsExceptionHandler;

@Configuration
@Role(BeanDefinition.ROLE_INFRASTRUCTURE)
@EnableJms
public class JmsConfig {

	@Value("${activemq.url}")
	private String activeMqUrl;
	
	@Value("${activemq.concurrency}")
	private String concurrency;

	@Value("${activemq.userName}")
	private String userName;

	@Value("${activemq.password}")
	private String password;

	@Autowired
	private JmsExceptionHandler jmsExceptionHandler;

	@Autowired
	private BeanFactory beanFactory;

	@Bean
	public DefaultJmsListenerContainerFactory jmsListenerContainerFactory(
			final JmsExceptionHandler jmsExceptionHandler) {
		DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
		factory.setConnectionFactory(connectionFactory());
		factory.setDestinationResolver(destinationResolver());
		factory.setConcurrency(concurrency);
		
		return factory;
	}

	@Bean
	public DestinationResolver destinationResolver() {
		return new DynamicDestinationResolver();
	}

	@Bean
	public ConnectionFactory connectionFactory() {
		ActiveMQConnectionFactory activeMQ = new ActiveMQConnectionFactory(userName, password, activeMqUrl);
		activeMQ.setTrustAllPackages(true);
		return activeMQ;
	}

	@Bean
	public JmsTemplate jmsTemplate() throws JMSException {
		JmsTemplate jmsTemplate = new JmsTemplate(connectionFactory());
		jmsTemplate.setDeliveryMode(DeliveryMode.PERSISTENT);
		return jmsTemplate;
	}
  
}
