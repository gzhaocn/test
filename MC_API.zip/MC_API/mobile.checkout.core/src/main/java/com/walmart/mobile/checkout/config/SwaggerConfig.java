package com.walmart.mobile.checkout.config;

import static com.google.common.collect.Sets.newHashSet;
import static springfox.documentation.spi.schema.contexts.ModelContext.returnValue;
import static springfox.documentation.spring.web.HandlerMethodReturnTypes.handlerReturnType;
import static springfox.documentation.spring.web.readers.operation.ModelRefs.modelRef;
import static springfox.documentation.spring.web.readers.operation.ResponseMessagesReader.httpStatusCode;
import static springfox.documentation.spring.web.readers.operation.ResponseMessagesReader.message;
import static springfox.documentation.swagger.annotations.Annotations.findApiOperationAnnotation;
import static springfox.documentation.swagger.annotations.Annotations.findApiResponsesAnnotations;
import static springfox.documentation.swagger.annotations.Annotations.resolvedTypeFromOperation;
import static springfox.documentation.swagger.annotations.Annotations.resolvedTypeFromResponse;

import java.util.Set;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.fasterxml.classmate.ResolvedType;
import com.fasterxml.classmate.TypeResolver;
import com.google.common.base.Optional;

import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.builders.ResponseMessageBuilder;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.schema.TypeNameExtractor;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.ResponseMessage;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.schema.contexts.ModelContext;
import springfox.documentation.spi.service.contexts.OperationContext;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger.readers.operation.SwaggerResponseMessageReader;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class SwaggerConfig extends WebMvcConfigurerAdapter {

	
	public static final String SYSTEM_ON_LINE = "Y";
	
	@Value("${system.online.pro}")
	private String onLineSystem;
	
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("swagger-ui.html").addResourceLocations("classpath:/META-INF/resources/");
		registry.addResourceHandler("/webjars/**").addResourceLocations("classpath:/META-INF/resources/webjars/");
	}

	@Bean
	public SwaggerResponseMessageReader swaggerResponseMessageReader(TypeNameExtractor typeNameExtractor,
			TypeResolver typeResolver) {
		return new SwaggerResponseMessageReader(typeNameExtractor, typeResolver) {

			private Optional<ResolvedType> resolvedType(ResolvedType resolvedType, ApiResponse apiResponse) {
				return Optional.fromNullable(resolvedTypeFromResponse(typeResolver, resolvedType).apply(apiResponse));
			}

			@Override
			protected Set<ResponseMessage> read(HandlerMethod handlerMethod, OperationContext context) {

				ResolvedType defaultResponse = handlerReturnType(typeResolver, handlerMethod);
				Optional<ResolvedType> operationResponse = findApiOperationAnnotation(handlerMethod.getMethod())
						.transform(resolvedTypeFromOperation(typeResolver, defaultResponse));
				Optional<ApiResponses> apiResponses = findApiResponsesAnnotations(handlerMethod.getMethod());
				Set<ResponseMessage> responseMessages = newHashSet();
				apiResponseIsPresent(typeNameExtractor, context, operationResponse, apiResponses, responseMessages);
				operationResponseIsPresent(typeNameExtractor, handlerMethod, context, operationResponse, responseMessages);
				return responseMessages;

			}

			private void operationResponseIsPresent(TypeNameExtractor typeNameExtractor, HandlerMethod handlerMethod, OperationContext context, Optional<ResolvedType> operationResponse,
					Set<ResponseMessage> responseMessages) {
				if (operationResponse.isPresent()) {
					ModelContext modelContext = returnValue(operationResponse.get(), context.getDocumentationType(),
							context.getAlternateTypeProvider(),
							context.getDocumentationContext().getGenericsNamingStrategy());
					ResolvedType resolvedType = context.alternateFor(operationResponse.get());
					ModelRef responseModel = modelRef(resolvedType, modelContext, typeNameExtractor);
					context.operationBuilder().responseModel(responseModel);
					ResponseMessage defaultMessage = new ResponseMessageBuilder().code(httpStatusCode(handlerMethod))
							.message(message(handlerMethod)).responseModel(responseModel).build();
					if (!responseMessages.contains(defaultMessage) && !"void".equals(responseModel.getType())) {
						responseMessages.add(defaultMessage);
					}
				}
			}

			private void apiResponseIsPresent(TypeNameExtractor typeNameExtractor, OperationContext context, Optional<ResolvedType> operationResponse, Optional<ApiResponses> apiResponses,
					Set<ResponseMessage> responseMessages) {
				if (apiResponses.isPresent()) {
					ApiResponse[] apiResponseAnnotations = apiResponses.get().value();
					for (ApiResponse apiResponse : apiResponseAnnotations) {
						ModelContext modelContext = returnValue(apiResponse.response(), context.getDocumentationType(),
								context.getAlternateTypeProvider(),
								context.getDocumentationContext().getGenericsNamingStrategy());
						Optional<ModelRef> responseModel = Optional.absent();
						Optional<ResolvedType> type = resolvedType(null, apiResponse);
						Integer code = apiResponse.code();
						if (0 <= code && code <= 599) {
							type = type.or(operationResponse);
						}

						if (type.isPresent()) {
							responseModel = Optional
									.of(modelRef(context.alternateFor(type.get()), modelContext, typeNameExtractor));
						}
						responseMessages.add(new ResponseMessageBuilder().code(apiResponse.code())
								.message(apiResponse.message()).responseModel(responseModel.orNull()).build());
					}

				}
			}
		};
	}

	@Bean
	public Docket createRestApi() {
		if(SYSTEM_ON_LINE.equals(onLineSystem)){
			return new Docket(DocumentationType.SWAGGER_2)  
					        .apiInfo(apiInfoOnline()).select().paths(PathSelectors.none())//如果是线上环境，添加路径过滤，设置为全部都不符合  
					.build();
		}else {
		    return new Docket(DocumentationType.SWAGGER_2).apiInfo(apiInfo()).select()
				.apis(RequestHandlerSelectors.basePackage("com.walmart.mobile.checkout.controller"))
				.paths(PathSelectors.any()).build();
		}
	}
	
	

	private ApiInfo apiInfo() {
		return new ApiInfoBuilder().title("mobile checkOut RESTful APIs").description("").termsOfServiceUrl("").license("")
				.contact("walmart china mobile server team").version("1.0").build();
	}

	private ApiInfo apiInfoOnline() {  
		       return new ApiInfoBuilder()  
		              .title("")  
		               .description("")  
		               .license("")  
		                .licenseUrl("")  
		               .termsOfServiceUrl("")  
		               .version("")  
		               .contact("")  
		                .build();  
		    }

	
}
