package com.walmart.mobile.checkout.config;

import java.util.Arrays;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.data.redis.RedisProperties;
import org.springframework.boot.autoconfigure.data.redis.RedisProperties.Cluster;
import org.springframework.boot.autoconfigure.data.redis.RedisProperties.Pool;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;

@Configurable
@EnableRedisRepositories("com.walmart.mobile.checkout.redis")
public class RedisConfig {

	@Value("${spring.redis.cluster.nodes}")
	private String nodeList;

	@Bean
	@Primary
	public RedisProperties RedisProperties() {
		RedisProperties rp = new RedisProperties();
		if (StringUtils.isNotEmpty(nodeList)) {
			Cluster cluster = new Cluster();
			cluster.setNodes(Arrays.asList(nodeList.split(",")));
			rp.setCluster(cluster);
		}
		rp.setPool(new Pool());
		return rp;
	}
}
