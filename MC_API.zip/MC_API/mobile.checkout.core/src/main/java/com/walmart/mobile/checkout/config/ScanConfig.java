package com.walmart.mobile.checkout.config;

import org.mybatis.spring.mapper.MapperScannerConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.walmart.mobile.checkout.restConfig.RestScannerConfigurer;

@Configuration
public class ScanConfig {

	@Bean
	public MapperScannerConfigurer dynamicMssqlMapperScannerConfigurer() {
		MapperScannerConfigurer scanConfig = new MapperScannerConfigurer();
		scanConfig.setBasePackage("com.walmart.mobile.checkout.mapper");
		scanConfig.setSqlSessionFactoryBeanName("dynamicSqlServerSessionFactory");
		return scanConfig;
	}

	@Bean
	public RestScannerConfigurer restScannerConfigurer() {
		RestScannerConfigurer scanConfig = new RestScannerConfigurer();
		scanConfig.setBasePackage("com.walmart.mobile.checkout.rest");
		return scanConfig;
	}

	@Bean
	public MapperScannerConfigurer userDynamicMssqlMapperScannerConfigurer() {
		MapperScannerConfigurer scanConfig = new MapperScannerConfigurer();
		scanConfig.setBasePackage("com.walmart.mobile.checkout.userMapper");
		scanConfig.setSqlSessionFactoryBeanName("userDynamicSqlServerSessionFactory");
		return scanConfig;
	}

	@Bean
	public MapperScannerConfigurer deliveryMssqlMapperScannerConfigurer() {
		MapperScannerConfigurer scanConfig = new MapperScannerConfigurer();
		scanConfig.setBasePackage("com.walmart.mobile.checkout.deliveryMapper");
		scanConfig.setSqlSessionFactoryBeanName("deliverySqlServerSessionFactory");
		return scanConfig;
	}
}
