package com.walmart.mobile.checkout.handler.exp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.walmart.mobile.checkout.annotation.HandlerException;
import com.walmart.mobile.checkout.bean.Message;
import com.walmart.mobile.checkout.exception.ApplicationException;
import com.walmart.mobile.checkout.exception.ApplicationRuntimeException;
import com.walmart.mobile.checkout.exception.MessageException;

@HandlerException
@ControllerAdvice
public class JmsExceptionHandler {
	private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionHandler.class);

	@ExceptionHandler(Throwable.class)
	@ResponseBody
	public ResponseEntity<Message> handleThrowable(Throwable ex) {
		return this.baseResponse(ex, null, true);
	}

	@ExceptionHandler(ApplicationRuntimeException.class)
	@ResponseBody
	public ResponseEntity<Message> handleThrowable(ApplicationRuntimeException ex) {
		return this.baseResponse(ex, null, true);
	}

	@ExceptionHandler(ApplicationException.class)
	@ResponseBody
	public ResponseEntity<Message> handleThrowable(ApplicationException ex) {
		return this.baseResponse(ex, ex.getErrorCode(), true);
	}

	@ExceptionHandler(MessageException.class)
	@ResponseBody
	public ResponseEntity<Message> handleThrowable(MessageException ex) {
		return baseResponse(ex, ex.getErrorCode(), false);
	}

	private ResponseEntity<Message> baseResponse(Throwable ex, Integer code, boolean bool) {
		if (bool) {
			LOGGER.error(ex.getMessage(), ex);
		}
		Integer returnCode = code;
		if (code == null) {
			returnCode = -1;
		}
		return new ResponseEntity<>(Message.createFail(returnCode.toString(), ex.getMessage()), null, HttpStatus.OK);
	}
}