package com.walmart.mobile.checkout.handler.send;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import com.walmart.mobile.checkout.annotation.JmsHandler;

@JmsHandler
public class CreaditW4SendHandler {

	@Autowired
	private JmsTemplate jmsTemplate;

	@Value("${credit.w4.queue.name}")
	private String creaditW4Name;

	private static final Logger LOG = LoggerFactory.getLogger(CreaditW4SendHandler.class);

	public void sendMessage(final String msg) {

		LOG.info("creaditW4Name msg is {}", msg);
		jmsTemplate.send(creaditW4Name, new MessageCreator() {
			@Override
			public Message createMessage(Session session) throws JMSException {
				return session.createTextMessage(msg);
			}
		});

	}

}
