package com.walmart.mobile.checkout.exception.handler;

/**
 * 错误码接口
 * 
 * @author lliao2
 */
public interface ErrorInfoInterface {
	String getCode();

	String getMessage();
}
