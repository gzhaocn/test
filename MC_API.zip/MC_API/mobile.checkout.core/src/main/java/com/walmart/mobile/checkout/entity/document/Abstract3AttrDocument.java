package com.walmart.mobile.checkout.entity.document;

import java.io.Serializable;
import java.util.Date;

/**
 * 抽象实体基类，如果主键是数据库端自动生成 请使用{@link BaseEntity}，如果是Oracle 请使用
 * {@link BaseOracleEntity}
 * <p/>
 * <p>
 * User: pengxinxin
 * <p>
 * Date: 13-3-20 下午8:38
 * <p>
 * Version: 1.0
 */
public abstract class Abstract3AttrDocument<I extends Serializable> extends AbstractDocument<I> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5942724515603576605L;

	public abstract Date getCreatedTime();

	public abstract void setCreatedTime(final Date createdTime);

	public abstract Date getUpdatedTime();

	public abstract void setUpdatedTime(final Date updatedTime);

}
