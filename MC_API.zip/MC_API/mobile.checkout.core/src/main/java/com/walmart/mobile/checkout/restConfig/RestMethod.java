package com.walmart.mobile.checkout.restConfig;

import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.context.ApplicationContext;
import org.springframework.web.bind.annotation.RequestMapping;

import com.walmart.mobile.checkout.constant.GlobalErrorInfoEnum;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.utils.AppUtils;

public class RestMethod {

	private final ApplicationContext application;
	private final Class<?> mapperInterface;
	private final Method iMethod;
	protected static final Set<String> BASET_TYPE = new HashSet<>();
	private final ServiceMethod serviceMethod = new ServiceMethod();

	private Map<Class<?>, Class<?>> paramMap = new HashMap<>();
	private Map<Class<?>, Class<?>> resultMap = new HashMap<>();

	private Method sMethod;

	static {
		BASET_TYPE.add("int");
		BASET_TYPE.add("void");
		BASET_TYPE.add("integer");
		BASET_TYPE.add("java.lang.integer");
		BASET_TYPE.add("long");
		BASET_TYPE.add("java.lang.long");
		BASET_TYPE.add("float");
		BASET_TYPE.add("java.lang.float");
		BASET_TYPE.add("double");
		BASET_TYPE.add("java.lang.Boolean");
		BASET_TYPE.add("boolean");
		BASET_TYPE.add("java.lang.double");
		BASET_TYPE.add("byte");
		BASET_TYPE.add("java.lang.byte");
		BASET_TYPE.add("char");
		BASET_TYPE.add("character");
		BASET_TYPE.add("java.lang.character");
		BASET_TYPE.add("string");
		BASET_TYPE.add("java.lang.string");
	}

	public RestMethod(ApplicationContext application, Class<?> mapperInterface, Method iMethod) throws GlobalErrorInfoException {
		this.mapperInterface = mapperInterface;
		this.iMethod = iMethod;
		this.application = application;
		this.initServiceMethod();
	}

	private Object getServiceObject() throws GlobalErrorInfoException {
		String serviceName = getServiceName();
		return application.getBean(serviceName);
	}

	private String getServiceName() throws GlobalErrorInfoException {
		FeignClient feignClient = mapperInterface.getAnnotation(FeignClient.class);
		if (feignClient != null) {
			return feignClient.value();
		}
		throw new GlobalErrorInfoException(GlobalErrorInfoEnum.CFG_NOT_FUND_SERVICE);
	}

	private Method getServiceMethod(Object service, Integer methodLenth) throws GlobalErrorInfoException {
		String methodName = getServiceMethodName();
		try {
			for (Method method : service.getClass().getDeclaredMethods()) {
				if (method.getName().equalsIgnoreCase(methodName) && method.getParameters().length == methodLenth) {
					return method;
				}
			}
			throw new GlobalErrorInfoException(GlobalErrorInfoEnum.CFG_NOT_FUND_METHOD);
		} catch (SecurityException e) {
			throw new GlobalErrorInfoException(GlobalErrorInfoEnum.CFG_SECURITY_CHECK_METHOD, e);
		}
	}

	private String getServiceMethodName() throws GlobalErrorInfoException {
		RequestMapping requestMapping = iMethod.getAnnotation(RequestMapping.class);
		if (requestMapping != null) {
			String methodName = requestMapping.value()[0];
			return methodName.replace("/", "").replace("\\", "");
		}
		throw new GlobalErrorInfoException(GlobalErrorInfoEnum.CFG_NOT_FUND_METHOD);
	}

	private Class<?> resolveGenericType(Type type) throws GlobalErrorInfoException {
		String name = type.getTypeName();

		Class<?> clazz;
		if (name.contains("<")) {
			name = name.substring(name.indexOf('<') + 1, name.indexOf('>'));
		}
		try {
			if (BASET_TYPE.contains(name)) {
				return (Class<?>) type;
			}
			clazz = Class.forName(name);
		} catch (ClassNotFoundException e) {
			throw new GlobalErrorInfoException(GlobalErrorInfoEnum.CFG_NOT_FUND_CLASS, e);
		}
		return clazz;
	}

	private void initParamMap() throws GlobalErrorInfoException {
		for (int i = 0; i < iMethod.getGenericParameterTypes().length; i++) {
			paramMap.put(resolveGenericType(iMethod.getGenericParameterTypes()[i]), resolveGenericType(sMethod.getGenericParameterTypes()[i]));
		}
	}

	private void initResultMap() throws GlobalErrorInfoException {
		resultMap.put(resolveGenericType(sMethod.getGenericReturnType()), resolveGenericType(iMethod.getGenericReturnType()));
	}

	private void initServiceMethod() throws GlobalErrorInfoException {
		Object service = getServiceObject();
		serviceMethod.setService(service);
		this.sMethod = getServiceMethod(service, iMethod.getParameters().length);
		serviceMethod.setMethod(this.sMethod);
		initParamMap();
		initResultMap();
	}

	private String trimClassName(Class<?> clazz) {
		return clazz.getSimpleName().toLowerCase().trim();
	}

	private Object[] getServiceParam(Object[] args) throws GlobalErrorInfoException {
		Object[] temp = null;
		if (args != null) {
			temp = new Object[args.length];
			for (int i = 0; i < iMethod.getGenericParameterTypes().length; i++) {
				Class<?> clazz = resolveGenericType(iMethod.getGenericParameterTypes()[i]);
				temp[i] = getObjectInstance(args[i], paramMap.get(clazz));
			}
		}
		return temp;
	}

	private Object doCollectionObject(Collection<Object> sourceCollection, Class<?> targetClass) throws GlobalErrorInfoException {
		List<Object> list = new ArrayList<>();
		for (Iterator<Object> it = sourceCollection.iterator(); it.hasNext();) {
			Object obj = it.next();
			list.add(getObjectInstance(obj, targetClass));
			it.remove();
		}
		sourceCollection.addAll(list);
		return sourceCollection;
	}

	@SuppressWarnings("unchecked")
	private Object getObjectInstance(Object source, Class<?> targetClass) throws GlobalErrorInfoException {
		if (source == null || BASET_TYPE.contains(trimClassName(targetClass))) {
			return source;
		} else if (source instanceof Collection<?>) {
			return doCollectionObject((Collection<Object>) source, targetClass);
		} else if (targetClass.isArray()) {
			throw new GlobalErrorInfoException(GlobalErrorInfoEnum.CFG_NOT_SUPPORT_ARRAY);
		} else {
			return AppUtils.copyProperties(source, targetClass);
		}
	}

	private Object getInvokeResult(Object result) throws GlobalErrorInfoException {
		if (result == null) {
			return null;
		}
		Class<?> clazz = resolveGenericType(sMethod.getGenericReturnType());
		return getObjectInstance(result, resultMap.get(clazz));
	}

	public Object execute(Object[] args) throws GlobalErrorInfoException {
		return getInvokeResult(serviceMethod.invoke(getServiceParam(args)));
	}
}
