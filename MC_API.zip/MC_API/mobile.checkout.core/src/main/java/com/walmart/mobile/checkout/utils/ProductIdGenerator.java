package com.walmart.mobile.checkout.utils;

public class ProductIdGenerator {
	private ProductIdGenerator() {
	}

	private final static long SUPPLIER_NBR = 3L * 10000000000000L;

	private final static long FC = 0Xffffffffe1880c78L;
	private final static long LEFT_SEVEN = 0X00000007L;
	private final static long RIGHT_SEVEN = 0x00000380L;
	private final static int SHIFT_SEVEN = 7;

	private final static long LEFT_THIRTEEN = 0X1E000000L;
	private final static long RIGHT_THIRTEEN = 0XF000L;
	private final static int SHIFT_THIRTEEN = 13;

	private final static long LEFT_FOUR = 0X700000L;
	private final static long RIGHT_FOUR = 0X70000L;
	private final static int SHIFT_FOUR = 4;

	public final static long SECRET = 872635271829L;

	public static long encode(long data) {
		long t = data ^ SECRET;
		long a = (t & LEFT_SEVEN) << SHIFT_SEVEN;
		long b = (t & RIGHT_SEVEN) >> SHIFT_SEVEN;
		long c = (t & LEFT_THIRTEEN) >> SHIFT_THIRTEEN;
		long d = (t & RIGHT_THIRTEEN) << SHIFT_THIRTEEN;
		long g = (t & LEFT_FOUR) >> SHIFT_FOUR;
		long h = (t & RIGHT_FOUR) << SHIFT_FOUR;
		return (t & FC | a) | b | c | d | g | h;
	}

	public static long decode(long data) {
		long a = (data & LEFT_SEVEN) << SHIFT_SEVEN;
		long b = (data & RIGHT_SEVEN) >> SHIFT_SEVEN;
		long c = (data & LEFT_THIRTEEN) >> SHIFT_THIRTEEN;
		long d = (data & RIGHT_THIRTEEN) << SHIFT_THIRTEEN;
		long g = (data & LEFT_FOUR) >> SHIFT_FOUR;
		long h = (data & RIGHT_FOUR) << SHIFT_FOUR;
		return ((data & FC | a) | b | c | d | g | h) ^ SECRET;
	}

	public static Long revertUpc(Long productId) {
		return decode(productId % SUPPLIER_NBR);
	}

	public static Long generatorProductId(Long upc) {
		return SUPPLIER_NBR + encode(upc);
	}
}
