package com.walmart.mobile.checkout.utils;

import java.io.StringReader;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.walmart.mobile.checkout.constant.GlobalErrorInfoEnum;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;

/**
 * 使用Jaxb2.0实现XML<->Java Object的Binder.
 * 
 * 特别支持Root对象是List的情形.
 * 
 * @author jonas.wang
 */
public class JaxbUtil {

	/**
	 * Xml->Java Object.
	 * 
	 * @throws GlobalErrorInfoException
	 */
	@SuppressWarnings("unchecked")
	public <T> T fromXml(String xml, Class<?> clazz) throws GlobalErrorInfoException {
		try {
			JAXBContext context = JAXBContext.newInstance(clazz);
			XMLInputFactory xif = XMLInputFactory.newFactory();
			xif.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
			xif.setProperty(XMLInputFactory.SUPPORT_DTD, true);
			XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(xml));
			return (T) createUnmarshaller(context).unmarshal(xsr);
		} catch (JAXBException | XMLStreamException e) {
			throw new GlobalErrorInfoException(GlobalErrorInfoEnum.XML_PARSE_EXCEPTION, e);
		}
	}

	/**
	 * 创建UnMarshaller.
	 * 
	 * @throws GlobalErrorInfoException
	 */
	public Unmarshaller createUnmarshaller(JAXBContext context) throws GlobalErrorInfoException {
		try {
			return context.createUnmarshaller();
		} catch (JAXBException e) {
			throw new GlobalErrorInfoException(GlobalErrorInfoEnum.XML_PARSE_EXCEPTION, e);
		}
	}

}
