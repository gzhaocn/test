package com.walmart.mobile.checkout.constant;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.unionpay.acp.sdk.SDKConfig;
import com.walmart.mobile.checkout.utils.PropertyUtils;

/**
 * 加载银联支付相关的配置参数，属性文件：hd-stage(dev).properties
 */
public class UpmpConstants {

	private static final Logger LOGGER = LoggerFactory.getLogger(UpmpConstants.class);

	private UpmpConstants() {
	}

	// 版本号
	public static final String version;

	// 编码方式
	public static final String charset;

	// 交易网址
	public static final String tradeUrl;

	// 查询网址
	public static final String queryUrl;

	// 商户代码
	public static final String merId;

	// 通知URL
	public static final String merBackEndUrl;

	// 加密方式
	public static final String signType;

	// 商城密匙，需要和银联商户网站上配置的一样
	public static final String securityKey;

	// 币种
	public static final String currency;

	// 订单付款超时时间
	public static final String orderTimeOutMin;

	private static final String KEY_VERSION = "upmp.version";
	private static final String KEY_CHARSET = "upmp.charset";
	private static final String KEY_TRADE_URL = "upmp.trade.url";
	private static final String KEY_QUERY_URL = "upmp.query.url";
	private static final String KEY_MER_ID = "upmp.mer.id";
	private static final String KEY_MER_BACK_END_URL = "upmp.mer.back.end.url";

	private static final String KEY_SIGN_METHOD = "upmp.sign.method";
	private static final String KEY_SECURITY_KEY = "upmp.security.key";
	private static final String KEY_CURRENCY = "upmp.currency";
	private static final String KEY_ORDER_TIME_OUT_MIN = "upmp.order.timeout";
	// 成功应答码
	public static final String RESPONSE_CODE_SUCCESS = "00";

	public static final String TRANS_STATUS_SUCCESS = "00";

	// 签名
	public final static String SIGNATURE = "signature";

	// 签名方法
	public final static String SIGN_METHOD = "signMethod";

	// 应答码
	public final static String RESPONSE_CODE = "respCode";

	// 应答信息
	public final static String RESPONSE_MSG = "respMsg";

	// 交易类型（交易）
	public final static String TRANS_TYPE_TRADE = "01";

	// 交易类型（退货）
	public final static String TRANS_TYPE_REFUND = "04";

	static {
		SDKConfig.getConfig().loadPropertiesFromSrc();
		version = PropertyUtils.getConfigValue(KEY_VERSION);
		charset = PropertyUtils.getConfigValue(KEY_CHARSET);
		tradeUrl = PropertyUtils.getConfigValue(KEY_TRADE_URL);
		queryUrl = PropertyUtils.getConfigValue(KEY_QUERY_URL);
		merId = PropertyUtils.getConfigValue(KEY_MER_ID);
		merBackEndUrl = PropertyUtils.getConfigValue(KEY_MER_BACK_END_URL);
		signType = PropertyUtils.getConfigValue(KEY_SIGN_METHOD);
		securityKey = PropertyUtils.getConfigValue(KEY_SECURITY_KEY);
		currency = PropertyUtils.getConfigValue(KEY_CURRENCY);
		orderTimeOutMin = PropertyUtils.getConfigValue(KEY_ORDER_TIME_OUT_MIN);
		LOGGER.info(
				"Unionpay init config args, VERSION={},CHARSET={},TRADE_URL={},QUERY_URL=={},MER_ID={},MER_BACK_END_URL={},SIGN_TYPE={},SECURITY_KEY={},CURRENCY={}.ORDER_TIME_OUT_MIN={}",
				version, charset, tradeUrl, queryUrl, merId, merBackEndUrl, signType, securityKey, currency,
				orderTimeOutMin);

	}

}
