package com.walmart.mobile.checkout.converter;

import org.springframework.core.convert.converter.Converter;

import com.alibaba.fastjson.JSON;

public class StringToBeanConverter<T> implements Converter<String, T> {

	private final Class<T> clazz;

	public StringToBeanConverter(Class<T> clazz) {
		this.clazz = clazz;
	}

	@Override
	public T convert(String source) {
		return JSON.parseObject(source, clazz);
	}
}
