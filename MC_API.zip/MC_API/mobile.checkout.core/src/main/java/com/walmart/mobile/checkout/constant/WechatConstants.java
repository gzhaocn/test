package com.walmart.mobile.checkout.constant;

import com.walmart.mobile.checkout.utils.PropertyUtils;

public class WechatConstants {

	private WechatConstants() {
	}

	// 这个就是自己要保管好的私有Key了（切记只能放在自己的后台代码里，不能放在任何可能被看到源代码的客户端程序中）
	// 每次自己Post数据给API的时候都要用这个key来对所有字段进行签名，生成的签名会放在Sign这个字段，API收到Post数据的时候也会用同样的签名算法对Post过来的数据进行签名和验证
	// 收到API的返回的时候也要用这个key来对返回的数据算下签名，跟API的Sign数据进行比较，如果值不一致，有可能数据被第三方给篡改

	private static final String key;

	// 微信分配的公众号ID（开通公众号之后可以获取到）
	private static final String appID;

	// 微信支付分配的商户号ID（开通公众号的微信支付功能之后可以获取到）
	private static final String mchID;

	// HTTPS证书的本地路径
	private static final String certLocalPath;

	// HTTPS证书密码，默认密码等于商户号MCHID
	private static final String certPassword;

	// 支付Key
	private static final String payKey;

	// 支付api
	private static final String payApi;

	private static String notifyUrl;

	private static String httpsRequestClassName = " com.walmart.mobile.checkout.utils.WechatHttpsRequest";

	private static final String h5AppID;
	private static final String h5AppKey;
	private static final String h5MchID;
	private static final String h5CertLocalPath;
	private static final String h5CertPassword;
	private static final String h5NotifyUrl;

	static {

		payApi = PropertyUtils.getConfigValue("weixin.pay.url");
		notifyUrl = PropertyUtils.getConfigValue("weixin.payment.notify_url");
		key = PropertyUtils.getConfigValue("weixin.key");
		payKey = PropertyUtils.getConfigValue("weixin.paykey");
		appID = PropertyUtils.getConfigValue("weixin.appid");
		mchID = PropertyUtils.getConfigValue("weixin.mch_id");
		certLocalPath = PropertyUtils.getConfigValue("weixin.certLocalPath");
		certPassword = PropertyUtils.getConfigValue("weixin.certPassword");

		h5AppID = PropertyUtils.getConfigValue("weixin.h5.appid");
		h5AppKey = PropertyUtils.getConfigValue("weixin.h5.key");
		h5MchID = PropertyUtils.getConfigValue("weixin.h5.mch_id");
		h5CertLocalPath = PropertyUtils.getConfigValue("weixin.h5.certLocalPath");
		h5CertPassword = PropertyUtils.getConfigValue("weixin.h5.certPassword");
		h5NotifyUrl = PropertyUtils.getConfigValue("weixin.h5.payment.notify_url");
	}

	public static String getKey() {
		return key;
	}

	public static String getPayKey() {
		return payKey;
	}

	public static String getAppid() {
		return appID;
	}

	public static String getMchid() {
		return mchID;
	}

	public static String getCertLocalPath() {
		return certLocalPath;
	}

	public static String getCertPassword() {
		return certPassword;
	}

	public static String getPayApi() {
		return payApi;
	}

	public static String getNotifyUrl() {
		return notifyUrl;
	}

	public static void setHttpsRequestClassName(String name) {
		httpsRequestClassName = name;
	}

	public static String getHttpsRequestClassName() {
		return httpsRequestClassName;
	}

	public static String getH5AppID() {
		return h5AppID;
	}

	public static String getH5AppKey() {
		return h5AppKey;
	}

	public static String getH5MchID() {
		return h5MchID;
	}

	public static String getH5CertLocalPath() {
		return h5CertLocalPath;
	}

	public static String getH5CertPassword() {
		return h5CertPassword;
	}

	public static String getH5notifyurl() {
		return h5NotifyUrl;
	}

}
