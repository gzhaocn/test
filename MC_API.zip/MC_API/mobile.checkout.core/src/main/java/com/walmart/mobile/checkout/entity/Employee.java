package com.walmart.mobile.checkout.entity;

import java.math.BigInteger;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.walmart.mobile.checkout.entity.document.BaseDocument;

@Document(collection = "associate_discount_card")
public class Employee extends BaseDocument<BigInteger> {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Field("account_nbr")
	private String accountNbr;
	@Field("last_name")
	private String lastName;
	@Field("first_name")
	private String firstName;
	@Field("birth_date")
	private Date birthDate;
	private String status;
	@Field("discount_pct")
	private Double discountPct;
	@Field("binding_user_id")
	private String bindingUserId;
	@Field("binding_time")
	private Date bindingTime;
	@Field("created_time")
	private Date createdTime;
	@Field("updated_time")
	private Date updatedTime;

	public String getAccountNbr() {
		return accountNbr;
	}

	public void setAccountNbr(String accountNbr) {
		this.accountNbr = accountNbr;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		if (!StringUtils.isEmpty(lastName)) {
			this.lastName = lastName.trim();
		}
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		if (!StringUtils.isEmpty(firstName)) {
			this.firstName = firstName.trim();
		}
	}

	public Date getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	public Double getDiscountPct() {
		return discountPct;
	}

	public void setDiscountPct(Double discountPct) {
		this.discountPct = discountPct;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getBindingUserId() {
		return bindingUserId;
	}

	public void setBindingUserId(String bindingUserId) {
		this.bindingUserId = bindingUserId;
	}

	public Date getBindingTime() {
		return bindingTime;
	}

	public void setBindingTime(Date bindingTime) {
		this.bindingTime = bindingTime;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Date getUpdatedTime() {
		return updatedTime;
	}

	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}
}
