package com.walmart.mobile.checkout.utils;

import java.math.BigDecimal;
import java.math.RoundingMode;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AmountUtil {
	private static final Logger LOGGER = LoggerFactory.getLogger(AmountUtil.class);
	private AmountUtil(){}
	/**
	 * 订单支付金额经计算后舍弃小数点后第3位,且不进位
	 * 
	 * @param itemAmount
	 * @param discount
	 * @param shippingFee
	 * @param packageFee
	 * @return
	 */
	public static BigDecimal calcOrderPaymentAmount(BigDecimal itemAmount, BigDecimal discount, BigDecimal shippingFee, BigDecimal packageFee,BigDecimal ewsAmount) {
		BigDecimal paymentAmount = BigDecimal.ZERO;

		if (itemAmount != null) {
			paymentAmount = paymentAmount.add(itemAmount);
		}

		if (discount != null) {
			paymentAmount = paymentAmount.subtract(discount);
		}

		if (shippingFee != null) {
			paymentAmount = paymentAmount.add(shippingFee);
		}

		if (packageFee != null) {
			paymentAmount = paymentAmount.add(packageFee);
		}
		
		if (ewsAmount != null) {
			paymentAmount = paymentAmount.add(ewsAmount);
		}

		if (paymentAmount.scale() > 2) {
				LOGGER.info("order payment amount scale is greater then 2,actual: {}" , paymentAmount );
		}
		return paymentAmount.setScale(2, RoundingMode.DOWN);
	}

}
