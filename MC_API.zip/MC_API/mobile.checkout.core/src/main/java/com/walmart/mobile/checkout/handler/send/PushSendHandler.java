package com.walmart.mobile.checkout.handler.send;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import com.walmart.mobile.checkout.annotation.JmsHandler;

@JmsHandler
public class PushSendHandler {

	@Autowired
	private JmsTemplate jmsTemplate;

	@Value("${pushMessage.queue.name}")
	private String pushMessageQueueName;

	private static final Logger LOG = LoggerFactory.getLogger(PushSendHandler.class);
	
	public void sendMessage(final String msg) {

		LOG.info("push msg is {}",msg);
		jmsTemplate.send(pushMessageQueueName, new MessageCreator() {
			@Override
			public Message createMessage(Session session) throws JMSException {
				return session.createTextMessage(msg);
			}
		});

	}
	

}
