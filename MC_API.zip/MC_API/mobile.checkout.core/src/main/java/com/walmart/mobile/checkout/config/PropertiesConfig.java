package com.walmart.mobile.checkout.config;

import java.io.IOException;

import org.apache.commons.lang.ArrayUtils;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import com.walmart.mobile.checkout.constant.GlobalErrorInfoEnum;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoRuntimeException;
import com.walmart.mobile.checkout.utils.PropertyUtils;

@Configuration
public class PropertiesConfig {

	@Bean
	public PropertyPlaceholderConfigurer getPropertyPlaceholderConfigurer() {
		PropertyUtils prop = new PropertyUtils();
		prop.setSystemPropertiesModeName("SYSTEM_PROPERTIES_MODE_OVERRIDE");
		prop.setIgnoreResourceNotFound(false);
		prop.setLocations(getPorpResource());
		return prop;
	}

	public Resource[] getPorpResource() {
		String packageSearchPath = "classpath*:mchk/*.properties";
		Resource[] resources = null;
		try {
			resources = new PathMatchingResourcePatternResolver().getResources(packageSearchPath);
			Resource[] configs = new PathMatchingResourcePatternResolver()
					.getResources("classpath*:config/*.properties");
			resources = (Resource[]) ArrayUtils.addAll(resources, configs);
		} catch (IOException e) {
			throw new GlobalErrorInfoRuntimeException(GlobalErrorInfoEnum.RESOURCE_NOT_EXIST,e);
		}
		return resources;
	}
}
