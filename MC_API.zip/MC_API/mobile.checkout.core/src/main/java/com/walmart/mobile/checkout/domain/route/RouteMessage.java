package com.walmart.mobile.checkout.domain.route;

public class RouteMessage {
	// 0 成功
	// 1 openid不存在
	// 2 电话号码不存在
	// 3 userid不存在
	// 4 映射关系不存在
	// 5 路由已经存在
	// 100 输入参数错误，电话号码为空
	// 101 输入参数错误，openid为空
	// 102 输入参数错误，userid为空
	// 200 修改电话号码错误
	// 800 收到不期望的请求：企图给openid重新建立路由
	// 999 未知错误
	public static final int ERROR_CODE_SUCCESS = 0;
	public static final int ERROR_CODE_NOTEXIST_OPENID = 1;
	public static final int ERROR_CODE_NOTEXIST_MOBILE = 2;
	public static final int ERROR_CODE_NOTEXIST_USERID = 3;
	public static final int ERROR_CODE_NOTEXIST_DAG_DOMAIN_MAPPING = 4;
	public static final int ERROR_CODE_ALREADYEXIST_ROUTE = 5;
	public static final int ERROR_CODE_INVALID_MOBILE = 100;
	public static final int ERROR_CODE_INVALID_OPENID = 101;
	public static final int ERROR_CODE_INVALID_USERID = 102;
	public static final int ERROR_CODE_FAILED_CHANGE_MOBILE = 200;
	public static final int ERROR_CODE_DUPLICATE_ROUTE_OPENID = 800;
	public static final int ERROR_CODE_UNKNOWN = 999;

	private int errorCode;
	private Route route;

	public RouteMessage(int errorCode, Route route) {
		this.errorCode = errorCode;
		this.route = route;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public Route getRoute() {
		return route;
	}

	public void setRoute(Route route) {
		this.route = route;
	}
}
