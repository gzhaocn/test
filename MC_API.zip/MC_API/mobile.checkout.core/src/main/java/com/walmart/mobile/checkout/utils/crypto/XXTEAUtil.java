package com.walmart.mobile.checkout.utils.crypto;

public class XXTEAUtil {
	private XXTEAUtil(){}

	private static String toHexUtil(int n) {
		String rt = "";
		switch (n) {
		case 10:
			rt += "A";
			break;
		case 11:
			rt += "B";
			break;
		case 12:
			rt += "C";
			break;
		case 13:
			rt += "D";
			break;
		case 14:
			rt += "E";
			break;
		case 15:
			rt += "F";
			break;
		default:
			rt = Integer.toString(n);
		}
		return rt;
	}

	public static String toHex(int n) {
		StringBuilder sb = new StringBuilder();
		if (n / 16 == 0) {
			return toHexUtil(n);
		} else {
			String t = toHex(n / 16);
			int nn = n % 16;
			sb.append(t).append(toHexUtil(nn));
		}
		return sb.toString();
	}

	public static String parseAscii(String str) {
		StringBuilder sb = new StringBuilder();
		byte[] bs = str.getBytes();
		for (int i = 0; i < bs.length; i++){
			sb.append(toHex(bs[i]));
		}
		return sb.toString();
	}

	/**
	 * Encrypt data with key.
	 * 
	 * @param v
	 * @param k
	 * @return
	 */
	public static int[] encrypt(int[] v, int[] k) {
		int n = v.length;

		int y;
		int p;
		int rounds = 6 + 52 / n;
		int sum = 0;
		int z = v[n - 1];
		int delta = 0x9E3779B9;
		do {
			sum += delta;
			int e = (sum >>> 2) & 3;
			for (p = 0; p < n - 1; p++) {
				y = v[p + 1];
				z = v[p] += (z >>> 5 ^ y << 2) + (y >>> 3 ^ z << 4) ^ (sum ^ y) + (k[p & 3 ^ e] ^ z);
			}
			y = v[0];
			z = v[n - 1] += (z >>> 5 ^ y << 2) + (y >>> 3 ^ z << 4) ^ (sum ^ y) + (k[p & 3 ^ e] ^ z);
		} while (--rounds > 0);

		return v;
	}

	private static String pad(String str, int size, boolean isprefixed) {
		if (str == null){
			str = "";
		}
		int strSize = str.length();
		int padLen = size - strSize;
		StringBuilder retvalue = new StringBuilder();
		for (int i = 0; i < padLen; i++) {
			retvalue.append("0");
		}
		if (isprefixed){
			return retvalue.append(str).toString();
		}
		return retvalue.insert(0, str).toString();
	}
	



	public static int[] encryptStringToIntArray(String s) {
		String encryptCodeStr = XXTEAUtil.parseAscii(s);
		// 得到加密长度 2位
		int encryptCodeLength = encryptCodeStr.length();
		byte encryptLength = (byte) (encryptCodeLength / 8);// XXTEA加密的整形个数=加密字符串长度/8;如果对8取余，余数不为0则+1
		byte nRemainder1 = (byte) (encryptCodeLength % 8);
		if (nRemainder1 != 0) {
			encryptLength++;
		}

		byte nRemainder = (byte) ((encryptCodeLength % 8) / 2);
		// 将字符串转成16进制的整形数
		// 先转前面前面8的整数个数，再转最后一个整数
		int[] enCodeInt = new int[encryptLength];

		int stmp1 ;
		int stmp2 ;
		String strTmp4;
		String strTmp5;
		if (nRemainder != 0) {
			// 将字符串分中化成一个一个整形值，由于JAVA Integer.valueOf（）整形值范围受限，将整形值分为二个4字符值处理
			for (int k = 0; k < encryptLength - 1; k++) {
				strTmp4 = encryptCodeStr.substring(k * 8, k * 8 + 4);
				strTmp5 = encryptCodeStr.substring(k * 8 + 4, (k + 1) * 8);
				stmp1 = Integer.valueOf(strTmp4, 16); // 00852953
				stmp2 = Integer.valueOf(strTmp5, 16);
				enCodeInt[k] = (stmp1 << 16) | stmp2;
			}
			enCodeInt[encryptLength - 1] = Integer.valueOf(encryptCodeStr.substring((encryptLength - 1) * 8, (encryptLength - 1) * 8 + nRemainder1), 16);
		} else {
			for (int k = 0; k < encryptLength; k++) {
				strTmp4 = encryptCodeStr.substring(k * 8, k * 8 + 4);
				strTmp5 = encryptCodeStr.substring(k * 8 + 4, (k + 1) * 8);
				stmp1 = Integer.valueOf(strTmp4, 16); // 00852953
				stmp2 = Integer.valueOf(strTmp5, 16);
				enCodeInt[k] = (stmp1 << 16) | stmp2;
			}
		}
		return enCodeInt;
	}
	
	public static String encryptIntToString(String s,String key) {
		/**int[] keys = { 0x00852953, 0x00543210, 0x00852953, 0x00543210 };*/
		int[] ss = encrypt(encryptStringToIntArray(s), encryptStringToIntArray(key));
		/**int[] ss = encrypt(encryptStringToIntArray(s), keys);*/
		StringBuilder sb = new StringBuilder();
		for (int k = 0; k < ss.length; k++) {
			String strTmp1 = pad(Integer.toHexString(ss[k]).toUpperCase(), 8, true);
			sb.append(strTmp1);
		}
		return sb.toString();
	}
	
	
	
	
/**	public static void main(String args[]) {
		String b = "6D6F62696C65434B";
		String s = "mobileCK";
		String s1 = "mobileCK456456456456456456456456456546456";
		System.out.println("转换后的字符串是：" + XXTEAUtil.parseAscii(s));
		String sb = encryptIntToString(s,s1);
		System.out.println("DeQRResult2===========" + sb.toString());
		System.out.println("345345435");

	}
*/

	

}
