package com.walmart.mobile.checkout.config;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.data.mongodb.config.AbstractMongoConfiguration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.mongodb.Mongo;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;

@EnableMongoRepositories(basePackages = "com.walmart.mobile.checkout.repo")
public class MongoDbConfig extends AbstractMongoConfiguration {

	private static Logger logger = LoggerFactory.getLogger(MongoDbConfig.class);

	@Value("${mongo.dbName}")
	private String dbName;

	@Value("${mongo.username}")
	private String username;

	@Value("${mongo.password}")
	private String password;

	@Value("${mongo.host}")
	private String host;

	@Value("${mongo.port}")
	private Integer port;

	@Autowired
	private MappingMongoConverter mappingMongoConverter;

	@Override
	protected String getDatabaseName() {
		return dbName;
	}

	@Bean
	@Override
	public MongoTemplate mongoTemplate() throws Exception {
		return new MongoTemplate(mongoDbFactory(), mappingMongoConverter);
	}

	@Override
	public Mongo mongo() throws Exception {
		logger.debug("mongo db host:{},port:{},username:{},password:{}", host, port, username, password);
		MongoCredential credential = MongoCredential.createCredential(username, getDatabaseName(),
				password.toCharArray());
		String[] hosts = host.split(",");
		List<ServerAddress> serverList = new ArrayList<>();
		for (String hostTemp : hosts) {
			ServerAddress serverAddress = new ServerAddress(hostTemp, port);
			serverList.add(serverAddress);
		}

		return new MongoClient(serverList, Arrays.asList(credential));
	}
}
