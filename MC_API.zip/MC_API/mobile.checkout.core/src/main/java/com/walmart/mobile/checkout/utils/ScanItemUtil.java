package com.walmart.mobile.checkout.utils;

import java.math.BigDecimal;

import org.apache.commons.lang.StringUtils;

public class ScanItemUtil {

	private static final String SCALEITEMSTARTWITH = "21";
	private static final int SCALEITEMPLUSTART = 2;
	private static final int SCALEITEMPLUEND = 7;
	private static final int SCALEITEMLENGTH = 12;
	private static final int SCALEITEMPRICEYUANSTART = 7;
	private static final int SCALEITEMPRICEYUANEND = 10;
	private static final int SCALEITEMPRICEFENSTART = 10;
	private static final int SCALEITEMPRICEFENEND = 12;
	private static final String SCALEITEMSPECIALCASE = "00000";

	private ScanItemUtil() {
		throw new IllegalAccessError("Utility class");
	}

	/**
	 * convert upc for Scan Item scan item: 21 + PLU(5) + price(5) + check(1)
	 * special case is a upc : 21 + PLU(5) + 00000 + check(1)
	 * 
	 * @param upc
	 */
	public static Long convertUpc(Long upc) {
		String plu;

		if (upc.toString().startsWith(SCALEITEMSTARTWITH) && upc.toString().length() == SCALEITEMLENGTH) {
			if (SCALEITEMSPECIALCASE.equals(upc.toString().substring(SCALEITEMPRICEYUANSTART, SCALEITEMPRICEFENEND))) {
				return upc;
			}
			plu = upc.toString().substring(SCALEITEMPLUSTART, SCALEITEMPLUEND);
			return valueOfToLong(SCALEITEMSTARTWITH + plu + SCALEITEMSPECIALCASE);
		}
		return upc;
	}
	
	public static boolean isSpecialScaleItem(Long upc)
	{
		return upc.toString().startsWith(SCALEITEMSTARTWITH)
				&& upc.toString().length() == SCALEITEMLENGTH
				&& SCALEITEMSPECIALCASE
						.equals(upc.toString().substring(SCALEITEMPRICEYUANSTART, SCALEITEMPRICEFENEND));		
	}
	
	public static boolean isScaleItem(Long upc) {
		return upc.toString().startsWith(SCALEITEMSTARTWITH)
				&& upc.toString().length() == SCALEITEMLENGTH
				&& !SCALEITEMSPECIALCASE
						.equals(upc.toString().substring(SCALEITEMPRICEYUANSTART, SCALEITEMPRICEFENEND));
	}

	public static float getScanItemPriceWithTax(Long upc) {
		return getScanItemPriceWithTaxFormBarCode(upc);
	}
	
	
	public static float getScanItemPriceWithTaxFormBarCode(Long barCode) {
		String amount = barCode.toString().substring(7, String.valueOf(barCode).length());
		return valueOfToFloat(amount.substring(0,amount.length()-2)+"."+amount.substring(amount.length()-2,amount.length()));
	}
	
	
	public static Long getBarCode(Long upc,Float priceWithTax)
	{
		String plu;
		if(isSpecialScaleItem(upc))
		{
			plu = upc.toString().substring(SCALEITEMPLUSTART, SCALEITEMPLUEND);
			return valueOfToLong(SCALEITEMSTARTWITH + plu + new BigDecimal(priceWithTax.toString()).multiply(new BigDecimal(100)).intValue()); 
		}
		return upc;
	}
	
	
	/**
	 * The string to turn Long Spaces and blank area
	 * 
	 * @param value
	 * @return Long
	 */
	private static long valueOfToLong(String value) {
		long reValue;
		if (StringUtils.isEmpty(value)) {
			reValue = 0L;
		} else {
			reValue = Long.parseLong(value.replaceAll("\\s+", ""));
		}
		return reValue;
	}
	
	
	/**
	 * The string to turn float Spaces and blank area
	 * 
	 * @param value
	 * @return float
	 */
	private static float valueOfToFloat(String value) {
		float reValue;
		if (StringUtils.isEmpty(value)) {
			reValue = 0;
		} else {
			reValue = Float.parseFloat(value.replaceAll("\\s+", ""));
		}
		return reValue;
	}
}
