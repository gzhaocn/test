package com.walmart.mobile.checkout.utils.crypto;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.walmart.mobile.checkout.constant.GlobalErrorInfoEnum;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;


public class SHA1Util {
	private static final Logger LOG = LoggerFactory.getLogger(SHA1Util.class);
	private SHA1Util(){
		//构造函数
	}
    //Sha1签名  
    public static String getSha1(String str) throws GlobalErrorInfoException {  
        if (str == null || str.length() == 0) {  
            return null;  
        }  
        char[] hexDigits = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',  
                'a', 'b', 'c', 'd', 'e', 'f' };  
  
        try {  
            MessageDigest mdTemp = MessageDigest.getInstance("SHA1");  
            mdTemp.update(str.getBytes("UTF-8"));  
  
            byte[] md = mdTemp.digest();  
            int j = md.length;  
            char[] buf = new char[j * 2];  
            int k = 0;  
            for (int i = 0; i < j; i++) {  
                byte byte0 = md[i];  
                buf[k++] = hexDigits[byte0 >>> 4 & 0xf];  
                buf[k++] = hexDigits[byte0 & 0xf];  
            }  
            return new String(buf);  
        } catch (NoSuchAlgorithmException|UnsupportedEncodingException e) {  
        	LOG.error("SHA1Util getsha1 error", e);
        	throw new GlobalErrorInfoException(GlobalErrorInfoEnum.ENCYPTY_CYPTY_ERROR);
        }  
    }  
}
