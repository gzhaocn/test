package com.walmart.mobile.checkout.restConfig;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.walmart.mobile.checkout.constant.GlobalErrorInfoEnum;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;

public class ServiceMethod {

	private final static Logger LOGGER = LoggerFactory.getLogger(ServiceMethod.class);

	private Object service;

	private Method method;

	public Object getService() {
		return service;
	}

	public void setService(Object service) {
		this.service = service;
	}

	public Method getMethod() {
		return method;
	}

	public void setMethod(Method method) {
		this.method = method;
	}

	public Object invoke(Object... args) throws GlobalErrorInfoException {
		Object result = null;
		try {
			result = method.invoke(service, args);
		} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
			throw new GlobalErrorInfoException(GlobalErrorInfoEnum.CFG_EXECUTE_METHOD, e);
		} finally {
			LOGGER.info("invoke {} service {} method. args:{},result:{}", service.getClass().getSimpleName(),
					method.getName(), Arrays.toString(args), result);
		}
		return result;
	}
}
