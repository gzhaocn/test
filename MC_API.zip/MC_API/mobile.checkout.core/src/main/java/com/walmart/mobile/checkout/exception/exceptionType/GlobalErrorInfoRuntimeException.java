package com.walmart.mobile.checkout.exception.exceptionType;

import com.walmart.mobile.checkout.exception.handler.ErrorInfoInterface;

/**
 * 统一错误码异常
 */
public class GlobalErrorInfoRuntimeException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final transient ErrorInfoInterface errorInfo;
	private final boolean isPrint;

	public GlobalErrorInfoRuntimeException(ErrorInfoInterface errorInfo, Throwable cause) {
		super("cause:" + errorInfo.getMessage(), cause);
		this.isPrint = false;
		this.errorInfo = errorInfo;
	}

	public GlobalErrorInfoRuntimeException(ErrorInfoInterface errorInfo) {
		this.isPrint = true;
		this.errorInfo = errorInfo;
	}

	public ErrorInfoInterface getErrorInfo() {
		return errorInfo;
	}

	public boolean isPrint() {
		return isPrint;
	}
}
