package com.walmart.mobile.checkout.utils.crypto;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.walmart.mobile.checkout.constant.GlobalErrorInfoEnum;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoRuntimeException;
import com.walmart.mobile.checkout.utils.PropertyUtils;

/**
 * AES加密解密辅助类. <!-- Date, Author, Descriptions -->
 * 
 * @author leo
 * @version 1.0.0
 * 
 */
public class AESUtil {
	private static final Logger LOGGER = LoggerFactory.getLogger(AESUtil.class);

	private static final String AES = "AES";
	private static String cryptKey;

	static {
		try {
			AESUtil.cryptKey = PropertyUtils.getConfigValue("aes.crypt_key");
		} catch (Exception e) {
			LOGGER.error("initAESUtil error ", e);
			throw new GlobalErrorInfoRuntimeException(GlobalErrorInfoEnum.RESOURCE_NOT_EXIST);
		}
	}

	private AESUtil() {
	}

	/**
	 * 加密.
	 * 
	 * @param src
	 * @param key
	 * @return
	 * @throws NoSuchPaddingException
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeyException
	 * @throws BadPaddingException
	 * @throws IllegalBlockSizeException
	 * @throws Exception
	 */
	private static byte[] encrypt(byte[] src, String key) throws NoSuchAlgorithmException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		Cipher cipher = Cipher.getInstance(AES);
		SecretKeySpec securekey = new SecretKeySpec(key.getBytes(), AES);
		cipher.init(Cipher.ENCRYPT_MODE, securekey);

		return cipher.doFinal(src);
	}

	/**
	 * 解密.
	 * 
	 * @param decryptStr
	 * @return
	 * @throws NoSuchPaddingException
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeyException
	 * @throws BadPaddingException
	 * @throws IllegalBlockSizeException
	 * @throws Exception
	 */
	private static byte[] decrypt(byte[] src, String key) throws NoSuchAlgorithmException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		Cipher cipher = Cipher.getInstance(AES);
		SecretKeySpec securekey = new SecretKeySpec(key.getBytes(), AES);
		cipher.init(Cipher.DECRYPT_MODE, securekey);

		return cipher.doFinal(src);
	}

	/**
	 * 二行制转十六进制字符串.
	 * 
	 * @param b
	 * @return
	 */
	private static String byte2hex(byte[] b) {
		StringBuilder hs = new StringBuilder();
		String stmp;

		for (int n = 0; n < b.length; n++) {
			stmp = java.lang.Integer.toHexString(b[n] & 0XFF);

			if (stmp.length() == 1) {
				hs.append("0");
			}
			hs.append(stmp);
		}

		return hs.toString().toUpperCase();
	}

	private static byte[] hex2byte(byte[] b) {
		if ((b.length % 2) != 0) {
			throw new IllegalArgumentException("the length is not an even number");
		}

		byte[] b2 = new byte[b.length / 2];

		for (int n = 0; n < b.length; n += 2) {
			String item = new String(b, n, 2);
			b2[n / 2] = (byte) Integer.parseInt(item, 16);
		}

		return b2;
	}

	/**
	 * 解密(供外部调用).
	 * 
	 * @param data
	 * @return
	 * @throws GlobalErrorInfoException
	 * @throws Exception
	 */
	public static final String decrypt(String data) throws GlobalErrorInfoException {
		try {
			return new String(decrypt(hex2byte(data.getBytes()), cryptKey));
		} catch (Exception e) {
			throw new GlobalErrorInfoException(GlobalErrorInfoEnum.ENCYPTY_CYPTY_ERROR, e);
		}
	}

	/**
	 * 加密(供外部调用).
	 * 
	 * @param data
	 * @return
	 * @throws GlobalErrorInfoException
	 * @throws BadPaddingException
	 * @throws IllegalBlockSizeException
	 * @throws NoSuchPaddingException
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeyException
	 * @throws Exception
	 */
	public static final String encrypt(String data) throws GlobalErrorInfoException {
		try {
			return byte2hex(encrypt(data.getBytes(), cryptKey));
		} catch (Exception e) {
			throw new GlobalErrorInfoException(GlobalErrorInfoEnum.ENCYPTY_CYPTY_ERROR, e);
		}
	}
}
