package com.walmart.mobile.checkout.rest;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.walmart.mobile.checkout.domain.UserAuthority;

@FeignClient("userService")
public interface UserClient {

	@RequestMapping(method = RequestMethod.GET, value = "/getUserByToken")
	UserAuthority getUserByToken(@RequestParam(value = "token") String token,String appType);

	@RequestMapping(method = RequestMethod.GET, value = "/getAllThirdPartyByUserIdAndType")
	String getAllThirdPartyByUserIdAndType(@RequestParam(value = "userId") String userId,
			@RequestParam(value = "type") Integer type);
}