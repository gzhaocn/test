package com.walmart.mobile.checkout.constant;

/**
 * 应用需要的常量,除String的类型以外都尽量使用基本数据类型,而不需要使用封装类.
 * 
 * 
 * @author kchen15
 *
 */
public final class AppConstants {

	/**
	 * gp常量
	 */
	public static final int OFFER_STATUS_EFFECTIVE = 0; // gp生效
	public static final int OFFER_STATUS_INEFFECTIVE = 1; // gp失效

	public static final int LOGIN_TYPE = LoginType.WECHAT_CHECKOUT;
	/**
	 * 线程中常量
	 */
	public static final String TOKEN = "token";
	public static final String DAGID = "dagId";
	public static final String USERID = "userId";
	public static final String LDAPUSERID = "ldapUserId";
	public static final String OPENID = "openId";
	public static final String STOREID = "storeId";
	public static final String APP_TYPE = "appType";
	public static final String MOBILE_PHONE = "mobilePhone";
	public static final String ROLE = "role";
	/*
	 * http请求的默认字符集
	 */
	public static final String HTTP_REQUEST_CHARSET = "utf-8";

	/*
	 * http请求的默认content-type
	 */
	public static final String HTTP_REQUEST_MIMETYPE = "application/json";

	/** -------------------- 重试常量 -------------------- */
	/** 异常重试次数 */
	public static final int EXP_RETRY = 5;
	/** 基础时间 */
	public static final long BASE_TIMTE = 3 * 1000L;
	/** 基础倍数 */
	public static final long BASE_MULTIPLES = 2L;
	/** 基础被减数 */
	public static final long BASE_SUB = 2L;
	/** 最大延迟时间6小时 */
	public static final long MAX_DELAY_TIME = (2 << 10) * BASE_TIMTE;

	/** 延迟发送其他另外队列的时间 */
	public static final long OTHER_QUEUE_DELAY_TIMTE = 200 * BASE_TIMTE;
	
	private AppConstants() {
	}
}
