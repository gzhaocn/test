package com.walmart.mobile.checkout.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.alibaba.druid.support.http.StatViewServlet;

@Configuration
public class DruidConfig {

	@Bean
	public ServletRegistrationBean druidServlet() {
		ServletRegistrationBean servlet = new ServletRegistrationBean(new StatViewServlet());
		List<String> list = new ArrayList<>();
		list.add("/druid/*");
		servlet.setUrlMappings(list);
		return servlet;
	}
}
