package com.walmart.mobile.checkout.selector;

import java.io.IOException;
import java.util.Properties;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.context.annotation.ImportSelector;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.EncodedResource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.core.type.AnnotationMetadata;

import com.walmart.mobile.checkout.config.ComponentScanConfig;
import com.walmart.mobile.checkout.config.DeliveryDbConfig;
import com.walmart.mobile.checkout.config.DroolsAutoConfiguration;
import com.walmart.mobile.checkout.config.DynamicConfig;
import com.walmart.mobile.checkout.config.JmsConfig;
import com.walmart.mobile.checkout.config.KafkaProducerConfig;
import com.walmart.mobile.checkout.config.LdapConfig;
import com.walmart.mobile.checkout.config.MongoDbConfig;
import com.walmart.mobile.checkout.config.PropertiesConfig;
import com.walmart.mobile.checkout.config.RedisConfig;
import com.walmart.mobile.checkout.config.RestConfig;
import com.walmart.mobile.checkout.config.ScanConfig;
import com.walmart.mobile.checkout.config.SwaggerConfig;
import com.walmart.mobile.checkout.config.UserDynamicConfig;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoRuntimeException;

public class CustomImportSelector implements ImportSelector {

	public String[] getConfigClass() {
		String configClass = getProperties().getProperty("config.class");
		if (StringUtils.isNotBlank(configClass)) {
			return configClass.split(",");
		}
		return null;
	}

	public Properties getProperties() {
		Resource[] resources = getPorpResource();
		Properties props = new Properties();
		for (Resource resource : resources) {
			try {
				PropertiesLoaderUtils.fillProperties(props, new EncodedResource(resource, "UTF-8"));
			} catch (IOException e) {
				throw new GlobalErrorInfoRuntimeException(null, e);
			}
		}
		return props;
	}

	private Resource[] getPorpResource() {
		String packageSearchPath = "classpath*:mchk/*.properties";
		Resource[] resources = null;
		try {
			resources = new PathMatchingResourcePatternResolver().getResources(packageSearchPath);
			Resource[] configs = new PathMatchingResourcePatternResolver().getResources("classpath*:config/*.properties");
			resources = (Resource[]) ArrayUtils.addAll(resources, configs);
		} catch (IOException e) {
			throw new GlobalErrorInfoRuntimeException(null, e);
		}
		return resources;
	}

	@Override
	public String[] selectImports(AnnotationMetadata importingClassMetadata) {
		String[] configClass = getConfigClass();
		if (configClass != null) {
			return configClass;
		}
		return new String[] { ComponentScanConfig.class.getName(), PropertiesConfig.class.getName(), DynamicConfig.class.getName(), ScanConfig.class.getName(), SwaggerConfig.class.getName(),
				MongoDbConfig.class.getName(), UserDynamicConfig.class.getName(), LdapConfig.class.getName(), RestConfig.class.getName(), RedisConfig.class.getName(), JmsConfig.class.getName(),
				KafkaProducerConfig.class.getName(), DeliveryDbConfig.class.getName(), DroolsAutoConfiguration.class.getName() };
	}

}
