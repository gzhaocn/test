package com.walmart.mobile.checkout.config;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Predicate;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.util.Base64Utils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.annotation.LdapPrivilegeInfo;
import com.walmart.mobile.checkout.annotation.PrivilegeInfo;
import com.walmart.mobile.checkout.constant.AppConstants;
import com.walmart.mobile.checkout.constant.GlobalErrorInfoEnum;
import com.walmart.mobile.checkout.dag.DagHost;
import com.walmart.mobile.checkout.dag.HostData;
import com.walmart.mobile.checkout.datasource.DynamicDataSource;
import com.walmart.mobile.checkout.domain.TokenAuth;
import com.walmart.mobile.checkout.domain.UserAuthority;
import com.walmart.mobile.checkout.domain.UserLdapVo;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.exception.handler.ResultBody;
import com.walmart.mobile.checkout.kafka.MsgProducer;
import com.walmart.mobile.checkout.rest.UserClient;
import com.walmart.mobile.checkout.rest.UserLdapClient;
import com.walmart.mobile.checkout.utils.ThreadLocalContextHolder;

/**
 * aop类 1、数据源切换 2、线程存储dagId-token-userId等信息，供后面使用 3、权限校验 4、全局输入输出日志打印、日志全局线程名
 * 
 * @author lliao2
 */
@Aspect
@Configuration
@EnableWebMvc
// @EnableKafka
@ComponentScan({ "com.walmart.mobile.checkout.controller", "com.walmart.mobile.checkout.service", "com.walmart.mobile.checkout.exception", "com.walmart.mobile.checkout.statemachine",
		"com.walmart.mobile.checkout.handler", "com.walmart.mobile.checkout.kafka", "com.walmart.mobile.checkout.component" })
public class ComponentScanConfig {

	private static final Logger LOG = LoggerFactory.getLogger(ComponentScanConfig.class);

	@Autowired
	private UserClient userClient;
	@Autowired
	private UserLdapClient userLdapClient;

	@Autowired
	private RestTemplate restTemplate;

	private volatile boolean isInit = false;

	@Autowired
	@Qualifier("dynamicDataSource")
	public DynamicDataSource dynamicDataSource;

	@Autowired
	@Qualifier("userDynamicDataSource")
	public DynamicDataSource userDynamicDataSource;

	@Value("${ddr.request.param}")
	private String ddrParam;

	@Value("${ddr.request.url}")
	private String ddrUrl;

	@Value("${check.user.url}")
	private String checkUserUrl;

	@Value("${kafka.enable}")
	private boolean kafkaEnable;
	@Autowired
	private MsgProducer msgProducer;

	private static final String CLIENT_INFO = "clientInfo";

	private JSONObject json;

	private void initUserDatasourceRouter() {
		LOG.info("dynamic user datasource init.");

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<>(ddrParam, headers);
		String result = restTemplate.postForObject(ddrUrl, entity, String.class);
		DagHost.triggerUserDag(true);
		List<DagHost> dss = JSONObject.parseObject(result, HostData.class).getData();
		Map<Object, Object> dataSources = new HashMap<>(16);
		for (int i = 0; i < dss.size(); i++) {
			DagHost dh = dss.get(i);
			String key = dh.getDagId();
			dataSources.put(key, dh.getDataSource());
		}
		userDynamicDataSource.setTargetDataSources(dataSources);
		userDynamicDataSource.afterPropertiesSet();
		DagHost.triggerUserDag(false);
	}

	private void initMcDatasourceRouter() {
		LOG.info("dynamic datasource init.");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<>(ddrParam, headers);
		String result = restTemplate.postForObject(ddrUrl, entity, String.class);
		DagHost.triggerUserDag(false);
		List<DagHost> dss = JSONObject.parseObject(result, HostData.class).getData();
		Map<Object, Object> dataSources = new HashMap<>(16);
		for (int i = 0; i < dss.size(); i++) {
			DagHost dh = dss.get(i);
			String key = dh.getDagId();
			dataSources.put(key, dh.getDataSource());
		}
		dynamicDataSource.setTargetDataSources(dataSources);
		dynamicDataSource.afterPropertiesSet();
	}

	private void initDatasourceRouter() {
		if (!isInit) {
			synchronized (this) {
				if (!isInit) {
					initMcDatasourceRouter();
					initUserDatasourceRouter();
					isInit = true;
				}
			}
		}
	}

	@Pointcut("execution(* com.walmart.mobile.checkout.controller.*.*(..)) ")
	public void webLog() {
		// 构造函数
	}

	@SuppressWarnings({ "rawtypes" })
	@Before("webLog()")
	public void doBefore(JoinPoint joinPoint) throws GlobalErrorInfoException {
		json = new JSONObject();
		ThreadLocalContextHolder.clear();
		ThreadLocalContextHolder.put("begin", System.currentTimeMillis());
		String threadName = getThreadName();
		HttpServletRequest request = null;
		try {
			// 接收到请求，记录请求内容
			ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
			request = attributes.getRequest();
			setUserAndIdToThread(request, threadName, false);
			initDatasourceRouter();

			logUrlAndMethod(request);

			// h5版本，cookie无法传递过来时取值
			String authrorization = request.getHeader("Authrorization");
			if (StringUtils.isNotBlank(authrorization)) {
				LOG.info("Authrorization:{}", authrorization);
				TokenAuth tokenAuth = JSON.parseObject(authrorization, TokenAuth.class);
				ThreadLocalContextHolder.put(AppConstants.TOKEN, tokenAuth.getToken());
				setDagIdWhenTokenAuthIsNotNull(tokenAuth);
			} else {
				// 后续统一用这个
				String authorization = request.getHeader("Authorization");
				if (StringUtils.isNotBlank(authorization)) {
					LOG.info("Authorization:{}", authorization);
					TokenAuth tokenAuth = JSON.parseObject(authorization, TokenAuth.class);
					ThreadLocalContextHolder.put(AppConstants.TOKEN, tokenAuth.getToken());
					setDagIdWhenTokenAuthIsNotNull(tokenAuth);
				} else {
					// 获取客户端传过来的cookie信息,存入线程
					Cookie[] cookies = request.getCookies();
					if (cookies != null) {
						List<Cookie> strList = Arrays.asList(cookies);
						Predicate<Cookie> tokenFilter = n -> AppConstants.TOKEN.equalsIgnoreCase(n.getName()) && (StringUtils.isNotBlank(n.getValue()));
						Predicate<Cookie> dagidFilter = n -> AppConstants.DAGID.equalsIgnoreCase(n.getName()) && (StringUtils.isNotBlank(n.getValue()));
						Predicate<Cookie> appTypeFilter = n -> AppConstants.APP_TYPE.equalsIgnoreCase(n.getName()) && (StringUtils.isNotBlank(n.getValue()));
						strList.stream().filter(tokenFilter.or(dagidFilter).or(appTypeFilter)).forEach(n -> ThreadLocalContextHolder.put(n.getName(), n.getValue()));
					}
				}

			}
			// 1.获取访问目标方法应该具备的权限
			// 为解析目标方法的PrivilegeInfo注解，根据我们定义的解析器，需要得到：目标类的class形式
			// 方法的名称
			Class targetClass = joinPoint.getTarget().getClass();
			Method m = ((MethodSignature) joinPoint.getSignature()).getMethod();

			// 检查权限
			checkPrivilege(targetClass, m, request);
			checkLdapUserPrivilege(targetClass, m, request);
		} finally {
			checkoutLogInfo(joinPoint, request);
		}
	}

	/**
	 * 扫描出场不传dagId
	 * 
	 * @param tokenAuth
	 */
	private void setDagIdWhenTokenAuthIsNotNull(TokenAuth tokenAuth) {
		if (tokenAuth.getDagId() != null) {
			ThreadLocalContextHolder.put(AppConstants.DAGID, tokenAuth.getDagId());
		}
		if (tokenAuth.getAppType() != null) {
			ThreadLocalContextHolder.put(AppConstants.APP_TYPE, tokenAuth.getAppType());
		}
	}

	/**
	 * 检查ldap用户权限
	 * 
	 * @param targetClass
	 * @param m
	 * @throws GlobalErrorInfoException
	 */
	private void checkLdapUserPrivilege(Class<?> targetClass, Method m, HttpServletRequest request) throws GlobalErrorInfoException {
		String url = request.getRequestURL().toString();
		String method = request.getMethod();
		if (targetClass != null && m != null) {
			boolean isLdapClzAnnotation = targetClass.isAnnotationPresent(LdapPrivilegeInfo.class);
			boolean isLdapMethondAnnotation = m.isAnnotationPresent(LdapPrivilegeInfo.class);
			LdapPrivilegeInfo rc = null;
			// 如果方法和类声明中同时存在这个注解，那么方法中的会覆盖类中的设定。
			if (isLdapMethondAnnotation) {
				rc = m.getAnnotation(LdapPrivilegeInfo.class);
			} else if (isLdapClzAnnotation) {
				rc = targetClass.getAnnotation(LdapPrivilegeInfo.class);
			}
			if (rc != null) {
				String ldapToken = checkTokenIsEmpty();
				UserLdapVo ldapLogin = userLdapClient.ldapAuth(ldapToken);
				if (ldapLogin == null) {
					throw new GlobalErrorInfoException(GlobalErrorInfoEnum.USER_UNAUTHORIZED);
				} else {
					ThreadLocalContextHolder.put(AppConstants.LDAPUSERID, ldapLogin.getUserId());
					ThreadLocalContextHolder.put(AppConstants.STOREID, ldapLogin.getStoreId());
					ThreadLocalContextHolder.put(AppConstants.ROLE, ldapLogin.getRole() == null ? "" : ldapLogin.getRole());
					LOG.info("ldapUserId is {},storeId is {},url is {},method is {}", ldapLogin.getUserId(), ldapLogin.getStoreId(), url, method);
				}
			}
		}
	}

	/**
	 * log url and method
	 * 
	 * @param request
	 */
	private void logUrlAndMethod(HttpServletRequest request) {
		String url = request.getRequestURL().toString();
		String method = request.getMethod();
		String uri = request.getRequestURI();
		String ip = request.getRemoteAddr();
		json.put("url", url);
		ThreadLocalContextHolder.put("url", url);
		LOG.info("REQUEST BEGIN, url: {}, method: {}, uri: {},ip:{}", url, method, uri, ip);
	}

	/**
	 * 判断方法和类名中是否有PrivilegeInfo注解，如果有则需要登录
	 * 
	 * @param targetClass
	 * @param m
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	private UserAuthority checkPrivilege(Class<?> targetClass, Method m, HttpServletRequest request) throws GlobalErrorInfoException {
		String url = request.getRequestURL().toString();
		String method = request.getMethod();
		boolean isAccessed = false;
		UserAuthority user = null;

		if (targetClass != null && m != null) {
			boolean isClzAnnotation = targetClass.isAnnotationPresent(PrivilegeInfo.class);
			boolean isMethondAnnotation = m.isAnnotationPresent(PrivilegeInfo.class);
			PrivilegeInfo rc = null;
			// 如果方法和类声明中同时存在这个注解，那么方法中的会覆盖类中的设定。
			if (isMethondAnnotation) {
				rc = m.getAnnotation(PrivilegeInfo.class);
				LOG.debug("isMethondAnnotation is run");
			} else if (isClzAnnotation) {
				rc = targetClass.getAnnotation(PrivilegeInfo.class);
				LOG.debug("isClzAnnotation is run");
			}
			if (rc == null) {
				isAccessed = true;
			} else {
				checkTokenIsEmpty();
				user = getUserByToken();
				if (isLogin(user)) {
					isAccessed = true;
					ThreadLocalContextHolder.setUserId(user.getUserId());
					LOG.info("userId is {},url is {},method is {}", user.getUserId(), url, method);

				} else {

					isAccessed = false;
				}
			}
		}

		// 3.如果没有权限，则不调用目标方法，抛出异常
		if (!isAccessed) {
			throw new GlobalErrorInfoException(GlobalErrorInfoEnum.USER_UNAUTHORIZED);
		}
		return user;
	}

	/**
	 * 检查token是否为空
	 * 
	 * @throws GlobalErrorInfoException
	 */
	private String checkTokenIsEmpty() throws GlobalErrorInfoException {
		String token = ThreadLocalContextHolder.get(AppConstants.TOKEN, String.class);
		LOG.info("the token value is {}", token);
		if (StringUtils.isEmpty(token)) {
			throw new GlobalErrorInfoException(GlobalErrorInfoEnum.USER_UNAUTHORIZED);
		}
		return token;
	}

	private String getParamBody(Object[] objs) {
		StringBuilder sb = new StringBuilder();
		if (objs != null) {
			for (int i = 0; i < objs.length; i++) {
				Object obj = objs[i];
				if (obj instanceof ServletRequest || obj instanceof ServletResponse) {
					continue;
				}
				/**
				 * 敏感信息处理
				 */
				String jsonString = JSON.toJSON(obj).toString();
				try {
					jsonString = sensitiveDataHidden(jsonString);
				} catch (Exception e) {
					LOG.error("{} is not a json,but it may be not a error", jsonString, e);
				}
				sb.append("param").append(i).append(":").append(jsonString).append(" ");

			}
		}
		return sb.toString();
	}

	private String sensitiveDataHidden(String jsonString) {
		if (jsonString != null && jsonString.trim().startsWith("{")) {
			net.sf.json.JSONObject jsonObject = net.sf.json.JSONObject.fromObject(jsonString);
			String res = jsonObject.optString("password");
			if (StringUtils.isNotBlank(res)) {
				return jsonString.replace(res, "******");
			}

			String idNumber = jsonObject.optString("idNumber");
			if (StringUtils.isNotBlank(idNumber)) {
				return jsonString.replace(idNumber, "******");
			}

		}
		return jsonString;
	}

	/**
	 * 记录日志
	 * 
	 * @param joinPoint
	 * @param request
	 * @param logContent
	 */
	private void checkoutLogInfo(JoinPoint joinPoint, HttpServletRequest request) {
		String logContent = getParamBody(joinPoint.getArgs());

		if (LOG.isInfoEnabled()) {
			LOG.info("CLASS_METHOD :{}.{} ", joinPoint.getSignature().getDeclaringTypeName(), joinPoint.getSignature().getName());
			LOG.info("ARGS : {}", logContent);
			json.put("reqBody", logContent);
			ThreadLocalContextHolder.put("reqBody", logContent);
		}
		// 从head头中取 clientInfo信息
		String clientInfo = request.getHeader(CLIENT_INFO);
		if (StringUtils.isNotBlank(clientInfo)) {
			clientInfo = new String(Base64Utils.decodeFromString(clientInfo));
			json.put(CLIENT_INFO, clientInfo);
			// 记录下请求内容
			LOG.info("CLIENTINFO :{} ", clientInfo);
			ThreadLocalContextHolder.put(CLIENT_INFO, clientInfo);
		}

	}

	/**
	 * 查询token是否存在
	 * 
	 * @return
	 */
	public UserAuthority getUserByToken() {
		String token = ThreadLocalContextHolder.get(AppConstants.TOKEN, String.class);
		String appType = ThreadLocalContextHolder.get(AppConstants.APP_TYPE, String.class);
		UserAuthority userAuthority = userClient.getUserByToken(token, appType);
		String userAuthorityValue = userAuthority != null ? JSON.toJSONString(userAuthority) : null;
		LOG.info("userAuthority value is {}", userAuthorityValue);
		if (userAuthority != null) {
			ThreadLocalContextHolder.setMobilePhone(userAuthority.getMobilePhone());
		}

		return userAuthority;
	}

	/**
	 * 获取线程名称
	 * 
	 * @return
	 */
	private String getThreadName() {
		String threadName = Thread.currentThread().getName();
		Integer index = threadName.indexOf('|');
		if (index != -1) {
			threadName = threadName.substring(0, index).trim();
		}
		ThreadLocalContextHolder.put("threadName", threadName);
		return threadName;
	}

	/**
	 * 同一线程加上logid和用户,便于日志的检索和问题的追踪
	 */
	private void setUserAndIdToThread(HttpServletRequest request, String threadName, boolean bool) {
		if (bool) {
			Thread.currentThread().setName(threadName);
			return;
		}
		StringBuilder nameBuff = new StringBuilder(threadName);
		// 从head头中取 clientInfo信息
		String clientInfo = request.getHeader("clientInfo");
		String logId = null;
		if (StringUtils.isNotBlank(clientInfo)) {
			clientInfo = new String(Base64Utils.decodeFromString(clientInfo));
			logId = JSONObject.parseObject(clientInfo).getString("logId");
		}
		if (StringUtils.isEmpty(logId)) {
			logId = logId();
		}
		nameBuff.append(" | ").append(logId);
		Thread.currentThread().setName(nameBuff.toString());
		json.put("traceId", nameBuff.toString());
		ThreadLocalContextHolder.put("traceId", nameBuff.toString());
	}

	private String logId() {
		String logId = UUID.randomUUID().toString();
		ThreadLocalContextHolder.put("logId", logId);
		return logId;
	}

	private boolean isLogin(UserAuthority user) {
		return user != null && user.getUserId() != null && user.getStatus() != 1;
	}

	@AfterReturning(returning = "ret", pointcut = "webLog()")
	public void doAfterReturning(Object ret) {

		// 处理完请求，返回内容
		Long time = System.currentTimeMillis() - ThreadLocalContextHolder.get("begin", Long.class);
		json.put("usedTime", time);
		ThreadLocalContextHolder.put("usedTime", time);
		if (ret instanceof ResultBody) {
			ResultBody resultBody = (ResultBody) ret;
			resultBody.setResponseTime(time);
		}
		String retResult = null;
		if (ret != null) {
			retResult = JSON.toJSON(ret).toString();
		}
		LOG.info("RESPONSE : {},SPEND TIME : {}", retResult, time);
		String threadName = ThreadLocalContextHolder.get("threadName", String.class);
		setUserAndIdToThread(null, threadName, true);
		json.put("respBody", retResult);
		ThreadLocalContextHolder.put("respBody", retResult);
		json.put("sendTime", System.currentTimeMillis());

		if (kafkaEnable) {
			try {
				msgProducer.send(json.toJSONString());
			} catch (Exception e) {
				LOG.error("kafka send error ,{}", e);
			}
		}

	}

}
