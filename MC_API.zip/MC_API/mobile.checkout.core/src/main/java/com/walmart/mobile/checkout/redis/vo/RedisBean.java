package com.walmart.mobile.checkout.redis.vo;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;
import org.springframework.data.redis.core.TimeToLive;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

@RedisHash
public class RedisBean<T> {
	@Id
	private String id;

	private T value;

	private String strValue;

	private Integer count = 0;

	@TimeToLive
	private Integer liveTime;

	private Date liveDate;

	public String getStrValue() {
		return strValue;
	}

	public Date getLiveDate() {
		return liveDate;
	}

	public void setLiveDate(Date liveDate) {
		this.liveDate = liveDate;
		this.setLiveTime(liveDate);
	}

	private void setLiveTime(Date liveDate) {
		Long time = liveDate.getTime() - System.currentTimeMillis();
		if (time > 0) {
			this.liveTime = (int) (time / 1000);
		}
	}

	public T getValue() {
		return value;
	}

	public T getValue(Class<T> clazz) {
		if (!(value instanceof String) && !(value instanceof Number)) {
			return JSON.parseObject(this.strValue, clazz);
		}
		return value;
	}

	public void setValue(T value) {
		this.value = value;
		if (!(value instanceof String) && !(value instanceof Number)) {
			this.strValue = JSONObject.toJSONString(value);
		}
	}

	public Integer getCount() {
		return count;
	}

	public void addCount(Integer count) {
		this.count += count;
	}

	public int getLiveTime() {
		return this.liveTime;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}
