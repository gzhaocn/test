package com.walmart.mobile.checkout.config;

import java.io.IOException;

import javax.sql.DataSource;

import org.mybatis.spring.SqlSessionFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.web.client.RestTemplate;

import com.walmart.mobile.checkout.constant.GlobalErrorInfoEnum;
import com.walmart.mobile.checkout.datasource.DynamicDataSource;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoRuntimeException;

@Configuration
@Import(DruidConfig.class)
public class DynamicConfig {

	@Autowired
	private RestTemplateBuilder builder;

	@Bean
	public RestTemplate restTemplate() {
		return this.builder.build();
	}

	@Bean(name = "dynamicDataSource")
	@Primary
	public DataSource dataSourceRouter() {
		return new DynamicDataSource();
	}

	public Resource[] getXmlResource() {
		String packageSearchPath = "classpath*:mapper/**/*.xml";
		Resource[] resources = null;
		try {
			resources = new PathMatchingResourcePatternResolver().getResources(packageSearchPath);
		} catch (IOException e) {
			throw new GlobalErrorInfoRuntimeException(GlobalErrorInfoEnum.RESOURCE_NOT_EXIST, e);
		}
		return resources;
	}

	@Bean(name = "dynamicSqlServerSessionFactory")
	@Primary
	public SqlSessionFactoryBean dynamicSqlServerSessionFactory() {
		SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
		bean.setDataSource(dataSourceRouter());
		bean.setMapperLocations(getXmlResource());
		return bean;
	}

	@Bean(name = "dynamicSqlServerTransactionManager")
	@Primary
	public DataSourceTransactionManager dynamicSqlServerTransactionManager() {
		return new DataSourceTransactionManager(dataSourceRouter());
	}
}
