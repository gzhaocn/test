package com.walmart.mobile.checkout.domain.route;

public class RouteInterfaceRequest {

	private static final String METHOD_QUERY_BY_MOBILE = "query_route_by_mobile";
	private static final String METHOD_QUERY_BY_OPENID = "query_route_by_openid";
	private static final String METHOD_QUERY_BY_USERID = "query_route_by_userid";
	private static final String METHOD_CREATE_ROUTE = "create_route";

	private String method;
	private Route route;

	/**
	 * private RouteInterfaceRequest() { }
	 */

	public static RouteInterfaceRequest createQueryByMobileRequest() {
		RouteInterfaceRequest request = new RouteInterfaceRequest();
		request.setMethod(METHOD_QUERY_BY_MOBILE);
		return request;
	}

	public static RouteInterfaceRequest createQueryByOpenIdRequest() {
		RouteInterfaceRequest request = new RouteInterfaceRequest();
		request.setMethod(METHOD_QUERY_BY_OPENID);
		return request;
	}

	public static RouteInterfaceRequest createQueryByUserIdRequest() {
		RouteInterfaceRequest request = new RouteInterfaceRequest();
		request.setMethod(METHOD_QUERY_BY_USERID);
		return request;
	}

	public static RouteInterfaceRequest createCreateRouteRequest() {
		RouteInterfaceRequest request = new RouteInterfaceRequest();
		request.setMethod(METHOD_CREATE_ROUTE);
		return request;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public Route getRoute() {
		return route;
	}

	public void setRoute(Route route) {
		this.route = route;
	}
}
