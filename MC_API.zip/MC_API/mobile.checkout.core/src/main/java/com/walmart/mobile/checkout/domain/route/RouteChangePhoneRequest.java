package com.walmart.mobile.checkout.domain.route;

public class RouteChangePhoneRequest {
	private static final String METHOD_CANSTANT = "modify_mobile";

	private String method;
	private ChangePhoneInfo modifyUserMobileInfo;

	public RouteChangePhoneRequest() {
		this.method = METHOD_CANSTANT;
	}

	public class ChangePhoneInfo {
		private String oldMobilePhone;
		private String newMobilePhone;

		public String getOldMobilePhone() {
			return oldMobilePhone;
		}

		public void setOldMobilePhone(String oldMobilePhone) {
			this.oldMobilePhone = oldMobilePhone;
		}

		public String getNewMobilePhone() {
			return newMobilePhone;
		}

		public void setNewMobilePhone(String newMobilePhone) {
			this.newMobilePhone = newMobilePhone;
		}
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public ChangePhoneInfo getModifyUserMobileInfo() {
		return modifyUserMobileInfo;
	}

	public void setModifyUserMobileInfo(ChangePhoneInfo modifyUserMobileInfo) {
		this.modifyUserMobileInfo = modifyUserMobileInfo;
	}

}
