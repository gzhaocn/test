package com.walmart.mobile.checkout.entity.document;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * <p>
 * 抽象实体基类，提供统一的ID，和相关的基本功能方法
 * <p>
 * User: feixuhui
 * <p>
 * Date: 15-1-12
 * <p>
 * Version: 1.0
 */
public abstract class Base3AttrDocument<I extends Serializable> extends Abstract3AttrDocument<I> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8502798010817068445L;

	@Id
	private I id;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@Field("created_time")
	private Date createdTime;
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@Field("updated_time")
	private Date updatedTime;

	@Override
	public I getId() {
		return id;
	}

	@Override
	public void setId(I id) {
		this.id = id;
	}

	@Override
	public Date getCreatedTime() {
		return createdTime;
	}

	@Override
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	@Override
	public Date getUpdatedTime() {
		return updatedTime;
	}

	@Override
	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}
	
	@Override
	public boolean equals(Object obj) {

		if (this == obj) {
			return true;
		}

		if (this.getId() == null || obj == null || !(this.getClass().equals(obj.getClass()))) {
			return false;
		}

		Base3AttrDocument<?> that = (Base3AttrDocument<?>) obj;

		return this.getId().equals(that.getId());
	}

	@Override
	public int hashCode() {
		return this.getId() == null ? 0 : this.getId().hashCode();
	}

}
