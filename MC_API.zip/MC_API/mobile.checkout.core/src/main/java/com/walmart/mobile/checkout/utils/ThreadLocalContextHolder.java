package com.walmart.mobile.checkout.utils;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections.MapUtils;

import com.walmart.mobile.checkout.domain.route.Route;

/**
 * 
 * 上下文Holder,保存以类为维度的上下文缓存
 * 
 * 
 * @author Denny
 *
 */
@SuppressWarnings("unchecked")
public class ThreadLocalContextHolder {

	private static final ThreadLocal<Map<String, Map<String, Object>>> ROOTCONTEXT = new ThreadLocal<>();

	private static final ThreadLocal<Integer> DEPATHCOUNTER = new ThreadLocal<>();

	private ThreadLocalContextHolder() {
		
	}
	
	public static void setUserId(String userId) {
		ThreadLocalContextHolder.put("userId", userId);
	}
	
	public static String getUserId() {
		return ThreadLocalContextHolder.get("userId", String.class);
	}
	
	public static void setOpenId(String openId) {
		ThreadLocalContextHolder.put("openId", openId);
	}
	
	public static String getOpenId() {
		return ThreadLocalContextHolder.get("openId", String.class);
	}
	
	
	
	public static void setMobilePhone(String mobilePhone) {
		ThreadLocalContextHolder.put("mobilePhone", mobilePhone);
	}
	
	
	public static String getMobilePhone() {
		return ThreadLocalContextHolder.get("mobilePhone", String.class);
	}


	public static void switchDataSoureByRoute(Route route) {
		String dagId = route.getDagId();
		ThreadLocalContextHolder.put("dagId", dagId);
	}

	public static void switchDataSoureByDagId(String dagId) {
		ThreadLocalContextHolder.put("dagId", dagId);
	}

	public static void incDepth() {
		Integer depth;
		if ((depth = DEPATHCOUNTER.get()) == null) {
			depth = 0;
		}

		depth += 1;

		DEPATHCOUNTER.set(depth);
	}

	public static void decDepth() {
		Integer depth;

		if ((depth = DEPATHCOUNTER.get()) == null) {
			depth = 1;
		}

		depth += -1;

		if (depth <= 0) {
			ROOTCONTEXT.remove();
			DEPATHCOUNTER.remove();
		}
	}

	public static <T> T get(String key, Class<T> clazz) {
		Map<String, Object> innerContext = getContext(clazz);

		if (innerContext == null || !innerContext.containsKey(key)) {
			return null;
		}

		return (T) innerContext.get(key);
	}

	public static Map<String, Object> getContext(Class<?> clazz) {
		Map<String, Object> subContext;
		if (ROOTCONTEXT.get() == null || (subContext = ROOTCONTEXT.get().get(clazz.getName())) == null) {
			return null;
		}

		return subContext;
	}

	public static <T> void put(String key, T target) {
		put(key, target, target != null ? (Class<T>) target.getClass() : null);
	}

	public static void putNull(String key, Class<?> clazz) {
		put(key, null, clazz);
	}

	public static <T> void put(String key, T target, Class<T> clazz) {
		Map<String, Object> innerContext = checkAndInitContext(clazz);

		if (innerContext != null) {
			innerContext.put(key, target);
		}
	}

	public static void clear() {
		ROOTCONTEXT.remove();
	}

	public static void clear(Class<?> clazz) {
		Map<String, Map<String, Object>> context = ROOTCONTEXT.get();
		if (context != null) {
			context.remove(clazz.getName());
		}
	}

	public static <T> void put(Class<T> clazz, Map<String, T> context) {
		if (MapUtils.isNotEmpty(context)) {
			Map<String, Object> subContext = checkAndInitContext(clazz);
			if (subContext != null) {
				subContext.putAll(context);
			}
		}
	}

	public static void put(Map<String, Map<String, Object>> context) {
		if (MapUtils.isNotEmpty(context)) {
			if (ROOTCONTEXT.get() == null) {
				init();
			}
			ROOTCONTEXT.get().putAll(context);
		}
	}

	private static void init() {
		ROOTCONTEXT.set(new HashMap<String, Map<String, Object>>(16));
	}

	private static void subInit(Class<?> clazz) {
		if (ROOTCONTEXT.get() == null) {
			init();
		}
		ROOTCONTEXT.get().put(clazz.getName(), new HashMap<String, Object>(16));
	}

	private static <T> Map<String, Object> checkAndInitContext(Class<T> clazz) {
		Map<String, Object> innerContext = getContext(clazz);

		if (innerContext == null) {
			subInit(clazz);
			innerContext = getContext(clazz);
		}
		return innerContext;
	}
}
