package com.walmart.mobile.checkout.restConfig;

import java.io.Serializable;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.springframework.context.ApplicationContext;

import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;

public class RestMapper<T> implements InvocationHandler, Serializable {
	private static final long serialVersionUID = -6424540398559729838L;
	private final Class<T> mapperInterface;
	private final transient Map<Method, RestMethod> methodCache = new HashMap<>();
	private final transient ApplicationContext application;

	public RestMapper(ApplicationContext application, Class<T> mapperInterface) {
		this.mapperInterface = mapperInterface;
		this.application = application;
	}

	@Override
	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
		if (Object.class.equals(method.getDeclaringClass())) {
			return method.invoke(this, args);
		}
		final RestMethod restMethod = cachedRestMethod(method);
		return restMethod.execute(args);
	}

	private RestMethod cachedRestMethod(Method method) throws GlobalErrorInfoException {
		RestMethod restMethod = methodCache.get(method);
		if (restMethod == null) {
			restMethod = new RestMethod(application, mapperInterface, method);
			methodCache.put(method, restMethod);
		}
		return restMethod;
	}

}
