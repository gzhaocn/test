package com.walmart.mobile.checkout.dag;

import java.util.List;

import com.walmart.mobile.checkout.dag.DagHost;

public class HostData {
	private List<DagHost> data;

	public List<DagHost> getData() {
		return data;
	}

	public void setData(List<DagHost> data) {
		this.data = data;
	}
}
