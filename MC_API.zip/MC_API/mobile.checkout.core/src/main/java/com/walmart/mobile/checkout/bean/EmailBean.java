package com.walmart.mobile.checkout.bean;

public class EmailBean {
	private String body;
	private String title;
	private String[] toMailList;

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String[] getToMailList() {
		return toMailList;
	}

	public void setToMailList(String[] toMailList) {
		this.toMailList = toMailList;
	}

}
