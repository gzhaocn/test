package com.walmart.mobile.checkout.utils;

import org.kie.api.runtime.KieContainer;

/**
 * @author lliao2
 */
public class KieUtils {
	private KieUtils() {
	}

	private static KieContainer kieContainer;

	public static KieContainer getKieContainer() {
		return kieContainer;
	}

	public static void setKieContainer(KieContainer kieContainer) {
		KieUtils.kieContainer = kieContainer;
	}

}
