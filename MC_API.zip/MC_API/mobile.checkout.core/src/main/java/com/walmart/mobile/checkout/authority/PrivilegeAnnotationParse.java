package com.walmart.mobile.checkout.authority;


import java.lang.reflect.Method;

import org.apache.log4j.Logger;

import com.walmart.mobile.checkout.annotation.PrivilegeInfo;
import com.walmart.mobile.checkout.constant.GlobalErrorInfoEnum;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;

/**
 * 权限注解解析器
 * 这个解析器的主要功能，是解析目标方法上如果有PrivilegeInfo注解，那么解析出这个注解中的value值（权限的值）
 *@author lliao2
 */
public class PrivilegeAnnotationParse {
	private static final Logger LOG = Logger.getLogger(PrivilegeAnnotationParse.class);
	private PrivilegeAnnotationParse(){}
    /**
     * 解析注解
     * @param targetClass　目标类的class形式
     * @param methodName　在客户端调用哪个方法,methodName就代表哪个方法　
     * @return
     * @throws GlobalErrorInfoException 
     * @throws SecurityException 
     * @throws NoSuchMethodException 
     * @throws Exception 
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public static  PrivilegeInfo parse(Class targetClass, String methodName) throws GlobalErrorInfoException   {
        PrivilegeInfo privilegeInfo = null ;
        Method method = null ;
        try{
         method = targetClass.getMethod(methodName);
         if (method.isAnnotationPresent(PrivilegeInfo.class)) {
             //得到方法上的注解
              privilegeInfo = method.getAnnotation(PrivilegeInfo.class);
         }
        }catch(NoSuchMethodException|SecurityException e){
        	LOG.error("NoSuchMethodException|SecurityException ",e);
        	throw new GlobalErrorInfoException(GlobalErrorInfoEnum.FAILED);
        }
        
        //判断方法上是否有Privilege注解
       
        return privilegeInfo;
    }
}