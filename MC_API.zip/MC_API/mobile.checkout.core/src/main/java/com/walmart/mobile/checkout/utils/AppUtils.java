package com.walmart.mobile.checkout.utils;

import java.text.MessageFormat;

import javax.jms.JMSException;
import javax.jms.Message;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

public final class AppUtils {

	private AppUtils() {

	}

	public static final String messageFormat(String pattern, Object... arguments) {
		return MessageFormat.format(pattern, arguments);
	}

	public static Object copyProperties(Object source, Class<?> targetClass) {
		if (source == null) {
			return null;
		}
		return JSONObject.parseObject(JSONObject.toJSONString(source), targetClass);
	}

	public static Integer getJmsIntegerValue(String name, Message message) throws JMSException {
		return message.getIntProperty(name);
	}

	public static String getJmsStringValue(String name, Message message) throws JMSException {
		return message.getStringProperty(name);
	}

	public static <T> T getJavaBean(String source, Class<T> clazz) {
		return JSON.parseObject(source, clazz);
	}
}
