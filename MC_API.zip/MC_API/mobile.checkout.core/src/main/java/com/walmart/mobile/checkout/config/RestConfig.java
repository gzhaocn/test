package com.walmart.mobile.checkout.config;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
/**
 * 设置restTemplate的超时时间，解决服务没响应或者响应时间过长的问题
 * @author lliao2
 *
 */
@Configuration
public class RestConfig {
	@Value("${rest.ReadTimeout}")
	private int readTimeout;
	@Value("${rest.ConnectTimeout}")
	private int connectionTimeout;

	@Bean
	public SimpleClientHttpRequestFactory httpClientFactory() {
		SimpleClientHttpRequestFactory httpRequestFactory = new SimpleClientHttpRequestFactory();
		httpRequestFactory.setReadTimeout(readTimeout);
		httpRequestFactory.setConnectTimeout(connectionTimeout);
		return httpRequestFactory;
	}

	@Bean
	public RestTemplate restTemplate(SimpleClientHttpRequestFactory httpClientFactory) {
		return new RestTemplate(httpClientFactory);
	}

}
