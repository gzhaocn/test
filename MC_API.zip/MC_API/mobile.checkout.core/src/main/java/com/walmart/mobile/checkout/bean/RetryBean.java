package com.walmart.mobile.checkout.bean;

import com.walmart.mobile.checkout.constant.AppConstants;

public class RetryBean {

	private Integer size = 0;

	private Integer count = 0;

	private String message;

	private Long delayTime = 0L;

	private String correlationID;

	private String queueName;

	public Integer getSize() {
		return size;
	}

	public void setSize(Integer size) {
		this.size = size == null ? 0 : size;
	}

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count == null ? 1 : count;
		this.count++;
		this.delayTime = (AppConstants.BASE_MULTIPLES << this.count - AppConstants.BASE_SUB)
				/ AppConstants.BASE_MULTIPLES * AppConstants.BASE_TIMTE;
		this.delayTime = this.delayTime > AppConstants.MAX_DELAY_TIME ? AppConstants.MAX_DELAY_TIME : this.delayTime;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getCorrelationID() {
		return correlationID;
	}

	public void setCorrelationID(String correlationID) {
		this.correlationID = correlationID;
	}

	public boolean isRetry() {
		return this.count > 0 && this.size > 0;
	}

	public String getQueueName() {
		return queueName;
	}

	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}

	public boolean isComplete() {
		return this.size.compareTo(this.count - 1) <= 0;
	}

	public Long getDelayTime() {
		return delayTime;
	}

	public void setDelayTime(Long delayTime) {
		this.delayTime = delayTime;
	}
}
