package com.walmart.mobile.checkout.domain.route;

import java.util.List;

public class RouteDagDomainResponse {
	private int errorCode;
	private List<DagDomain> data;

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public List<DagDomain> getData() {
		return data;
	}

	public void setData(List<DagDomain> data) {
		this.data = data;
	}

}
