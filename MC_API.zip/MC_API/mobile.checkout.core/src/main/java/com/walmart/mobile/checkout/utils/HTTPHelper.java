package com.walmart.mobile.checkout.utils;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import com.alibaba.fastjson.JSONObject;

public class HTTPHelper {

	public static final String ENCODING_UTF8 = "UTF-8";

	private HTTPHelper() {
	}

	public static HttpHeaders createResponseHeaders() {
		HttpHeaders responseHeaders = new HttpHeaders();

		responseHeaders.set("charset", ENCODING_UTF8);
		responseHeaders.set("pageEncoding", ENCODING_UTF8);

		responseHeaders.setContentType(new MediaType("application", "json", Charset.forName("UTF-8")));

		return responseHeaders;
	}

	public static Map<String, String> parameters(Map<String, String[]> parameters) {
		Map<String, String> params = new HashMap<>(16);
		for (Entry<String, String[]> paramsEntry : parameters.entrySet()) {
			if (paramsEntry.getValue() != null) {
				params.put(paramsEntry.getKey(), paramsEntry.getValue()[0]);
			}
		}
		return params;
	}

	public static final JSONObject buildJSONObjectFromParameter(HttpServletRequest request) throws IOException {
		return JSONObject.parseObject(request.getParameter("data"));
	}

	public static final <T> T getObject(HttpServletRequest request, Class<T> clazz) throws IOException {
		return com.alibaba.fastjson.JSONObject.parseObject(request.getParameter("data"), clazz);
	}

	public static final <T> List<T> getList(HttpServletRequest request, Class<T> clazz) throws IOException {
		List<T> list = com.alibaba.fastjson.JSONArray.parseArray(request.getParameter("data"), clazz);
		return list == null ? Collections.emptyList() : list;
	}

	public static String getIpAddr(HttpServletRequest request) {
		String ip = request.getHeader("x-forwarded-for");

		final String unknown = "unknown";

		if (ip == null || ip.length() == 0 || unknown.equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || unknown.equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || unknown.equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}
		if (ip == null || ip.length() == 0 || unknown.equalsIgnoreCase(ip)) {
			ip = request.getHeader("http_client_ip");
		}
		if (ip == null || ip.length() == 0 || unknown.equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_X_FORWARDED_FOR");
		}
		// 如果是多级代理，那么取第一个ip为客户ip
		if (ip != null && ip.indexOf(',') != -1) {
			ip = ip.substring(ip.lastIndexOf(',') + 1, ip.length()).trim();
		}

		if (ip != null && "0:0:0:0:0:0:0:1".equals(ip)) {
			ip = PropertyUtils.getConfigValue("weixin.request.ip");
		}
		return ip;
	}
}