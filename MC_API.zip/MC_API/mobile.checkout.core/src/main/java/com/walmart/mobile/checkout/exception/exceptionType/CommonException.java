package com.walmart.mobile.checkout.exception.exceptionType;

public class CommonException extends Exception {
	private static final long serialVersionUID = 1L;

	public CommonException(Throwable cause) {
		super(cause);
	}

	public CommonException(String message, Throwable cause) {
		super(message + " cause:" + cause.getMessage(), cause);
	}

	public CommonException(String message, Integer code, Throwable cause) {
		super(message + " cause:" + cause.getMessage(), cause);

	}

	public CommonException(String message) {
		super(message);
	}

	public CommonException(String message, Integer code) {
		super(message);

	}

}
