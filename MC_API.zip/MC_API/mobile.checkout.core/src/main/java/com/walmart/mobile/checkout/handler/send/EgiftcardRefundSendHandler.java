package com.walmart.mobile.checkout.handler.send;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import com.walmart.mobile.checkout.annotation.JmsHandler;

@JmsHandler
public class EgiftcardRefundSendHandler {

	@Autowired
	private JmsTemplate jmsTemplate;

	@Value("${egiftcard.refund.queue.name}")
	private String egiftcardRefundQueueName;



	public void egiftcardRefundMessage(final String msg) {  
		jmsTemplate.send(egiftcardRefundQueueName, new MessageCreator() {
			@Override
			public Message createMessage(Session session) throws JMSException {
				return session.createTextMessage(msg);
				
			}
		});
	}

}
