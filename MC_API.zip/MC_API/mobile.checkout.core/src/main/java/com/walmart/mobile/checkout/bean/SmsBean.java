package com.walmart.mobile.checkout.bean;

import java.io.Serializable;

public class SmsBean implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -8189851731094905836L;

	private String mobile;

	private String body;

	private String ext = "";

	private String stime = "";

	private String rrid = "";

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getExt() {
		return ext;
	}

	public void setExt(String ext) {
		this.ext = ext;
	}

	public String getStime() {
		return stime;
	}

	public void setStime(String stime) {
		this.stime = stime;
	}

	public String getRrid() {
		return rrid;
	}

	public void setRrid(String rrid) {
		this.rrid = rrid;
	}
}
