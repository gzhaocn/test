package com.walmart.mobile.checkout.domain;

import java.math.BigInteger;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.walmart.mobile.checkout.entity.document.BaseDocument;

@JsonInclude(Include.NON_NULL)
@Document(collection = "stores")
public class StoreVo extends BaseDocument<BigInteger> {
	private static final long serialVersionUID = 1403126665460852705L;

	@Indexed(unique = true)
	@Field("store_id")
	private Integer storeId;
	@Field("name_cn")
	private String nameCn;
	@Field("short_name_cn")
	private String shortNameCn;
	private Integer status;
	@Field("delivery_threshold")
	private Integer deliveryThreshold;
	@Field("delivery_item_upc")
	private Long deliveryItemUpc;
	@Field("delivery_flag")
	private Integer deliveryFlag;
	private Integer scanFlag;

	public Integer getDeliveryFlag() {
		return deliveryFlag;
	}

	public void setDeliveryFlag(Integer deliveryFlag) {
		this.deliveryFlag = deliveryFlag;
	}

	/**
	 * @Field("city_first_spell") private String cityFirstSpell;
	 */

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	@JsonIgnore
	public String getNameCn() {
		return nameCn;
	}

	public void setNameCn(String nameCn) {
		this.nameCn = nameCn;
	}

	public String getShortNameCn() {
		return shortNameCn;
	}

	public void setShortNameCn(String shortNameCn) {
		this.shortNameCn = shortNameCn;
	}

	/**
	 * @JsonIgnore public String getProvinceCn() { return provinceCn; }
	 * 
	 *             public void setProvinceCn(String provinceCn) {
	 *             this.provinceCn = provinceCn; }
	 * 
	 *             public String getCityCn() { return cityCn; }
	 * 
	 *             public void setCityCn(String cityCn) { this.cityCn = cityCn;
	 *             }
	 * @JsonIgnore public String getArea() { return area; }
	 * 
	 *             public void setArea(String area) { this.area = area; }
	 * 
	 *             public String getAddressCn() { return addressCn; }
	 * 
	 *             public void setAddressCn(String addressCn) { this.addressCn =
	 *             addressCn; }
	 * @JsonIgnore public String getOperateTime() { return operateTime; }
	 * 
	 *             public void setOperateTime(String operateTime) {
	 *             this.operateTime = operateTime; }
	 * 
	 *             public Double getLongitude() { return longitude; }
	 * 
	 *             public void setLongitude(Double longitude) { this.longitude =
	 *             longitude; }
	 * 
	 *             public Double getLatitude() { return latitude; }
	 * 
	 *             public void setLatitude(Double latitude) { this.latitude =
	 *             latitude; }
	 * @JsonIgnore public String getTelephone() { return telephone; }
	 * 
	 *             public void setTelephone(String telephone) { this.telephone =
	 *             telephone; }
	 * 
	 *             public Integer getCityId() { return cityId; }
	 * 
	 *             public void setCityId(Integer cityId) { this.cityId = cityId;
	 *             }
	 * @JsonIgnore public Date getStartDate() { return startDate; }
	 * 
	 *             public void setStartDate(Date startDate) { this.startDate =
	 *             startDate; }
	 */

	@JsonIgnore
	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getDeliveryThreshold() {
		return deliveryThreshold == null ? 0 : deliveryThreshold;
	}

	public void setDeliveryThreshold(Integer deliveryThreshold) {
		this.deliveryThreshold = deliveryThreshold;
	}

	public Long getDeliveryItemUpc() {
		return deliveryItemUpc;
	}

	public void setDeliveryItemUpc(Long deliveryItemUpc) {
		this.deliveryItemUpc = deliveryItemUpc;
	}

	public Integer getScanFlag() {
		return scanFlag;
	}

	public void setScanFlag(Integer scanFlag) {
		this.scanFlag = scanFlag;
	}

	/**
	 * public String getCityFirstSpell() { return cityFirstSpell; }
	 * 
	 * public void setCityFirstSpell(String cityFirstSpell) {
	 * this.cityFirstSpell = cityFirstSpell; }
	 */

}
