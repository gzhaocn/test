package com.walmart.mobile.checkout.domain.route;

public class RouteDagDomainRequest {
	private static final String METHOD = "query_dag_host_mapping";

	private String method;

	public RouteDagDomainRequest() {
		this.method = METHOD;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}
}
