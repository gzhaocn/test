package com.walmart.mobile.checkout.entity.document;

import java.io.Serializable;

import org.springframework.data.annotation.Id;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * <p>
 * 抽象实体基类，提供统一的ID，和相关的基本功能方法
 * <p>
 * User: feixuhui
 * <p>
 * Date: 15-1-12
 * <p>
 * Version: 1.0
 */
public abstract class BaseDocument<I extends Serializable> extends AbstractDocument<I> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	private I id;

	@Override
	@JsonIgnore
	public I getId() {
		return id;
	}

	@Override
	public void setId(I id) {
		this.id = id;
	}
	@Override
	public boolean equals(Object obj) {

		if (this == obj) {
			return true;
		}

		if (this.getId() == null || obj == null || !(this.getClass().equals(obj.getClass()))) {
			return false;
		}

		BaseDocument<?> that = (BaseDocument<?>) obj;

		return this.getId().equals(that.getId());
	}

	@Override
	public int hashCode() {
		return this.getId() == null ? 0 : this.getId().hashCode();
	}
	

}
