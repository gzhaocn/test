package com.walmart.mobile.checkout.domain.route;

public class RouteInterfaceResponse {
	private int errorCode;
	private Route route;

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public Route getRoute() {
		return route;
	}

	public void setRoute(Route route) {
		this.route = route;
	}
}
