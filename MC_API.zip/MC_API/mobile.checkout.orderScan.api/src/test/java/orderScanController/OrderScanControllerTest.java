package orderScanController;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;

import org.junit.Assert;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;

import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.bo.order.OrderScanConfirmParameter;
import com.walmart.mobile.checkout.bo.order.OrderScanListParameter;
import com.walmart.mobile.checkout.bo.order.OrderScanParameter;
import com.walmart.mobile.checkout.constant.order.OrderStatus;
import com.walmart.mobile.checkout.dag.DagHost;
import com.walmart.mobile.checkout.dag.HostData;
import com.walmart.mobile.checkout.datasource.DynamicDataSource;
import com.walmart.mobile.checkout.domain.order.Order;
import com.walmart.mobile.checkout.entity.UserLdap;
import com.walmart.mobile.checkout.exception.handler.ResultBody;
import com.walmart.mobile.checkout.service.LdapService;
import com.walmart.mobile.checkout.service.OrderService;
import com.walmart.mobile.checkout.utils.ThreadLocalContextHolder;
import com.walmart.mobile.checkout.vo.LdapLoginReturnMsg;

/*@RunWith(SpringJUnit4ClassRunner.class)
 @WebAppConfiguration
 @ContextConfiguration(classes = { MainConfig.class })*/
public class OrderScanControllerTest {
	protected MockHttpServletResponse response;

	protected MockMvc mockMVC;

	@Autowired
	private WebApplicationContext wac;
	@Autowired
	private OrderService orderService;

	@Autowired
	private LdapService ldapService;

	@Autowired
	@Qualifier("dynamicDataSource")
	public DynamicDataSource dynamicDataSource;

	@Value("${ddr.request.param}")
	private String ddrParam;

	@Value("${ddr.request.url}")
	private String ddrUrl;

	@Autowired
	private RestTemplate restTemplate;

	private void initDatasourceRouter() {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<>(ddrParam, headers);
		String result = restTemplate.postForObject(ddrUrl, entity, String.class);
		List<DagHost> dss = JSONObject.parseObject(result, HostData.class).getData();
		Map<Object, Object> dataSources = new HashMap<>(16);
		for (int i = 0; i < dss.size(); i++) {
			DagHost dh = dss.get(i);
			String key = dh.getDagId();
			dataSources.put(key, dh.getDataSource());
		}
		dynamicDataSource.setTargetDataSources(dataSources);
		dynamicDataSource.afterPropertiesSet();

	}

	// @PostConstruct
	private void init() {
		initDatasourceRouter();
	}

	// @Before
	public void before() {
		mockMVC = MockMvcBuilders.webAppContextSetup(wac).build();
		MockitoAnnotations.initMocks(this);
	}

	// @Test
	public void scanOrderListTest() throws Exception {
		ThreadLocalContextHolder.put("dagId", "002");

		ldapService.saveUserLdap("test", "testtesttest", new Date(), 1059);

		UserLdap userLdapBo = new UserLdap();
		userLdapBo.setUserId("test");
		userLdapBo.setToken("testtesttest");

		LdapLoginReturnMsg ldapLoginReturnMsg = ldapService.authByAd(userLdapBo);

		String restUrl1 = "/orderScan/scanOrderList";

		Cookie[] cookies = new Cookie[1];
		Cookie cookie2 = new Cookie("token", ldapLoginReturnMsg.getToken());
		cookies[0] = cookie2;

		OrderScanListParameter scanOrder = new OrderScanListParameter();
		scanOrder.setUserId("8D957586BD0E47B8A77FB0E025D253E5");
		List<String> orderIds = new ArrayList<>();
		orderIds.add("11059170020000013299");
		scanOrder.setOrderIds(orderIds);

		// 。。。设置值
		String requestJson = JSONObject.toJSONString(scanOrder);
		String responseString = mockMVC
				.perform(MockMvcRequestBuilders.post(restUrl1).contentType(MediaType.APPLICATION_JSON).cookie(cookies)
						.content(requestJson))// .andDo(print())
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();

		ResultBody resultBody = JSONObject.parseObject(responseString, ResultBody.class);
		Assert.assertTrue("", resultBody.getCode().equals("0"));

	}


	// @Test
	public void orderScanForPadTest() throws Exception {
		ThreadLocalContextHolder.put("dagId", "002");

		ldapService.saveUserLdap("test", "testtesttest", new Date(), 1059);

		UserLdap userLdapBo = new UserLdap();
		userLdapBo.setUserId("test");
		userLdapBo.setToken("testtesttest");

		LdapLoginReturnMsg ldapLoginReturnMsg = ldapService.authByAd(userLdapBo);

		String restUrl2 = "/orderScan/scanOrderForPad";

		Cookie[] cookies = new Cookie[1];
		Cookie cookie2 = new Cookie("token", ldapLoginReturnMsg.getToken());
		cookies[0] = cookie2;

		OrderScanParameter orderScanParameter = new OrderScanParameter();
		orderScanParameter.setOrderId("11059170020000013299");

		// 。。。设置值
		String requestJson = JSONObject.toJSONString(orderScanParameter);
		String responseString = mockMVC
				.perform(MockMvcRequestBuilders.post(restUrl2).contentType(MediaType.APPLICATION_JSON).cookie(cookies)
						.content(requestJson))// .andDo(print())
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();

		ResultBody resultBody = JSONObject.parseObject(responseString, ResultBody.class);
		Assert.assertTrue("", resultBody.getCode().equals("0"));

	}

	// @Test
	public void orderScanForPadConfirmTest() throws Exception {
		ThreadLocalContextHolder.put("dagId", "002");
		
		Order order = orderService.getOrderByOrderId("11059170020000013299");
		order.setStatus(OrderStatus.PAID);
		orderService.updateByPrimaryKeySelective(order);

		ldapService.saveUserLdap("test", "testtesttest", new Date(), 1059);
		UserLdap userLdapBo = new UserLdap();
		userLdapBo.setUserId("test");
		userLdapBo.setToken("testtesttest");

		LdapLoginReturnMsg ldapLoginReturnMsg = ldapService.authByAd(userLdapBo);

		String restUrl3 = "/orderScan/scanOrderForPadConfirm";

		Cookie[] cookies = new Cookie[1];
		Cookie cookie2 = new Cookie("token", ldapLoginReturnMsg.getToken());
		cookies[0] = cookie2;

		OrderScanConfirmParameter orderScanConfirmParameter = new OrderScanConfirmParameter();
		orderScanConfirmParameter.setUserId("8D957586BD0E47B8A77FB0E025D253E5");
		orderScanConfirmParameter.setStoreId("1059");

		orderScanConfirmParameter.setOrderId("11059170020000013299");

		// 。。。设置值
		String requestJson = JSONObject.toJSONString(orderScanConfirmParameter);
		String responseString = mockMVC
				.perform(MockMvcRequestBuilders.post(restUrl3).contentType(MediaType.APPLICATION_JSON).cookie(cookies)
						.content(requestJson))// .andDo(print())
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();

		ResultBody resultBody = JSONObject.parseObject(responseString, ResultBody.class);
		Assert.assertTrue("", resultBody.getCode().equals("0"));
		
		order = orderService.getOrderByOrderId("11059170020000013299");
		order.setStatus(OrderStatus.PAID);
		orderService.updateByPrimaryKeySelective(order);

	}

}
