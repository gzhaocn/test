package orderScanController;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Date;
import java.util.List;

import javax.servlet.http.Cookie;

import org.easymock.EasyMock;
import org.easymock.IMocksControl;
import org.junit.Assert;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.controller.GateMacController;
import com.walmart.mobile.checkout.entity.GateMac;
import com.walmart.mobile.checkout.entity.UserLdap;
import com.walmart.mobile.checkout.exception.handler.ResultBody;
import com.walmart.mobile.checkout.service.GateMacService;
import com.walmart.mobile.checkout.service.LdapService;

/*@RunWith(SpringJUnit4ClassRunner.class)
 @WebAppConfiguration
 @ContextConfiguration(classes = { MainConfig.class })*/
public class GateMacControllerMockTest {
	protected MockHttpServletResponse response;

	protected MockMvc mockMVC;

	@Autowired
	private WebApplicationContext wac;

	@Autowired
	GateMacController gateMacController;

	@Autowired
	private GateMacService gateMacService;

	@Autowired
	private LdapService ldapService;

	// @Before
	public void before() {
		mockMVC = MockMvcBuilders.webAppContextSetup(wac).build();
		MockitoAnnotations.initMocks(this);
	}

	// @Test
	public void queryOrderListTest() throws Exception {

		saveUser();
		UserLdap userLdapBo = new UserLdap();
		userLdapBo.setUserId("test");
		userLdapBo.setToken("testtesttest");
		Cookie[] cookies = new Cookie[1];
		Cookie cookie2 = new Cookie("token", "testtesttest");
		cookies[0] = cookie2;

		String restUrl = "/gateMac/macInformation";
		GateMac gateMac = new GateMac();
		gateMac.setStoreId(1059);
		// 。。。设置值

		String gateMacListJson = "[{\"id\":27681688975263574287844739490,\"mac\":\"34043434df34\",\"sequenceNumber\":\"2\",\"storeId\":1059},{\"id\":27681696722896099985751536847,\"mac\":\"BC000105ACa4\",\"sequenceNumber\":\"1d\",\"storeId\":1059},{\"id\":27697410207742693110652465767,\"mac\":\"008139921539\",\"sequenceNumber\":\"2\",\"storeId\":1059},{\"id\":27699222342093518042165028847,\"mac\":\"008139921539\",\"sequenceNumber\":\"1\",\"storeId\":1059},{\"id\":27743626329856827620790067130,\"mac\":\"008139961511\",\"sequenceNumber\":\"2\",\"storeId\":1059}]";
		List<GateMac> gateMacList = JSON.parseArray(gateMacListJson, GateMac.class);

		IMocksControl mocksControl = EasyMock.createStrictControl();
		GateMacService gateMacServiceMock = mocksControl.createMock(GateMacService.class);

		EasyMock.expect(gateMacServiceMock.findByStoreId(EasyMock.anyInt())).andReturn(gateMacList);
		mocksControl.replay();
		// 结合spring 将mock的对象注入到controller里
		ReflectionTestUtils.setField(gateMacController, "gateMacService", gateMacServiceMock);

		String requestJson = JSONObject.toJSONString(gateMac);
		String responseString = mockMVC.perform(MockMvcRequestBuilders.post(restUrl).contentType(MediaType.APPLICATION_JSON).cookie(cookies).content(requestJson))// .andDo(print())
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();

		ResultBody resultBody = JSONObject.parseObject(responseString, ResultBody.class);
		Assert.assertTrue("", resultBody.getCode().equals("0"));

	}

	// @Test
	public void queryOrderListTest2() throws Exception {
		saveUser();
		UserLdap userLdapBo = new UserLdap();
		userLdapBo.setUserId("test");
		userLdapBo.setToken("testtesttest");
		Cookie[] cookies = new Cookie[1];
		Cookie cookie2 = new Cookie("token", "testtesttest");
		cookies[0] = cookie2;
		String restUrl = "/gateMac/macInformation";
		GateMac gateMac = new GateMac();
		gateMac.setStoreId(10590);
		// 。。。设置值
		List<GateMac> gateMacList = null;

		IMocksControl mocksControl = EasyMock.createStrictControl();
		GateMacService gateMacServiceMock = mocksControl.createMock(GateMacService.class);

		EasyMock.expect(gateMacServiceMock.findByStoreId(EasyMock.anyInt())).andReturn(gateMacList);
		mocksControl.replay();
		// 结合spring 将mock的对象注入到controller里
		ReflectionTestUtils.setField(gateMacController, "gateMacService", gateMacServiceMock);

		String requestJson = JSONObject.toJSONString(gateMac);
		String responseString = mockMVC.perform(MockMvcRequestBuilders.post(restUrl).contentType(MediaType.APPLICATION_JSON).cookie(cookies).content(requestJson))// .andDo(print())
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();

		ResultBody resultBody = JSONObject.parseObject(responseString, ResultBody.class);
		Assert.assertTrue("", resultBody.getCode().equals("-220"));

	}

	private void saveUser() {
		UserLdap userLdap = ldapService.selectUserLdapByUserId("test");
		if (userLdap == null) {
			ldapService.saveUserLdap("test", "testtesttest", new Date(), 1059);
		} else {
			userLdap.setTokenUpdatedTime(new Date());
			ldapService.saveUserLdap(userLdap);
		}
	}

}
