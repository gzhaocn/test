package orderScanController;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;

import org.easymock.EasyMock;
import org.easymock.IMocksControl;
import org.junit.Assert;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.bo.order.OrderBo;
import com.walmart.mobile.checkout.bo.order.OrderScanConfirmParameter;
import com.walmart.mobile.checkout.bo.order.OrderScanListParameter;
import com.walmart.mobile.checkout.bo.order.OrderScanParameter;
import com.walmart.mobile.checkout.controller.OrderScanController;
import com.walmart.mobile.checkout.dag.DagHost;
import com.walmart.mobile.checkout.dag.HostData;
import com.walmart.mobile.checkout.datasource.DynamicDataSource;
import com.walmart.mobile.checkout.domain.order.Order;
import com.walmart.mobile.checkout.entity.UserLdap;
import com.walmart.mobile.checkout.exception.handler.ResultBody;
import com.walmart.mobile.checkout.rest.order.UserCreditInfoClient;
import com.walmart.mobile.checkout.rest.vo.CheckCreditVo;
import com.walmart.mobile.checkout.service.LdapService;
import com.walmart.mobile.checkout.service.OrderService;
import com.walmart.mobile.checkout.service.refund.RefundService;
import com.walmart.mobile.checkout.utils.ThreadLocalContextHolder;
import com.walmart.mobile.checkout.vo.LdapLoginReturnMsg;

/*@RunWith(SpringJUnit4ClassRunner.class)
 @WebAppConfiguration
 @ContextConfiguration(classes = { MainConfig.class })*/
public class OrderScanControllerMockTest {
	protected MockHttpServletResponse response;

	protected MockMvc mockMVC;

	@Autowired
	private WebApplicationContext wac;
	@Autowired
	private OrderService orderService;
	@Autowired
	RefundService refundService;

	@Autowired
	OrderScanController orderScanController;

	@Autowired
	private LdapService ldapService;

	@Autowired
	@Qualifier("dynamicDataSource")
	public DynamicDataSource dynamicDataSource;

	@Value("${ddr.request.param}")
	private String ddrParam;

	@Value("${ddr.request.url}")
	private String ddrUrl;

	@Autowired
	private RestTemplate restTemplate;

	private void initDatasourceRouter() {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<>(ddrParam, headers);
		String result = restTemplate.postForObject(ddrUrl, entity, String.class);
		List<DagHost> dss = JSONObject.parseObject(result, HostData.class).getData();
		Map<Object, Object> dataSources = new HashMap<>(16);
		for (int i = 0; i < dss.size(); i++) {
			DagHost dh = dss.get(i);
			String key = dh.getDagId();
			dataSources.put(key, dh.getDataSource());
		}
		dynamicDataSource.setTargetDataSources(dataSources);
		dynamicDataSource.afterPropertiesSet();

	}

	// @PostConstruct
	private void init() {
		initDatasourceRouter();
	}

	// @Before
	public void before() {
		mockMVC = MockMvcBuilders.webAppContextSetup(wac).build();
		MockitoAnnotations.initMocks(this);
	}

	// @Test
	public void scanOrderListTest() throws Exception {
		ThreadLocalContextHolder.put("dagId", "002");

		saveUser();

		UserLdap userLdapBo = new UserLdap();
		userLdapBo.setUserId("test");
		userLdapBo.setToken("testtesttest");

		String restUrl1 = "/orderScan/scanOrderList";

		Cookie[] cookies = new Cookie[1];
		Cookie cookie2 = new Cookie("token", "testtesttest");
		cookies[0] = cookie2;

		OrderScanListParameter scanOrder = new OrderScanListParameter();
		scanOrder.setUserId("test");
		List<String> orderIds = new ArrayList<>();
		orderIds.add("110591700200000132992");
		scanOrder.setOrderIds(orderIds);

		String orderListJson = "[{\"amount\":29.00,\"cancelReason\":0,\"completedTime\":1515654219823,\"createdTime\":1501139693797,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"11059170020000013299\",\"packagingFee\":0,\"paidTime\":1501141304673,\"payType\":4,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":30,\"storeId\":1059,\"timeout\":false,\"totalGpDiscount\":0.00,\"userId\":\"8D957586BD0E47B8A77FB0E025D253E5\",\"version\":1940,\"voucherDiscount\":0.00}]";
		List<Order> orderList = JSON.parseArray(orderListJson, Order.class);
		String orderBoJson = "[{\"amount\":29.00,\"cancelReason\":0,\"completedTime\":1515654219823,\"createdTime\":1501139693797,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"11059170020000013299\",\"orderLineBoList\":[{\"cartItemId\":1,\"department\":96,\"descOnline\":\"I南非BD品乐塔基红葡萄酒.\",\"gpDiscount\":0.00,\"itemAmount\":0.00,\"itemNumber\":21342855,\"itemType\":0,\"magneticFlag\":0,\"orderDiscountList\":[{\"cartItemId\":1,\"gpDiscount\":0.00,\"gpDiscountTimes\":0,\"gpGroupSeq\":1,\"gpOfferId\":1064131,\"gpTypeCode\":1,\"orderId\":\"11059170020000013299\",\"productId\":3459145122792,\"promotionDescCn\":\"6件及以上享9折\",\"storeId\":1059}],\"orderId\":\"11059170020000013299\",\"orderQuantity\":1,\"orderWeight\":0.00000,\"posDescOnline\":\"进口红酒.\",\"priceWithTax\":29.00,\"priceWithoutTax\":24.79,\"productId\":3459145122792,\"reportCode\":0,\"returnBy\":1502349293797,\"storeId\":1059,\"taxRate\":0.1700,\"thumbnailUrl\":\"bCdRnDfLNIkZsHIOIWX2OA.JPG\",\"unitCost\":25.6500,\"upc\":600980216821,\"wasPrice\":0.00}],\"packagingFee\":0,\"paidTime\":1501141304673,\"payType\":4,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":30,\"storeId\":1059,\"timeout\":false,\"totalGpDiscount\":0.00,\"userId\":\"8D957586BD0E47B8A77FB0E025D253E5\",\"version\":1940,\"voucherDiscount\":0.00}]";
		List<OrderBo> orderBoList = JSON.parseArray(orderBoJson, OrderBo.class);
		String checkCreditJson = "{\"checkFlag\":1,\"userName\":\"\"}";
		CheckCreditVo checkCredit = JSON.parseObject(checkCreditJson, CheckCreditVo.class);
		IMocksControl mocksControl = EasyMock.createStrictControl();
		OrderService orderServiceMock = mocksControl.createMock(OrderService.class);
		UserCreditInfoClient userCreditInfoClientMock = mocksControl.createMock(UserCreditInfoClient.class);

		EasyMock.expect(orderServiceMock.selectOrderListByUserIdAndOrderIds(EasyMock.anyString(), EasyMock.anyObject(List.class))).andReturn(orderList);
		EasyMock.expect(orderServiceMock.getOrderBoList(EasyMock.anyObject(List.class))).andReturn(orderBoList);
		EasyMock.expect(userCreditInfoClientMock.checkTencentCredit(EasyMock.anyString())).andReturn(checkCredit);
		mocksControl.replay();
		// 结合spring 将mock的对象注入到controller里
		ReflectionTestUtils.setField(orderScanController, "orderService", orderServiceMock);
		ReflectionTestUtils.setField(orderScanController, "userCreditInfoClient", userCreditInfoClientMock);

		// 。。。设置值
		String requestJson = JSONObject.toJSONString(scanOrder);
		String responseString = mockMVC.perform(MockMvcRequestBuilders.post(restUrl1).contentType(MediaType.APPLICATION_JSON).cookie(cookies).content(requestJson))// .andDo(print())
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();

		ResultBody resultBody = JSONObject.parseObject(responseString, ResultBody.class);
		Assert.assertTrue("", resultBody.getCode().equals("0"));

	}

	// @Test
	public void orderScanForPadTest() throws Exception {
		ThreadLocalContextHolder.put("dagId", "002");

		saveUser();

		UserLdap userLdapBo = new UserLdap();
		userLdapBo.setUserId("test");
		userLdapBo.setToken("testtesttest");

		LdapLoginReturnMsg ldapLoginReturnMsg = ldapService.authByAd(userLdapBo);

		String restUrl2 = "/orderScan/scanOrderForPad";

		Cookie[] cookies = new Cookie[1];
		Cookie cookie2 = new Cookie("token", ldapLoginReturnMsg.getToken());
		cookies[0] = cookie2;

		OrderScanParameter orderScanParameter = new OrderScanParameter();
		orderScanParameter.setOrderId("11059170020000013299");

		String orderJson = "{\"amount\":29.00,\"cancelReason\":0,\"completedTime\":1515654219823,\"createdTime\":1501139693797,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"11059170020000013299\",\"packagingFee\":0,\"paidTime\":1501141304673,\"payType\":4,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":30,\"storeId\":1059,\"timeout\":false,\"totalGpDiscount\":0.00,\"userId\":\"8D957586BD0E47B8A77FB0E025D253E5\",\"version\":1940,\"voucherDiscount\":0.00}";
		Order order = JSON.parseObject(orderJson, Order.class);
		String orderBoJson = "";
		OrderBo orderBo = JSON.parseObject(orderBoJson, OrderBo.class);
		String orderBoListJson = "[{\"amount\":29.00,\"cancelReason\":0,\"completedTime\":1515654219823,\"createdTime\":1501139693797,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"11059170020000013299\",\"orderLineBoList\":[{\"cartItemId\":1,\"department\":96,\"descOnline\":\"I南非BD品乐塔基红葡萄酒.\",\"gpDiscount\":0.00,\"itemAmount\":0.00,\"itemNumber\":21342855,\"itemType\":0,\"magneticFlag\":0,\"orderDiscountList\":[{\"cartItemId\":1,\"gpDiscount\":0.00,\"gpDiscountTimes\":0,\"gpGroupSeq\":1,\"gpOfferId\":1064131,\"gpTypeCode\":1,\"orderId\":\"11059170020000013299\",\"productId\":3459145122792,\"promotionDescCn\":\"6件及以上享9折\",\"storeId\":1059}],\"orderId\":\"11059170020000013299\",\"orderQuantity\":1,\"orderWeight\":0.00000,\"posDescOnline\":\"进口红酒.\",\"priceWithTax\":29.00,\"priceWithoutTax\":24.79,\"productId\":3459145122792,\"reportCode\":0,\"returnBy\":1502349293797,\"storeId\":1059,\"taxRate\":0.1700,\"thumbnailUrl\":\"bCdRnDfLNIkZsHIOIWX2OA.JPG\",\"unitCost\":25.6500,\"upc\":600980216821,\"wasPrice\":0.00}],\"packagingFee\":0,\"paidTime\":1501141304673,\"payType\":4,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":30,\"storeId\":1059,\"timeout\":false,\"totalGpDiscount\":0.00,\"userId\":\"8D957586BD0E47B8A77FB0E025D253E5\",\"version\":1940,\"voucherDiscount\":0.00}]";
		List<OrderBo> orderBoList = JSON.parseArray(orderBoListJson, OrderBo.class);
		String checkCreditJson = "{\"checkFlag\":1,\"userName\":\"\"}";
		CheckCreditVo checkCredit = JSON.parseObject(checkCreditJson, CheckCreditVo.class);

		IMocksControl mocksControl = EasyMock.createStrictControl();
		OrderService orderServiceMock = mocksControl.createMock(OrderService.class);
		UserCreditInfoClient userCreditInfoClientMock = mocksControl.createMock(UserCreditInfoClient.class);

		EasyMock.expect(orderServiceMock.getOrderByOrderId(EasyMock.anyString())).andReturn(order);
		EasyMock.expect(orderServiceMock.selectOrderListbyUserIdAndstatusAndStoreId(EasyMock.anyString(), EasyMock.anyInt(), EasyMock.anyInt())).andReturn(orderBoList);
		// EasyMock.expect(orderServiceMock.requestOrderDetailByOrder(EasyMock.anyObject())).andReturn(orderBo);
		EasyMock.expect(userCreditInfoClientMock.checkTencentCredit(EasyMock.anyString())).andReturn(checkCredit);
		mocksControl.replay();
		// 结合spring 将mock的对象注入到controller里
		ReflectionTestUtils.setField(orderScanController, "orderService", orderServiceMock);
		ReflectionTestUtils.setField(orderScanController, "userCreditInfoClient", userCreditInfoClientMock);

		// 。。。设置值
		String requestJson = JSONObject.toJSONString(orderScanParameter);
		String responseString = mockMVC.perform(MockMvcRequestBuilders.post(restUrl2).contentType(MediaType.APPLICATION_JSON).cookie(cookies).content(requestJson))// .andDo(print())
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();

		ResultBody resultBody = JSONObject.parseObject(responseString, ResultBody.class);
		Assert.assertTrue("", resultBody.getCode().equals("0"));

	}

	// @Test
	public void orderScanForPadConfirmTest() throws Exception {
		ThreadLocalContextHolder.put("dagId", "002");
		saveUser();
		UserLdap userLdapBo = new UserLdap();
		userLdapBo.setUserId("test");
		userLdapBo.setToken("testtesttest");

		String restUrl3 = "/orderScan/scanOrderForPadConfirm";

		Cookie[] cookies = new Cookie[1];
		Cookie cookie2 = new Cookie("token", "testtesttest");
		cookies[0] = cookie2;

		OrderScanConfirmParameter orderScanConfirmParameter = new OrderScanConfirmParameter();
		orderScanConfirmParameter.setUserId("8D957586BD0E47B8A77FB0E025D253E5");
		orderScanConfirmParameter.setStoreId("1059");
		orderScanConfirmParameter.setOrderId("11059170020000013299");

		String orderJson = "{\"amount\":29.00,\"cancelReason\":0,\"completedTime\":1515656781980,\"createdTime\":1501139693797,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"11059170020000013299\",\"packagingFee\":0,\"paidTime\":1501141304673,\"payType\":4,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":30,\"storeId\":1059,\"timeout\":false,\"totalGpDiscount\":0.00,\"userId\":\"8D957586BD0E47B8A77FB0E025D253E5\",\"version\":1944,\"voucherDiscount\":0.00}";
		Order order = JSON.parseObject(orderJson, Order.class);
		String orderBoJson = "{\"amount\":29.00,\"cancelReason\":0,\"completedTime\":1515657672280,\"createdTime\":1501139693797,\"deliveryMethod\":0,\"deliveryPeriod\":0,\"invoiceTitle\":\"\",\"invoiceType\":0,\"orderId\":\"11059170020000013299\",\"orderLineBoList\":[{\"cartItemId\":1,\"department\":96,\"descOnline\":\"I南非BD品乐塔基红葡萄酒.\",\"gpDiscount\":0.00,\"itemAmount\":0.00,\"itemNumber\":21342855,\"itemType\":0,\"magneticFlag\":0,\"orderDiscountList\":[{\"cartItemId\":1,\"gpDiscount\":0.00,\"gpDiscountTimes\":0,\"gpGroupSeq\":1,\"gpOfferId\":1064131,\"gpTypeCode\":1,\"orderId\":\"11059170020000013299\",\"productId\":3459145122792,\"promotionDescCn\":\"6件及以上享9折\",\"storeId\":1059}],\"orderId\":\"11059170020000013299\",\"orderQuantity\":1,\"orderWeight\":0.00000,\"posDescOnline\":\"进口红酒.\",\"priceWithTax\":29.00,\"priceWithoutTax\":24.79,\"productId\":3459145122792,\"reportCode\":0,\"returnBy\":1502349293797,\"storeId\":1059,\"taxRate\":0.1700,\"thumbnailUrl\":\"bCdRnDfLNIkZsHIOIWX2OA.JPG\",\"unitCost\":25.6500,\"upc\":600980216821,\"wasPrice\":0.00}],\"packagingFee\":0,\"paidTime\":1501141304673,\"payType\":4,\"shippingFee\":0,\"shortNameCn\":\"香蜜湖店\",\"status\":80,\"storeId\":1059,\"timeout\":false,\"totalGpDiscount\":0.00,\"userId\":\"8D957586BD0E47B8A77FB0E025D253E5\",\"version\":1948,\"voucherDiscount\":0.00}";
		OrderBo orderBo = JSON.parseObject(orderBoJson, OrderBo.class);
		String checkCreditJson = "{\"checkFlag\":1,\"userName\":\"\"}";
		CheckCreditVo checkCredit = JSON.parseObject(checkCreditJson, CheckCreditVo.class);

		IMocksControl mocksControl = EasyMock.createStrictControl();
		OrderService orderServiceMock = mocksControl.createMock(OrderService.class);
		UserCreditInfoClient userCreditInfoClientMock = mocksControl.createMock(UserCreditInfoClient.class);
		RefundService refundServiceMock = mocksControl.createMock(RefundService.class);

		EasyMock.expect(orderServiceMock.selectOrderByUserIdAndOrderIdAndStoreId(EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyInt())).andReturn(order);
		EasyMock.expect(orderServiceMock.updateStatusByOrder(EasyMock.anyObject())).andReturn(1);
		EasyMock.expect(orderServiceMock.requestOrderDetailByUserIdAndOrderIdForPassMachine(EasyMock.anyString(), EasyMock.anyString())).andReturn(orderBo);
		// EasyMock.expect(refundServiceMock.getOrderRefundList(EasyMock.anyString())).andReturn(refundList);
		EasyMock.expect(userCreditInfoClientMock.checkTencentCredit(EasyMock.anyString())).andReturn(checkCredit);
		mocksControl.replay();
		// 结合spring 将mock的对象注入到controller里
		ReflectionTestUtils.setField(orderScanController, "orderService", orderServiceMock);
		ReflectionTestUtils.setField(orderScanController, "refundService", refundServiceMock);
		ReflectionTestUtils.setField(orderScanController, "userCreditInfoClient", userCreditInfoClientMock);

		// 。。。设置值
		String requestJson = JSONObject.toJSONString(orderScanConfirmParameter);
		String responseString = mockMVC.perform(MockMvcRequestBuilders.post(restUrl3).contentType(MediaType.APPLICATION_JSON).cookie(cookies).content(requestJson))// .andDo(print())
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();

		ResultBody resultBody = JSONObject.parseObject(responseString, ResultBody.class);
		Assert.assertTrue("", resultBody.getCode().equals("0"));

	}

	private void saveUser() {
		UserLdap userLdap = ldapService.selectUserLdapByUserId("test");
		if (userLdap == null) {
			ldapService.saveUserLdap("test", "testtesttest", new Date(), 1059);
		} else {
			userLdap.setTokenUpdatedTime(new Date());
			ldapService.saveUserLdap(userLdap);
		}
	}
}
