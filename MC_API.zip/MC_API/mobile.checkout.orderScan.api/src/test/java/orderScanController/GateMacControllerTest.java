package orderScanController;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Assert;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.entity.GateMac;
import com.walmart.mobile.checkout.exception.handler.ResultBody;

/*@RunWith(SpringJUnit4ClassRunner.class)
 @WebAppConfiguration
 @ContextConfiguration(classes = { MainConfig.class })*/
public class GateMacControllerTest {
	protected MockHttpServletResponse response;

	protected MockMvc mockMVC;

	@Autowired
	private WebApplicationContext wac;

	// @Before
	public void before() {
		mockMVC = MockMvcBuilders.webAppContextSetup(wac).build();
		MockitoAnnotations.initMocks(this);
	}

	// @Test
	public void queryOrderListTest() throws Exception {
		String restUrl = "/gateMac/macInformation";


		GateMac gateMac = new GateMac();
		gateMac.setStoreId(1059);
		// 。。。设置值
		String requestJson = JSONObject.toJSONString(gateMac);
		String responseString = mockMVC.perform(MockMvcRequestBuilders.post(restUrl).contentType(MediaType.APPLICATION_JSON).content(requestJson))// .andDo(print())
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();

		ResultBody resultBody = JSONObject.parseObject(responseString, ResultBody.class);
		Assert.assertTrue("", resultBody.getCode().equals("0"));

	}
	
	// @Test
	public void queryOrderListTest2() throws Exception {
		String restUrl = "/gateMac/macInformation";


		GateMac gateMac = new GateMac();
		gateMac.setStoreId(10590);
		// 。。。设置值
		String requestJson = JSONObject.toJSONString(gateMac);
		String responseString = mockMVC.perform(MockMvcRequestBuilders.post(restUrl).contentType(MediaType.APPLICATION_JSON).content(requestJson))// .andDo(print())
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();

		ResultBody resultBody = JSONObject.parseObject(responseString, ResultBody.class);
		Assert.assertTrue("", resultBody.getCode().equals("-220"));

	}
	


	

	

}
