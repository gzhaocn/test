package com.walmart.mobile.checkout.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.walmart.mobile.checkout.annotation.LdapPrivilegeInfo;
import com.walmart.mobile.checkout.bo.order.QueryMacParamter;
import com.walmart.mobile.checkout.constant.order.OrderErrorInfoEnum;
import com.walmart.mobile.checkout.entity.GateMac;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.exception.handler.ResultBody;
import com.walmart.mobile.checkout.service.GateMacService;
import com.walmart.mobile.checkout.service.OrderValidationService;

@Controller
@RequestMapping("/gateMac")
public class GateMacController {

	@Autowired
	private GateMacService gateMacService;

	@Autowired
	private OrderValidationService orderValidationService;

	/**
	 * 下发闸机信息
	 * 
	 * @param id
	 * @param request
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	@LdapPrivilegeInfo
	@ApiOperation(value = "macInformation", notes = "下发门店monitor信息")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -220, message = "mac地址门店没配置") })
	@RequestMapping(value = "/macInformation", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody macInformation(HttpServletRequest request, @RequestBody GateMac gateMac) throws GlobalErrorInfoException {
		List<GateMac> gateMacList = gateMacService.findByStoreId(gateMac.getStoreId());
		if (gateMacList == null || gateMacList.isEmpty()) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.GATEMAC_NOT_CONFIGURED);
		}
		return new ResultBody(gateMacList);
	}

	@LdapPrivilegeInfo
	@ApiOperation(value = "saveMac", notes = "保存或修改monitor信息")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -280, message = "参数不能为空"), @ApiResponse(code = -285, message = "门店对应的通道已存在"),
			@ApiResponse(code = -286, message = "mac地址已存在") })
	@RequestMapping(value = "/saveMac", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody saveMac(HttpServletRequest request, @RequestBody GateMac gateMac) throws GlobalErrorInfoException {
		if (StringUtils.isEmpty(gateMac.getMac()) || StringUtils.isEmpty(gateMac.getSequenceNumber()) || gateMac.getStoreId() == null) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.PARAMTER_CONTIANIS_NULL);
		}
		GateMac gateMac2;
		gateMac2 = gateMacService.findBySequenceNumberAndStoreId(gateMac.getSequenceNumber(), gateMac.getStoreId());
		if (gateMac2 != null) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.STORE_AND_SEQ_IS_CONFIG);
		}
		gateMac2 = gateMacService.findByMac(gateMac.getMac());
		if (gateMac2 != null) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.MAC_IS_CONFIG);
		}

		gateMac.setCreateTime(new Date());
		gateMacService.saveGateMac(gateMac);
		return new ResultBody();
	}

	@LdapPrivilegeInfo
	@ApiOperation(value = "updateMac", notes = "修改monitor信息")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -280, message = "参数不能为空"), @ApiResponse(code = -285, message = "门店对应的通道已存在"),
			@ApiResponse(code = -286, message = "mac地址已存在") })
	@RequestMapping(value = "/updateMac", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody updateMac(HttpServletRequest request, @RequestBody GateMac gateMac) throws GlobalErrorInfoException {
		if (StringUtils.isEmpty(gateMac.getGateMacId()) || StringUtils.isEmpty(gateMac.getMac()) || StringUtils.isEmpty(gateMac.getSequenceNumber()) || gateMac.getStoreId() == null) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.PARAMTER_CONTIANIS_NULL);
		}
		GateMac gateMac2;
		gateMac2 = gateMacService.findBySequenceNumberAndStoreId(gateMac.getSequenceNumber(), gateMac.getStoreId());
		if (gateMac2 != null && !StringUtils.equals(gateMac2.getGateMacId(), gateMac.getGateMacId())) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.STORE_AND_SEQ_IS_CONFIG);
		}
		gateMac2 = gateMacService.findByMac(gateMac.getMac());
		if (gateMac2 != null && !StringUtils.equals(gateMac2.getGateMacId(), gateMac.getGateMacId())) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.MAC_IS_CONFIG);
		}
		gateMac.setUpdateTime(new Date());
		gateMacService.saveGateMac(gateMac);
		return new ResultBody();
	}

	@LdapPrivilegeInfo
	@ApiOperation(value = "deleteMac", notes = "删除monitor信息")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -280, message = "参数不能为空") })
	@RequestMapping(value = "/deleteMac", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody deleteMac(HttpServletRequest request, @RequestBody GateMac gateMac) throws GlobalErrorInfoException {
		if (StringUtils.isEmpty(gateMac.getGateMacId())) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.PARAMTER_CONTIANIS_NULL);
		}
		GateMac gateMac2 = gateMacService.findOne(gateMac.getId());
		gateMacService.deleteGateMac(gateMac2);
		return new ResultBody();
	}

	@ApiOperation(value = "queryMacInformationByMac", notes = "通过mac地址查询")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -280, message = "参数不能为空"), @ApiResponse(code = -220, message = "mac地址门店没配置"),
			@ApiResponse(code = -225, message = "checkSum加密失败"), @ApiResponse(code = -215, message = "checkSum对比不通过") })
	@RequestMapping(value = "/queryMacInformationByMac", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody queryMacInformationByMac(HttpServletRequest request, @RequestBody QueryMacParamter queryMacParamter) throws GlobalErrorInfoException {
		if (StringUtils.isEmpty(queryMacParamter.getMac())) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.PARAMTER_CONTIANIS_NULL);
		}
		orderValidationService.macCheckSum(queryMacParamter.getAppKey(), queryMacParamter.getVersion(), queryMacParamter.getFormat(), queryMacParamter.getTimeStamp(), queryMacParamter.getSign(),
				queryMacParamter.getMac());
		GateMac gateMac = gateMacService.findByMac(queryMacParamter.getMac());
		if (gateMac == null) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.GATEMAC_NOT_CONFIGURED);
		}

		return new ResultBody(gateMac);
	}
}
