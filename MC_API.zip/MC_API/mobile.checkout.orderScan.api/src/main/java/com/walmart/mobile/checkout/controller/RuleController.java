package com.walmart.mobile.checkout.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.walmart.mobile.checkout.component.ReloadDroolsRules;
import com.walmart.mobile.checkout.constant.order.OrderErrorInfoEnum;
import com.walmart.mobile.checkout.entity.ExitRule;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.exception.handler.ResultBody;
import com.walmart.mobile.checkout.repo.ExitRuleRepository;

/**
 * @author lliao2
 */
@RequestMapping("/rule")
@Controller
public class RuleController {
	private static final Logger LOG = LoggerFactory.getLogger(RuleController.class);

	@Autowired
	private ReloadDroolsRules reloadDroolsRules;
	@Autowired
	ExitRuleRepository exitRuleRepository;

	private static final String MOBILECK = "mobileCK";

	@ResponseBody
	@RequestMapping(value = "/reload/{checkSum}", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public ResultBody reload(@PathVariable("checkSum") String checkSum) throws GlobalErrorInfoException {
		if (!MOBILECK.equals(checkSum)) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.PARAMTER_NOT_EQUALS);
		}
		reloadDroolsRules.reload();
		return new ResultBody("ok");
	}

	@ResponseBody
	@RequestMapping(value = "/saveRule/{checkSum}", method = RequestMethod.POST)
	public ResultBody saveRule(@PathVariable("checkSum") String checkSum) throws GlobalErrorInfoException {
		if (!MOBILECK.equals(checkSum)) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.PARAMTER_NOT_EQUALS);
		}
		ExitRule exitRule = exitRuleRepository.findByRuleType("mcExitRule");
		if (exitRule == null) {
			exitRule = new ExitRule();
			exitRule.setRuleType("mcExitRule");
			exitRule.setRuleValue(readFile());
			exitRule.setCreateTime(new Date());
			exitRuleRepository.save(exitRule);
		} else {
			exitRule.setRuleValue(readFile());
			exitRule.setUpdateTime(new Date());
			exitRuleRepository.save(exitRule);
		}

		return new ResultBody("ok");
	}

	public String readFile() {
		String json = "";
		byte[] buffer = new byte[10240];
		InputStream stream = null;
		try {
			stream = this.getClass().getResourceAsStream("/rules/exitRule.drl");
			final int actual = IOUtils.read(stream, buffer);
			json = new String(buffer, 0, actual);

		} catch (IOException e) {
			LOG.info("read rule file error", e);
			json = "drl rule file not exit";
		} finally {
			IOUtils.closeQuietly(stream);
		}
		return json;
	}
}
