package com.walmart.mobile.checkout.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.annotation.LdapPrivilegeInfo;
import com.walmart.mobile.checkout.annotation.PrivilegeInfo;
import com.walmart.mobile.checkout.bo.order.CheckPersonAndTransation;
import com.walmart.mobile.checkout.bo.order.MonitorExitParameter;
import com.walmart.mobile.checkout.bo.order.MonitorOrderAmount;
import com.walmart.mobile.checkout.bo.order.MonitorRedisInformation;
import com.walmart.mobile.checkout.bo.order.MonitorRefreshParameter;
import com.walmart.mobile.checkout.bo.order.OrderBo;
import com.walmart.mobile.checkout.bo.order.OrderExit;
import com.walmart.mobile.checkout.bo.order.OrderExitActionParameter;
import com.walmart.mobile.checkout.bo.order.OrderExitParameter;
import com.walmart.mobile.checkout.bo.order.OrderRefundBo;
import com.walmart.mobile.checkout.bo.order.OrderRefundParameter;
import com.walmart.mobile.checkout.bo.order.OrderScanAllConfirmParameter;
import com.walmart.mobile.checkout.bo.order.OrderScanConRejectParameter;
import com.walmart.mobile.checkout.bo.order.OrderScanConfirmParameter;
import com.walmart.mobile.checkout.bo.order.OrderScanListParameter;
import com.walmart.mobile.checkout.bo.order.OrderScanParameter;
import com.walmart.mobile.checkout.bo.order.QueryOrderListParamter;
import com.walmart.mobile.checkout.bo.order.ScanRefundBo;
import com.walmart.mobile.checkout.bo.order.TransactionRuleParamter;
import com.walmart.mobile.checkout.bo.refund.ReturnApproveParamter;
import com.walmart.mobile.checkout.component.ReloadDroolsRules;
import com.walmart.mobile.checkout.constant.AppConstants;
import com.walmart.mobile.checkout.constant.order.InvoiceCons;
import com.walmart.mobile.checkout.constant.order.MessageTypeCons;
import com.walmart.mobile.checkout.constant.order.OrderCons;
import com.walmart.mobile.checkout.constant.order.OrderErrorInfoEnum;
import com.walmart.mobile.checkout.constant.order.OrderStatus;
import com.walmart.mobile.checkout.constant.refund.PayType;
import com.walmart.mobile.checkout.constant.refund.RefundStatus;
import com.walmart.mobile.checkout.domain.StoreVo;
import com.walmart.mobile.checkout.domain.check.CheckHistory;
import com.walmart.mobile.checkout.domain.order.Order;
import com.walmart.mobile.checkout.domain.order.OrderEws;
import com.walmart.mobile.checkout.domain.order.OrderLine;
import com.walmart.mobile.checkout.domain.payment.EGiftcardNewNotification;
import com.walmart.mobile.checkout.domain.payment.WechatNotification;
import com.walmart.mobile.checkout.domain.refund.Refund;
import com.walmart.mobile.checkout.domain.route.Route;
import com.walmart.mobile.checkout.entity.GateMac;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.exception.handler.ResultBody;
import com.walmart.mobile.checkout.handler.send.CreaditW4SendHandler;
import com.walmart.mobile.checkout.handler.send.EgiftcardNewRefundSendHandler;
import com.walmart.mobile.checkout.handler.send.InvoiceSendHandler;
import com.walmart.mobile.checkout.handler.send.WechatH5RefundSendHandler;
import com.walmart.mobile.checkout.handler.send.WechatRefundSendHandler;
import com.walmart.mobile.checkout.redis.RedisOperationRepo;
import com.walmart.mobile.checkout.redis.vo.RedisBean;
import com.walmart.mobile.checkout.refund.protocol.RefundReqData;
import com.walmart.mobile.checkout.rest.StoreServiceClient;
import com.walmart.mobile.checkout.rest.order.DeliveryServiceClient;
import com.walmart.mobile.checkout.rest.order.UserCreditInfoClient;
import com.walmart.mobile.checkout.rest.vo.CheckCreditVo;
import com.walmart.mobile.checkout.service.GateMacService;
import com.walmart.mobile.checkout.service.IdService;
import com.walmart.mobile.checkout.service.OrderService;
import com.walmart.mobile.checkout.service.OrderValidationService;
import com.walmart.mobile.checkout.service.RouteService;
import com.walmart.mobile.checkout.service.invoice.InvoiceService;
import com.walmart.mobile.checkout.service.payment.EGiftCardNewService;
import com.walmart.mobile.checkout.service.payment.WechatNotificationService;
import com.walmart.mobile.checkout.service.refund.RefundService;
import com.walmart.mobile.checkout.service.refund.ReverseRecordSaleService;
import com.walmart.mobile.checkout.utils.DateUtil;
import com.walmart.mobile.checkout.utils.ThreadLocalContextHolder;
import com.walmart.mobile.checkout.utils.order.OrderUtils;

@Controller
@RequestMapping("/orderScan")
public class OrderScanController {
	@Autowired
	private OrderValidationService orderValidationService;
	@Autowired
	private OrderService orderService;
	@Autowired
	private IdService orderSerialNumberService;
	@Autowired
	RefundService refundService;
	@Autowired
	UserCreditInfoClient userCreditInfoClient;

	@Autowired
	RouteService routeService;

	@Autowired
	WechatRefundSendHandler wechatRefundSendHandler;

	@Autowired
	EgiftcardNewRefundSendHandler egiftcardNewRefundSendHandler;

	@Autowired
	EGiftCardNewService eGiftCardNewService;

	@Autowired
	WechatH5RefundSendHandler wechatH5RefundSendHandler;
	@Autowired
	WechatNotificationService wechatNotificationService;
	@Autowired
	ReverseRecordSaleService reverseRecordSaleService;

	@Autowired
	private InvoiceService invoiceService;
	@Autowired
	private InvoiceSendHandler invoiceSendHandler;
	@Autowired
	private DeliveryServiceClient deliveryServiceClient;

	@Value("${payment.amount.test}")
	private String paymentAmount;
	@Value("${recordsale.resource.type}")
	private String resourceType;

	@Autowired
	GateMacService gateMacService;

	@Autowired
	private RedisOperationRepo<MonitorRedisInformation> redisOperationRepo;

	@Autowired
	StoreServiceClient storeServiceClient;

	@Autowired
	private ReloadDroolsRules reloadDroolsRules;

	@Autowired
	CreaditW4SendHandler creaditW4SendHandler;

	private static final Logger LOG = LoggerFactory.getLogger(OrderScanController.class);

	private static final String ADMIN = "admin";

	/**
	 * 扫描二维码接口（此接口存在客户端调用2种情况，传订单号按订单号查询，不传订单号按userId查询）
	 * 
	 * @param id
	 * @param request
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	@PrivilegeInfo
	@ApiOperation(value = "orderExit", notes = "出场扫描二维码")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -214, message = "找不到该订单信息"), @ApiResponse(code = -226, message = "订单已扫描或者已完成"),
			@ApiResponse(code = -221, message = "查询不到已支付订单信息") })
	@RequestMapping(value = "/orderExit", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody orderExit(HttpServletRequest request, @RequestBody OrderExitParameter orderExitParameter) throws GlobalErrorInfoException {
		String userId;
		if (orderExitParameter.getOrderId() != null) {
			// 根据orderId查询userId
			Order order = orderService.getOrderByOrderId(orderExitParameter.getOrderId());
			orderValidationService.checkOrder(order);
			userId = order.getUserId();
		} else {
			userId = ThreadLocalContextHolder.get(AppConstants.USERID, String.class);
		}
		String dagId = ThreadLocalContextHolder.get(AppConstants.DAGID, String.class);
		String batchNo = UUID.randomUUID().toString().replaceAll("-", "");
		Date createTime = new Date();

		List<Order> orderList = orderService.queryOrderListbyUserIdAndstatusAndStoreId(userId, OrderStatus.PAID, orderExitParameter.getStoreId());
		List<CheckHistory> checkHistoryList = new ArrayList<>();
		List<OrderBo> orderBoList;

		Integer messageType = MessageTypeCons.ORDERLIST_EXIST_PUSH;
		CheckCreditVo checkCredit = userCreditInfoClient.checkTencentCredit(userId);
		Integer itemAllQuantity = 0;
		BigDecimal itemAllAmount = BigDecimal.ZERO;
		Integer shoppingBagQuantity = 0;
		BigDecimal shoppingBagAmount = BigDecimal.ZERO;
		TransactionRuleParamter transactionRuleParamter = new TransactionRuleParamter();
		Map<String, Long> minuteMap = new HashMap<>(10);

		if (CollectionUtils.isNotEmpty(orderList)) {
			Order orderScanTime = orderList.stream().filter(x -> x.getScanTime() == null).findAny().orElse(null);
			if (orderScanTime == null) {
				throw new GlobalErrorInfoException(OrderErrorInfoEnum.SCAN_ORDER_HAS_COMPLETED);
			}
			orderBoList = orderService.getOrderBoList(orderList);
			orderService.buildTransactionRuleParamter(batchNo, createTime, orderExitParameter.getStoreId(), checkHistoryList, orderBoList, itemAllQuantity, itemAllAmount, shoppingBagQuantity,
					shoppingBagAmount, transactionRuleParamter, minuteMap);
			/**
			 * orderService.updateOrderAndBuildOrderDelivery(orderList,
			 * checkCredit, orderExitParameter.getSequenceNumber());
			 * sendInvoiceList(orderList, checkCredit);
			 */
		} else {
			// orderlist为空，不需要消磁，订单必检
			messageType = MessageTypeCons.ORDERLIST_NOT_EXIST_PUSH;
			checkCredit.setMagneticFlag(0);
			checkCredit.setCheckFlag(1);
			// 前端用来判断 提示语
			checkCredit.setNullOrderFlag(1);
		}
		CheckPersonAndTransation checkPersonAndTransation = orderService.buildCheckPersonAndTransaction(batchNo, createTime, userId, orderList, checkHistoryList, checkCredit,
				transactionRuleParamter.getItemAllAmount(), transactionRuleParamter.getShoppingBagQuantity(), transactionRuleParamter.getAverageAmount(),
				transactionRuleParamter.getOtherItemQuantity(), minuteMap);

		orderService.ruleCheckPersonAndTransation(checkPersonAndTransation);

		Integer storeId = orderExitParameter.getStoreId();
		String sequenceNumber = orderExitParameter.getSequenceNumber();

		String screenFlag = orderService.saveCheckHistoryAndUpdateOrder(storeId, dagId, orderList, checkHistoryList, checkCredit, sequenceNumber);
		sendInvoiceList(orderList, checkCredit);

		String mobilePhone = ThreadLocalContextHolder.get(AppConstants.MOBILE_PHONE, String.class);
		/**
		 * orderService.batchSendPushMsg(orderExitParameter.getStoreId(),
		 * orderExitParameter.getSequenceNumber(), orderList, messageType,
		 * checkCredit, StringUtils.EMPTY, mobilePhone, StringUtils.EMPTY);
		 */
		// 推送消息
		orderService.batchSendPushMsg(orderExitParameter.getStoreId(), orderExitParameter.getSequenceNumber(), orderList, messageType, checkCredit, StringUtils.EMPTY, mobilePhone, screenFlag);

		return new ResultBody(checkCredit);
	}

	private void sendInvoiceList(List<Order> orderList, CheckCreditVo checkCredit) {
		for (Order order : orderList) {
			/**
			 * 免检的才会修改订单状态到完成，然后可以发送生成发票
			 */
			if (checkCredit.getCheckFlag() == 0) {
				sendInvoiceSingle(order);
			}
		}
	}

	private void sendInvoiceSingle(Order order) {
		OrderBo orderbo = orderService.requestOrderDetailByUserIdAndOrderIdForPassMachine(order.getUserId(), order.getOrderId());
		// 0 不需要1纸质发票 3电子个人发票 4电子单位发票
		if ((InvoiceCons.ELECTRONIC_PERSONAL_INVOICE == order.getInvoiceType() || InvoiceCons.ELECTRONIC_UNIT_INVOICE == order.getInvoiceType()) && order.getPayType() != InvoiceCons.EGIFTCARD) {
			if (InvoiceCons.INVOICE_OPENED.equals(order.getInvoiceNo())) {
				LOG.info("invoice has been opened or tcNumber is null , orderId : {}", order.getOrderId());
			} else {
				List<Refund> refundList = refundService.getOrderRefundList(order.getOrderId());
				String invoiceMessage = invoiceService.sendInvoiceInfo(orderbo, InvoiceCons.NEED_REPLACE_APPLYKEY,
						StringUtils.isBlank(order.getTcNumber()) ? InvoiceCons.TC_NUMBER_NULL : order.getTcNumber(), refundList);
				invoiceSendHandler.invoiceSendMessage(invoiceMessage);
				LOG.info("send invoice mq message : {}", invoiceMessage);
			}
		}
	}

	/**
	 * 通过消息获取订单明细信息
	 * 
	 * @param id
	 * @param request
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	@LdapPrivilegeInfo
	@ApiOperation(value = "scanOrderList", notes = "获取扫码的order列表信息")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -2, message = "用户未登陆，没有操作权限"), @ApiResponse(code = -214, message = "找不到该订单信息") })
	@RequestMapping(value = "/scanOrderList", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody scanOrderList(@RequestBody OrderScanListParameter scanOrder) throws GlobalErrorInfoException {
		List<String> orderIds = scanOrder.getOrderIds();
		if (orderIds.isEmpty()) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDERID_IS_BLANK);
		}
		ThreadLocalContextHolder.put(AppConstants.DAGID, OrderUtils.getDagId(orderIds.get(0)));
		List<Order> orderList = orderService.selectOrderListByUserIdAndOrderIds(scanOrder.getUserId(), orderIds);
		if (orderList.isEmpty()) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDER_NOT_EXIST);
		}
		List<OrderBo> orderBoList = orderService.getOrderBoList(orderList);

		OrderBo orderBo = orderBoList.stream().filter(x -> x.getUserId() != null).findAny().orElse(null);
		CheckCreditVo checkCredit = userCreditInfoClient.checkTencentCredit(orderBo.getUserId());
		List<CheckHistory> checkHistoryList = orderService.selectCheckHistoryList(orderBo);

		OrderExit orderExit = new OrderExit(orderBoList, null, checkCredit.getUserName(), null);
		orderExit.setCheckHistoryList(checkHistoryList);
		return new ResultBody(orderExit);
	}

	/**
	 * 扫描二维码接口FOR pad
	 * 
	 * @param id
	 * @param request
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	@LdapPrivilegeInfo
	@ApiOperation(value = "scanOrderForPad", notes = "扫描二维码 FOR PAD")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -2, message = "用户未登陆，没有操作权限"), @ApiResponse(code = -214, message = "找不到该订单信息"),
			@ApiResponse(code = -219, message = "AP用户未配置门店") })
	@RequestMapping(value = "/scanOrderForPad", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody scanOrderForPad(HttpServletRequest request, @RequestBody OrderScanParameter orderScanParameter) throws GlobalErrorInfoException {
		ThreadLocalContextHolder.put(AppConstants.DAGID, OrderUtils.getDagId(orderScanParameter.getOrderId()));
		Integer storeId = ThreadLocalContextHolder.get(AppConstants.STOREID, Integer.class);
		if (storeId == null) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.LDAP_USER_NOT_CONFIGURED_STOREIDGROUP);
		}
		Order order = orderService.getOrderByOrderId(orderScanParameter.getOrderId());
		if (order == null) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDER_NOT_EXIST);
		}
		/**
		 * 如果扫描的是支付订单，则把用户所有的已支付订单查询出来，否则只查询扫描的订单信息
		 */
		List<OrderBo> orderBoList = new ArrayList<>();
		if (order.getStatus() == OrderStatus.PAID) {
			orderBoList = orderService.selectOrderListbyUserIdAndstatusAndStoreId(order.getUserId(), OrderStatus.PAID, null);
		} else {
			OrderBo orderBo = orderService.requestOrderDetailByOrder(order);
			orderBoList.add(orderBo);
		}
		/**
		 * 设置用户名和是否检查标志
		 */
		CheckCreditVo checkCredit = userCreditInfoClient.checkTencentCredit(order.getUserId());
		OrderExit orderExit = new OrderExit(orderBoList, checkCredit.getCheckFlag(), checkCredit.getUserName(), null);
		return new ResultBody(orderExit);
	}

	/**
	 * 扫描二维码接口FOR pad
	 * 
	 * @param id
	 * @param request
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	@LdapPrivilegeInfo
	@ApiOperation(value = "scanOrderForPadConfirm", notes = "扫描二维码 FOR PAD 确认通过")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -2, message = "用户未登陆，没有操作权限"), @ApiResponse(code = -214, message = "找不到该订单信息"),
			@ApiResponse(code = -216, message = "orderId 不能为空"), @ApiResponse(code = -212, message = "订单状态不允许转换") })
	@RequestMapping(value = "/scanOrderForPadConfirm", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody scanOrderForPadConfirm(HttpServletRequest request, @RequestBody OrderScanConfirmParameter orderScanConfirmParameter) throws GlobalErrorInfoException {

		String ldapUserId = ThreadLocalContextHolder.get(AppConstants.LDAPUSERID, String.class);
		LOG.info("the confirm opeartion user is {},orderId is {}", ldapUserId, orderScanConfirmParameter.getOrderId());

		Integer storeId = ThreadLocalContextHolder.get(AppConstants.STOREID, Integer.class);
		if (storeId == null) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.LDAP_USER_NOT_CONFIGURED_STOREIDGROUP);
		}
		String orderId = orderScanConfirmParameter.getOrderId();
		if (StringUtils.isBlank(orderId)) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDERID_IS_BLANK);
		}
		String dagId = OrderUtils.getDagId(orderScanConfirmParameter.getOrderId());
		ThreadLocalContextHolder.put(AppConstants.DAGID, dagId);

		Order order = orderService.selectOrderByUserIdAndOrderIdAndStoreId(orderScanConfirmParameter.getUserId(), orderId, storeId);
		if (order == null) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDER_NOT_EXIST);
		}
		order.setCancelReason(orderScanConfirmParameter.getCancelReason());
		order.setCancelRemark(orderScanConfirmParameter.getCancelRemark());
		orderService.updateStatusByOrder(order);

		sendInvoiceSingle(order);

		String storeIdAndSequenceNumber = orderScanConfirmParameter.getStoreId() + "_" + order.getSequenceNumber();
		StoreVo storeVo = orderService.checkRedis(orderId, storeId, order, storeIdAndSequenceNumber);
		if (storeVo.getScanFlag() != null && storeVo.getScanFlag() == 0) {
			orderService.commonComfirmPushMsg(MessageTypeCons.COMMON_COMFIREM_PUSH, ldapUserId, order.getSequenceNumber(), storeId, order);
		}

		// 发送用来统计月均交易
		if (order.getStatus() == OrderStatus.COMPLETE && order.getCancelReason() != null) {
			String userId = order.getUserId();
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("userId", userId);
			jsonObject.put("dagId", dagId);
			creaditW4SendHandler.sendMessage(jsonObject.toString());
		}
		return new ResultBody();
	}

	/**
	 * 扫描二维码 FOR PAD 全部确认通过FOR pad
	 * 
	 * @param id
	 * @param request
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	@LdapPrivilegeInfo
	@ApiOperation(value = "scanOrderForPadAllConfirm", notes = "扫描二维码 FOR PAD 全部确认通过")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -2, message = "用户未登陆，没有操作权限"), @ApiResponse(code = -214, message = "找不到订单信息"),
			@ApiResponse(code = -216, message = "orderId 不能为空"), @ApiResponse(code = -212, message = "订单状态不允许转换"), @ApiResponse(code = -229, message = "订单列表中没有已支付订单") })
	@RequestMapping(value = "/scanOrderForPadAllConfirm", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody scanOrderForPadAllConfirm(HttpServletRequest request, @RequestBody OrderScanAllConfirmParameter orderScanAllConfirmParameter) throws GlobalErrorInfoException {

		String ldapUserId = ThreadLocalContextHolder.get(AppConstants.LDAPUSERID, String.class);
		LOG.info("the confirm opeartion user is {}", ldapUserId);

		Integer storeId = ThreadLocalContextHolder.get(AppConstants.STOREID, Integer.class);
		if (storeId == null) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.LDAP_USER_NOT_CONFIGURED_STOREIDGROUP);
		}

		List<String> orderIds = orderScanAllConfirmParameter.getOrderIds();
		if (CollectionUtils.isEmpty(orderIds)) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDERID_IS_BLANK);
		}
		ThreadLocalContextHolder.put(AppConstants.DAGID, OrderUtils.getDagId(orderIds.get(0)));
		/**
		 * 查询用户订单中已支付的订单
		 */
		List<Order> orderList = orderService.selectOrderListByUserIdAndOrderIdsAndStoreId(orderScanAllConfirmParameter.getUserId(), orderIds, storeId);
		if (CollectionUtils.isEmpty(orderList)) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDERS_STATUS_NOT_PAID);
		}
		orderService.updateStatusByOrderIds(orderList, orderScanAllConfirmParameter.getCancelReason(), orderScanAllConfirmParameter.getCancelRemark());

		for (Order order : orderList) {
			sendInvoiceSingle(order);
		}
		orderService.commonAllConfirmPush(ldapUserId, storeId, orderList);

		return new ResultBody();
	}

	/**
	 * 根据手机号码查询用户已支付订单
	 * 
	 * @param id
	 * @param request
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	@LdapPrivilegeInfo
	@ApiOperation(value = "queryOrderListByMobile", notes = "根据手机号码查询用户已支付订单")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -2, message = "用户未登陆，没有操作权限"), @ApiResponse(code = -252, message = "手机号码不能为空"),
			@ApiResponse(code = -214, message = "该手机号对应的用户,没有已支付的订单"), @ApiResponse(code = -253, message = "该手机号找不到对应的用户") })
	@RequestMapping(value = "/queryOrderListByMobile", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody queryOrderListByMobile(HttpServletRequest request, @RequestBody QueryOrderListParamter queryOrderListParamter) throws GlobalErrorInfoException {
		if (StringUtils.isBlank(queryOrderListParamter.getMobilePhone())) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.MOBILEPHONE_IS_NOT_EXIST);
		}

		Route phoneRoute = routeService.getRouteByMobilePhone(queryOrderListParamter.getMobilePhone());
		if (phoneRoute == null) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.MOBILEPHONE_MATCH_USER_IS_NOT_EXIST);
		}
		ThreadLocalContextHolder.put(AppConstants.DAGID, phoneRoute.getDagId());
		List<OrderBo> orderList = orderService.selectOrderListbyUserIdAndstatusAndStoreId(phoneRoute.getUserId(), OrderStatus.PAID, null);
		if (CollectionUtils.isEmpty(orderList)) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDER_NOT_EXIST);
		}
		/**
		 * 设置用户名和是否检查标志
		 */
		OrderBo orderBo = orderList.stream().filter(x -> x.getUserId() != null).findAny().orElse(null);
		CheckCreditVo checkCredit = userCreditInfoClient.checkTencentCredit(orderBo.getUserId());
		OrderExit orderExit = new OrderExit(orderList, checkCredit.getCheckFlag(), checkCredit.getUserName(), null);
		return new ResultBody(orderExit);
	}

	/**
	 * 扫描二维码接口FOR pad reject
	 * 
	 * @param id
	 * @param request
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	@LdapPrivilegeInfo
	@ApiOperation(value = "scanOrderForPadReject", notes = "扫描二维码 FOR PAD 不通过")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -214, message = "找不到该订单信息"), @ApiResponse(code = -216, message = "orderId 不能为空"),
			@ApiResponse(code = -212, message = "订单状态不允许转换"), @ApiResponse(code = -272, message = "订单已经有退货记录，请走部分退货流程"), @ApiResponse(code = -279, message = "运单的当前状态，不允许订单不通过") })
	@RequestMapping(value = "/scanOrderForPadReject", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody scanOrderForPadReject(HttpServletRequest request, @RequestBody OrderScanConRejectParameter orderScanConRejectParameter) throws GlobalErrorInfoException {

		String ldapUserId = ThreadLocalContextHolder.get(AppConstants.LDAPUSERID, String.class);
		LOG.info("the reject opeartion user is {},orderId is {}", ldapUserId, orderScanConRejectParameter.getOrderId());
		Integer cancelReason = orderScanConRejectParameter.getCancelReason();
		String cancelRemark = orderScanConRejectParameter.getCancelRemark();
		String orderId = orderScanConRejectParameter.getOrderId();
		Integer storeId = ThreadLocalContextHolder.get(AppConstants.STOREID, Integer.class);
		if (StringUtils.isBlank(orderId)) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDERID_IS_BLANK);
		}
		ThreadLocalContextHolder.put(AppConstants.DAGID, OrderUtils.getDagId(orderId));

		Order order = orderService.getOrderByOrderId(orderId);
		if (order == null) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDER_NOT_EXIST);
		}

		List<Refund> refundDbList = refundService.getOrderRefundList(orderId);
		if (CollectionUtils.isNotEmpty(refundDbList)) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDER_HAVE_REFUND_RECORD);
		}

		/**
		 * 运单状态设置为取消update logic
		 */
		if (order.getDeliveryFlag() != null && order.getDeliveryFlag() == 1) {
			boolean flag = deliveryServiceClient.cancelDelivery(orderId);
			if (!flag) {
				throw new GlobalErrorInfoException(OrderErrorInfoEnum.DELIVERY_STATUS_CANT_REJECT);
			}
			LOG.info("deliveryServiceClient cancelDelivery function  orderId is {},flag is {}", orderId, flag);
		}

		Refund refund = orderScanReject(cancelReason, cancelRemark, ldapUserId, orderId, order);
		List<Refund> refundList = new ArrayList<>();
		refundList.add(refund);
		BigDecimal totalRefundAmount = order.getAmount();

		sendRefundAndrevrseRecordSale(orderId, order, refund.getBatchNo(), refundList, totalRefundAmount);

		String sequenceNumber = order.getSequenceNumber();
		String storeIdAndSequenceNumber = storeId + "_" + sequenceNumber;
		StoreVo storeVo = orderService.checkRedis(orderId, storeId, order, storeIdAndSequenceNumber);
		if (storeVo.getScanFlag() != null && storeVo.getScanFlag() == 0) {
			orderService.commonComfirmPushMsg(MessageTypeCons.SHORT_CUT_REJECT_PUSH, ldapUserId, sequenceNumber, storeId, order);
		}

		return new ResultBody();
	}

	/**
	 * 扫描二维码接口FOR pad shortCut reject
	 * 
	 * @param id
	 * @param request
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	@LdapPrivilegeInfo
	@ApiOperation(value = "shortCutForPadReject", notes = "快捷方式不通过，供快捷页面刷新数据")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -280, message = "参数不能为空"), @ApiResponse(code = -281, message = "redis中没有查询到记录"),
			@ApiResponse(code = -284, message = "快捷方式不通过，必须有通道号"), @ApiResponse(code = -283, message = "前端orderIds与redis中保存的不一致，不是通道最新订单") })
	@RequestMapping(value = "/shortCutForPadReject", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody shortCutForPadReject(HttpServletRequest request, @RequestBody OrderExitActionParameter orderExitActionParameter) throws GlobalErrorInfoException {

		String ldapUserId = ThreadLocalContextHolder.get(AppConstants.LDAPUSERID, String.class);
		LOG.info("shortCutForPadReject exitShortcut operation user is {}", ldapUserId);

		if (orderExitActionParameter.getStoreId() == null || StringUtils.isEmpty(orderExitActionParameter.getSequenceNumber())) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.PARAMTER_CONTIANIS_NULL);
		}
		String storeIdAndSequenceNumber = orderExitActionParameter.getStoreId() + "_" + orderExitActionParameter.getSequenceNumber();
		if (!redisOperationRepo.exists(storeIdAndSequenceNumber)) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.REDIS_OPERATION_NULL);
		}
		RedisBean<MonitorRedisInformation> redisBean = redisOperationRepo.findOne(storeIdAndSequenceNumber);
		if (redisBean == null) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.REDIS_OPERATION_NULL);
		}
		MonitorRedisInformation monitorRedisInformation = redisBean.getValue(MonitorRedisInformation.class);

		List<MonitorOrderAmount> redisMonitorOrderAmountList = monitorRedisInformation.getMonitorOrderAmountList();
		List<MonitorOrderAmount> clientMonitorOrderAmountList = orderExitActionParameter.getMonitorOrderAmountList();

		if (redisMonitorOrderAmountList.size() != clientMonitorOrderAmountList.size()) {
			ResultBody resultBody = new ResultBody();
			resultBody.setCode(OrderErrorInfoEnum.OPERATION_ORDER_IS_NOT_MONITOR_ORDER.getCode());
			resultBody.setResult(monitorRedisInformation);
			return resultBody;
		}

		redisMonitorOrderAmountList.sort((MonitorOrderAmount r1, MonitorOrderAmount r2) -> r1.getOrderId().compareTo(r2.getOrderId()));
		clientMonitorOrderAmountList.sort((MonitorOrderAmount c1, MonitorOrderAmount c2) -> c1.getOrderId().compareTo(c2.getOrderId()));
		for (int i = 0; i < redisMonitorOrderAmountList.size(); i++) {
			if (!StringUtils.equals(redisMonitorOrderAmountList.get(i).getOrderId(), clientMonitorOrderAmountList.get(i).getOrderId())
					|| redisMonitorOrderAmountList.get(i).getAmount().compareTo(clientMonitorOrderAmountList.get(i).getAmount()) != 0) {
				ResultBody resultBody = new ResultBody();
				resultBody.setCode(OrderErrorInfoEnum.OPERATION_ORDER_IS_NOT_MONITOR_ORDER.getCode());
				resultBody.setResult(monitorRedisInformation);
				return resultBody;
			}
		}

		return new ResultBody();

	}

	private void sendRefundAndrevrseRecordSale(String orderId, Order order, String batchNo, List<Refund> refundList, BigDecimal totalRefundAmount) throws GlobalErrorInfoException {

		/** 先退款，在逆向过机 */
		if (order.getPayType() == OrderCons.WECHAT_PAY_TYPE) {
			wechatRefundSend(orderId, order, batchNo, totalRefundAmount);
		} else if (order.getPayType() == OrderCons.EGIFTCARD) {
			egfitcardRefundSend(orderId, batchNo, totalRefundAmount);
		}
		/**
		 * 发送逆向过机
		 */
		OrderBo orderBo = orderService.requestOrderDetailByUserIdAndOrderIdForPassMachine(null, orderId);
		String reverseData = reverseRecordSaleService.sendReverseRecordSale(refundList, resourceType, orderBo, order.getStatus());
		LOG.info("orderId is {},reverseData is {}", orderId, reverseData);

	}

	@LdapPrivilegeInfo
	@ApiOperation(value = "scanOrderRefund", notes = "扫描订单二维码获取退货订单")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -214, message = "订单不存在"), @ApiResponse(code = -216, message = "订单id不能为空"),
			@ApiResponse(code = -263, message = "退货列表不能为空"), @ApiResponse(code = -269, message = "退款订单不存在") })
	@RequestMapping(value = "/scanOrderRefund", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody scanOrderRefund(@RequestBody OrderRefundParameter orderRefundParameter) throws GlobalErrorInfoException {

		String ldapUserId = ThreadLocalContextHolder.get(AppConstants.LDAPUSERID, String.class);

		LOG.info("scan refund order user is {},orderId is {}", ldapUserId, orderRefundParameter.getOrderId());

		String role = ThreadLocalContextHolder.get(AppConstants.ROLE, String.class);
		if (!StringUtils.equals(ADMIN, role)) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.REJECT_ITEM_APPROVE_USER_UNAUTHORIZED);
		}

		String orderId = orderRefundParameter.getOrderId();
		if (StringUtils.isBlank(orderId)) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDERID_IS_BLANK);
		}
		ThreadLocalContextHolder.put(AppConstants.DAGID, OrderUtils.getDagId(orderId));

		Order order = orderService.getOrderByOrderId(orderId);
		if (order == null) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDER_NOT_EXIST);
		}

		List<Refund> refundList = refundService.getApplyOrderRefundList(orderId);

		if (refundList == null || refundList.isEmpty()) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.REFUND_NOT_FOUND);
		}
		OrderRefundBo orderRefundBo = new OrderRefundBo();
		BeanUtils.copyProperties(order, orderRefundBo);

		Map<Long, Long> itemNumberAndCartItemIdMap = new HashMap<>(16);
		List<OrderEws> orderEwsList = orderService.selectOrderEwsList(orderId);
		if (CollectionUtils.isNotEmpty(orderEwsList)) {
			for (OrderEws orderEws : orderEwsList) {
				itemNumberAndCartItemIdMap.put(orderEws.getEwsItemNumber(), orderEws.getCartItemId());
			}
		}

		Map<Long, OrderLine> orderLineMap = orderService.getOrderLineMap(orderId, orderRefundBo, itemNumberAndCartItemIdMap);

		CheckCreditVo checkCredit = userCreditInfoClient.checkTencentCredit(order.getUserId());
		orderRefundBo.setUserName(checkCredit.getUserName());

		buildScanRefundBoList(refundList, orderRefundBo, itemNumberAndCartItemIdMap, orderLineMap);

		return new ResultBody(orderRefundBo);
	}

	/**
	 * 构建refundList
	 * 
	 * @param refundList
	 * @param orderRefundBo
	 * @param itemNumberAndCartItemIdMap
	 * @param orderLineMap
	 */
	private void buildScanRefundBoList(List<Refund> refundList, OrderRefundBo orderRefundBo, Map<Long, Long> itemNumberAndCartItemIdMap, Map<Long, OrderLine> orderLineMap) {
		List<ScanRefundBo> list = new ArrayList<>();
		refundList.forEach(refund -> {
			ScanRefundBo refundBo = new ScanRefundBo();
			BeanUtils.copyProperties(refund, refundBo);
			OrderLine orderLine = orderLineMap.get(refundBo.getUpc() * 100 + refundBo.getCartItemId());
			if (refund.getEwsFlag() == 1 && itemNumberAndCartItemIdMap.containsKey(refund.getItemNumber())) {
				orderLine = orderLineMap.get(refundBo.getUpc() * 100 + itemNumberAndCartItemIdMap.get(refund.getItemNumber()));
			}

			if (orderLine != null) {
				refundBo.setWasPrice(orderLine.getWasPrice());
				refundBo.setThumbnailUrl(orderLine.getThumbnailUrl());
				refundBo.setDescOnline(orderLine.getDescOnline());
				refundBo.setPriceWithTax(orderLine.getPriceWithTax());
				refundBo.setItemAmount(orderLine.getItemAmount());
				refundBo.setItemType(orderLine.getItemType());
			}
			list.add(refundBo);
		});
		orderRefundBo.setScanRefundBoList(list);
	}

	/**
	 * 退货申请审批
	 * 
	 * @param id
	 * @param request
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	@LdapPrivilegeInfo
	@ApiOperation(value = "orderScanRejectItemApprove", notes = "退货申请审批")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -268, message = "退货审批数组为空"), @ApiResponse(code = -267, message = "该用户没有审批权限") })
	@RequestMapping(value = "/orderScanRejectItemApprove", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody orderScanRejectItemApprove(@RequestBody List<ReturnApproveParamter> returnApproveParamterList) throws GlobalErrorInfoException {
		String ldapUserId = ThreadLocalContextHolder.get(AppConstants.LDAPUSERID, String.class);
		LOG.info("orderScanRejectItemApprove operation user is {}", ldapUserId);
		if (CollectionUtils.isEmpty(returnApproveParamterList)) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.REJECT_ITEM_APPROVE_LIST_ISEMPTY);
		}
		/**
		 * 判断用户是否有管理员权限
		 */
		String role = ThreadLocalContextHolder.get(AppConstants.ROLE, String.class);
		if (!StringUtils.equals(ADMIN, role)) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.REJECT_ITEM_APPROVE_USER_UNAUTHORIZED);
		}
		ThreadLocalContextHolder.put(AppConstants.DAGID, OrderUtils.getDagId(returnApproveParamterList.get(0).getRequestNumber()));

		BigDecimal totalRefundAmount = BigDecimal.ZERO;
		String requestNumber = returnApproveParamterList.get(0).getRequestNumber();
		String batchNo = requestNumber + DateUtil.dateToString(new Date(), DateUtil.PATTERN_YYYYMMDD);
		String orderId = StringUtils.EMPTY;
		List<Refund> refundList = new ArrayList<>();

		for (ReturnApproveParamter returnApproveParamter : returnApproveParamterList) {
			int returnQuantity = returnApproveParamter.getReturnQuantity();
			Refund refund = refundService.selectByPrimaryKey(returnApproveParamter.getRequestNumber());
			orderId = refund.getOrderId();
			if (refund.getRefundStatus() != RefundStatus.RETURN_STATUS_SUBMIT || returnQuantity < 0) {
				LOG.info("refundStatus is {},  returnQuantity is  {}", refund.getRefundStatus(), returnQuantity);
				continue;
			}
			if (returnApproveParamter.getReturnQuantity() == 0) {
				refund.setReturnQuantity(0);
				refund.setReturnAmount(BigDecimal.ZERO);
				refund.setRefundStatus(Byte.valueOf(String.valueOf(RefundStatus.RETURN_STATUS_REFUND_SUCCESS)));
				refund.setRefundTime(new Date());
				refund.setBatchNo(batchNo);
				refundList.add(refund);
				continue;
			}
			OrderLine orderLine = refundService.queryOrderLine(refund.getOrderId(), refund.getProductId(), refund.getCartItemId(), refund.getItemNumber(), refund.getEwsFlag());
			int noRefundQuantity = orderLine.getOrderQuantity() - refundService.selectReturnQuantity(refund.getOrderId(), refund.getProductId(), refund.getCartItemId());
			if (noRefundQuantity < returnQuantity) {
				LOG.info("approveReturn  returnQuantity is more than deliveryQuantity, requestNumber is {}", refund.getRequestNumber());
				continue;
			}

			BigDecimal amount;
			// 不管退款成功或失败，都更新数量与退款金额
			if (refund.getRequestQuantity() != returnQuantity) {
				amount = refund.getReturnAmount().divide(new BigDecimal(refund.getRequestQuantity()), 2, BigDecimal.ROUND_HALF_UP).multiply(new BigDecimal(returnQuantity));
				refund.setReturnAmount(amount);
			} else {
				amount = refund.getReturnAmount();
			}
			totalRefundAmount = totalRefundAmount.add(amount);
			refund.setReturnQuantity(returnQuantity);
			refund.setRefundStatus(Byte.valueOf(String.valueOf(RefundStatus.RETURN_STATUS_REFUND_PENDING)));
			refund.setRefundTime(new Date());
			refund.setBatchNo(batchNo);
			refundList.add(refund);
		}
		refundService.updateByBatchRefund(refundList);
		refundList.removeIf(refund -> refund.getReturnQuantity() == 0);

		Order order = orderService.getOrderByOrderId(orderId);
		String refundListJson = JSON.toJSONString(refundList);
		LOG.info("the batchNo is {} ,refundList is {},the totalRefundAmount is {} ", batchNo, refundListJson, totalRefundAmount);

		if (CollectionUtils.isNotEmpty(refundList)) {
			sendRefundAndrevrseRecordSale(orderId, order, batchNo, refundList, totalRefundAmount);
		}
		return new ResultBody("totalRfundAmount:" + totalRefundAmount);
	}

	/**
	 * 修改订单状态并且记录refund数据
	 * 
	 * @param orderScanConRejectParameter
	 * @param userId
	 * @param orderId
	 * @param order
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	private Refund orderScanReject(Integer cancelReason, String cancelRemark, String userId, String orderId, Order order) throws GlobalErrorInfoException {
		order.setCancelReason(cancelReason);
		order.setCancelRemark(cancelRemark);
		order.setCompletedTime(new Date());
		/**
		 * 通过状态机改状态到支付取消中
		 */
		orderService.updateStatusByOrderCancelling(order);
		LOG.info("the order reject by {}", userId);
		/**
		 * 写refund表
		 */
		String requestNumber = this.orderSerialNumberService.buildRefundId(order.getStoreId(), OrderUtils.getDagId(orderId));
		Refund refund = refundService.buildRefund(requestNumber, orderId, order.getCancelReason(), order.getPayType(), order.getAmount());
		refundService.insertRefund(refund);
		LOG.info("insert refund success");
		return refund;
	}

	/**
	 * 发送微信退款message
	 * 
	 * @param orderId
	 * @param order
	 * @param refund
	 */
	private void wechatRefundSend(String orderId, Order order, String batchNo, BigDecimal totalRefundAmount) {
		WechatNotification notification = wechatNotificationService.getByOutTradeNo(orderId);
		if (notification != null && order.getOrderType() == OrderCons.MCK_ORDER_TYPE && order.getPayType() == OrderCons.WECHAT_PAY_TYPE) {
			/**
			 * 调起mq发起mobileCK微信退款
			 */
			int totalFee = notification.getTotalFee();

			int refundFee = totalRefundAmount.multiply(new BigDecimal(100)).intValue();
			if ("1".equals(paymentAmount)) {
				totalFee = 1;
				refundFee = 1;
			}
			/**
			 * int totalFee = notification.getTotalFee(); int refundFee =
			 * order.getAmount().multiply(new BigDecimal(100)).intValue();
			 */
			RefundReqData refundReqData = new RefundReqData(notification.getTransactionId(), notification.getOrderId(), notification.getDeviceInfo(), batchNo, totalFee, refundFee, "system", "CNY",
					PayType.MOBILECK_WECHATPAY);
			String json = JSON.toJSON(refundReqData).toString();
			wechatRefundSendHandler.wechatRefundMessage(json);
			LOG.info("send to mobileCK wechat mq the data is {}", json);

		} else if (notification != null && order.getOrderType() == OrderCons.H5_ORDER_TYPE && order.getPayType() == OrderCons.WECHAT_PAY_TYPE) {
			// h5 微信退款
			int totalFee = notification.getTotalFee();
			int refundFee = totalRefundAmount.multiply(new BigDecimal(100)).intValue();
			if ("1".equals(paymentAmount)) {
				totalFee = 1;
				refundFee = 1;
			}
			RefundReqData refundReqData = new RefundReqData(notification.getTransactionId(), notification.getOrderId(), notification.getDeviceInfo(), batchNo, totalFee, refundFee, "system", "CNY",
					PayType.H5_WECHATPAY);
			String json = JSON.toJSON(refundReqData).toString();
			wechatH5RefundSendHandler.wechatRefundMessage(json);
			LOG.info("send to h5 wechat mq the data is {}", json);
		}
	}

	private void egfitcardRefundSend(String orderId, String batchNo, BigDecimal totalRefundAmount) {

		EGiftcardNewNotification egiftcardNewNotification = eGiftCardNewService.selectEgiftcardNotificationByOrderId(orderId);
		String totalFee = egiftcardNewNotification.getTotalFee();
		JSONObject map = new JSONObject(true);
		map.put("channelTradeNo", orderId);
		map.put("channelRefundNo", batchNo);
		map.put("totalFee", totalFee);
		map.put("refundFee", totalRefundAmount);
		String mapString = map.toString();
		LOG.info("send to mobileCK egiftcard  mq the data is {}", mapString);
		egiftcardNewRefundSendHandler.egiftcardNewRefundMessage(mapString);

	}

	/**
	 * 出厂快捷方式通过指令
	 * 
	 * @param id
	 * @param request
	 * @return
	 * @throws GlobalErrorInfoException
	 */

	@LdapPrivilegeInfo
	@ApiOperation(value = "exitShortcutConfirmOperation", notes = "出厂快捷方式通过指令")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -2, message = "用户未登陆，没有操作权限"), @ApiResponse(code = -280, message = "参数不能为空"),
			@ApiResponse(code = -281, message = "redis中没有查询到记录"), @ApiResponse(code = -283, message = "前端orderIds与redis中保存的不一致，不是通道最新订单"), @ApiResponse(code = -288, message = "订单已经被处理") })
	@RequestMapping(value = "/exitShortcutConfirmOperation", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody exitShortcutConfirmOperation(@RequestBody OrderExitActionParameter orderExitActionParameter) throws GlobalErrorInfoException {
		String ldapUserId = ThreadLocalContextHolder.get(AppConstants.LDAPUSERID, String.class);
		LOG.info("exitShortcut operation user is {},the operation is {}", ldapUserId);

		if (orderExitActionParameter.getStoreId() == null || StringUtils.isEmpty(orderExitActionParameter.getSequenceNumber())) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.PARAMTER_CONTIANIS_NULL);
		}
		String storeIdAndSequenceNumber = orderExitActionParameter.getStoreId() + "_" + orderExitActionParameter.getSequenceNumber();
		LOG.info("storeIdAndSequenceNumberis {}", storeIdAndSequenceNumber);
		if (!redisOperationRepo.exists(storeIdAndSequenceNumber)) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.REDIS_OPERATION_NULL);
		}
		RedisBean<MonitorRedisInformation> redisBean = redisOperationRepo.findOne(storeIdAndSequenceNumber);
		if (redisBean == null) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.REDIS_OPERATION_NULL);
		}
		MonitorRedisInformation monitorRedisInformation = redisBean.getValue(MonitorRedisInformation.class);

		List<MonitorOrderAmount> redisMonitorOrderAmountList = monitorRedisInformation.getMonitorOrderAmountList();
		List<MonitorOrderAmount> clientMonitorOrderAmountList = orderExitActionParameter.getMonitorOrderAmountList();

		if (redisMonitorOrderAmountList.size() != clientMonitorOrderAmountList.size()) {
			ResultBody resultBody = new ResultBody();
			resultBody.setCode(OrderErrorInfoEnum.OPERATION_ORDER_IS_NOT_MONITOR_ORDER.getCode());
			resultBody.setResult(monitorRedisInformation);
			return resultBody;
		}
		LOG.info("redisMonitorOrderAmountList is {}", JSON.toJSONString(redisMonitorOrderAmountList));
		LOG.info("clientMonitorOrderAmountList is {}", JSON.toJSONString(clientMonitorOrderAmountList));
		redisMonitorOrderAmountList.sort((MonitorOrderAmount r1, MonitorOrderAmount r2) -> r1.getOrderId().compareTo(r2.getOrderId()));
		clientMonitorOrderAmountList.sort((MonitorOrderAmount c1, MonitorOrderAmount c2) -> c1.getOrderId().compareTo(c2.getOrderId()));
		ThreadLocalContextHolder.put(AppConstants.DAGID, monitorRedisInformation.getDagId());
		List<String> orderIds = new ArrayList<>();
		int j = 0;
		for (int i = 0; i < redisMonitorOrderAmountList.size(); i++) {
			MonitorOrderAmount monitorOrderAmount = redisMonitorOrderAmountList.get(i);
			orderIds.add(monitorOrderAmount.getOrderId());
			// 查询数据库中order状态，防止在A通道扫码后又在B通道扫码的情况
			Order order = orderService.getOrderByOrderId(monitorOrderAmount.getOrderId());
			monitorOrderAmount.setStatus(order.getStatus());
			if (!StringUtils.equals(monitorOrderAmount.getOrderId(), clientMonitorOrderAmountList.get(i).getOrderId())
					|| monitorOrderAmount.getAmount().compareTo(clientMonitorOrderAmountList.get(i).getAmount()) != 0
					|| monitorOrderAmount.getStatus() != clientMonitorOrderAmountList.get(i).getStatus()) {
				j++;
				redisBean.setValue(monitorRedisInformation);
				// 保存redis
				redisOperationRepo.save(redisBean);

			}

		}
		// 防止在不同通道扫码过的订单，产生的垃圾数据
		MonitorOrderAmount monitorOrderAmount2 = redisMonitorOrderAmountList.stream().filter(x -> x.getStatus() == OrderStatus.PAID).findAny().orElse(null);
		if (monitorOrderAmount2 == null) {
			// 删除redis
			redisOperationRepo.delete(storeIdAndSequenceNumber);
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ALL_ORDER_HAS_DEAL_WITH);
		}
		if (j > 0) {
			ResultBody resultBody = new ResultBody();
			resultBody.setCode(OrderErrorInfoEnum.OPERATION_ORDER_IS_NOT_MONITOR_ORDER.getCode());
			resultBody.setResult(monitorRedisInformation);
			return resultBody;
		}

		String userId = monitorRedisInformation.getUserId();
		List<Order> orderList = orderService.selectOrderListByUserIdAndOrderIdsAndStoreId(userId, orderIds, orderExitActionParameter.getStoreId());
		if (CollectionUtils.isEmpty(orderList)) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDERS_STATUS_NOT_PAID);
		}
		// 通过操作
		orderService.updateStatusByOrderIds(orderList, orderExitActionParameter.getCancelReason(), orderExitActionParameter.getCancelRemark());
		for (Order order : orderList) {
			sendInvoiceSingle(order);
		}
		// 删除redis
		redisOperationRepo.delete(storeIdAndSequenceNumber);
		// 推送消息

		for (MonitorOrderAmount monitorOrderAmount : redisMonitorOrderAmountList) {
			orderService.buildMonitorOrderAmount(orderList, monitorOrderAmount);
		}
		orderService.shortPushMsg(MessageTypeCons.SHORT_CUT_COMFIREM_PUSH, ldapUserId, orderExitActionParameter.getSequenceNumber(), orderExitActionParameter.getStoreId(), monitorRedisInformation);

		return new ResultBody();
	}

	/**
	 * monitor刷新订单状态
	 * 
	 * @param monitorRefreshParameter
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	@ApiOperation(value = "monitorRefreshOrderList", notes = "monitor刷新订单状态")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -2, message = "用户未登陆，没有操作权限"), @ApiResponse(code = -220, message = "mac地址没有配置"),
			@ApiResponse(code = -225, message = "checkSum加密失败"), @ApiResponse(code = -215, message = "checkSum对比不通过"), @ApiResponse(code = -216, message = "orderIds列表为空") })
	@RequestMapping(value = "/monitorRefreshOrderList", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody monitorRefreshOrderList(@RequestBody MonitorRefreshParameter monitorRefreshParameter) throws GlobalErrorInfoException {

		orderValidationService.macCheckSum(monitorRefreshParameter.getAppKey(), monitorRefreshParameter.getVersion(), monitorRefreshParameter.getFormat(), monitorRefreshParameter.getTimeStamp(),
				monitorRefreshParameter.getSign(), monitorRefreshParameter.getMac());

		List<String> orderIds = monitorRefreshParameter.getOrderIds();
		if (CollectionUtils.isEmpty(orderIds)) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDERID_IS_BLANK);
		}
		String mac = monitorRefreshParameter.getMac();
		GateMac gateMac = orderService.checkGateMac(mac);

		Integer storeId = gateMac.getStoreId();
		ThreadLocalContextHolder.put(AppConstants.DAGID, OrderUtils.getDagId(orderIds.get(0)));

		List<Order> orderList = orderService.selectOrderListByOrderIdsAndStoreId(orderIds, storeId);
		return new ResultBody(orderList);
	}

	/**
	 * 刷新订单状态
	 * 
	 * @param orderExitParameter
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	@LdapPrivilegeInfo
	@ApiOperation(value = "exitRefreshRedisInfromation", notes = "出场刷新通道最新订单")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -2, message = "用户未登陆，没有操作权限"), @ApiResponse(code = -220, message = "mac地址没有配置") })
	@RequestMapping(value = "/exitRefreshRedisInfromation", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody exitRefreshRedisInfromation(@RequestBody OrderExitParameter orderExitParameter) throws GlobalErrorInfoException {

		List<GateMac> gateMacList = gateMacService.findByStoreId(orderExitParameter.getStoreId());
		if (CollectionUtils.isEmpty(gateMacList)) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.GATEMAC_NOT_CONFIGURED);
		}
		List<MonitorRedisInformation> monitorRedisInformationList = new ArrayList<>();
		for (GateMac gateMac : gateMacList) {
			String storeIdAndSequenceNumber = orderExitParameter.getStoreId() + "_" + gateMac.getSequenceNumber();
			if (!redisOperationRepo.exists(storeIdAndSequenceNumber)) {
				continue;
			}
			RedisBean<MonitorRedisInformation> redisBean = redisOperationRepo.findOne(storeIdAndSequenceNumber);
			if (redisBean == null) {
				continue;
			}
			MonitorRedisInformation monitorRedisInformation = redisBean.getValue(MonitorRedisInformation.class);
			monitorRedisInformationList.add(monitorRedisInformation);
		}

		return new ResultBody(monitorRedisInformationList);
	}

	/**
	 * 通过消息获取订单明细信息
	 * 
	 * @param id
	 * @param request
	 * @return ok
	 * @throws GlobalErrorInfoException
	 */
	@ApiOperation(value = "monitorScanOrderList", notes = "monitor获取扫码的order列表信息")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -220, message = "mac地址没有配置"), @ApiResponse(code = -221, message = "找不到订单"),
			@ApiResponse(code = -226, message = "订单已扫描或者已完成"), @ApiResponse(code = -282, message = "参数中订单号和手机号码不能同时为空"), @ApiResponse(code = -225, message = "checkSum加密失败"),
			@ApiResponse(code = -215, message = "checkSum对比不通过"), @ApiResponse(code = -253, message = "DDR找不到路由信息"), @ApiResponse(code = -287, message = "找不到对应的mac地址通道信息") })
	@RequestMapping(value = "/monitorScanOrderList", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody monitorScanOrderList(@RequestBody MonitorExitParameter monitorExitParameter) throws GlobalErrorInfoException {

		orderValidationService.monitorCheckSum(monitorExitParameter.getAppKey(), monitorExitParameter.getVersion(), monitorExitParameter.getFormat(), monitorExitParameter.getTimeStamp(),
				monitorExitParameter.getOrderId(), monitorExitParameter.getSign(), monitorExitParameter.getMac(), monitorExitParameter.getMobilePhone());

		if (StringUtils.isEmpty(monitorExitParameter.getOrderId()) && StringUtils.isEmpty(monitorExitParameter.getMobilePhone())) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDERID_AND_MOBILEPHONE_BOTH_NULL);
		}
		String batchNo = UUID.randomUUID().toString().replaceAll("-", "");
		Date createTime = new Date();
		String mac = monitorExitParameter.getMac();
		GateMac gateMac = orderService.checkGateMac(mac);
		/**
		 * 防止扫码过程中通道号被修改，无法推送的情况，下发最新的通道信息
		 */
		GateMac gateMac2 = gateMacService.findByMacAndSequenceNumber(mac, monitorExitParameter.getSequnceNumber());
		if (gateMac2 == null) {
			ResultBody resultBody = new ResultBody();
			resultBody.setCode(OrderErrorInfoEnum.MAC_AND_SEQNUMBER_CANT_QUERY.getCode());
			resultBody.setMessage("mac and sequenceNumber can't query result");
			resultBody.setResult(gateMac);
			return resultBody;
		}

		Map<String, String> userIdAndMobilePhoneMap = orderService.getUserIdAndMobilePhone(monitorExitParameter);
		Integer storeId = gateMac.getStoreId();
		String userId = userIdAndMobilePhoneMap.get(AppConstants.USERID);
		String mobilePhone = userIdAndMobilePhoneMap.get(AppConstants.MOBILE_PHONE);
		String dagId = userIdAndMobilePhoneMap.get(AppConstants.DAGID);

		List<Order> orderList = orderService.queryOrderListbyUserIdAndstatusAndStoreId(userId, OrderStatus.PAID, storeId);

		List<CheckHistory> checkHistoryList = new ArrayList<>();

		List<OrderBo> orderBoList = null;
		Integer messageType = MessageTypeCons.ORDERLIST_EXIST_PUSH;
		CheckCreditVo checkCredit = userCreditInfoClient.checkTencentCredit(userId);

		Integer itemAllQuantity = 0;
		BigDecimal itemAllAmount = BigDecimal.ZERO;
		Integer shoppingBagQuantity = 0;
		BigDecimal shoppingBagAmount = BigDecimal.ZERO;

		TransactionRuleParamter transactionRuleParamter = new TransactionRuleParamter();
		Map<String, Long> minuteMap = new HashMap<>(10);
		if (CollectionUtils.isNotEmpty(orderList)) {
			Order orderScanTime = orderList.stream().filter(x -> x.getScanTime() == null).findAny().orElse(null);
			if (orderScanTime == null) {
				throw new GlobalErrorInfoException(OrderErrorInfoEnum.SCAN_ORDER_HAS_COMPLETED);
			}
			orderBoList = orderService.getOrderBoList(orderList);
			orderService.buildTransactionRuleParamter(batchNo, createTime, storeId, checkHistoryList, orderBoList, itemAllQuantity, itemAllAmount, shoppingBagQuantity, shoppingBagAmount,
					transactionRuleParamter, minuteMap);
		} else {
			// orderlist为空，不需要消磁，订单必检
			messageType = MessageTypeCons.ORDERLIST_NOT_EXIST_PUSH;
			checkCredit.setMagneticFlag(0);
			checkCredit.setCheckFlag(1);
			// 前端用来判断 提示语
			checkCredit.setNullOrderFlag(1);
		}

		CheckPersonAndTransation checkPersonAndTransation = orderService.buildCheckPersonAndTransaction(batchNo, createTime, userId, orderList, checkHistoryList, checkCredit,
				transactionRuleParamter.getItemAllAmount(), transactionRuleParamter.getShoppingBagQuantity(), transactionRuleParamter.getAverageAmount(),
				transactionRuleParamter.getOtherItemQuantity(), minuteMap);

		orderService.ruleCheckPersonAndTransation(checkPersonAndTransation);

		String sequenceNumber = gateMac.getSequenceNumber();
		String screenFlag = orderService.saveCheckHistoryAndUpdateOrder(storeId, dagId, orderList, checkHistoryList, checkCredit, sequenceNumber);
		sendInvoiceList(orderList, checkCredit);

		// 自动通过订单不需要保存redis
		if (CollectionUtils.isNotEmpty(orderList) && orderList.get(0).getStatus() == OrderStatus.PAID) {
			orderService.monitorRedisSave(monitorExitParameter, userId, orderList, sequenceNumber, dagId, storeId, screenFlag);
		}
		// 推送消息
		orderService.batchSendPushMsg(storeId, gateMac.getSequenceNumber(), orderList, messageType, checkCredit, monitorExitParameter.getSeqId(), mobilePhone, screenFlag);

		OrderExit orderExit = new OrderExit(orderBoList, checkCredit);
		orderExit.setCheckHistoryList(checkHistoryList);
		return new ResultBody(orderExit);
	}

}
