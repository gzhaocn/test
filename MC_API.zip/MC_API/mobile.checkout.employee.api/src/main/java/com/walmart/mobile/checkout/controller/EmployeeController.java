package com.walmart.mobile.checkout.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.walmart.mobile.checkout.annotation.PrivilegeInfo;
import com.walmart.mobile.checkout.bo.DiscountCardParam;
import com.walmart.mobile.checkout.constant.AppConstants;
import com.walmart.mobile.checkout.constant.EmployeeErrorInfoEnum;
import com.walmart.mobile.checkout.entity.Employee;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.exception.handler.ResultBody;
import com.walmart.mobile.checkout.service.EmployeeService;
import com.walmart.mobile.checkout.utils.AppUtils;
import com.walmart.mobile.checkout.utils.ThreadLocalContextHolder;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Controller
@RequestMapping("employee")
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	@ApiOperation(value = "bind discount card", notes = "绑定员工折扣卡")
	@ApiResponses({ @ApiResponse(code = -1100, message = "已经绑定员工折扣卡"), @ApiResponse(code = -1101, message = "员工折扣卡验证字段为空"),
			@ApiResponse(code = -1102, message = "员工卡未找到"), @ApiResponse(code = -1103, message = "员工折扣卡已被绑定"),
			@ApiResponse(code = -1104, message = "员工折扣卡信息验证不通过") })
	@PrivilegeInfo
	@RequestMapping(value = "bind/discountcard", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody bindDiscountCard(@RequestBody DiscountCardParam discountCardParam) throws GlobalErrorInfoException {
		checkParam(discountCardParam);
		String userId = ThreadLocalContextHolder.getUserId();
		Employee employee = employeeService.findByAccountNbr(discountCardParam.getAccountNbr());
		employeeService.checkUserBind(employeeService.findByUserId(userId));
		employeeService.checkBind(discountCardParam, employee);
		employeeService.bindDiscountCard(employee, userId);
		return new ResultBody();
	}

	@ApiOperation(value = "get discount card", notes = "获取用户折扣卡信息")
	@PrivilegeInfo
	@RequestMapping(value = "get/discountcard", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody getDiscountCard(HttpServletRequest request) {
		Employee employee = employeeService.findByUserId(ThreadLocalContextHolder.getUserId());
		return new ResultBody(AppUtils.copyProperties(employee, DiscountCardParam.class));
	}

	private void checkParam(DiscountCardParam discountCardParam) throws GlobalErrorInfoException {
		if (StringUtils.isEmpty(discountCardParam.getAccountNbr()) || StringUtils.isEmpty(discountCardParam.getLastName())
				|| StringUtils.isEmpty(discountCardParam.getFirstName()) || discountCardParam.getBirthDate() == null) {
			throw new GlobalErrorInfoException(EmployeeErrorInfoEnum.DISCOUNT_CARD_NOT_EMPTY);
		}

	}

}
