package com.walmart.mobile.checkout.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.annotation.LdapPrivilegeInfo;
import com.walmart.mobile.checkout.bo.invoice.InvoicePdfMain;
import com.walmart.mobile.checkout.bo.invoice.InvoicePdfReq;
import com.walmart.mobile.checkout.bo.invoice.InvoiceResp;
import com.walmart.mobile.checkout.bo.invoice.PaperInvoiceParamter;
import com.walmart.mobile.checkout.domain.order.Order;
import com.walmart.mobile.checkout.exception.exceptionType.CommonException;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.exception.handler.ResultBody;
import com.walmart.mobile.checkout.rest.service.invoice.OrderInvoiceClient;
import com.walmart.mobile.checkout.utils.ThreadLocalContextHolder;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Controller
@RequestMapping("invoice")
public class InvoiceController {
	private static final Logger LOGGER = LoggerFactory.getLogger(InvoiceController.class.getName());

	/**
	 * dagId在订单号规则中出现的开始位置，从此位置向后截取3位即为dagId.
	 */
	public static final int ORDER_ID_PATTERN_OF_DAG_ID_INDEX = 7;

	// storeId在订单号规则中出现的开始位置，从此位置向后截取4位即为storeId.
	public static final int ORDER_ID_PATTERN_OF_STORE_ID_INDEX = 1;
	
	/**
	 * 开纸质发票
	 */
	private static final String  MAKE_OUT_AN_INVOICE = "-1";
	/**
	 * 纸质发票红冲
	 */
	private static final String  RDD_PUNCHING_INVOICE = "-2";

	@Autowired
	private OrderInvoiceClient orderInvoiceClient;

	@ApiOperation(value = "update invoice PDF URL ", notes = "更新电子发票地址")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功") })
	@RequestMapping(value = "/updateInvoiceUrl", method = RequestMethod.POST)
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public String updateInvoiceUrl(@RequestBody String invoicePdfReqJson, HttpServletRequest request)
			throws CommonException {
		InvoiceResp invoiceResp = new InvoiceResp();
		try {
			InvoicePdfReq invoicePdfReq = JSON.parseObject(invoicePdfReqJson, InvoicePdfReq.class);
			// 校验回写发票地址参数
			Integer result = checkInvoicePdfInfo(invoicePdfReq);
			LOGGER.info("invoice callBack parma : {} ", invoicePdfReqJson);
			if (result == 0) {
				String remark = invoicePdfReq.getMain().getRemark();
				String orderId = getOrderId(remark);
				String invoceUrl = null;
				String reverseInvoiceUrl = null;
				String invoiceNo = null;
				String invoiceCode = null;
				String status = invoicePdfReq.getMain().getStatus();
				String originInvoiceNo = invoicePdfReq.getMain().getOriginInvoiceNo();
				String originInvoiceCode = invoicePdfReq.getMain().getOriginInvoiceCode();

				if ((originInvoiceNo != null && !StringUtils.isEmpty(originInvoiceNo.trim()))
						&& (originInvoiceCode != null && !StringUtils.isEmpty(originInvoiceCode.trim()))) {
					reverseInvoiceUrl = invoicePdfReq.getMain().getPdfUrl();
				} else {
					invoceUrl = invoicePdfReq.getMain().getPdfUrl();
					invoiceNo = invoicePdfReq.getMain().getInvoiceNo();
					invoiceCode = invoicePdfReq.getMain().getInvoiceCode();
				}

				LOGGER.info("invoice pdfurl :{} ", invoceUrl);
				String dagId = orderId.substring(ORDER_ID_PATTERN_OF_DAG_ID_INDEX,
						ORDER_ID_PATTERN_OF_DAG_ID_INDEX + 3);
				ThreadLocalContextHolder.switchDataSoureByDagId(dagId);
				Order order = orderInvoiceClient.getOrderByOrderId(orderId);
				result = updatePdfUrl(order, invoceUrl, orderId, status, invoiceNo, invoiceCode, reverseInvoiceUrl);
			}

			setResponse(result, invoiceResp);

		} catch (Exception e) {
			LOGGER.error("invoice update url error ", e);
			setResponse(-5, invoiceResp);
		}
		String invoiceCallBack = JSONObject.toJSONString(invoiceResp);
		LOGGER.info("invoice callBack result : {} ", invoiceCallBack);
		return invoiceCallBack;
	}
	
	
	
	@ApiOperation(value = "saveInvoiceWrongMsg", notes = "发票反馈开票失败原因")
	@RequestMapping(value = "/saveInvoiceWrongMsg", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody saveInvoiceWrongMsg(@RequestBody String invoiceBackMsgJson ,HttpServletRequest request) throws GlobalErrorInfoException {
		LOGGER.info("invoice fail info:  {} " , invoiceBackMsgJson);
		return new ResultBody();
	} 
	

	private Integer checkInvoicePdfInfo(InvoicePdfReq invoicePdfReq) {
		Integer result = 0;
		InvoicePdfMain main = invoicePdfReq.getMain();
		if (main.getRemark() == null && "".equals(main.getRemark())) {
			result = -2;
		} else if (main.getPdfUrl() == null && "".equals(main.getPdfUrl()) || "null".equals(main.getPdfUrl())) {
			result = -3;
		}

		return result;
	}

	private String getOrderId(String remark) {
		String[] strs = StringUtils.trimToEmpty(remark).split("\n");
		String orderId = "";
		int len = ArrayUtils.getLength(strs);
		if (len > 1) {
			orderId = strs[1];
		} else if (len == 1) {
			orderId = strs[0];
		}
		return orderId;
	}

	private InvoiceResp setResponse(Integer result, InvoiceResp invoiceResp) {

		if (result == 1) {
			invoiceResp.setMessage("update invoice pdfURL success");
		} else if (result == -1) {
			invoiceResp.setMessage("pdfURL has bean updated");
		} else if (result == -2) {
			invoiceResp.setMessage("parameter remark can not empty ,should full with orderId");
		} else if (result == -3) {
			invoiceResp.setMessage("parameter pdfUrl can not empty ,should full with url");
		} else if (result == -4) {
			invoiceResp.setMessage("invaild orderId");
		} else if (result == -5) {
			invoiceResp.setMessage("json format error");
		} else {
			invoiceResp.setMessage("update invoice pdfURL fail");
		}
		invoiceResp.setStatus(result.toString());
		return invoiceResp;
	}

	private Integer updatePdfUrl(Order order, String newPdfUrl, String orderId, String status, String invoiceNo,
			String invoiceCode, String reverseInvoiceUrl) {
		LOGGER.error("orderid :{} , invoice status :{} ", orderId, status);
		Integer result ;
		if (order != null) {
			result = orderInvoiceClient.updateInvoicePdfUrl(orderId, newPdfUrl, order.getVersion(), invoiceNo,
					invoiceCode, reverseInvoiceUrl);
		} else {
			result = -4;
		}

		return result;
	}
	
	
	
	
	/**
	 * 纸质发票记录
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@ApiOperation(value = "paperInvoiceRecord", notes = "纸质发票记录")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功") })
	@LdapPrivilegeInfo
	@RequestMapping(value = "/paperInvoiceRecord", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody generateInvoice(HttpServletRequest request, @RequestBody PaperInvoiceParamter paperInvoiceParamter) throws GlobalErrorInfoException {
		String orderId = paperInvoiceParamter.getOrderId();
		String dagId = orderId.substring(ORDER_ID_PATTERN_OF_DAG_ID_INDEX,ORDER_ID_PATTERN_OF_DAG_ID_INDEX + 3);
		ThreadLocalContextHolder.switchDataSoureByDagId(dagId);
		String invoiceNo;
		if("1".equals(paperInvoiceParamter.getRecordType())){
			invoiceNo = MAKE_OUT_AN_INVOICE;
		}else{
			invoiceNo = RDD_PUNCHING_INVOICE;
		}
		orderInvoiceClient.updatePaperInvoiceInvoiceNo(orderId, invoiceNo);
		return new ResultBody();
	}
	
	
	
	
	
}
