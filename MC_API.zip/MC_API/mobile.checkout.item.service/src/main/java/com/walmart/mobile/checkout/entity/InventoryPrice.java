package com.walmart.mobile.checkout.entity;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.walmart.mobile.checkout.entity.document.BaseDocument;

@CompoundIndex(name = "ix-product_id-store_id", def = "{'store_id' : 1, 'product_id' : 1}")
@Document(collection = "inventory_price")
public class InventoryPrice extends BaseDocument<BigInteger> {
	private static final long serialVersionUID = 1L;

	public static final int STOCK_STATUS_ALWAYS_IN_STOCK = 1;
	public static final int STOCK_STATUS_NEED_CHECK_STOCK = 0;
	public static final int STOCK_STATUS_NOT_AVAILIABLE_IN_STORE = 2;

	// client side only need in_stock/out_of_stock
	public static final int CLIENT_STOCK_STATUS_INSTOCK = 1;
	public static final int CLIENT_STOCK_STATUS_OUTOFSTOCK = 0;
	public static final int CLIENT_STOCK_RESTRICTED_PURCHASE = 2;// 限制购买
	public static final int CLIENT_STOCK_STATUS_OUTOFSTOCK_DEFAULT = 0;

	public static final int SAFE_INVENTORY = 10;

	@Field("product_id")
	private Long productId;
	@Field("store_id")
	private Integer storeId;
	@Field("upc")
	private Long upc;
	@Field("price_with_tax")
	private Float priceWithTax = 0.0f;
	@Field("inventory")
	private Integer inventory = 0;
	@Field("was_price")
	private Float wasPrice = 0.0f;
	@Field("price_start_date")
	private Date priceStartDate;
	@Field("price_end_date")
	private Date priceEndDate;
	@Field("stock_status")
	private Integer stockStatus;
	@Field("price_without_tax")
	private BigDecimal priceWithoutTax;
	@Field("tax_rate")
	private BigDecimal taxRate;
	@Field("unit_cost")
	private BigDecimal unitCost;
	@Field("promotion_desc_cn")
	private String promotionDescCn;
	@Field("gp_offer_ids")
	private List<Integer> gpOfferIds;
	@Field("gp_offers")
	private List<OfferForItem> gpOffers;
	@Field("desc_online")
	private String descOnline;
	@Field("restriction_qty")
	private Integer restrictionQty;
	@Field("report_code")
	private Integer reportCode;
	@Field("pos_desc")
	private String posDescOnline;
	@Field("magnetic_flag")
	private Integer magneticFlag;
	@Field("package_code")
	private Integer packageCode;

	@Field("item_number")
	private Long itemNumber;

	@Field("ews_flag")
	private Integer ewsFlag;

	@Field("relation_item_number")
	private Long relationItemNumber;

	@Field("department_wm_internal")
	private Integer departmentWmInternal;
	/**
	 * 复合条码商品标记 1、是
	 */
	@Field("unit_flag")
	private Integer unitFlag;

	@Field("associate_discount_flag") // Y/N 是与否
	private String assocDisc;

	public String getAssocDisc() {
		return assocDisc;
	}

	public void setAssocDisc(String assocDisc) {
		this.assocDisc = assocDisc;
	}

	public Long getRelationItemNumber() {
		return relationItemNumber;
	}

	public void setRelationItemNumber(Long relationItemNumber) {
		this.relationItemNumber = relationItemNumber;
	}

	public Integer getStoreId() {
		return storeId;
	}

	public Integer getPackageCode() {
		return packageCode;
	}

	public void setPackageCode(Integer packageCode) {
		this.packageCode = packageCode;
	}

	public Integer getRestrictionQty() {
		return restrictionQty;
	}

	public void setDescOnline(String descOnline) {
		this.descOnline = descOnline;
	}

	public String getDescOnline() {
		return descOnline;
	}

	public Float getPriceWithTax() {
		if (priceWithTax != null) {
			return new BigDecimal(priceWithTax.toString()).setScale(2, BigDecimal.ROUND_HALF_UP).floatValue();
		}
		return priceWithTax;
	}

	public Integer getInventory() {
		return inventory == null ? 0 : inventory;
	}

	public Float getWasPrice() {
		return wasPrice;
	}

	public Date getPriceStartDate() {
		return priceStartDate;
	}

	public Date getPriceEndDate() {
		return priceEndDate;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public void setRestrictionQty(Integer restrictionQty) {
		this.restrictionQty = restrictionQty;
	}

	public void setPriceWithTax(Float priceWithTax) {
		this.priceWithTax = priceWithTax;
	}

	public void setInventory(Integer inventory) {
		this.inventory = inventory;
	}

	public void setWasPrice(Float wasPrice) {
		this.wasPrice = wasPrice;
	}

	public void setPriceStartDate(Date priceStartDate) {
		this.priceStartDate = priceStartDate;
	}

	public void setPriceEndDate(Date priceEndDate) {
		this.priceEndDate = priceEndDate;
	}

	public Long getUpc() {
		return upc;
	}

	public void setUpc(Long upc) {
		this.upc = upc;
	}

	public Integer getStockStatus() {
		return stockStatus;
	}

	public void setStockStatus(Integer stockStatus) {
		this.stockStatus = stockStatus;
	}

	public int getClientStockStatus() {
		if (stockStatus == null) {
			return CLIENT_STOCK_STATUS_OUTOFSTOCK;
		}
		switch (stockStatus) {
		case InventoryPrice.STOCK_STATUS_ALWAYS_IN_STOCK:
			return CLIENT_STOCK_STATUS_INSTOCK;
		case InventoryPrice.STOCK_STATUS_NOT_AVAILIABLE_IN_STORE:
			return CLIENT_STOCK_STATUS_OUTOFSTOCK;
		case InventoryPrice.STOCK_STATUS_NEED_CHECK_STOCK:
			return inventory != null ? CLIENT_STOCK_STATUS_INSTOCK : CLIENT_STOCK_STATUS_OUTOFSTOCK;
		default:
			return CLIENT_STOCK_STATUS_OUTOFSTOCK_DEFAULT;
		}
	}

	public BigDecimal getPriceWithoutTax() {
		return priceWithoutTax;
	}

	public void setPriceWithoutTax(BigDecimal priceWithoutTax) {
		this.priceWithoutTax = priceWithoutTax;
	}

	public BigDecimal getTaxRate() {
		return taxRate;
	}

	public void setTaxRate(BigDecimal taxRate) {
		this.taxRate = taxRate;
	}

	public BigDecimal getUnitCost() {
		return unitCost;
	}

	public void setUnitCost(BigDecimal unitCost) {
		this.unitCost = unitCost;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public String getPromotionDescCn() {
		return this.promotionDescCn;
	}

	public List<Integer> getGpOfferIds() {
		return gpOfferIds;
	}

	public void setPromotionDescCn(String promotionDescCn) {
		this.promotionDescCn = promotionDescCn;
	}

	public void setGpOfferIds(List<Integer> gpOfferIds) {
		this.gpOfferIds = gpOfferIds;
	}

	public List<OfferForItem> getGpOffers() {
		return gpOffers;
	}

	public void setGpOffers(List<OfferForItem> gpOffers) {
		this.gpOffers = gpOffers;
	}

	@Override
	public int hashCode() {
		return this.getId() == null ? 0 : this.getId().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (!(obj instanceof InventoryPrice)) {
			return false;
		}
		InventoryPrice other = (InventoryPrice) obj;
		return this.getId().equals(other.getId());
	}

	/**
	 * @return the reportCode
	 */
	public Integer getReportCode() {
		return reportCode;
	}

	/**
	 * @param reportCode
	 *            the reportCode to set
	 */
	public void setReportCode(Integer reportCode) {
		this.reportCode = reportCode;
	}

	public String getPosDescOnline() {
		return posDescOnline;
	}

	public void setPosDescOnline(String posDescOnline) {
		this.posDescOnline = posDescOnline;
	}

	public Long getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(Long itemNumber) {
		this.itemNumber = itemNumber;
	}

	public Integer getMagneticFlag() {
		return magneticFlag == null ? 0 : magneticFlag;
	}

	public void setMagneticFlag(Integer magneticFlag) {
		this.magneticFlag = magneticFlag;
	}

	public Integer getEwsFlag() {
		return ewsFlag;
	}

	public void setEwsFlag(Integer ewsFlag) {
		this.ewsFlag = ewsFlag;
	}

	public Integer getDepartmentWmInternal() {
		return departmentWmInternal;
	}

	public void setDepartmentWmInternal(Integer departmentWmInternal) {
		this.departmentWmInternal = departmentWmInternal;
	}

	public Integer getUnitFlag() {
		return unitFlag == null ? 0 : unitFlag;
	}

	public void setUnitFlag(Integer unitFlag) {
		this.unitFlag = unitFlag;
	}

}