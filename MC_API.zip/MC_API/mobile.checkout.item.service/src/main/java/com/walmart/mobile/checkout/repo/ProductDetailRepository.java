package com.walmart.mobile.checkout.repo;

import org.springframework.data.repository.CrudRepository;
import java.math.BigInteger;
import java.util.List;
import com.walmart.mobile.checkout.entity.ProductDetail;

public interface ProductDetailRepository extends
		CrudRepository<ProductDetail, BigInteger> {
	
	ProductDetail findByItemNumber(Long itemNumber);
	ProductDetail findByUpc(Long upc);
	List<ProductDetail> findByItemNumberIn(List<Long> itemNumbers);

}
