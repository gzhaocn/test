package com.walmart.mobile.checkout.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.walmart.mobile.checkout.bo.ItemDetail;
import com.walmart.mobile.checkout.bo.ItemScanResp;
import com.walmart.mobile.checkout.bo.ShoppingCartResp;
import com.walmart.mobile.checkout.constant.ItemErrorInfoEnum;
import com.walmart.mobile.checkout.domain.StoreVo;
import com.walmart.mobile.checkout.entity.GpOfferForItem;
import com.walmart.mobile.checkout.entity.InventoryPrice;
import com.walmart.mobile.checkout.entity.NoDeliverItem;
import com.walmart.mobile.checkout.entity.ProductDetail;
import com.walmart.mobile.checkout.entity.ShoppingItem;
import com.walmart.mobile.checkout.entity.SpecialItem;
import com.walmart.mobile.checkout.entity.StoreShoppingBagForItem;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.repo.InventoryPriceRepository;
import com.walmart.mobile.checkout.repo.NoDeliverItemRepository;
import com.walmart.mobile.checkout.repo.ProductDetailRepository;
import com.walmart.mobile.checkout.repo.SpecialItemRepository;
import com.walmart.mobile.checkout.rest.StoreServiceClient;
import com.walmart.mobile.checkout.rest.item.GpOfferServiceItemClient;
import com.walmart.mobile.checkout.rest.item.StoreShoppingBagClient;
import com.walmart.mobile.checkout.utils.ScanItemUtil;

@Service
public class ItemService {

	private static final int SCALEITEMTYPE = 1; // scale item type：1

	private static final int UN_DELIVER_ITEM = 0;
	private static final int DELIVER_ITEM = 1;

	@Autowired
	InventoryPriceRepository inventoryPriceRepository;
	@Autowired
	ProductDetailRepository productDetailRepository;
	@Autowired
	StoreShoppingBagClient storeShoppingBagClient;
	@Autowired
	GpOfferServiceItemClient gpOfferServiceClient;

	@Autowired
	SpecialItemRepository specialItemRepository;

	@Autowired
	NoDeliverItemRepository noDeliverItemRepository;

	@Autowired
	StoreServiceClient storeServiceClient;

	// add by leo begin

	public InventoryPrice findByStoreIdAndProductId(Integer storeId, Long productId) {
		return inventoryPriceRepository.findByStoreIdAndProductId(storeId, productId);
	}

	public InventoryPrice findByStoreIdAndUpc(Integer storeId, Long upc) {
		return inventoryPriceRepository.findByStoreIdAndUpc(storeId, upc);
	}

	/**
	 * public ProductDetail findByProductId(Long productId) { return
	 * productDetailRepository.findByProductId(productId); }
	 */
	/**
	 * public void productDetailSave(ProductDetail productDetail) {
	 * productDetailRepository.save(productDetail); }
	 * 
	 * public void inventoryPriceSave(InventoryPrice inventoryPrice) {
	 * inventoryPriceRepository.save(inventoryPrice); }
	 */

	public ProductDetail findByItemNumber(Long itemNumber) {
		return productDetailRepository.findByItemNumber(itemNumber);
	}

	public List<InventoryPrice> findByStoreIdAndItemNumberIn(Integer storeId, List<Long> itemNumbers) {
		return inventoryPriceRepository.findByStoreIdAndItemNumberIn(storeId, itemNumbers);
	}

	public InventoryPrice findByStoreIdAndItemNumber(Integer storeId, Long itemNumber) {
		return inventoryPriceRepository.findByStoreIdAndItemNumber(storeId, itemNumber);
	}

	public List<SpecialItem> findByUpcIn(List<Long> upcs) {
		return specialItemRepository.findByUpcIn(upcs);
	}

	public List<NoDeliverItem> findByNoDeliveryItemUpcIn(List<Long> upcs) {
		return noDeliverItemRepository.findByUpcIn(upcs);
	}

	// add by leo end

	private InventoryPrice getInventoryPrice(Integer storeId, Long number, Boolean isUpc) throws GlobalErrorInfoException {
		InventoryPrice invPrice;
		if (isUpc) {
			invPrice = this.inventoryPriceRepository.findByStoreIdAndUpc(storeId, ScanItemUtil.convertUpc(number));
		} else {
			invPrice = this.inventoryPriceRepository.findByStoreIdAndItemNumber(storeId, number);
		}
		if (invPrice == null) {
			throw new GlobalErrorInfoException(ItemErrorInfoEnum.ITEM_NOT_FOUND);
		} else {
			if (invPrice.getRelationItemNumber() != null) {
				invPrice = this.inventoryPriceRepository.findByStoreIdAndItemNumber(storeId, invPrice.getRelationItemNumber());
			}
		}
		return invPrice;
	}

	/**
	 * for scan interface, get by itemNumber
	 * 
	 * @param storeId
	 * @param itemNumber
	 *            (start with 40)
	 * @throws GlobalErrorInfoException
	 */
	public ItemScanResp getItemDetailByItemNumber(Integer storeId, Long itemNumber) throws GlobalErrorInfoException {
		InventoryPrice invPrice = getInventoryPrice(storeId, itemNumber, false);
		return getItemDetailByItemNumber(invPrice.getItemNumber(), invPrice);
	}

	private ItemScanResp getItemDetailByItemNumber(Long itemNumber, InventoryPrice invPrice) throws GlobalErrorInfoException {
		ProductDetail productDetail = productDetailRepository.findByItemNumber(itemNumber);
		ItemScanResp itemScanResp = null;
		if (productDetail != null) {
			itemScanResp = new ItemScanResp();
			if (!invPrice.getGpOfferIds().isEmpty()) {
				itemScanResp.getGpOfferList().addAll(gpOfferServiceClient.findByGpOfferIdInAndStatus(invPrice.getGpOfferIds(), 0));
			}
			ItemDetail itemDetail = new ItemDetail();
			itemDetail.setBarCode(ScanItemUtil.getBarCode(productDetail.getUpc(), invPrice.getPriceWithTax()));
			if (ScanItemUtil.isSpecialScaleItem(productDetail.getUpc())) {
				itemDetail.setSpecialScaleItem(1);
			}

			if (productDetail.getItemType() == SCALEITEMTYPE) {
				itemDetail.setAmount(ScanItemUtil.getScanItemPriceWithTax(ScanItemUtil.getBarCode(productDetail.getUpc(), invPrice.getPriceWithTax())));
				if (new Integer(0).equals(invPrice.getPackageCode()) && ScanItemUtil.isSpecialScaleItem(productDetail.getUpc())) {
					throw new GlobalErrorInfoException(ItemErrorInfoEnum.SCAN_ERROR);
				}
				if (ScanItemUtil.isSpecialScaleItem(productDetail.getUpc()) && invPrice.getPackageCode() == null) {
					throw new GlobalErrorInfoException(ItemErrorInfoEnum.SCAN_DATA_ERROR);
				}
			}
			setResponse(invPrice, productDetail, itemDetail);

			// 设置是否支持配送 1：支持配送 ，0 不支持配送
			this.setDeliverItemFlag(productDetail.getUpc(), itemDetail);

			itemScanResp.setItemDetail(itemDetail);
		}
		return itemScanResp;
	}

	public ItemScanResp getItemDetailByStoreIdAndUpc(Integer storeId, Long upc) throws GlobalErrorInfoException {
		InventoryPrice invPrice = getInventoryPrice(storeId, upc, true);
		return getItemDetailByStoreIdAndUpc(ScanItemUtil.isScaleItem(upc) ? upc : invPrice.getUpc(), invPrice);
	}

	/**
	 * for scan interface
	 * 
	 * @param storeId
	 * @param upc
	 *            (scale item contained amount)
	 * @throws GlobalErrorInfoException
	 */
	private ItemScanResp getItemDetailByStoreIdAndUpc(Long upc, InventoryPrice invPrice) throws GlobalErrorInfoException {
		ItemScanResp itemScanResp = null;
		ProductDetail productDetail = productDetailRepository.findByItemNumber(invPrice.getItemNumber());
		if (productDetail != null) {
			itemScanResp = new ItemScanResp();
			if (!invPrice.getGpOfferIds().isEmpty()) {
				itemScanResp.getGpOfferList().addAll(gpOfferServiceClient.findByGpOfferIdInAndStatus(invPrice.getGpOfferIds(), 0));
			}
			ItemDetail itemDetail = new ItemDetail();
			itemDetail.setBarCode(ScanItemUtil.getBarCode(upc, invPrice.getPriceWithTax()));
			if (ScanItemUtil.isSpecialScaleItem(upc)) {
				itemDetail.setSpecialScaleItem(1);
			}
			if (productDetail.getItemType() == SCALEITEMTYPE) {
				if (new Integer(0).equals(invPrice.getPackageCode()) && ScanItemUtil.isSpecialScaleItem(upc)) {
					throw new GlobalErrorInfoException(ItemErrorInfoEnum.SCAN_ERROR);
				}
				if (ScanItemUtil.isSpecialScaleItem(upc) && invPrice.getPackageCode() == null) {
					throw new GlobalErrorInfoException(ItemErrorInfoEnum.SCAN_DATA_ERROR);
				}
				itemDetail.setAmount(ScanItemUtil.getScanItemPriceWithTax(ScanItemUtil.getBarCode(upc, invPrice.getPriceWithTax())));
			}
			setResponse(invPrice, productDetail, itemDetail);

			// 设置是否支持配送 1：支持配送 ，0 不支持配送
			this.setDeliverItemFlag(productDetail.getUpc(), itemDetail);

			itemScanResp.setItemDetail(itemDetail);
		}
		return itemScanResp;
	}

	

	/**
	 * for shopping card update interface
	 * 
	 * @param storeId
	 * @param shoppingItems
	 * @throws GlobalErrorInfoException
	 */
	public ShoppingCartResp updateShoppingCartItems(Integer storeId, List<ShoppingItem> shoppingItems) throws GlobalErrorInfoException {
		ShoppingCartResp itemCartResp = new ShoppingCartResp();
		List<Long> productIds = new ArrayList<>();
		for (ShoppingItem shoppingItem : shoppingItems) {
			productIds.add(shoppingItem.getProductId());
		}

		List<InventoryPrice> inventoryPriceList = inventoryPriceRepository.findByStoreIdAndProductIdIn(storeId, productIds);
		List<Long> itemNumbers = new ArrayList<>();
		Map<Long, Long> productIdAndItemNumberMap = new HashMap<>(16);
		for (InventoryPrice inventoryPrice : inventoryPriceList) {
			itemNumbers.add(inventoryPrice.getItemNumber());
			productIdAndItemNumberMap.put(inventoryPrice.getProductId(), inventoryPrice.getItemNumber());
		}

		List<ProductDetail> productDetails = productDetailRepository.findByItemNumberIn(itemNumbers);

		//
		List<Long> upcList = new ArrayList<>();
		for (ProductDetail productDetail : productDetails) {
			upcList.add(productDetail.getUpc());
		}
		Map<Long, Long> noDeliverItemMap = new HashMap<>(16);
		List<NoDeliverItem> noDeliverItemList = noDeliverItemRepository.findByUpcIn(upcList);
		for (NoDeliverItem noDeliverItem : noDeliverItemList) {
			noDeliverItemMap.put(noDeliverItem.getUpc(), noDeliverItem.getUpc());
		}

		Map<Long, ProductDetail> productDetailMap = new HashMap<>(16);
		for (ProductDetail productDetail : productDetails) {
			productDetailMap.put(productDetail.getItemNumber(), productDetail);
		}

		List<ItemDetail> shoppingBagItemDetailList = getShoppingBagItemDetailList(storeId);
		Map<Long, InventoryPrice> inventoryPriceMap = new HashMap<>(16);
		List<Integer> offerIds = new ArrayList<>();
		for (InventoryPrice inventoryPrice : inventoryPriceList) {
			inventoryPriceMap.put(inventoryPrice.getProductId(), inventoryPrice);
			offerIds.addAll(inventoryPrice.getGpOfferIds());
		}
		for (ItemDetail itemDetial : shoppingBagItemDetailList) {
			offerIds.addAll(itemDetial.getGpOfferIds());
		}
		itemCartResp.getShoppingBagList().addAll(shoppingBagItemDetailList);
		List<GpOfferForItem> listGpOffers = gpOfferServiceClient.findByGpOfferIdInAndStatus(offerIds, 0);
		itemCartResp.getGpOfferList().addAll(listGpOffers);

		for (ShoppingItem shoppingItem : shoppingItems) {
			Long productId = shoppingItem.getProductId();
			ItemDetail itemDetail = new ItemDetail();
			ProductDetail productDetail = null;
			if (productIdAndItemNumberMap.containsKey(productId)) {
				productDetail = productDetailMap.get(productIdAndItemNumberMap.get(productId));
			}
			InventoryPrice invPrice = inventoryPriceMap.get(productId);
			
			if (invPrice == null || productDetail == null){
				continue;
			}
			
			// for special scale item, reset barCode and amount
			if (shoppingItem.getSpecialScaleItem() == 1) {
				itemDetail.setBarCode(ScanItemUtil.getBarCode(productDetail.getUpc(), invPrice.getPriceWithTax()));
				itemDetail.setAmount(ScanItemUtil.getScanItemPriceWithTax(ScanItemUtil.getBarCode(productDetail.getUpc(), invPrice.getPriceWithTax())));
			} else {
				itemDetail.setBarCode(shoppingItem.getBarCode());
				itemDetail.setAmount(shoppingItem.getAmount());
			}
			itemDetail.setSpecialScaleItem(shoppingItem.getSpecialScaleItem());
			itemDetail.setCartItemId(shoppingItem.getCartItemId());
			setResponse(invPrice, productDetail, itemDetail);

			if (noDeliverItemMap.containsKey(productDetail.getUpc())) {
				itemDetail.setDeliverFlag(UN_DELIVER_ITEM);
			} else {
				itemDetail.setDeliverFlag(DELIVER_ITEM);
			}

			itemCartResp.getItemDetailList().add(itemDetail);
		}
		itemCartResp.getDeliveryItemList().addAll(getDeliveryItemList(storeId));
		
		return itemCartResp;
	}

	/**
	 * public List<ProductDetail> findByProductIdIn(List<Long> productIds) {
	 * return productDetailRepository.findByProductIdIn(productIds); }
	 */
	public List<ProductDetail> findByItemNumberIn(List<Long> itemNumbers) {
		return productDetailRepository.findByItemNumberIn(itemNumbers);
	}

	public List<InventoryPrice> selectInventoryPriceByStoreAndProductIds(int storeId, List<Long> productIds) throws GlobalErrorInfoException {
		if (null == productIds || productIds.isEmpty()) {
			return new ArrayList<>();
		}
		return this.inventoryPriceRepository.findByStoreIdAndProductIdIn(storeId, productIds);
	}

	/**
	 * build Response replace productId to UPC(contained amount) for Scale Item
	 * 
	 * @param invPrice
	 * @param itemDetail
	 * @param productDetail
	 * @throws GlobalErrorInfoException
	 */
	private void setResponse(InventoryPrice invPrice, ProductDetail productDetail, ItemDetail itemDetail) throws GlobalErrorInfoException {
		itemDetail.setDescOnlineDetailHtml(productDetail.getDescOnlineDetailHtml());
		itemDetail.setItemType(productDetail.getItemType());
		itemDetail.setProductId(invPrice.getProductId());
		itemDetail.setStockStatus(invPrice.getStockStatus());
		itemDetail.setRestrictionQty(invPrice.getRestrictionQty());
		if (invPrice.getDescOnline() == null || invPrice.getDescOnline().isEmpty()) {
			itemDetail.setDescOnline(productDetail.getDescOnline());
		} else {
			itemDetail.setDescOnline(invPrice.getDescOnline());
		}
		itemDetail.setWasPrice(invPrice.getWasPrice());
		itemDetail.setPriceWithTax(invPrice.getPriceWithTax());
		itemDetail.setStoreId(invPrice.getStoreId());
		itemDetail.setSalesQty(productDetail.getSalesQty());
		/** itemDetail.setPromotionDescCn(invPrice.getPromotionDescCn()); */
		if (productDetail.getSalesAmt() != null) {
			itemDetail.setSalesAmt(productDetail.getSalesAmt());
		} else {
			itemDetail.setSalesAmt(0);
		}
		itemDetail.setInventory(invPrice.getInventory());
		if (invPrice.getGpOffers() != null) {
			itemDetail.setGpOffers(invPrice.getGpOffers());
		}
		itemDetail.setGpOfferIds(invPrice.getGpOfferIds());
		itemDetail.setImgUrl(productDetail.getImgUrl());
		itemDetail.setThumbnailUrl(productDetail.getThumbnailUrl());
		itemDetail.setProductFlag(productDetail.getProductFlag());
		itemDetail.setSpecifications(productDetail.getSpecifications());
		itemDetail.setMagneticFlag(invPrice.getMagneticFlag());
		itemDetail.setPackageCode(invPrice.getPackageCode());
		itemDetail.setEwsFlag(invPrice.getEwsFlag());
		itemDetail.setAssocDisc(invPrice.getAssocDisc());
	}

	/**
	 * get shopping bag item details
	 * 
	 * @param storeId
	 * @throws GlobalErrorInfoException
	 */
	private List<ItemDetail> getShoppingBagItemDetailList(Integer storeId) throws GlobalErrorInfoException {
		List<ItemDetail> shoppingBagItemDetailList = new ArrayList<>();
		List<StoreShoppingBagForItem> storeShoppingBagList = storeShoppingBagClient.getShoppingBagByStoreId(storeId);
		List<Long> itemNumbers = new ArrayList<>();
		for (StoreShoppingBagForItem storeShoppingBag : storeShoppingBagList) {
			itemNumbers.add(storeShoppingBag.getItemNumber());
		}

		List<ProductDetail> productDetails = productDetailRepository.findByItemNumberIn(itemNumbers);
		Map<Long, ProductDetail> productDetailMap = new HashMap<>(16);
		for (ProductDetail productDetail : productDetails) {
			productDetailMap.put(productDetail.getItemNumber(), productDetail);
		}

		List<InventoryPrice> inventoryPriceList = inventoryPriceRepository.findByStoreIdAndItemNumberIn(storeId, itemNumbers);
		Map<Long, InventoryPrice> inventoryPriceMap = new HashMap<>(16);
		for (InventoryPrice inventoryPrice : inventoryPriceList) {
			inventoryPriceMap.put(inventoryPrice.getItemNumber(), inventoryPrice);
		}

		for (StoreShoppingBagForItem storeShoppingBag : storeShoppingBagList) {
			Long itemNumber = storeShoppingBag.getItemNumber();
			ItemDetail itemDetail = new ItemDetail();
			ProductDetail productDetail = productDetailMap.get(itemNumber);
			InventoryPrice invPrice = inventoryPriceMap.get(itemNumber);
			if (invPrice != null && productDetail != null) {
				setResponse(invPrice, productDetail, itemDetail);
				itemDetail.setBarCode(invPrice.getUpc());
				itemDetail.setDescOnline(storeShoppingBag.getDescOnline());
				shoppingBagItemDetailList.add(itemDetail);
			}
		}
		Collections.sort(shoppingBagItemDetailList, new Comparator<ItemDetail>() {
			@Override
			public int compare(ItemDetail o1, ItemDetail o2) {
				return o1.getPriceWithTax().compareTo(o2.getPriceWithTax());
			}
		});

		return shoppingBagItemDetailList;
	}

	private void setDeliverItemFlag(Long upc, ItemDetail itemDetail) {
		// 设置是否支持配送 1：支持配送 ，0 不支持配送
		NoDeliverItem noDeliverItem = noDeliverItemRepository.findByUpc(upc);
		if (noDeliverItem == null) {
			itemDetail.setDeliverFlag(DELIVER_ITEM);
		} else {
			itemDetail.setDeliverFlag(UN_DELIVER_ITEM);
		}
	}

	private List<ItemDetail> getDeliveryItemList(Integer storeId) {
		List<ItemDetail> deliveryItemList = new ArrayList<>();
		StoreVo storeVo = storeServiceClient.findByStoreId(storeId);

		if (storeVo.getDeliveryFlag() != 1 || storeVo.getDeliveryItemUpc() == null) {

		} else {
			ItemDetail itemDetail = new ItemDetail();
			if (storeVo.getDeliveryThreshold() != null) {
				itemDetail.setDeliveryThreshold(storeVo.getDeliveryThreshold());
			}
			InventoryPrice inventoryPrice = inventoryPriceRepository.findByStoreIdAndUpc(storeId, storeVo.getDeliveryItemUpc());
			itemDetail.setPriceWithTax(inventoryPrice.getPriceWithTax());
			itemDetail.setProductId(inventoryPrice.getProductId());
			itemDetail.setStoreId(storeId);
			itemDetail.setItemType(0);
			itemDetail.setAssocDisc(inventoryPrice.getAssocDisc());
			deliveryItemList.add(itemDetail);
		}
		return deliveryItemList;
	}
}
