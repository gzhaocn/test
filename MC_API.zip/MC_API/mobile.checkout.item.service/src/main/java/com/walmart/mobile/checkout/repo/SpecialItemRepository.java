package com.walmart.mobile.checkout.repo;

import java.math.BigInteger;
import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.walmart.mobile.checkout.entity.SpecialItem;

public interface SpecialItemRepository extends CrudRepository<SpecialItem, BigInteger> {
	SpecialItem findByUpc( Long upc);
	
	List<SpecialItem> findByUpcIn(List<Long> upcs);
}
