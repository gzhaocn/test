package com.walmart.mobile.checkout.entity;

import java.io.Serializable;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel
public class ShoppingItem implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6207495921219106428L;

	@ApiModelProperty(value = "商品编码")
	private Long productId;

	@ApiModelProperty(value = "金额")
	private Float amount;

	@ApiModelProperty(value = "二维码")
	private Long barCode;

	@ApiModelProperty(value = "cartItemId")
	private Long cartItemId;

	@ApiModelProperty(value = "specialScaleItem")
	private Integer specialScaleItem=0;//for client, used for 21 + 00000 special item

	
	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public Float getAmount() {
		return amount;
	}

	public void setAmount(Float amount) {
		this.amount = amount;
	}

	public Long getBarCode() {
		return barCode;
	}

	public void setBarCode(Long barCode) {
		this.barCode = barCode;
	}

	public Long getCartItemId() {
		return cartItemId;
	}

	public void setCartItemId(Long cartItemId) {
		this.cartItemId = cartItemId;
	}
	
	public Integer getSpecialScaleItem() {
		return specialScaleItem;
	}

	public void setSpecialScaleItem(Integer specialScaleItem) {
		this.specialScaleItem = specialScaleItem;
	}
}
