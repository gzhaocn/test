package com.walmart.mobile.checkout.repo;

import java.math.BigInteger;
import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.walmart.mobile.checkout.entity.InventoryPrice;

public interface InventoryPriceRepository extends CrudRepository<InventoryPrice, BigInteger> {

	InventoryPrice findByStoreIdAndProductId(Integer storeId, Long productId);

	InventoryPrice findByStoreIdAndUpc(Integer storeId, Long upc);

	InventoryPrice findByStoreIdAndItemNumber(Integer storeId, Long itemNumber);

	List<InventoryPrice> findByStoreIdAndProductIdIn(Integer storeId, List<Long> productIdList);

	List<InventoryPrice> findByStoreIdAndItemNumberIn(Integer storeId, List<Long> itemNumberList);

	List<InventoryPrice> findByProductIdIn(List<Long> productIdList);

}