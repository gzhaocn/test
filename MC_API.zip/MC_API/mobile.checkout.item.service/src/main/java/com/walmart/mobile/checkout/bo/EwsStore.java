package com.walmart.mobile.checkout.bo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel
public class EwsStore {
	@ApiModelProperty(value = "门店号码", required = true)
	private Integer storeId;

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}
}
