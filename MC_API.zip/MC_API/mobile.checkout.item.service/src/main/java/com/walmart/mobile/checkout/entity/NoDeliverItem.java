package com.walmart.mobile.checkout.entity;

import java.math.BigInteger;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.walmart.mobile.checkout.entity.document.BaseDocument;

@Document(collection = "no_deliver_item")
public class NoDeliverItem extends BaseDocument<BigInteger> implements Comparable<NoDeliverItem> {

	private static final long serialVersionUID = -2916199798323882836L;

	@Field("upc")
	private Long upc;
	
	public Long getUpc() {
		return upc;
	}

	public void setUpc(Long upc) {
		this.upc = upc;
	}

	@Override
	public int compareTo(NoDeliverItem o) {
		return this.upc.compareTo(o.getUpc());
	}

	@Override
	public int hashCode() {
		return this.getUpc() == null ? 0 : this.getUpc().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (!(obj instanceof NoDeliverItem)) {
			return false;
		}
		NoDeliverItem other = (NoDeliverItem) obj;
		return this.getUpc().equals(other.getUpc());
	}
	

}
