package com.walmart.mobile.checkout.entity;

import java.math.BigDecimal;
import java.math.BigInteger;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.walmart.mobile.checkout.entity.document.BaseDocument;

@Document(collection = "ews_price")
public class EwsPrice extends BaseDocument<BigInteger> implements Comparable<EwsPrice> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1917288188019505924L;
	@Field("category")
	private String category;
	@Field("item_number")
	private Long itemNumber;
	@Field("start_price")
	private BigDecimal startPrice;
	@Field("end_price")
	private BigDecimal endPrice;
	@Field("time_slot")
	private Integer timeSlot;
	@Field("ews_price")
	private BigDecimal extendedWarrantyPrice;
	@Field("ews_barcode")
	private Long ewsBarcode;
	@Field("desc")
	private String desc;
	private String assocDisc;

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Long getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(Long itemNumber) {
		this.itemNumber = itemNumber;
	}

	public BigDecimal getStartPrice() {
		return startPrice;
	}

	public void setStartPrice(BigDecimal startPrice) {
		this.startPrice = startPrice;
	}

	public BigDecimal getEndPrice() {
		return endPrice;
	}

	public void setEndPrice(BigDecimal endPrice) {
		this.endPrice = endPrice;
	}

	public Integer getTimeSlot() {
		return timeSlot;
	}

	public void setTimeSlot(Integer timeSlot) {
		this.timeSlot = timeSlot;
	}

	public Long getEwsBarcode() {
		return ewsBarcode;
	}

	public void setEwsBarcode(Long ewsBarcode) {
		this.ewsBarcode = ewsBarcode;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	@Override
	public int compareTo(EwsPrice o) {
		if (o == null) {
			return -1;
		}
		return this.itemNumber.compareTo(o.getItemNumber());
	}

	@Override
	public int hashCode() {
		return this.getItemNumber() == null ? 0 : this.getItemNumber().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (!(obj instanceof EwsPrice)) {
			return false;
		}
		EwsPrice other = (EwsPrice) obj;
		return this.getItemNumber().equals(other.getItemNumber());
	}

	public BigDecimal getExtendedWarrantyPrice() {
		return extendedWarrantyPrice;
	}

	public void setExtendedWarrantyPrice(BigDecimal extendedWarrantyPrice) {
		this.extendedWarrantyPrice = extendedWarrantyPrice;
	}

	public String getAssocDisc() {
		return assocDisc;
	}

	public void setAssocDisc(String assocDisc) {
		this.assocDisc = assocDisc;
	}
}
