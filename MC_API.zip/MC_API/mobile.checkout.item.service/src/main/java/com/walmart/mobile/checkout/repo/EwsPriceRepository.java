package com.walmart.mobile.checkout.repo;

import java.math.BigInteger;

import org.springframework.data.repository.CrudRepository;

import com.walmart.mobile.checkout.entity.EwsPrice;

public interface EwsPriceRepository extends CrudRepository<EwsPrice, BigInteger> {

}
