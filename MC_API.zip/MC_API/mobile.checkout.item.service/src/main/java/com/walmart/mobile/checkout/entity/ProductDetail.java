package com.walmart.mobile.checkout.entity;

import java.math.BigInteger;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.walmart.mobile.checkout.entity.document.BaseDocument;

@Document(collection = "product_detail")
public class ProductDetail extends BaseDocument<BigInteger> implements Comparable<ProductDetail> {
	private static final long serialVersionUID = 1L;

	public static final int PRODUCT_STATUS_ACTIVE = 0;
	public static final int PRODUCT_STATUS_DELETED = 1;
	public static final int PRODUCT_STATUS_OFFLINE = 2;

	public static final int RETURN_WITHIN_DAYS = 7;
	@Indexed
	private Long upc;
	@Field("desc_online")
	private String descOnline;
	@Field("keywords")
	private List<String> keywords;
	@Field("desc_online_detail_html")
	private String descOnlineDetailHtml;
	@Field("category_online")
	private HashSet<Integer> categoryOnline;
	@Field("department_wm_internal")
	private Integer departmentWmInternal;
	@Field("fineline_wm_internal")
	private Integer finelineWmInternal;
	private LinkedHashMap<String, String> specifications;
	@Field("thumbnail_url")
	private String thumbnailUrl;
	@Field("img_url")
	private String[] imgUrl;
	@Field("sales_qty")
	private Integer salesQty;
	@Field("sales_amt")
	private Integer salesAmt;
	@Field("product_flag")
	private List<Integer> productFlag;
	@Field("return_within_days")
	private Integer returnWithinDays;
	@Field("status")
	private Integer status;
	@Field("brand_name")
	private String brandName;

	@Field("item_type")
	private Integer itemType;

	@Field("item_number")
	private Long itemNumber;

	public ProductDetail() {
		// 构造函数
	}

	public ProductDetail(BigInteger id) {
		setId(id);
	}

	public String getDescOnline() {
		if (StringUtils.isNotBlank(brandName)) {
			return brandName + " " + descOnline;
		} else {
			return descOnline;
		}
	}

	public String getDescOnlineDetailHtml() {
		return descOnlineDetailHtml;
	}

	public HashSet<Integer> getCategoryOnline() {
		return categoryOnline;
	}

	public Integer getDepartmentWmInternal() {
		return departmentWmInternal;
	}

	public Integer getFinelineWmInternal() {
		return finelineWmInternal;
	}

	public LinkedHashMap<String, String> getSpecifications() {
		return specifications;
	}

	public String getThumbnailUrl() {
		return thumbnailUrl;
	}

	public String[] getImgUrl() {
		return imgUrl;
	}

	public Integer getSalesQty() {
		return salesQty;
	}

	public List<Integer> getProductFlag() {
		return productFlag;
	}

	public Integer getReturnWithinDays() {
		return returnWithinDays;
	}

	public void setDescOnline(String descOnline) {
		this.descOnline = descOnline;
	}

	public void setDescOnlineDetailHtml(String descOnlineDetailHtml) {
		this.descOnlineDetailHtml = descOnlineDetailHtml;
	}

	public void setCategoryOnline(HashSet<Integer> categoryOnline) {
		this.categoryOnline = categoryOnline;
	}

	public void setDepartmentWmInternal(Integer departmentWmInternal) {
		this.departmentWmInternal = departmentWmInternal;
	}

	public void setFinelineWmInternal(Integer finelineWmInternal) {
		this.finelineWmInternal = finelineWmInternal;
	}

	public void setSpecifications(LinkedHashMap<String, String> specifications) {
		this.specifications = specifications;
	}

	public void setThumbnailUrl(String thumbnailUrl) {
		this.thumbnailUrl = thumbnailUrl;
	}

	public void setImgUrl(String[] imgUrl) {
		this.imgUrl = imgUrl;
	}

	public void setSalesQty(Integer salesQty) {
		this.salesQty = salesQty;
	}

	public void setProductFlag(List<Integer> productFlag) {
		this.productFlag = productFlag;
	}

	public void setReturnWithinDays(Integer returnWithinDays) {
		this.returnWithinDays = returnWithinDays;
	}

	public Long getUpc() {
		return upc;
	}

	public void setUpc(Long upc) {
		this.upc = upc;
	}

	public Integer getStatus() {
		return status == null ? 0 : status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public List<String> getKeywords() {
		return keywords;
	}

	public void setKeywords(List<String> keywords) {
		this.keywords = keywords;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public Integer getSalesAmt() {
		return salesAmt;
	}

	public void setSalesAmt(Integer salesAmt) {
		this.salesAmt = salesAmt;
	}

	@Override
	public int compareTo(ProductDetail o) {
		if (o == null) {
			return -1;
		}
		return this.upc.compareTo(o.upc);
	}

	public Integer getItemType() {
		return itemType;
	}

	public void setItemType(Integer itemType) {
		this.itemType = itemType;
	}

	@Override
	public int hashCode() {
		return this.getItemNumber() == null ? 0 : this.getItemNumber().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (!(obj instanceof ProductDetail)) {
			return false;
		}
		ProductDetail other = (ProductDetail) obj;
		return this.getItemNumber().equals(other.getItemNumber());
	}

	public Long getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(Long itemNumber) {
		this.itemNumber = itemNumber;
	}

}