package com.walmart.mobile.checkout.constant;

import com.walmart.mobile.checkout.exception.handler.ErrorInfoInterface;

/**
 * 系统及业务级别的错误码
 */
public enum ItemErrorInfoEnum implements ErrorInfoInterface {
	ITEM_NOT_FOUND("-600", "Item not found"), 
	MISSING_STOREID("-601", "Miss store Id"), 
	MISSING_PRODUCTS("-602","Product id is empty"),
	SCAN_ERROR("-603","无效扫描，请扫描商品上的磅秤标签"),
	SCAN_DATA_ERROR("-604","本商品暂时不售卖,请联系门店工作人员.");
	private String code;

	private String message;

	ItemErrorInfoEnum(String code, String message) {
		this.code = code;
		this.message = message;
	}

	@Override
	public String getCode() {
		return this.code;
	}

	@Override
	public String getMessage() {
		return this.message;
	}
}
