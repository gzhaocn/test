package com.walmart.mobile.checkout.entity;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.List;

public class GpOfferForItem {
	/**
	* 
	*/
	private Integer gpOfferId;
	private Integer gpTypeCode;
	private Date beginDate;
	private Date endDate;
	private Float discountFactor;
	private List<GroupForItem> groups;
	private String promotionDescEn;
	private String promotionDescCn;
	private String promotionActualDesc;
	private List<Long> gpOfferCategoryIds;
	private Integer backgroundColor;
	private String gpThumbnailUrl;
	private Integer status;
	private String promotionTitleCn;
	private Date updatedTime;
	private Integer discountTimes;

	public String getPromotionDesc() {
		return promotionDescCn;
	}

	public Integer getDiscountTimes() {
		return discountTimes;
	}

	public void setDiscountTimes(Integer discountTimes) {
		this.discountTimes = discountTimes;
	}

	public Integer getGpOfferId() {
		return gpOfferId;
	}

	public Integer getGpTypeCode() {
		return gpTypeCode;
	}

	public Date getBeginDate() {
		return beginDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public Float getDiscountFactor() {

		BigDecimal df = new BigDecimal(discountFactor.toString());
		return df.setScale(2, RoundingMode.HALF_UP).floatValue();
	}

	public List<GroupForItem> getGroups() {
		return groups;
	}

	public String getPromotionDescEn() {
		return promotionDescEn == null ? "" : promotionDescEn;
	}

	public String getPromotionDescCn() {
		return promotionDescCn == null ? "" : promotionDescCn.replace("{", "").replace("}", "");
	}

	public void setGpOfferId(Integer gpOfferId) {
		this.gpOfferId = gpOfferId;
	}

	public void setGpTypeCode(Integer gpTypeCode) {
		this.gpTypeCode = gpTypeCode;
	}

	public void setBeginDate(Date beginDate) {
		this.beginDate = beginDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public void setDiscountFactor(Float discountFactor) {
		this.discountFactor = discountFactor;
	}

	public void setGroups(List<GroupForItem> groups) {
		this.groups = groups;
	}

	public void setPromotionDescEn(String promotionDescEn) {
		this.promotionDescEn = promotionDescEn;
	}

	public void setPromotionDescCn(String promotionDescCn) {
		this.promotionDescCn = promotionDescCn;
	}

	public Integer getBackgroundColor() {
		return backgroundColor;
	}

	public void setBackgroundColor(Integer backgroundColor) {
		this.backgroundColor = backgroundColor;
	}

	public List<Long> getGpOfferCategoryIds() {
		return gpOfferCategoryIds;
	}

	public void setGpOfferCategoryIds(List<Long> gpOfferCategoryIds) {
		this.gpOfferCategoryIds = gpOfferCategoryIds;
	}

	public String getGpThumbnailUrl() {
		return gpThumbnailUrl;
	}

	public void setGpThumbnailUrl(String gpThumbnailUrl) {
		this.gpThumbnailUrl = gpThumbnailUrl;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getPromotionTitleCn() {
		return promotionTitleCn;
	}

	public void setPromotionTitleCn(String promotionTitleCn) {
		this.promotionTitleCn = promotionTitleCn;
	}

	public Date getUpdatedTime() {
		return updatedTime;
	}

	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}

	public String getPromotionActualDesc() {
		return promotionActualDesc;
	}

	public void setPromotionActualDesc(String promotionActualDesc) {
		this.promotionActualDesc = promotionActualDesc;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((gpOfferId == null) ? 0 : gpOfferId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}

		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}

		GpOfferForItem other = (GpOfferForItem) obj;

		if (gpOfferId == null || other.gpOfferId == null || !(this.gpOfferId.equals(other.gpOfferId))) {
			return false;
		}
		return true;
	}
}
