package com.walmart.mobile.checkout.bo;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.walmart.mobile.checkout.entity.OfferForItem;

public class ItemDetail implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8584897912982493492L;

	private Long productId;
	private String descOnline;
	private String descOnlineDetailHtml;
	private Integer itemType;
	private Float wasPrice;
	private Float priceWithTax;
	private Float amount = null;
	private Integer salesQty;
	private Integer salesAmt;
	private String promotionDescCn;
	private Integer inventory;
	private Integer stockStatus;
	private String[] imgUrl;
	private String thumbnailUrl;
	private List<Integer> productFlag;
	private Integer storeId;
	private List<OfferForItem> gpOffers;
	private List<Integer> gpOfferIds;
	private Map<String, String> specifications;
	private Long barCode;// orginal item code, for scale item
	private Long cartItemId; // created from client
	private Integer specialScaleItem = 0;// for client, used for 21 + 00000
											// special item
	private Integer restrictionQty;
	private Integer magneticFlag;
	private Integer packageCode;
	private Integer ewsFlag;
	private Integer deliverFlag; // 是否支持配送标志 1：表示支持配送 0:表示不支持配送
	private Integer deliveryThreshold;
	private String assocDisc;

	public String getAssocDisc() {
		return assocDisc;
	}

	public void setAssocDisc(String assocDisc) {
		this.assocDisc = assocDisc;
	}

	public Integer getEwsFlag() {
		return ewsFlag;
	}

	public void setEwsFlag(Integer ewsFlag) {
		this.ewsFlag = ewsFlag;
	}

	public String getDescOnline() {
		return descOnline;
	}

	public void setDescOnline(String descOnline) {
		this.descOnline = descOnline;
	}

	public String getDescOnlineDetailHtml() {
		return descOnlineDetailHtml;
	}

	public void setDescOnlineDetailHtml(String descOnlineDetailHtml) {
		this.descOnlineDetailHtml = descOnlineDetailHtml;
	}

	public Integer getItemType() {
		return itemType;
	}

	public void setItemType(Integer itemType) {
		this.itemType = itemType;
	}

	public Float getWasPrice() {
		return wasPrice;
	}

	public void setWasPrice(Float wasPrice) {
		this.wasPrice = wasPrice;
	}

	public Float getPriceWithTax() {
		return priceWithTax;
	}

	public void setPriceWithTax(Float priceWithTax) {
		this.priceWithTax = priceWithTax;
	}

	public Integer getSalesQty() {
		return salesQty;
	}

	public void setSalesQty(Integer salesQty) {
		this.salesQty = salesQty;
	}

	public String getPromotionDescCn() {
		return promotionDescCn;
	}

	public void setPromotionDescCn(String promotionDescCn) {
		this.promotionDescCn = promotionDescCn;
	}

	public Integer getInventory() {
		return inventory;
	}

	public void setInventory(Integer inventory) {
		this.inventory = inventory;
	}

	public Integer getStockStatus() {
		return stockStatus;
	}

	public void setStockStatus(Integer stockStatus) {
		this.stockStatus = stockStatus;
	}

	public String[] getImgUrl() {
		return imgUrl;
	}

	public void setImgUrl(String[] imgUrl) {
		this.imgUrl = imgUrl;
	}

	public List<Integer> getProductFlag() {
		return productFlag;
	}

	public void setProductFlag(List<Integer> productFlag) {
		this.productFlag = productFlag;
	}

	public Map<String, String> getSpecifications() {
		return specifications;
	}

	public void setSpecifications(Map<String, String> specifications) {
		this.specifications = specifications;
	}

	public String getThumbnailUrl() {
		return thumbnailUrl;
	}

	public void setThumbnailUrl(String thumbnailUrl) {
		this.thumbnailUrl = thumbnailUrl;
	}

	public Integer getSalesAmt() {
		return salesAmt;
	}

	public void setSalesAmt(Integer salesAmt) {
		this.salesAmt = salesAmt;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public List<OfferForItem> getGpOffers() {
		return gpOffers;
	}

	public void setGpOffers(List<OfferForItem> gpOffers) {
		this.gpOffers = gpOffers;
	}

	public Float getAmount() {
		return amount;
	}

	public void setAmount(Float amount) {
		this.amount = amount;
	}

	public Long getBarCode() {
		return barCode;
	}

	public void setBarCode(Long barCode) {
		this.barCode = barCode;
	}

	public Long getCartItemId() {
		return cartItemId;
	}

	public void setCartItemId(Long cartItemId) {
		this.cartItemId = cartItemId;
	}

	public List<Integer> getGpOfferIds() {
		return gpOfferIds;
	}

	public void setGpOfferIds(List<Integer> gpOfferIds) {
		this.gpOfferIds = gpOfferIds;
	}

	public Integer getRestrictionQty() {
		return restrictionQty;
	}

	public void setRestrictionQty(Integer restrictionQty) {
		this.restrictionQty = restrictionQty;
	}

	public Integer getSpecialScaleItem() {
		return specialScaleItem;
	}

	public void setSpecialScaleItem(Integer specialScaleItem) {
		this.specialScaleItem = specialScaleItem;
	}

	public Integer getPackageCode() {
		return packageCode;
	}

	public void setPackageCode(Integer packageCode) {
		this.packageCode = packageCode;
	}

	public Integer getMagneticFlag() {
		return magneticFlag == null ? 0 : magneticFlag;
	}

	public void setMagneticFlag(Integer magneticFlag) {
		this.magneticFlag = magneticFlag;
	}

	public Integer getDeliverFlag() {
		return deliverFlag;
	}

	public void setDeliverFlag(Integer deliverFlag) {
		this.deliverFlag = deliverFlag;
	}

	public Integer getDeliveryThreshold() {
		return deliveryThreshold;
	}

	public void setDeliveryThreshold(Integer deliveryThreshold) {
		this.deliveryThreshold = deliveryThreshold;
	}
}