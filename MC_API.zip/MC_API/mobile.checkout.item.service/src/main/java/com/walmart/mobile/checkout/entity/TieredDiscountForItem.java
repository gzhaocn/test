package com.walmart.mobile.checkout.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import org.springframework.data.mongodb.core.mapping.Field;

public class TieredDiscountForItem implements Serializable {

	private static final long serialVersionUID = 2745696401756239193L;

	@Field("threshold_qty")
	private Integer thresholdQty;

	@Field("discount_factor")
	private BigDecimal discountFactor;

	@Field("threshold_amt")
	private BigDecimal thresholdAmt;

	public BigDecimal getThresholdAmt() {
		return thresholdAmt;
	}

	public void setThresholdAmt(BigDecimal thresholdAmt) {
		this.thresholdAmt = thresholdAmt;
	}

	public BigDecimal getDiscountFactor() {
		return discountFactor;
	}

	public void setDiscountFactor(BigDecimal discountFactor) {
		this.discountFactor = discountFactor;
	}

	public Integer getThresholdQty() {
		return thresholdQty;
	}

	public void setThresholdQty(Integer thresholdQty) {
		this.thresholdQty = thresholdQty;
	}

}
