package com.walmart.mobile.checkout.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.walmart.mobile.checkout.bo.EwsStore;
import com.walmart.mobile.checkout.entity.EwsPrice;
import com.walmart.mobile.checkout.entity.InventoryPrice;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.repo.EwsPriceRepository;
import com.walmart.mobile.checkout.repo.InventoryPriceRepository;

@Service
public class EwsPriceService {

	private static final Logger LOGGER = LoggerFactory.getLogger(EwsPriceService.class);
	@Autowired
	private EwsPriceRepository ewsPriceRepository;

	@Autowired
	private InventoryPriceRepository inventoryPriceRepository;

	public List<EwsPrice> getAllEwsPrice(EwsStore ewsStore) throws GlobalErrorInfoException {
		List<EwsPrice> ewsPriceList = new ArrayList<>();
		Iterable<EwsPrice> it = ewsPriceRepository.findAll();
		Integer storeId = ewsStore.getStoreId();
		it.forEach(ewsPrice -> {
			if (storeId != null) {
				Long itemNumber = ewsPrice.getItemNumber();
				InventoryPrice ip = inventoryPriceRepository.findByStoreIdAndItemNumber(storeId, itemNumber);
				if (ip != null) {
					ewsPrice.setExtendedWarrantyPrice(new BigDecimal(ip.getPriceWithTax().toString()));
					ewsPrice.setAssocDisc(ip.getAssocDisc());
				} else {
					LOGGER.info("not found ews prodcut.storeId:{},itemNumber:{}", storeId, itemNumber);
				}
			}
			ewsPriceList.add(ewsPrice);
		});
		return ewsPriceList;
	}
}
