package com.walmart.mobile.checkout.bo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import com.walmart.mobile.checkout.entity.ShoppingItem;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel
public class SelectItemsParameter implements Serializable {

	private static final long serialVersionUID = -8556135339803921788L;

	@ApiModelProperty(value = "门店号码", required = true)
	private Integer storeId;

	@ApiModelProperty(value = "商品金额数组, productId, amount集合，包含称重商品productId,称重商品amount")
	private List<ShoppingItem> shoppingItems = new ArrayList<>();

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public List<ShoppingItem> getShoppingItems() {
		return shoppingItems;
	}

	public void setShoppingItems(List<ShoppingItem> shoppingItems) {
		this.shoppingItems = shoppingItems;
	}

}
