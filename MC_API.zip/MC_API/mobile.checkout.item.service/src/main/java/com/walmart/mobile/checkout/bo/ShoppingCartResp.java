package com.walmart.mobile.checkout.bo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.walmart.mobile.checkout.entity.GpOfferForItem;

public class ShoppingCartResp implements Serializable {

	private static final long serialVersionUID = 1L;

	private List<GpOfferForItem> gpOfferList = new ArrayList<>();

	private List<ItemDetail> itemDetailList = new ArrayList<>();

	private List<ItemDetail> shoppingBagList = new ArrayList<>();

	private List<ItemDetail> deliveryItemList = new ArrayList<>();

	private Integer assocDiscount = -1;

	public Integer getAssocDiscount() {
		return assocDiscount;
	}

	public void setAssocDiscount(Integer assocDiscount) {
		if (null != assocDiscount) {
			this.assocDiscount = assocDiscount;
		}
	}

	public List<GpOfferForItem> getGpOfferList() {
		return gpOfferList;
	}

	public void setGpOfferList(List<GpOfferForItem> gpOfferList) {
		this.gpOfferList = gpOfferList;
	}

	public List<ItemDetail> getItemDetailList() {
		return itemDetailList;
	}

	public void setItemDetailList(List<ItemDetail> itemDetailList) {
		this.itemDetailList = itemDetailList;
	}

	public List<ItemDetail> getShoppingBagList() {
		return shoppingBagList;
	}

	public void setShoppingBagList(List<ItemDetail> shoppingBagList) {
		this.shoppingBagList = shoppingBagList;
	}

	public List<ItemDetail> getDeliveryItemList() {
		return deliveryItemList;
	}

	public void setDeliveryItemList(List<ItemDetail> deliveryItemList) {
		this.deliveryItemList = deliveryItemList;
	}

}