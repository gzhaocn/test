package com.walmart.mobile.checkout.bo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.walmart.mobile.checkout.entity.GpOfferForItem;


public class ItemScanResp implements Serializable {

	private static final long serialVersionUID = 1L;

	private List<GpOfferForItem> gpOfferList = new ArrayList<>();

	private ItemDetail itemDetail;

	public List<GpOfferForItem> getGpOfferList() {
		return gpOfferList;
	}

	public void setGpOfferList(List<GpOfferForItem> gpOfferList) {
		this.gpOfferList = gpOfferList;
	}

	public ItemDetail getItemDetail() {
		return itemDetail;
	}

	public void setItemDetail(ItemDetail itemDetail) {
		this.itemDetail = itemDetail;
	}

}