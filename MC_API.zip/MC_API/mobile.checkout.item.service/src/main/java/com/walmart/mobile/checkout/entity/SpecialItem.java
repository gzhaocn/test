package com.walmart.mobile.checkout.entity;

import java.math.BigInteger;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.walmart.mobile.checkout.entity.document.BaseDocument;

@Document(collection = "special_item")
public class SpecialItem extends BaseDocument<BigInteger> implements Comparable<SpecialItem> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7281931988680331409L;
	@Field("upc")
	private Long upc;
	@Field("sequence")
	private Integer sequence;

	@Override
	public int compareTo(SpecialItem o) {
		if (o == null) {
			return -1;
		}
		return this.upc.compareTo(o.getUpc());
	}

	@Override
	public int hashCode() {
		return this.upc == null ? 0 : this.getUpc().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (!(obj instanceof SpecialItem)) {
			return false;
		}
		SpecialItem other = (SpecialItem) obj;
		return this.getUpc().equals(other.getUpc());
	}

	public Long getUpc() {
		return upc;
	}

	public void setUpc(Long upc) {
		this.upc = upc;
	}

	public Integer getSequence() {
		return sequence;
	}

	public void setSequence(Integer sequence) {
		this.sequence = sequence;
	}

}
