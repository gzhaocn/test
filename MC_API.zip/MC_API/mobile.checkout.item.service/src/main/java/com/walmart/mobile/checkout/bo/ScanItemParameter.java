package com.walmart.mobile.checkout.bo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

import com.walmart.mobile.checkout.utils.ProductIdGenerator;

@ApiModel
public class ScanItemParameter implements Serializable {

	private static final long serialVersionUID = -8556135339803921788L;

	@ApiModelProperty(value = "门店号码")
	private Integer storeId;

	@ApiModelProperty(value = "商品UPC")
	private Long upc;

	@ApiModelProperty(value = "商品itemNumber")
	private Long itemNumber;

	private String scanBarCode;
	private String origin;

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public Long getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(Long itemNumber) {
		this.itemNumber = itemNumber;
	}

	public Long getUpc() {
		return upc;
	}

	public void setUpc(Long upc) {
		this.upc = ProductIdGenerator.decode(upc);
	}

	@ApiModelProperty(hidden = true)
	public void setUpcForTest(Long upc) {
		this.upc = upc;
	}

	public String getScanBarCode() {
		return scanBarCode;
	}

	public void setScanBarCode(String scanBarCode) {
		this.scanBarCode = scanBarCode;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

}
