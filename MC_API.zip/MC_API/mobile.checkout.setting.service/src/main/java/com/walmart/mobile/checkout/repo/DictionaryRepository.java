package com.walmart.mobile.checkout.repo;

import java.math.BigInteger;
import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.walmart.mobile.checkout.entity.Dictionary;

/**
 * 
 * @author Feixuhui
 */
public interface DictionaryRepository extends CrudRepository<Dictionary, BigInteger> {

	List<Dictionary> findByTypeAndSubType(String type, String subType);

}
