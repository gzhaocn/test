package com.walmart.mobile.checkout.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.walmart.mobile.checkout.entity.ClientReport;
import com.walmart.mobile.checkout.repo.ClientReportRepository;

@Service
public class ClientReportService {

	@Autowired
	private ClientReportRepository clientReportRepository;

	public void saveClientReportList(List<ClientReport> clientReportList) {
		clientReportRepository.save(clientReportList);
	}
}
