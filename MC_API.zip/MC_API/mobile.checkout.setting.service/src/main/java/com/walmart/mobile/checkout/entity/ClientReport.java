package com.walmart.mobile.checkout.entity;

import java.util.Date;

import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel
@CompoundIndex(name = "log_id", def = "{'log_id' : 1}")
@Document(collection = "client_report")
public class ClientReport {
	@Field("log_id")
	@ApiModelProperty(value = "日志id")
	private String logId;
	@Field("timestamp")
	@ApiModelProperty(value = "调用接口时间")
	private Date timestamp;
	@Field("before_request")
	@ApiModelProperty(value = "请求前客户端处理时间")
	private Long beforeRequest;
	@Field("request_to_response")
	@ApiModelProperty(value = "请求到相应时间")
	private Long requestToResponse;
	@Field("after_response")
	@ApiModelProperty(value = "请求后客户端处理时间")
	private Long afterResponse;
	@Field("api")
	@ApiModelProperty(value = "请求接口")
	private String api;
	@Field("model")
	@ApiModelProperty(value = "手机")
	private String model;
	@Field("system")
	@ApiModelProperty(value = "手机操作系统")
	private String system;
	@Field("network_type")
	@ApiModelProperty(value = "手机网络.wifi 4g等")
	private String networkType;
	@Field("phone")
	@ApiModelProperty(value = "手机号码")
	private String phone;
	@Field("platform")
	@ApiModelProperty(value = "上报平台. wechat, h5等")
	private String platform;
	@Field("server_process_time")
	@ApiModelProperty(value = "服务执行时间")
	private Long serverProcessTime;

	public Long getServerProcessTime() {
		return serverProcessTime;
	}

	public void setServerProcessTime(Long serverProcessTime) {
		this.serverProcessTime = serverProcessTime;
	}

	public String getApi() {
		return api;
	}

	public void setApi(String api) {
		this.api = api;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}

	public String getNetworkType() {
		return networkType;
	}

	public void setNetworkType(String networkType) {
		this.networkType = networkType;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getPlatform() {
		return platform;
	}

	public void setPlatform(String platform) {
		this.platform = platform;
	}

	public String getLogId() {
		return logId;
	}

	public void setLogId(String logId) {
		this.logId = logId;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public Long getBeforeRequest() {
		return beforeRequest;
	}

	public void setBeforeRequest(Long beforeRequest) {
		this.beforeRequest = beforeRequest;
	}

	public Long getRequestToResponse() {
		return requestToResponse;
	}

	public void setRequestToResponse(Long requestToResponse) {
		this.requestToResponse = requestToResponse;
	}

	public Long getAfterResponse() {
		return afterResponse;
	}

	public void setAfterResponse(Long afterResponse) {
		this.afterResponse = afterResponse;
	}
}
