package com.walmart.mobile.checkout.repo;

import java.math.BigInteger;

import org.springframework.data.repository.CrudRepository;

import com.walmart.mobile.checkout.entity.ClientReport;

public interface ClientReportRepository extends CrudRepository<ClientReport, BigInteger> {
}
