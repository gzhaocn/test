package com.walmart.mobile.checkout.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.walmart.mobile.checkout.entity.VersionControl;
import com.walmart.mobile.checkout.repo.VersionControlRepository;

@Service
public class VersionControlService {
	@Autowired
	VersionControlRepository versionControlRepository;

	public VersionControl findOne(String id) {
		VersionControl versionControl = versionControlRepository.findOne(id);
		if (versionControl == null) {
			versionControl = new VersionControl();
			versionControl.setVersion("1");
		}
		return versionControl;
	}

	public List<VersionControl> findByVersionTypeStartingWith(String versionType) {
		return versionControlRepository.findByVersionTypeStartingWith(versionType);
	}
}
