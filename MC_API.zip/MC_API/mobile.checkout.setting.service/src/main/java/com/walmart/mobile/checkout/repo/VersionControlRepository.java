package com.walmart.mobile.checkout.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.walmart.mobile.checkout.entity.VersionControl;

public interface VersionControlRepository extends CrudRepository<VersionControl, String> {

	VersionControl findByVersion(String version);

	List<VersionControl> findByVersionTypeStartingWith(String versionType);

}
