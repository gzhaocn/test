package com.walmart.mobile.checkout.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.walmart.mobile.checkout.entity.Dictionary;
import com.walmart.mobile.checkout.repo.DictionaryRepository;

@Service
public class DictionaryService {
	@Autowired
	private DictionaryRepository dictionaryRepository;

	public List<Dictionary> findByTypeAndSubType(String type, String subTtype) {
		return dictionaryRepository.findByTypeAndSubType(type, subTtype);
	}
}
