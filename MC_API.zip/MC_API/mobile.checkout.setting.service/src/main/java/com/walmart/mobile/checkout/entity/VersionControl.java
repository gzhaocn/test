package com.walmart.mobile.checkout.entity;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.walmart.mobile.checkout.annotation.Include;
import com.walmart.mobile.checkout.entity.document.BaseDocument;

@Document(collection = "system_version_control")
public class VersionControl extends BaseDocument<String> {

	private static final long serialVersionUID = 9212614777702684321L;

	@Field("version_type")
	private String versionType;

	@Include("version")
	@Field("version_id")
	private String version;

	public String getVersionType() {
		return versionType;
	}

	public void setVersionType(String versionType) {
		this.versionType = versionType;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

}
