package com.walmart.mobile.checkout.entity;

import java.math.BigInteger;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.walmart.mobile.checkout.entity.document.BaseDocument;

@Document(collection = "dictionary")
public class Dictionary extends BaseDocument<BigInteger> {
	private static final long serialVersionUID = 1L;
	@Indexed
	private String type;
	private String name;
	private String desc;
	private String value;
	@Field("sub_type")
	private String subType;

	@JsonIgnore
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@JsonIgnore
	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	@JsonIgnore
	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}
}