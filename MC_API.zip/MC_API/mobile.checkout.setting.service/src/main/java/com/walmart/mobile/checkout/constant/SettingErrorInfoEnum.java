package com.walmart.mobile.checkout.constant;

import com.walmart.mobile.checkout.exception.handler.ErrorInfoInterface;

/**
 * 系统及业务级别的错误码
 */
public enum SettingErrorInfoEnum implements ErrorInfoInterface {
	LIST_IS_EMPTY("-700", "report list is empty.");
	private String code;

	private String message;

	SettingErrorInfoEnum(String code, String message) {
		this.code = code;
		this.message = message;
	}

	@Override
	public String getCode() {
		return this.code;
	}

	@Override
	public String getMessage() {
		return this.message;
	}
}
