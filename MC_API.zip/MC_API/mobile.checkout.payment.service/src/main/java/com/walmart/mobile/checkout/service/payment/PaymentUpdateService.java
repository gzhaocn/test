package com.walmart.mobile.checkout.service.payment;

import java.math.BigDecimal;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.walmart.mobile.checkout.bo.payment.OrderVo;
import com.walmart.mobile.checkout.enumcode.payment.PaymentErrorInfoEnum;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.rest.payment.PaymentOrderClient;
import com.walmart.mobile.checkout.rest.payment.PaymentOrderStatusClient;

@Service
public class PaymentUpdateService {

	private static final Logger LOGGER = LoggerFactory.getLogger(PaymentUpdateService.class.getName());

	@Value("${order.timeout.minutes}")
	private int orderTimeoutMinutes;

	@Autowired
	private PaymentOrderClient paymentOrderClient;

	@Autowired
	private PaymentOrderStatusClient paymentOrderStatusClient;

	public int doUpdateStatus(String orderId, int version, int status, BigDecimal paymentCouponFee, int payType) {
		int result = 0;
		try {
			result = paymentOrderStatusClient.updateOrderStatusByOrderId(orderId, version, status, paymentCouponFee, payType);
			int executeCount = 1;
			while (executeCount < 4 && result != 1) {
				OrderVo orderNow = paymentOrderClient.getOrderByOrderId(orderId);
				result = paymentOrderStatusClient.updateOrderStatusByOrderId(orderId, orderNow.getVersion(), status, paymentCouponFee, payType);
				executeCount++;
				if (result == 1) {
					break;
				}
			}
		} catch (GlobalErrorInfoException e) {
			// 查询数据库获取订单的最新状态
			OrderVo orderInDB = paymentOrderClient.getOrderByOrderId(orderId);
			LOGGER.error("Failed to update order status to paid[30], orderId=[{}], currentStatus=[{}]", orderInDB.getOrderId(), orderInDB.getStatus(), e);
		}
		return result;
	}

	public int doUpdate(String orderId, int version, int status, BigDecimal paymentCouponFee, int payType) throws GlobalErrorInfoException {
		int result = 0;
		try {
			result = paymentOrderStatusClient.updateOrderStatusByOrderId(orderId, version, status, paymentCouponFee, payType);
			int executeCount = 1;
			while (executeCount < 4 && result != 1) {
				OrderVo orderNow = paymentOrderClient.getOrderByOrderId(orderId);
				result = paymentOrderStatusClient.updateOrderStatusByOrderId(orderId, orderNow.getVersion(), status, paymentCouponFee, payType);
				executeCount++;
				if (result == 1) {
					break;
				}
			}
		} catch (GlobalErrorInfoException e) {
			// 查询数据库获取订单的最新状态
			LOGGER.error("Failed to update order status to paid[30], orderId=[{}], currentStatus=[{}]", orderId, status, e);
			throw new GlobalErrorInfoException(PaymentErrorInfoEnum.ORDER_UPDATE_STATUS_FAIL);
		}
		return result;
	}

	/**
	 * 设置超时时间
	 * 
	 * @param order
	 * @throws GlobalErrorInfoException
	 */
	public boolean isTimeOut(Date createTime) {
		long currentTimeMillis = System.currentTimeMillis();
		// 设置超时
		long timeoutInterval = currentTimeMillis - createTime.getTime();
		return (timeoutInterval >= orderTimeoutMinutes * 60 * 1000);
	}

}
