package com.walmart.mobile.checkout.bo.recordsale;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class RecordSaleOrder implements Serializable {

	private static final long serialVersionUID = 7018518547980882285L;

	/**
	 * 订单号/batchNo
	 */
	private String orderId;
	
	
	/**
	 * 订单号
	 */
	private String realOrderId;


	/**
	 * 订单
	 */
	private RecordSaleOrderInfo orderInfo;
	

	/**
	 * 允许过机事件
	 */
	private Integer recordEvent;



	/**
	 * 明细
	 */
	private List<RecordSaleOrderLine> orderItems = new ArrayList<>();

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getRealOrderId() {
		return realOrderId;
	}

	public void setRealOrderId(String realOrderId) {
		this.realOrderId = realOrderId;
	}

	
	public Integer getRecordEvent() {
		return recordEvent;
	}

	public void setRecordEvent(Integer recordEvent) {
		this.recordEvent = recordEvent;
	}

	public RecordSaleOrderInfo getOrderInfo() {
		return orderInfo;
	}

	public void setOrderInfo(RecordSaleOrderInfo orderInfo) {
		this.orderInfo = orderInfo;
	}

	public List<RecordSaleOrderLine> getOrderItems() {
		return orderItems;
	}

	public void setOrderItems(List<RecordSaleOrderLine> orderItems) {
		this.orderItems = orderItems;
	}

}
