package com.walmart.mobile.checkout.utils.payment.alipay;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SignatureException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.walmart.mobile.checkout.enumcode.payment.PaymentErrorInfoEnum;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;

public class RSA {

	public static final String SIGN_ALGORITHMS = "SHA1WithRSA";
	private static final Logger LOGGER = LoggerFactory.getLogger(RSA.class);

	private RSA() {
	}

	public static String sign(String content, String privateKey, String inputCharset) throws GlobalErrorInfoException {
		try {
			PKCS8EncodedKeySpec priPKCS8 = new PKCS8EncodedKeySpec(java.util.Base64.getDecoder().decode(privateKey));

			KeyFactory keyf = KeyFactory.getInstance("RSA");
			PrivateKey priKey = keyf.generatePrivate(priPKCS8);

			java.security.Signature signature = java.security.Signature.getInstance(SIGN_ALGORITHMS);

			signature.initSign(priKey);
			signature.update(content.getBytes(inputCharset));

			byte[] signed = signature.sign();

			return java.util.Base64.getEncoder().encodeToString(signed);
		} catch (NoSuchAlgorithmException | InvalidKeySpecException | SignatureException | UnsupportedEncodingException
				| InvalidKeyException e) {
			LOGGER.error("sign error", e);
			throw new GlobalErrorInfoException(PaymentErrorInfoEnum.RSA_SIGN_ERROR, e);
		}

	}

	public static boolean verify(String content, String sign, String aliPublicKey, String inputCharset)
			throws GlobalErrorInfoException {
		try {
			KeyFactory keyFactory = KeyFactory.getInstance("RSA");
			byte[] encodedKey = java.util.Base64.getDecoder().decode(aliPublicKey);
			PublicKey pubKey = keyFactory.generatePublic(new X509EncodedKeySpec(encodedKey));

			java.security.Signature signature = java.security.Signature.getInstance(SIGN_ALGORITHMS);

			signature.initVerify(pubKey);
			signature.update(content.getBytes(inputCharset));

			return signature.verify(java.util.Base64.getDecoder().decode(sign));

		} catch (NoSuchAlgorithmException | InvalidKeySpecException | InvalidKeyException | SignatureException
				| UnsupportedEncodingException e) {
			LOGGER.error("verify error", e);
			throw new GlobalErrorInfoException(PaymentErrorInfoEnum.RSA_SIGN_ERROR, e);
		}

	}

}
