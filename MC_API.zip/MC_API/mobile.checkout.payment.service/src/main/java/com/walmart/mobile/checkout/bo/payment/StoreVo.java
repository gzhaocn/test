package com.walmart.mobile.checkout.bo.payment;

public class StoreVo {

	private Integer storeId;

	private String egiftcardPayMerId;

	private String egiftcardSaleMerId;

	private String termNo;

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public String getEgiftcardPayMerId() {
		return egiftcardPayMerId;
	}

	public void setEgiftcardPayMerId(String egiftcardPayMerId) {
		this.egiftcardPayMerId = egiftcardPayMerId;
	}

	public String getEgiftcardSaleMerId() {
		return egiftcardSaleMerId;
	}

	public void setEgiftcardSaleMerId(String egiftcardSaleMerId) {
		this.egiftcardSaleMerId = egiftcardSaleMerId;
	}

	public String getTermNo() {
		return termNo;
	}

	public void setTermNo(String termNo) {
		this.termNo = termNo;
	}

}
