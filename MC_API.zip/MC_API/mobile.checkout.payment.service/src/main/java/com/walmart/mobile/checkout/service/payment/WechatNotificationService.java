package com.walmart.mobile.checkout.service.payment;

import java.io.IOException;
import java.io.StringReader;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.xml.sax.InputSource;

import com.walmart.mobile.checkout.domain.payment.WechatNotification;
import com.walmart.mobile.checkout.mapper.payment.WechatNotificationMapper;

@Service
public class WechatNotificationService {

	private static final Logger LOGGER = LoggerFactory.getLogger(WechatNotificationService.class);

	@Autowired
	private WechatNotificationMapper wechatNotificationMapper;

	public void create(WechatNotification wetchatNotification) {
		wetchatNotification.setCreatedTime(new Date());
		wetchatNotification.setUpdatedTime(new Date());
		wechatNotificationMapper.insert(wetchatNotification);
	}

	private int string2int(String value) {
		if (!StringUtils.isBlank(value)) {
			return Integer.parseInt(value);
		} else {
			return 0;
		}
	}

	public Map<String, Object> getReturnWeiXinPay(String xml) {
		Map<String, Object> map = new HashMap<>(16);
		WechatNotification wechatNotification = new WechatNotification();
		String sign = "";
		String returnCode = "";
		String returnMsg = "";
		StringReader read = null;
		try {
			read = new StringReader(xml);
			// 创建新的输入源SAX 解析器将使用 InputSource 对象来确定如何读取 XML 输入
			InputSource source = new InputSource(read);
			// 创建一个新的SAXBuilder
			SAXBuilder sb = new SAXBuilder();
			// 通过输入源构造一个Document
			Document doc;
			doc = sb.build(source);
			Element root = doc.getRootElement();// 指向根节点
			List<Element> list = root.getChildren();

			if (list == null || list.isEmpty()) {
				map.put("wechatNotification", wechatNotification);
				map.put("returnMsg", returnMsg);
				map.put("returnCode", returnCode);
				map.put("sign", sign);
				return map;
			}

			for (Element element : list) {
				if ("return_code".equals(element.getName())) {
					returnCode = element.getText();
				}
				if ("return_msg".equals(element.getName())) {
					returnMsg = element.getText();
				}
				if ("sign".equals(element.getName())) {
					wechatNotification.setSign(element.getText());
					sign = element.getText();
				}
				if ("err_code".equals(element.getName())) {
					wechatNotification.setErrCode(element.getText());
				}
				if ("err_code_des".equals(element.getName())) {
					wechatNotification.setErrCodeDes(element.getText());
				}
				if ("out_trade_no".equals(element.getName())) {
					wechatNotification.setOrderId(element.getText());
				}
				if ("result_code".equals(element.getName())) {
					wechatNotification.setResultCode(element.getText());
				}
				if ("bank_type".equals(element.getName())) {
					wechatNotification.setBankType(element.getText());
				}
				if ("cash_fee".equals(element.getName())) {
					wechatNotification.setCashFee(string2int(element.getText()));
				}
				if ("cash_fee_type".equals(element.getName())) {
					wechatNotification.setCashFeeType(element.getText());
				}
				if ("coupon_fee".equals(element.getName())) {
					wechatNotification.setCouponFee(string2int(element.getText()));
				}
				if ("device_info".equals(element.getName())) {
					wechatNotification.setDeviceInfo(element.getText());
				}
				if ("fee_type".equals(element.getName())) {
					wechatNotification.setFeeType(element.getText());
				}
				if ("nonce_str".equals(element.getName())) {
					wechatNotification.setNonceStr(element.getText());
				}
				if ("openid".equals(element.getName())) {
					wechatNotification.setOpenid(element.getText());
				}
				if ("time_end".equals(element.getName())) {
					wechatNotification.setTimeEnd(element.getText());
				}
				if ("total_fee".equals(element.getName())) {
					wechatNotification.setTotalFee(string2int(element.getText()));
				}
				if ("trade_type".equals(element.getName())) {
					wechatNotification.setTradeType(element.getText());
				}
				if ("transaction_id".equals(element.getName())) {
					wechatNotification.setTransactionId(element.getText());
				}
				if ("attach".equals(element.getName())) {
					wechatNotification.setAttach(element.getText());
				}
			}

			map.put("wechatNotification", wechatNotification);
			map.put("returnMsg", returnMsg);
			map.put("returnCode", returnCode);
			map.put("sign", sign);
		} catch (JDOMException | IOException e) {
			LOGGER.error("wechat notification：", e);
		} finally {
			if (read != null) {
				read.close();
			}
		}
		return map;
	}

	/**
	 * 构造xml参数
	 * 
	 * @param xml
	 * @return
	 */
	public String xmlReturnApplyInfo(String returnCode, String returnMsg) {
		if (returnCode != null) {
			StringBuilder bf = new StringBuilder();
			bf.append("<xml>");

			bf.append("<return_code><![CDATA[");
			bf.append(returnCode);
			bf.append("]]></return_code>");
			if (returnMsg != null) {
				bf.append("<return_msg><![CDATA[");
				bf.append(returnMsg);
				bf.append("]]></return_msg>");
			}
			bf.append("</xml>");
			return bf.toString();
		}
		return "";
	}

	public WechatNotification getByOutTradeNo(String outTradeNo) {
		return wechatNotificationMapper.selectByPrimaryKey(outTradeNo);
	}

}
