package com.walmart.mobile.checkout.utils.payment.alipay;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class AlipayCore {

	private AlipayCore() {
	}

	public static Map<String, String> paraFilter(Map<String, String> sArray) {

		Map<String, String> result = new HashMap<>(16);
		if (sArray == null || sArray.size() <= 0) {
			return result;
		}
		for (Entry<String, String> entry : sArray.entrySet()) {
			String key = entry.getKey();
			String value = entry.getValue();
			if (value == null || "".equals(value) || "sign".equalsIgnoreCase(key)
					|| "sign_type".equalsIgnoreCase(key)) {
				continue;
			}
			result.put(key, value);
		}
		return result;
	}

	public static String createLinkString(Map<String, String> params) {

		List<String> keys = new ArrayList<>(params.keySet());
		Collections.sort(keys);
		StringBuilder prestr = new StringBuilder();
		for (int i = 0; i < keys.size(); i++) {
			String key = keys.get(i);
			String value = params.get(key);
			if (i == keys.size() - 1) {
				prestr.append(key).append("=").append(value);
			} else {
				prestr.append(key).append("=").append(value).append("&");
			}
		}
		return prestr.toString();
	}

}
