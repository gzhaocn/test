package com.walmart.mobile.checkout.domain.payment;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "礼品卡支付回写模型")
public class EGiftcardNewNotification {

	@ApiModelProperty(value = "商户号")
	@JsonProperty(value = "organ")
	private  String organ ;
	
	@ApiModelProperty(value = "渠道号标示")
	@JsonProperty(value = "channelCode")
	private String channelCode;
	
	@ApiModelProperty(value = "订单号")
	@JsonProperty(value = "channelTradeNo")
	private String channelTradeNo;
	
	@ApiModelProperty(value = "WFT订单号")
	@JsonProperty(value = "wftTradeNo")
	private String wftTradeNo;
	
	
	@ApiModelProperty(value = "订单金额")
	@JsonProperty(value = "totalFee")
	private String totalFee;
	
	@ApiModelProperty(value = "货币类型")
	@JsonProperty(value = "feeType")
	private String feeType;
	
	@ApiModelProperty(value = "支付完成时间")
	@JsonProperty(value = "timeEnd")
	private Date timeEnd ;
	
	@ApiModelProperty(value = "时间戳")
	@JsonProperty(value = "timestamp")
	private String timestamp;
	
	@ApiModelProperty(value = "随机字符串")
	@JsonProperty(value = "nonceStr")
	private String nonceStr ;
	
	@ApiModelProperty(value = "签名")
	@JsonProperty(value = "sign")
	private String sign ;

	private Date createdTime;

	private String createdBy;

	private Date updatedTime;

	private String updatedBy;

	
	public String getOrgan() {
		return organ;
	}

	public void setOrgan(String organ) {
		this.organ = organ;
	}

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getChannelTradeNo() {
		return channelTradeNo;
	}

	public void setChannelTradeNo(String channelTradeNo) {
		this.channelTradeNo = channelTradeNo;
	}

	public String getWftTradeNo() {
		return wftTradeNo;
	}

	public void setWftTradeNo(String wftTradeNo) {
		this.wftTradeNo = wftTradeNo;
	}

	public String getTotalFee() {
		return totalFee;
	}

	public void setTotalFee(String totalFee) {
		this.totalFee = totalFee;
	}

	public String getFeeType() {
		return feeType;
	}

	public void setFeeType(String feeType) {
		this.feeType = feeType;
	}

	public Date getTimeEnd() {
		return timeEnd;
	}

	public void setTimeEnd(Date timeEnd) {
		this.timeEnd = timeEnd;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getNonceStr() {
		return nonceStr;
	}

	public void setNonceStr(String nonceStr) {
		this.nonceStr = nonceStr;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getUpdatedTime() {
		return updatedTime;
	}

	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}


	

}