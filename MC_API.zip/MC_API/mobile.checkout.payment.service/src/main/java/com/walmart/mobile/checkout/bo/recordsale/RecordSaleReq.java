package com.walmart.mobile.checkout.bo.recordsale;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
 *
 */
@ApiModel(description = "TC Number 回写模型")
public class RecordSaleReq implements Serializable {

	private static final long serialVersionUID = 7422448539711116709L;

	@ApiModelProperty(value = "订单号")
	@JsonProperty(value = "order_id")
	private String orderId;

	@ApiModelProperty(value = "TC number")
	@JsonProperty(value = "tc_number")
	private String tcNumber;

	@ApiModelProperty(value = "POS机对应的流水号0-9999")
	@JsonProperty(value = "sequence_number")
	private Integer sequenceNumber;

	@ApiModelProperty(value = "小票机台号")
	@JsonProperty(value = "register_number")
	private Integer registerNumber;

	@ApiModelProperty(value = "小票过机时间")
	@JsonProperty(value = "trans_time")
	private Date transTime;

	@ApiModelProperty(value = "过机状态")
	private String status;

	@ApiModelProperty(value = "过机描述")
	private String description;

	@ApiModelProperty(value = "订单类型")
	@JsonProperty(value = "rs_order_type")
	private String rsOrderType;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getTcNumber() {
		return tcNumber;
	}

	public void setTcNumber(String tcNumber) {
		this.tcNumber = tcNumber;
	}

	public Integer getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(Integer sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public Integer getRegisterNumber() {
		return registerNumber;
	}

	public void setRegisterNumber(Integer registerNumber) {
		this.registerNumber = registerNumber;
	}

	public Date getTransTime() {
		return transTime;
	}

	public void setTransTime(Date transTime) {
		this.transTime = transTime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getRsOrderType() {
		return rsOrderType;
	}

	public void setRsOrderType(String rsOrderType) {
		this.rsOrderType = rsOrderType;
	}

}
