package com.walmart.mobile.checkout.service.payment;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.walmart.mobile.checkout.domain.payment.UnionpayNotification;
import com.walmart.mobile.checkout.mapper.payment.UnionpayNotificationMapper;

@Service
public class UnionpayNotificationService {

	@Autowired
	private UnionpayNotificationMapper unionpayNotificationMapper;

	public boolean isExsitForQn(String qn, String transType) {
		boolean result = false;
		Map<String, Object> params = new HashMap<>(16);
		params.put("qn", qn);
		params.put("transType", transType);
		List<UnionpayNotification> list = unionpayNotificationMapper.findByQnAndTransType(params);
		if (null != list && !list.isEmpty()) {
			result = true;
		}
		return result;
	}

	public UnionpayNotification createNotification(Map<String, String> parameters) {
		UnionpayNotification entity = new UnionpayNotification();
		entity.setVersion(parameters.get("version"));
		entity.setEncoding(parameters.get("encoding"));
		entity.setCertId(parameters.get("certId"));
		entity.setQueryId(parameters.get("queryId"));
		entity.setSignMethod(parameters.get("signMethod"));
		entity.setSignature(parameters.get("signature"));
		entity.setTxnType(parameters.get("txnType"));
		entity.setTxnSubType(parameters.get("txnSubType"));
		entity.setBizType(parameters.get("bizType"));
		entity.setAccessType(parameters.get("accessType"));
		entity.setMerId(parameters.get("merId"));
		entity.setOrderId(parameters.get("orderId"));
		entity.setTxnTime(parameters.get("txnTime"));
		entity.setTxnAmt(parameters.get("txnAmt"));
		entity.setCurrencyCode(parameters.get("currencyCode"));
		entity.setReserved(parameters.get("reserved"));
		entity.setReqReserved(parameters.get("reqReserved"));
		entity.setRespCode(parameters.get("respCode"));
		entity.setRespMsg(parameters.get("respMsg"));
		entity.setSettleAmount(parameters.get("settleAmount"));
		entity.setSettleCurrencyCode(parameters.get("settleCurrencyCode"));
		entity.setSettleDate(parameters.get("settleDate"));
		entity.setTraceNo(parameters.get("traceNo"));
		entity.setTraceTime(parameters.get("traceTime"));
		entity.setExchangeDate(parameters.get("exchangeDate"));
		entity.setExchangeRate(parameters.get("exchangeRate"));
		entity.setAccNo(parameters.get("accNo"));
		entity.setPayCardNo(parameters.get("payCardNo"));
		entity.setPayCardType(parameters.get("payCardType"));
		entity.setPayType(parameters.get("payType"));
		entity.setPayCardIssueName(parameters.get("payCardIssueName"));
		entity.setBindId(parameters.get("bindId"));
		entity.setVpcTransData(parameters.get("vpcTransData"));

		entity.setCreatedBy("unionpay");
		entity.setCreatedTime(new Date());

		unionpayNotificationMapper.insert(entity);

		return entity;
	}

}
