package com.walmart.mobile.checkout.constant.recordsale;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 *
 */
public final class RecordSaleConstants {

	private RecordSaleConstants() {
	}

	public static final String TAXTYPE_TAX_1 = "TAX_1";
	public static final int TAXTYPE_TAX_RATE_1 = 0;
	public static final String TAXTYPE_TAX_2 = "TAX_2";
	public static final int TAXTYPE_TAX_RATE_2 = 11;
	public static final String TAXTYPE_TAX_3 = "TAX_3";
	public static final int TAXTYPE_TAX_RATE_3 = 17;

	public static final BigDecimal TAXTYPE_BIGDECIMAL_TAX_RATE_1 = BigDecimal.valueOf(0.00d);
	public static final BigDecimal TAXTYPE_BIGDECIMAL_TAX_RATE_2 = BigDecimal.valueOf(0.11d);
	public static final BigDecimal TAXTYPE_BIGDECIMAL_TAX_RATE_3 = BigDecimal.valueOf(0.17d);

	// 订单来源
	public static final String MOBILE_CHECKOUT_ORDER_SOURCE = "23";

	// 商品类型 0 普通商品 1 称重商品 2 COUPON 3 GP item
	public static final int PRODUCT_TYPE_NOMOAL = 0;
	public static final int PRODUCT_TYPE_WEIGHT = 1;
	public static final int PRODUCT_TYPE_COUPON = 2;
	public static final int PRODUCT_TYPE_GPITEM = 3;

	// GP商品描述
	public static final String GP_ITEM_DESC = "Discount";

	// 订单类型 10 普通订单
	public static final String MOBILE_CHECKOUT_ORDER_TYPE = "10";
	// 订单类型 12退货订单
	public static final String  MOBILE_CHECKOUT_REVERSE_ORDER = "12";

	public static final String MOBILE_CHECKOUT_WEIGHT_UOM = "KG";

	protected static Map<Integer, String> taxTypeMap;

	static {
		taxTypeMap = new HashMap<>();
		taxTypeMap.put(TAXTYPE_TAX_RATE_1, TAXTYPE_TAX_1);
		taxTypeMap.put(TAXTYPE_TAX_RATE_2, TAXTYPE_TAX_2);
		taxTypeMap.put(TAXTYPE_TAX_RATE_3, TAXTYPE_TAX_3);
	}

	public static String getTaxType(Integer key) {
		return taxTypeMap.get(key);
	}
}
