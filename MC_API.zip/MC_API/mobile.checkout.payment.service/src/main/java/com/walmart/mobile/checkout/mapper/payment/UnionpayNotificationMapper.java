package com.walmart.mobile.checkout.mapper.payment;

import java.util.List;
import java.util.Map;

import com.walmart.mobile.checkout.domain.payment.UnionpayNotification;

public interface UnionpayNotificationMapper {

	int insert(UnionpayNotification record);

	List<UnionpayNotification> findByQnAndTransType(Map<String, Object> params);

	List<UnionpayNotification> findByOrderIdAndTransType(Map<String, Object> params);

	int deleteByPrimaryKey(String id);
}