package com.walmart.mobile.checkout.mapper.payment;

import java.util.List;
import java.util.Map;

import com.walmart.mobile.checkout.domain.payment.EGiftcardNotification;

public interface EGiftcardNotificationMapper {

	int deleteByPrimaryKey(String id);

	int insert(EGiftcardNotification record);

	int insertSelective(EGiftcardNotification record);

	EGiftcardNotification selectByPrimaryKey(String id);

	EGiftcardNotification selectByOrderId(String orderId);

	int updateByPrimaryKeySelective(EGiftcardNotification record);

	int updateByPrimaryKey(EGiftcardNotification record);

	List<EGiftcardNotification> getEGiftcardForParams(Map<String, Object> params);
}