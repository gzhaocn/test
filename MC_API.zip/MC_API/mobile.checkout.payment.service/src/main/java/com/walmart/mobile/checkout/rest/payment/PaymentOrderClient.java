package com.walmart.mobile.checkout.rest.payment;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.walmart.mobile.checkout.bo.payment.OrderVo;

@FeignClient("orderService")
public interface PaymentOrderClient {

	@RequestMapping(method = RequestMethod.GET, value = "/getOrderByOrderId")
	OrderVo getOrderByOrderId(@RequestParam(value = "orderId") String orderId);

	@RequestMapping(method = RequestMethod.GET, value = "/updateByPrimaryKeySelective")
	int updateByPrimaryKeySelective(@RequestParam(value = "orderVo") OrderVo orderVo);

}