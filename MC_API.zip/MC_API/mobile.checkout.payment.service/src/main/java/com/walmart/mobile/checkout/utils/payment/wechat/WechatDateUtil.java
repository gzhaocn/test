package com.walmart.mobile.checkout.utils.payment.wechat;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class WechatDateUtil {

	private WechatDateUtil() {
	}

	/*
	 * 订单开始交易的时间
	 */
	public static String timeStart() {
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
		return df.format(new Date());
	}

	/*
	 * 订单开始交易的时间
	 */
	public static String timeExpire() {
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
		Calendar now = Calendar.getInstance();
		now.add(Calendar.MINUTE, 30);
		return df.format(now.getTimeInMillis());
	}
}
