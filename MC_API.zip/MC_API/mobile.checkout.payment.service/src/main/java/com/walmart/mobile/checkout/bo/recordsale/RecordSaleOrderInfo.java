package com.walmart.mobile.checkout.bo.recordsale;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class RecordSaleOrderInfo implements Serializable {

	private static final long serialVersionUID = -1774141738592121751L;

	private String orderId;

	private int storeNbr;

	private String orderSource;

	private String rsOrderType;

	private BigDecimal saleAmount;

	private BigDecimal tenderAmount;

	private BigDecimal roundCorrection;
	
	private String originalTransactionCode ;

	private List<Tax> totalTax = new ArrayList<>();

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public int getStoreNbr() {
		return storeNbr;
	}

	public void setStoreNbr(int storeNbr) {
		this.storeNbr = storeNbr;
	}

	public String getOrderSource() {
		return orderSource;
	}

	public void setOrderSource(String orderSource) {
		this.orderSource = orderSource;
	}

	public String getRsOrderType() {
		return rsOrderType;
	}

	public void setRsOrderType(String rsOrderType) {
		this.rsOrderType = rsOrderType;
	}

	public BigDecimal getSaleAmount() {
		return saleAmount;
	}

	public void setSaleAmount(BigDecimal saleAmount) {
		this.saleAmount = saleAmount;
	}

	public BigDecimal getTenderAmount() {
		return tenderAmount;
	}

	public void setTenderAmount(BigDecimal tenderAmount) {
		this.tenderAmount = tenderAmount;
	}

	public String getOriginalTransactionCode() {
		return originalTransactionCode;
	}

	public void setOriginalTransactionCode(String originalTransactionCode) {
		this.originalTransactionCode = originalTransactionCode;
	}

	public List<Tax> getTotalTax() {
		return totalTax;
	}

	public void setTotalTax(List<Tax> totalTax) {
		this.totalTax = totalTax;
	}

	public BigDecimal getRoundCorrection() {
		return roundCorrection;
	}

	public void setRoundCorrection(BigDecimal roundCorrection) {
		this.roundCorrection = roundCorrection;
	}

}
