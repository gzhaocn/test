package com.walmart.mobile.checkout.bo.payment;

import java.io.Serializable;

import com.google.common.base.Strings;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "客户端支付回调参数模型")
public class PaymentSyncNotification implements Serializable {

	private static final long serialVersionUID = 7779591895061642610L;

	@ApiModelProperty(value = "支付类型", required = true)
	private int payType;

	@ApiModelProperty(value = "订单号", required = true)
	private String orderId;

	@ApiModelProperty(value = "支付状态码", required = true)
	private String code;

	public int getPayType() {
		return payType;
	}

	public void setPayType(int payType) {
		this.payType = payType;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public boolean isValid() {
		return payType > 0 && !Strings.isNullOrEmpty(orderId) && !Strings.isNullOrEmpty(code);
	}
}
