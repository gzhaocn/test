package com.walmart.mobile.checkout.service.recordsale;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.walmart.mobile.checkout.bo.order.OrderBo;
import com.walmart.mobile.checkout.bo.order.OrderLineBo;
import com.walmart.mobile.checkout.bo.recordsale.LinkSave;
import com.walmart.mobile.checkout.bo.recordsale.RecordSaleOrder;
import com.walmart.mobile.checkout.bo.recordsale.RecordSaleOrderInfo;
import com.walmart.mobile.checkout.bo.recordsale.RecordSaleOrderLine;
import com.walmart.mobile.checkout.bo.recordsale.Tax;
import com.walmart.mobile.checkout.bo.recordsale.Weight;
import com.walmart.mobile.checkout.constant.recordsale.RecordSaleConstants;
import com.walmart.mobile.checkout.domain.order.OrderDiscount;
import com.walmart.mobile.checkout.rest.service.recordsale.OrderRecordSaleClient;

@Service
public class RecordSaleService {

	private static final Logger LOG = LoggerFactory.getLogger(RecordSaleService.class);

	@Value("${recordsale.test}")
	String recordSaleStatus;
	
	@Value("${recordsale.test.store}")
	String recordSaleStore; 

	@Autowired
	private OrderRecordSaleClient orderRecordSaleClient;

	public String sendRecordSale(String orderId, String orderSource, String rsOrderType,Integer orderEvent) {
		String postStr = this.sendMobileCktRecordSale(orderId, orderSource, rsOrderType,  orderEvent);
		LOG.info(" orderId:{} ,  send recordsale message : {} ", orderId, postStr);
		if (null == postStr) {
			return null;
		}
		return postStr;
	}

	
	private RecordSaleOrder getRecordSaleOrder(String orderId, String orderSource, String rsOrderType,Integer orderEvent) {

		OrderBo orderBo = orderRecordSaleClient.requestOrderDetailByUserIdAndOrderIdForPassMachine(null, orderId);

		if (orderBo == null) {
			LOG.info(" orderid : {}  not find", orderId);
			return null;
		} 

		RecordSaleOrder rsOrder = new RecordSaleOrder();
		rsOrder.setOrderId(orderId);
		rsOrder.setRealOrderId(orderId);
		rsOrder.setRecordEvent(orderEvent);
		RecordSaleOrderInfo orderInfo = new RecordSaleOrderInfo();
		orderInfo.setOrderId(orderId);
		orderInfo.setOrderSource(orderSource);
		orderInfo.setRsOrderType(rsOrderType);
		
		if ("1".equals(recordSaleStatus)) {
			orderInfo.setStoreNbr(Integer.parseInt(recordSaleStore));
		} else {
			orderInfo.setStoreNbr(orderBo.getStoreId());
		}


		orderInfo.setTenderAmount(orderBo.getAmount());
		orderInfo.setSaleAmount(orderBo.getAmount().add(orderBo.getTotalGpDiscount()).add(orderBo.getVoucherDiscount()));

		List<OrderLineBo> orderLineBoList = orderBo.getOrderLineBoList();


		Map<Integer, Tax> map = new  HashMap<>(); 

		// GP的itemInfo
		Map<String, RecordSaleOrderLine> gpOrderItemMap = new HashMap<>(16);

		for (OrderLineBo orderLineBo : orderLineBoList) {

			List<OrderDiscount> itemOrderDiscountList = orderLineBo.getOrderDiscountList();
			RecordSaleOrderLine orderItem = new RecordSaleOrderLine();
			orderItem.setLineItemType(orderLineBo.getItemType());
			orderItem.setItemNbr(orderLineBo.getItemNumber()+"");
			orderItem.setItemDesc(orderLineBo.getPosDescOnline());
			orderItem.setUpcNbr(orderLineBo.getUpc() + "");
			orderItem.setReportCode(orderLineBo.getReportCode());
			orderItem.setDeptNbr(orderLineBo.getDepartment());
			orderItem.setQuantity(orderLineBo.getOrderQuantity());
			orderItem.setBasePrice(orderLineBo.getPriceWithoutTax());
			
			Tax tax = new Tax();
			tax.setTaxType(RecordSaleConstants
					.getTaxType(orderLineBo.getTaxRate().multiply(BigDecimal.valueOf(100)).intValue()));
				setTaxAmount(tax, orderLineBo, map);
				
			if (RecordSaleConstants.PRODUCT_TYPE_WEIGHT == orderLineBo.getItemType()) {
				Weight weight = new Weight();
				weight.setUom(RecordSaleConstants.MOBILE_CHECKOUT_WEIGHT_UOM);
				weight.setAmount(orderLineBo.getOrderWeight());
				orderItem.setTotalWeight(weight);
				orderItem.setItemAmount(orderLineBo.getItemAmount().subtract(orderLineBo.getGpDiscount()));
			}else{
				BigDecimal temp = orderLineBo.getPriceWithTax().multiply(new BigDecimal(orderLineBo.getOrderQuantity()));
				orderItem.setItemAmount(temp.subtract(orderLineBo.getGpDiscount()));
			}

			orderItem.setTax(tax);

			for (OrderDiscount orderDiscount : itemOrderDiscountList) {
				setOtherInfo(orderItem, orderDiscount, orderLineBo.getItemType());
				setGpOrderItem(gpOrderItemMap, orderItem, orderDiscount, orderLineBo);
			}

			rsOrder.getOrderItems().add(orderItem);
		}


		
		// 调整整体的税
		reviseTotalTax(gpOrderItemMap, map);

		orderInfo.getTotalTax().addAll(map.values());

		rsOrder.setOrderInfo(orderInfo);

		rsOrder.getOrderItems().addAll(gpOrderItemMap.values());

		// 修改不同税率的taxAmount

		 return rsOrder ;
		

	}

	
	
	private String sendMobileCktRecordSale(String orderId, String orderSource, String rsOrderType , Integer recordEvent) {
		return JSON.toJSONString(getRecordSaleOrder(orderId, orderSource, rsOrderType,recordEvent));
	}
	


	private void setTaxAmount(Tax tax, OrderLineBo orderLineBo, Map<Integer, Tax> map) {

		if (RecordSaleConstants.PRODUCT_TYPE_NOMOAL == orderLineBo.getItemType()) {
			// 非称重商品

			BigDecimal taxAmount = orderLineBo.getPriceWithTax().subtract(orderLineBo.getPriceWithoutTax())
					.multiply(BigDecimal.valueOf(orderLineBo.getOrderQuantity()));
			getTempTaxMap(map, taxAmount, orderLineBo.getTaxRate().multiply(BigDecimal.valueOf(100)).intValue());
			tax.setTaxAmount(taxAmount);

		} else {

			// 称重商品
			BigDecimal tempPriceAmount = orderLineBo.getPriceWithoutTax().multiply(orderLineBo.getOrderWeight()).setScale(2, BigDecimal.ROUND_HALF_UP);
			BigDecimal taxAmount = getSubTaxAmount(orderLineBo.getItemAmount(),tempPriceAmount);
			getTempTaxMap(map, taxAmount, orderLineBo.getTaxRate().multiply(BigDecimal.valueOf(100)).intValue());

			tax.setTaxAmount(taxAmount);

		}

	}

	

	/**
	 * 生成gpOrderItem
	 * 
	 * @param gpOrderItemMap
	 * @param orderItem
	 * @param orderDiscount
	 * @param orderLineBo
	 */
	private void setGpOrderItem(Map<String, RecordSaleOrderLine> gpOrderItemMap, RecordSaleOrderLine orderItem,
			OrderDiscount orderDiscount, OrderLineBo orderLineBo) {

		if (orderDiscount.getGpDiscount().compareTo(new BigDecimal(0)) == 0) { // 去掉没有生效的GP信息
			return;
		}
		RecordSaleOrderLine gpOrderItem = gpOrderItemMap.get(orderDiscount.getGpOfferId() + "");
		if (gpOrderItem != null) {
			BigDecimal tempTaxMount = getTaxAmount(orderDiscount.getGpDiscount(), orderLineBo.getTaxRate());
			gpOrderItem.getTax().setTaxAmount(gpOrderItem.getTax().getTaxAmount().add(tempTaxMount));
			gpOrderItem
					.setBasePrice(gpOrderItem.getBasePrice().add(orderDiscount.getGpDiscount().subtract(tempTaxMount)));
			gpOrderItem.setQuantity(1);
			gpOrderItem.setItemAmount(orderDiscount.getGpDiscount().add(gpOrderItem.getItemAmount()));
		} else {
			gpOrderItem = new RecordSaleOrderLine();
			gpOrderItem.setDeptNbr(orderItem.getDeptNbr());
			gpOrderItem.setLineItemType(RecordSaleConstants.PRODUCT_TYPE_GPITEM);
			gpOrderItem.setItemNbr("0");
			gpOrderItem.setItemDesc(RecordSaleConstants.GP_ITEM_DESC);
			gpOrderItem.setUpcNbr(orderDiscount.getLinkSaveId() == null ? "" : orderDiscount.getLinkSaveId() + "");
			gpOrderItem.setReportCode(orderItem.getReportCode());
			gpOrderItem.setDeptNbr(orderItem.getDeptNbr());
			// gp触发的次数
			gpOrderItem.setQuantity(1);
			Tax tax = new Tax();
			tax.setTaxType(orderItem.getTax().getTaxType());

			// 总税额 ： (含税价 -(含税价 / (1 + 税率)))
			tax.setTaxAmount(getTaxAmount(orderDiscount.getGpDiscount(), orderLineBo.getTaxRate()));
			// GP的优惠金额都是含税价，tLOG 都是 原价，单价原价
			gpOrderItem.setBasePrice((orderDiscount.getGpDiscount().subtract(tax.getTaxAmount())));

			gpOrderItem.setTax(tax);
			gpOrderItemMap.put(orderDiscount.getGpOfferId().toString(), gpOrderItem);
			gpOrderItem.setItemAmount(orderDiscount.getGpDiscount());
		}
	}

	private void setOtherInfo(RecordSaleOrderLine orderItem, OrderDiscount orderDiscount, int type) {
		LinkSave linkSave = new LinkSave();
		linkSave.setLinkSaveOfferId(orderDiscount.getLinkSaveId() == null ? "" : orderDiscount.getLinkSaveId() + "");
		if (RecordSaleConstants.PRODUCT_TYPE_NOMOAL == type) { // 普通商品
			linkSave.setLinkSaveTriggerQty(orderItem.getQuantity());// default
		} else {
			linkSave.setLinkSaveTriggerQty(1);
		}

		orderItem.getLinkSaves().add(linkSave);
	}

	// 税额 ： (含税价 -(含税价 / (1 + 税率)))
	private BigDecimal getTaxAmount(BigDecimal amount, BigDecimal taxRate) {
		return amount.subtract(amount.divide(BigDecimal.valueOf(1).add(taxRate), 2, BigDecimal.ROUND_HALF_UP));
	}

	private BigDecimal getSubTaxAmount(BigDecimal priceWithTax, BigDecimal priceWithoutTax) {
		LOG.info("priceWithTax:{} ,priceWithoutTax:{}", priceWithTax, priceWithoutTax);
		return priceWithTax.subtract(priceWithoutTax).setScale(2, BigDecimal.ROUND_HALF_UP);
	}





	private void getTempTaxMap(Map<Integer, Tax> map, BigDecimal taxAmount, Integer taxRate) {

		if (map.containsKey(taxRate)) {
			Tax tax = map.get(taxRate);
			tax.setTaxAmount(tax.getTaxAmount().add(taxAmount));
			map.put(taxRate, tax);
		} else {
			Tax tax = new Tax();
			tax.setTaxType(RecordSaleConstants.getTaxType(taxRate));
			tax.setTaxAmount(taxAmount);
			map.put(taxRate, tax);
		}
	}



	private void reviseTotalTax(Map<String, RecordSaleOrderLine> gpOrderItemMap, Map<Integer, Tax> map) {
		for (RecordSaleOrderLine recordSaleOrderLine : gpOrderItemMap.values()) {
			Tax tax = recordSaleOrderLine.getTax();
			switch (tax.getTaxType()) {
			case RecordSaleConstants.TAXTYPE_TAX_2:
				Tax taxRateTemp2 = map.get(RecordSaleConstants.TAXTYPE_TAX_RATE_2);
				taxRateTemp2.setTaxAmount(taxRateTemp2.getTaxAmount().subtract(tax.getTaxAmount()));
				break;
			case RecordSaleConstants.TAXTYPE_TAX_3:
				Tax taxRateTemp3 = map.get(RecordSaleConstants.TAXTYPE_TAX_RATE_3);
				taxRateTemp3.setTaxAmount(taxRateTemp3.getTaxAmount().subtract(tax.getTaxAmount()));
				break;
			default:
				break;
			}
		}
	}

}
