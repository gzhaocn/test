package com.walmart.mobile.checkout.utils.payment.egiftcard;

import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.exception.ExceptionUtils;

public class ProductIdAndBatchNoHelper {

	private ProductIdAndBatchNoHelper() {
	}

	public static final String getErrMsg(Throwable ex) {
		return ExceptionUtils.getFullStackTrace(ex).replaceAll("[\t\n]", " ").replaceAll("\r", "");
	}

	public static String connectParametersForUrl(Map<String, String> map) {
		StringBuilder sb = new StringBuilder();
		for (Entry<String, String> mapEntry : map.entrySet()) {
			sb.append(mapEntry.getKey());
			sb.append("=");
			sb.append(mapEntry.getValue());
			sb.append("&");
		}
		if (sb.length() > 0) {
			sb.deleteCharAt(sb.length() - 1);
		}
		return sb.toString();
	}

}
