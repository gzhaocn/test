package com.walmart.mobile.checkout.bo.payment;

import java.io.Serializable;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "支付请求参数模型(支付宝)")
public class AliPaymentRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9161582506981000526L;

	@ApiModelProperty(value = "订单编码", required = true)
	String orderId;

	@ApiModelProperty(value = "订单主题", required = true)
	String subject;

	@ApiModelProperty(value = "订单内容", required = true)
	String body;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

}
