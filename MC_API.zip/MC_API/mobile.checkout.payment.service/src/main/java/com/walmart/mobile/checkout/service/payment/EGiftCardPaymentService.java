package com.walmart.mobile.checkout.service.payment;

import java.math.BigDecimal;
import java.security.NoSuchAlgorithmException;
import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.walmart.mobile.checkout.bo.payment.OrderVo;
import com.walmart.mobile.checkout.bo.payment.StoreVo;
import com.walmart.mobile.checkout.rest.payment.PaymentOrderClient;
import com.walmart.mobile.checkout.rest.payment.PaymentStoreClient;
import com.walmart.mobile.checkout.rest.payment.PaymentUserClient;
import com.walmart.mobile.checkout.utils.crypto.SHA512;
import com.walmart.mobile.checkout.utils.payment.egiftcard.ProductIdAndBatchNoHelper;

@Service
public class EGiftCardPaymentService {

	private static final Logger LOGGER = LoggerFactory.getLogger(EGiftCardPaymentService.class);
	
	@Value("${payment.amount.test}")
	private String paymentAmount;
	
	@Value("${upcard.pay.v}")
	private String payVersion;

	@Value("${upcard.pay.url}")
	private String payJumpUrl;

	@Value("${card66.issuerId}")
	private String issuerId;

	@Value("${upcard.pay.timeout}")
	private int payTimeout;

	@Value("${upcard.pay.notifyUrl}")
	private String payNotifyUrl;

	@Value("${upcard.pay.pushTimes}")
	private int payPushTimes;

	@Value("${upcard.pay.custom}")
	private String payCustom;

	@Value("${upcard.pay.host}")
	private String payHost;

	@Value("${upcard.pay.protocol}")
	private String payProtocol;

	@Value("${upcard.pay.path}")
	private String payPath;

	@Value("${card66.merId}")
	private String merId;

	@Value("${card66.privateKey}")
	private String privateKey;

	@Autowired
	private PaymentUserClient paymentUserClient;

	@Autowired
	private PaymentOrderClient paymentOrderClient;

	@Autowired
	private PaymentStoreClient paymentStoreClient;

	public Map<String, String> getPayUrl(String userId, String orderId) throws NoSuchAlgorithmException {

		String cardType = "VIRTUAL";
		String mobilePhone = paymentUserClient.findByUserId(userId).getMobilePhone();
		OrderVo order = paymentOrderClient.getOrderByOrderId(orderId);
		// String amount = String.valueOf(new
		// BigDecimal("100").multiply(order.getAmount()));

		String amount = String.valueOf(order.getAmount().doubleValue());
		amount = getYuanToCent(amount);
		LOGGER.info("orgin count :  {}", amount);
		if("1".equals(paymentAmount)){
			amount = "1";
		}
		
		String merId = getMerIdByOrderId(order.getStoreId());
		String mac = generateMac(orderId, amount, payJumpUrl, cardType, mobilePhone, merId);
		Map<String, String> param = new HashMap<>(16);
		param.put("v", payVersion);
		param.put("issuerId", issuerId);
		param.put("merId", merId);
		param.put("orderId", orderId);
		param.put("amount", amount);
		param.put("mac", mac);
		param.put("timeout", Integer.toString(payTimeout));
		param.put("url", payJumpUrl);
		param.put("notifyUrl", payNotifyUrl);
		param.put("pushTimes", Integer.toString(payPushTimes));
		param.put("custom", payCustom);
		param.put("cardType", cardType);
		param.put("mobliePhone", mobilePhone);
		param.put("signType", "SHA512");
		String paramString = ProductIdAndBatchNoHelper.connectParametersForUrl(param);
		LOGGER.info("egift paramString :  {}", paramString);
		String payUrl = payProtocol + "://" + payHost + payPath + "?" + paramString;
		Map<String, String> retMap = new HashMap<>(2);
		retMap.put("payUrl", payUrl);
		retMap.put("jumpUrl", payJumpUrl);
		LOGGER.info("egift payUrl:{} ,jumpUrl:{} ", payUrl, payJumpUrl);
		return retMap;
	}

	private String generateMac(String orderId, String amount, String url, String cardType, String mobliePhone,
			String merId) throws NoSuchAlgorithmException {
		String v = payVersion;
		int timeout = payTimeout;
		String notifyUrl = payNotifyUrl;
		int pushTimes = payPushTimes;

		return SHA512.hashValue(v + merId + orderId + amount + timeout + url + notifyUrl + pushTimes + payCustom
				+ cardType + mobliePhone + privateKey).toUpperCase();
	}

	private String getMerIdByOrderId(Integer storeId) {
		StoreVo store = paymentStoreClient.findByStoreId(storeId);
		return store.getEgiftcardPayMerId() != null ? store.getEgiftcardPayMerId() : merId;
	}

	/**
	 * 对银商前台返回结果进行校验，确保返回结果来自银商
	 * 
	 * @param params
	 *            银商支付后前台返回结果参数map
	 * @return true：校验成功 false：校验失败
	 * @throws NoSuchAlgorithmException
	 */
	public boolean isReturnedFromEgiftcard(Map<String, String> params) throws NoSuchAlgorithmException {
		StringBuilder sb = new StringBuilder(params.get("type")).append(params.get("merId"))
				.append(params.get("orderId")).append(params.get("amount")).append(params.get("tranId"))
				.append(params.get("txndate")).append(params.get("txntime")).append(params.get("returnCode"))
				.append(privateKey);
		// 计算mac值
		String computeMac = SHA512.hashValue(sb.toString());
		LOGGER.info("computeMac:[{}], returnMac:[{}]", computeMac, params.get("mac"));
		// 根据返回值参数计算得到的mac值与银商返回的mac值一致（不区分大小写）
		return computeMac.equalsIgnoreCase(params.get("mac"));
	}

	private String getYuanToCent(String money) {
		BigDecimal b1 = new BigDecimal(money);
		BigDecimal b2 = new BigDecimal("100");
		NumberFormat numberFormat = NumberFormat.getIntegerInstance();
		numberFormat.setGroupingUsed(false);

		return numberFormat.format(b1.multiply(b2).doubleValue());
	}
}
