package com.walmart.mobile.checkout.rest.payment;

import java.math.BigDecimal;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;

@FeignClient("orderStatusService")
@FunctionalInterface
public interface PaymentOrderStatusClient {

	@RequestMapping(method = RequestMethod.GET, value = "/updateOrderStatusByOrderId")
	int updateOrderStatusByOrderId(@RequestParam(value = "orderId") String orderId,
			@RequestParam(value = "version") int version, @RequestParam(value = "status") int status, @RequestParam(value = "paymentCouponFee")  BigDecimal paymentCouponFee,
			@RequestParam(value = "payType") int payType) throws GlobalErrorInfoException;

}