package com.walmart.mobile.checkout.constant.recordsale;

import com.walmart.mobile.checkout.exception.handler.ErrorInfoInterface;

/**
 * 系统及业务级别的错误码
 */
public enum RecordSaleErrorInfoEnum implements ErrorInfoInterface {
	SUCCESS("0", "success"), RECORDSALE_UPDATE_FAILED("-801", "TC NUMBER更新失败"), RECORDSALE_SEND_MESSAGE_FAIL("-802",
			"consume recordsale message fail");

	private String code;

	private String message;

	RecordSaleErrorInfoEnum(String code, String message) {
		this.code = code;
		this.message = message;
	}

	@Override
	public String getCode() {
		return this.code;
	}

	@Override
	public String getMessage() {
		return this.message;
	}
}
