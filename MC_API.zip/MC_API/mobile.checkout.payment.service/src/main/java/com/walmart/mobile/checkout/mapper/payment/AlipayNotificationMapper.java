package com.walmart.mobile.checkout.mapper.payment;

import java.util.List;
import java.util.Map;

import com.walmart.mobile.checkout.domain.payment.AlipayNotification;

public interface AlipayNotificationMapper {

	int deleteByPrimaryKey(String id);

	int insert(AlipayNotification record);

	int insertSelective(AlipayNotification record);

	AlipayNotification selectByOrderAndTradeStatus(Map<String, Object> params);

	List<AlipayNotification> selectByPrimaryKey(String orderId);

	int updateByPrimaryKeySelective(AlipayNotification record);

	int updateByPrimaryKey(AlipayNotification record);

	List<AlipayNotification> selectByUserId(String userId);

	AlipayNotification selectByTradeIdAndTradeStatus(Map<String, Object> params);
}