package com.walmart.mobile.checkout.enumcode.payment;

import com.walmart.mobile.checkout.exception.handler.ErrorInfoInterface;

/**
 * 系统及业务级别的错误码
 */
public enum PaymentErrorInfoEnum implements ErrorInfoInterface {
	SUCCESS("0", "success"), CHECK_AUTH_FAILED("-401", "Not authorized to access this order."), ORDER_HAVE_BEAN_PAID(
			"-402",
			"order has been paid."), PAID_HAS_NO_RESULT("-403", "Paid ,but has no result."), WECHAT_CONNECTION_ERROR(
					"-404", "collection time out."), PAID_FAIL("-405", "Paid fail."), ORDER_UPDATE_STATUS_FAIL("-406",
							"order update status fail"), WECHAT_CALLBACK_EXCEPTION("-407",
									"wechat callback exception"), PAYMENT_VERIFICATION_ERROR("-408",
											"alipay parmeter vefification error"), UNION_VERIFICATION_ERROR("-409",
													"union parmeter vefification error"), RSA_SIGN_ERROR("-410",
															"rsa sign error"), STORE_ID_IS_EMPTY("-411",
																	"storeId is empty"), EGIFT_PAY_URL_ERROR("-412",
																			"get egift pay url  error"), EGIFT_PAY_PARAMTER_ERROR(
																					"-413",
																					"egift pay parameter error"), ORDER_IS_TIMEOUT(
																							"-414",
																							"order is time out"), WECHAT_SIGNATURE_ERROR(
																									"-415",
																									"wechat signature error");

	private String code;

	private String message;

	PaymentErrorInfoEnum(String code, String message) {
		this.code = code;
		this.message = message;
	}

	@Override
	public String getCode() {
		return this.code;
	}

	@Override
	public String getMessage() {
		return this.message;
	}
}
