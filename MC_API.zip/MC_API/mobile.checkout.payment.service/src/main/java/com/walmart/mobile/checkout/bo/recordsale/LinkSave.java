package com.walmart.mobile.checkout.bo.recordsale;

import java.io.Serializable;

public class LinkSave implements Serializable {

	private static final long serialVersionUID = 6227275106986820989L;

	private String linkSaveOfferId;

	private Integer linkSaveTriggerQty;

	public String getLinkSaveOfferId() {
		return linkSaveOfferId;
	}

	public void setLinkSaveOfferId(String linkSaveOfferId) {
		this.linkSaveOfferId = linkSaveOfferId;
	}

	public Integer getLinkSaveTriggerQty() {
		return linkSaveTriggerQty;
	}

	public void setLinkSaveTriggerQty(Integer linkSaveTriggerQty) {
		this.linkSaveTriggerQty = linkSaveTriggerQty;
	}

}
