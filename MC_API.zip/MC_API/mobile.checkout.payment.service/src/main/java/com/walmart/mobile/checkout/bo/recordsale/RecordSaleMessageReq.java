package com.walmart.mobile.checkout.bo.recordsale;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
 *
 */
@ApiModel(description = "record sale Message")
public class RecordSaleMessageReq implements Serializable {

	private static final long serialVersionUID = 7422448539711116709L;

	@ApiModelProperty(value = "订单号")
	@JsonProperty(value = "orderId")
	private String orderId;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

}
