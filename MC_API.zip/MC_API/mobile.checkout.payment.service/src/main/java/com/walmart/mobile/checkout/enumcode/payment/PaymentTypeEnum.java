package com.walmart.mobile.checkout.enumcode.payment;

public class PaymentTypeEnum {

	public static final int ALIPAY = 1;
	public static final int UNIONPAY = 3;
	public static final int EGIFTCARD = 4;
	public static final int WECHATPAY = 2;

	private PaymentTypeEnum() {
	}
}
