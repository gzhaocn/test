package com.walmart.mobile.checkout.service.payment;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.walmart.mobile.checkout.domain.payment.AlipayNotification;
import com.walmart.mobile.checkout.mapper.payment.AlipayNotificationMapper;

@Service
public class AlipayNotificationService {

	private static final Logger LOGGER = LoggerFactory.getLogger(AlipayNotificationService.class);

	@Autowired
	private AlipayNotificationMapper alipayNotificationMapper;

	public void create(AlipayNotification alipayNotification) {

		alipayNotificationMapper.insert(alipayNotification);
	}

	public AlipayNotification create(Map<String, String> properties) {

		AlipayNotification entity = new AlipayNotification();

		String orderId = properties.get("out_trade_no");
		entity.setOrderId(orderId);
		// 更新order状态

		entity.setCreatedBy("alipay");
		entity.setCreatedTime(new Date());
		assignProperties(entity, properties);

		alipayNotificationMapper.insert(entity);

		return entity;
	}

	public void update(AlipayNotification entity) {

		alipayNotificationMapper.updateByPrimaryKey(entity);
	}

	public AlipayNotification update(Map<String, String> properties) {

		AlipayNotification entity = new AlipayNotification();

		assignProperties(entity, properties);
		entity.setUpdatedTime(new Date());
		entity.setUpdatedBy(properties.get("updated_by"));
		alipayNotificationMapper.updateByPrimaryKey(entity);

		return entity;
	}

	public AlipayNotification selectByOrderAndTradeStatus(Map<String, Object> params) {
		return alipayNotificationMapper.selectByOrderAndTradeStatus(params);
	}

	private void assignProperties(AlipayNotification entity, Map<String, String> properties) {

		entity.setBody(properties.get("body"));
		entity.setSignature(properties.get("sign"));
		entity.setSignType(properties.get("sign_type"));
		entity.setSubject(properties.get("subject"));
		entity.setPaymentType(properties.get("payment_type"));
		entity.setTradeId(properties.get("trade_no"));
		entity.setTradeStatus(properties.get("trade_status"));
		entity.setSellerId(properties.get("seller_id"));
		entity.setSellerEmail(properties.get("seller_email"));
		entity.setBuyerId(properties.get("buyer_id"));
		entity.setBuyerEmail(properties.get("buyer_email"));
		entity.setQuantity(string2int(properties.get("quantity")));

		entity.setTotalFee(BigDecimal.valueOf(string2double(properties.get("total_fee"))));
		entity.setPrice(BigDecimal.valueOf(string2double(properties.get("price"))));

		entity.setGmtCreate(string2date(properties.get("gmt_create")));
		entity.setGmtPayment(string2date(properties.get("gmt_payment")));
		entity.setNotifyTime(string2date(properties.get("notify_time")));

		entity.setIsTotalFeeAdjust(properties.get("is_total_fee_adjust"));
		entity.setUseCoupon(properties.get("use_coupon"));
		entity.setDiscount(properties.get("discount"));
		entity.setNotifyType(properties.get("notify_type"));
		entity.setNotifyId(properties.get("notify_id"));
		entity.setExternalTransactionId(properties.get("external_transaction_id"));
		entity.setOrderId(properties.get("out_trade_no"));
		entity.setCurrency(properties.get("currency"));

	}

	private Date string2date(String value) {
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd");

		if (!StringUtils.isBlank(value)) {
			Date d = null;
			try {
				d = format.parse(value);
			} catch (ParseException e) {
				LOGGER.error("Failed to format the String to Date", e);
			}
			return d;
		} else {
			return null;
		}
	}

	private Double string2double(String value) {
		if (!StringUtils.isBlank(value)) {
			return Double.parseDouble(value);
		} else {
			return 0.0;
		}
	}

	private int string2int(String value) {
		if (!StringUtils.isBlank(value)) {
			return Integer.parseInt(value);
		} else {
			return 0;
		}
	}
}
