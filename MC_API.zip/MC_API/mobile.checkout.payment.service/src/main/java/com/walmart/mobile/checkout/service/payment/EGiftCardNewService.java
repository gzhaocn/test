package com.walmart.mobile.checkout.service.payment;

import java.security.NoSuchAlgorithmException;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.bo.payment.OrderVo;
import com.walmart.mobile.checkout.domain.payment.EGiftcardNewNotification;
import com.walmart.mobile.checkout.mapper.payment.EGiftcardNewNotificationMapper;
import com.walmart.mobile.checkout.utils.crypto.SHA512;

@Service
public class EGiftCardNewService {

	private static final Logger LOGGER = LoggerFactory.getLogger(EGiftCardNewService.class);
	
	@Autowired
	private EGiftcardNewNotificationMapper egiftcardNewNotificationMapper;

	@Value("${egiftcard.new.base.url}")
	private String baseUrl ;
	
	@Value("${egiftcard.new.appKey}")
	private String appKey ;//调用者身份码
	
	@Value("${egiftcard.new.organ}")
	private String organ ;//商户号
	
	@Value("${egiftcard.new.seckey}")
	private String seckey; //秘钥
	
	@Value("${egiftcard.new.channelcode}")
	private String channelCode ;//渠道号标示
	
	@Value("${egiftcard.new.notifyUrl}")
	private String notifyUrl = "http://202.105.124.225:50025/mobileCK/payment/new/egiftcard/payNotify" ; //通知地址
	
	private String backUrl ; //返回地址


	public String getEgiftcardUrl(String method, OrderVo orderVo ) throws NoSuchAlgorithmException{
		String timastamp = Long.toString(System.currentTimeMillis());
		StringBuilder stringBuilder = new StringBuilder(baseUrl);
		stringBuilder.append(appKey).append("/").append("organ/").append(organ+".json?");
		stringBuilder.append("timestamp="+timastamp);
		stringBuilder.append("&method="+method);
	
		String signatureString = organ+method+timastamp+""+getEgiftcardParameter(orderVo)+seckey;
		LOGGER.info("sign before string :{} ",signatureString);
		
		String signature = SHA512.hashValue(signatureString).toUpperCase();
		LOGGER.info("signature string :{} ",signature);
		
		stringBuilder.append("&signature="+signature);
		LOGGER.info("post string :{} ",stringBuilder.toString());
		return stringBuilder.toString();
	}

	public String getEgiftcardParameter(OrderVo orderVo)  {

		JSONObject map = new JSONObject(true);
		map.put("organ", organ);
		map.put("channelCode", channelCode);
		map.put("channelTradeNo", orderVo.getOrderId());
		map.put("totalFee", "1");
		map.put("feeType", "CNY");
		map.put("terminal", "82");
		map.put("barcode", "1111");//条形码
		map.put("storeId", orderVo.getStoreId());
		map.put("storeName", "香蜜店");//门店名称
		map.put("notifyUrl", notifyUrl);//通知接口地址
		map.put("backUrl","http://www.baidu.com");//门店名称
		return map.toString();
	}


	

	public EGiftcardNewNotification createEGiftcardNotification(EGiftcardNewNotification entity) {
		entity.setCreatedBy("mobilecheckout");
		entity.setCreatedTime(new Date());
		entity.setUpdatedBy("mobilecheckout");
		entity.setUpdatedTime(new Date());
		egiftcardNewNotificationMapper.insert(entity);
		return entity;
	}

	public EGiftcardNewNotification selectEgiftcardNotificationByOrderId(String orderId) {
		return egiftcardNewNotificationMapper.selectByOrderId(orderId);
	}
	
	public boolean checkNotify(EGiftcardNewNotification entity) throws NoSuchAlgorithmException{
		String sign = entity.getSign();
		StringBuilder sb = new StringBuilder();
		sb.append("channelCode="+entity.getChannelCode()+"&");
		sb.append("channelTradeNo="+entity.getChannelTradeNo()+"&");
		sb.append("feeType="+entity.getFeeType()+"&");
		sb.append("nonceStr="+entity.getNonceStr()+"&");
		sb.append("organ="+entity.getOrgan()+"&");
		sb.append("timeEnd="+entity.getTimeEnd().getTime()+"&");
		sb.append("timestamp="+entity.getTimestamp()+"&");
		sb.append("totalFee="+entity.getTotalFee()+"&");
		sb.append("wftTradeNo="+entity.getWftTradeNo()+seckey);
		String signString = sb.toString() ;
		String signature =  SHA512.hashValue(signString).toUpperCase();
		LOGGER.info("sign :{} , signature : {} ,  sign string :",sign, signature, signString);
		return signature.equals(sign);
	}
	
	public String setResponseString(String errorCode, String errmsg){
		JSONObject map = new JSONObject(true);
		map.put("errorCode", errorCode);
		map.put("errmsg", errmsg);
		return map.toString();
	}
}
