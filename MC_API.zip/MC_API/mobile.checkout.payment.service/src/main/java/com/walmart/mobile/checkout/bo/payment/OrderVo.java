package com.walmart.mobile.checkout.bo.payment;

import java.math.BigDecimal;
import java.util.Date;

public class OrderVo {

	private String orderId;

	private int status;

	private BigDecimal amount;

	private String tcNumber;

	private Integer tcSequenceNumber;

	private Integer tcRegisterNumber;

	private Date tcTransTime;

	private int cancelReason;

	private Date createdTime;

	private int payType;

	private Integer version;

	private Integer storeId;
	private Integer deliveryFlag;
	private String userId;

	public OrderVo() {
		this.version = 0;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getTcNumber() {
		return tcNumber;
	}

	public void setTcNumber(String tcNumber) {
		this.tcNumber = tcNumber;
	}

	public Integer getTcSequenceNumber() {
		return tcSequenceNumber;
	}

	public void setTcSequenceNumber(Integer tcSequenceNumber) {
		this.tcSequenceNumber = tcSequenceNumber;
	}

	public Integer getTcRegisterNumber() {
		return tcRegisterNumber;
	}

	public void setTcRegisterNumber(Integer tcRegisterNumber) {
		this.tcRegisterNumber = tcRegisterNumber;
	}

	public Date getTcTransTime() {
		return tcTransTime;
	}

	public void setTcTransTime(Date tcTransTime) {
		this.tcTransTime = tcTransTime;
	}

	public int getCancelReason() {
		return cancelReason;
	}

	public void setCancelReason(int cancelReason) {
		this.cancelReason = cancelReason;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public int getPayType() {
		return payType;
	}

	public void setPayType(int payType) {
		this.payType = payType;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public Integer getDeliveryFlag() {
		return deliveryFlag;
	}

	/**
	 * 运单标记
	 * 
	 * @param deliveryFlag
	 */
	public void setDeliveryFlag(Integer deliveryFlag) {
		this.deliveryFlag = deliveryFlag;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}
