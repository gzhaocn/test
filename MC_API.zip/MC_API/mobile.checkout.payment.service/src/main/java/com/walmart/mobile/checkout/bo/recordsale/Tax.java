package com.walmart.mobile.checkout.bo.recordsale;

import java.io.Serializable;
import java.math.BigDecimal;

import com.walmart.mobile.checkout.constant.recordsale.RecordSaleConstants;

public class Tax implements Serializable {

	private static final long serialVersionUID = 7018518547980882285L;

	private String taxType;

	private BigDecimal taxAmount;

	public Tax() {
		this.taxType = RecordSaleConstants.TAXTYPE_TAX_1;
		this.taxAmount = BigDecimal.valueOf(0);
	}

	public Tax(String taxType, BigDecimal taxAmount) {
		this.taxType = taxType;
		this.taxAmount = taxAmount;
	}

	public String getTaxType() {
		return taxType;
	}

	public void setTaxType(String taxType) {
		this.taxType = taxType;
	}

	public BigDecimal getTaxAmount() {
		return taxAmount;
	}

	public void setTaxAmount(BigDecimal taxAmount) {
		this.taxAmount = taxAmount;
	}

}
