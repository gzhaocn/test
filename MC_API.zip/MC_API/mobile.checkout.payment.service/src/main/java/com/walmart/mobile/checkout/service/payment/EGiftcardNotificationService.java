package com.walmart.mobile.checkout.service.payment;

import java.util.Date;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.walmart.mobile.checkout.domain.payment.EGiftcardNotification;
import com.walmart.mobile.checkout.mapper.payment.EGiftcardNotificationMapper;

@Service
public class EGiftcardNotificationService {

	@Autowired
	private EGiftcardNotificationMapper eGiftcardNotificationMapper;

	public EGiftcardNotification createEGiftcardNotification(Map<String, String> params) {
		EGiftcardNotification entity = new EGiftcardNotification();
		entity.setType(params.get("type"));
		entity.setMerId(params.get("merId"));
		entity.setMac(params.get("mac"));
		entity.setReturnCode(params.get("returnCode"));
		entity.setOrderId(params.get("orderId"));
		entity.setTranId(params.get("tranId"));
		entity.setTranDate(params.get("tranDate"));
		entity.setTranTime(params.get("tranTime"));
		entity.setAmount(params.get("amount"));
		entity.setCreatedTime(new Date());
		entity.setCreatedBy("eGiftcard");
		eGiftcardNotificationMapper.insert(entity);
		return entity;
	}

	public EGiftcardNotification selectEgiftcardNotificationByOrderId(String orderId) {
		return eGiftcardNotificationMapper.selectByOrderId(orderId);
	}
}
