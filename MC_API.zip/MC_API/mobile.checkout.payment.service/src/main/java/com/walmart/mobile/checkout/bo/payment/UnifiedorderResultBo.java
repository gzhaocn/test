package com.walmart.mobile.checkout.bo.payment;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 统一下单微信返回的参数组
 * 
 */
@ApiModel(description = "微信统一下单接口返回参数模型")
public class UnifiedorderResultBo {

	private UnifiedorderResult unifiedorderResult;
	@ApiModelProperty(value = "trade_type为NATIVE是有返回，可将该参数值生成二维码展示出来进行扫码支付")
	private String codeUrl;// trade_type为NATIVE是有返回，可将该参数值生成二维码展示出来进行扫码支付
	@ApiModelProperty(value = "设备号", required = true)
	private String deviceInfo;// 设备号
	@ApiModelProperty(value = "时间戳")
	private String timestamp; // 时间戳 ，客户端 调起支付接口用到

	public UnifiedorderResultBo() {
		/*
		 * default constructor
		 */
	}

	public UnifiedorderResultBo(UnifiedorderResult unifiedorderResult, String timeStamp) {
		this.unifiedorderResult = unifiedorderResult;
		this.timestamp = timeStamp;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public UnifiedorderResult getUnifiedorderResult() {
		return unifiedorderResult;
	}

	public void setUnifiedorderResult(UnifiedorderResult unifiedorderResult) {
		this.unifiedorderResult = unifiedorderResult;
	}

	public String getDeviceInfo() {
		return deviceInfo;
	}

	public void setDeviceInfo(String deviceInfo) {
		this.deviceInfo = deviceInfo;
	}

	public String getCodeUrl() {
		return codeUrl;
	}

	public void setCodeUrl(String codeUrl) {
		this.codeUrl = codeUrl;
	}

}
