package com.walmart.mobile.checkout.mapper.payment;

import com.walmart.mobile.checkout.domain.payment.WechatNotification;

public interface WechatNotificationMapper {

	int deleteByPrimaryKey(String outTradeNo);

	int insert(WechatNotification record);

	int insertSelective(WechatNotification record);

	WechatNotification selectByPrimaryKey(String outTradeNo);

	int updateByPrimaryKeySelective(WechatNotification record);

	int updateByPrimaryKey(WechatNotification record);
}