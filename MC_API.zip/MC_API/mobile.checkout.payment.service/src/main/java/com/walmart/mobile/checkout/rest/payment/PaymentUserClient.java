package com.walmart.mobile.checkout.rest.payment;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.walmart.mobile.checkout.bo.payment.UserVo;

@FeignClient("userService")
@FunctionalInterface
public interface PaymentUserClient {

	@RequestMapping(value = "/getUser")
	UserVo findByUserId(@RequestParam(value = "userId") String userId);

}