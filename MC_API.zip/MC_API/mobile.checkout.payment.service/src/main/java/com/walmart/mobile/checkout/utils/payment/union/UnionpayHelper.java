package com.walmart.mobile.checkout.utils.payment.union;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.unionpay.acp.sdk.SDKUtil;

public abstract class UnionpayHelper {

	private static final Logger LOGGER = LoggerFactory.getLogger(UnionpayHelper.class);

	public static final String ENCODING = "UTF-8";

	private UnionpayHelper() {
	}

	/**
	 * 数据提交 对数据进行签名
	 * 
	 * @param contentData
	 * @return 签名后的map对象
	 */
	@SuppressWarnings("unchecked")
	public static Map<String, String> signData(Map<String, ?> contentData) {
		Entry<String, String> obj;
		Map<String, String> submitFromData = new HashMap<>(16);
		for (Iterator<?> it = contentData.entrySet().iterator(); it.hasNext();) {
			obj = (Entry<String, String>) it.next();
			String value = obj.getValue();
			if (StringUtils.isNotBlank(value)) {
				// 对value值进行去除前后空处理
				submitFromData.put(obj.getKey(), value.trim());
				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug(obj.getKey() + "-->" + value.trim());
				}
			}
		}
		/**
		 * 签名
		 */
		SDKUtil.sign(submitFromData, ENCODING);
		return submitFromData;
	}

}
