package com.walmart.mobile.checkout.utils.payment.alipay;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.walmart.mobile.checkout.constant.AlipayConstants;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;

public class AlipayNotify {

	private AlipayNotify() {
	}

	private static final Logger LOGGER = LoggerFactory.getLogger(AlipayNotify.class.getName());

	public static boolean verify(Map<String, String> params) throws GlobalErrorInfoException {

		String responseTxt = "true";
		String notifyId = params.get("notify_id");
		String currency = params.get("currency");
		LOGGER.info("notify_id[{}], currency[{}]", notifyId, currency);
		if (notifyId != null) {
			responseTxt = verifyResponse(notifyId, currency);
		}
		String sign = params.get("sign");
		if (sign == null) {
			LOGGER.error("sign is null");
			return false;
		}
		LOGGER.info("sign is not null, and verify to continue, sign[{}]", sign);

		boolean isSign = getSignVerify(params, sign);

		LOGGER.info("VerifyResponse, responseTxt[{}]", responseTxt);
		if (isSign && "true".equals(responseTxt)) {
			LOGGER.info("verify is successfully.");
			return true;
		} else {
			LOGGER.info("verify is failed.");
			return false;
		}
	}

	private static boolean getSignVerify(Map<String, String> params, String sign) throws GlobalErrorInfoException {

		Map<String, String> sParaNew = AlipayCore.paraFilter(params);
		String preSignStr = AlipayCore.createLinkString(sParaNew);
		LOGGER.debug("SignVerify createLinkString, preSignStr[{}]", preSignStr);
		boolean isSign = false;

		if ("RSA".equals(AlipayConstants.SIGN_TYPE)) {
			isSign = RSA.verify(preSignStr, sign, AlipayConstants.ALI_PUBLIC_KEY, AlipayConstants.INPUT_CHARSET);
		}
		LOGGER.info("SignVerify finished, isSign[{}]", isSign);
		return isSign;
	}

	/**
	 * Verify alipay notification
	 * 
	 * @param notifyId
	 *            alipay notify_id
	 * @param currency
	 *            for FTZ use, eg. HKD, if not FTZ, currency is null
	 * @return verify result returned from alipay
	 */
	public static String verifyResponse(String notifyId, String currency) {

		String partner = AlipayConstants.PARTNER;
		// 如果回调参数中包含币种信息，就是境外支付回调
		if (!StringUtils.isBlank(currency)) {
			partner = AlipayConstants.PARTNER_FOREX;
		}
		String verifyUrl = AlipayConstants.HTTPS_UTL + "?service=notify_verify" + "&partner=" + partner + "&notify_id=" + notifyId;
		LOGGER.info("Verify_url[{}]", verifyUrl);
		return checkUrl(verifyUrl);
	}

	private static String checkUrl(String urlvalue) {
		String inputLine = "";
		try {
			URL url = new URL(urlvalue);
			HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
			try (BufferedReader in = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()))) {
				inputLine = in.readLine();
			}
		} catch (IOException e) {
			LOGGER.error("checkUrl error", e);
		}
		LOGGER.info("inputLine :{}", inputLine);
		return inputLine;
	}
}
