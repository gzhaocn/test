package com.walmart.mobile.checkout.mapper.payment;

import com.walmart.mobile.checkout.domain.payment.EGiftcardNewNotification;

public interface EGiftcardNewNotificationMapper {

	int insert(EGiftcardNewNotification record);

	EGiftcardNewNotification selectByOrderId(String orderId);
	
}