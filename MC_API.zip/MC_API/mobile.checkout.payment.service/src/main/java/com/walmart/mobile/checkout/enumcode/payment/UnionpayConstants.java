package com.walmart.mobile.checkout.enumcode.payment;

/**
 * 银联支付V5.0版异步通知应答报文参数
 */
public class UnionpayConstants {

	private UnionpayConstants() {
	}

	/**
	 * 版本号
	 */
	static final String RESPONSE_PARAMETER_VERSION = "version";
	/**
	 * 编码方式
	 */
	static final String RESPONSE_PARAMETER_ENCODING = "encoding";
	/**
	 * 证书ID
	 */
	static final String RESPONSE_PARAMETER_CERTID = "certId";
	/**
	 * 签名
	 */
	static final String RESPONSE_PARAMETER_SIGNATURE = "signature";
	/**
	 * 签名方法
	 */
	static final String RESPONSE_PARAMETER_SIGN_METHOD = "signMethod";
	/**
	 * 交易子类
	 */
	static final String RESPONSE_PARAMETER_TXN_SUB_TYPE = "txnSubType";
	/**
	 * 产品类型
	 */
	static final String RESPONSE_PARAMETER_BIZ_TYPE = "bizType";
	/**
	 * 接入类型
	 */
	static final String RESPONSE_PARAMETER_ACCESS_TYPE = "accessType";
	/**
	 * 商户代码
	 */
	static final String RESPONSE_PARAMETER_MER_ID = "merId";
	/**
	 * 商户订单号
	 */
	static final String RESPONSE_PARAMETER_ORDER_ID = "orderId";
	/**
	 * 订单发送时间
	 */
	public static final String RESPONSE_PARAMETER_TXN_TIME = "txnTime";
	/**
	 * 交易金额
	 */
	public static final String RESPONSE_PARAMETER_TXN_AMT = "txnAmt";
	/**
	 * 交易币种
	 */
	public static final String RESPONSE_PARAMETER_CURRENCY_CODE = "currencyCode";
	/**
	 * 请求方保留域
	 */
	public static final String RESPONSE_PARAMETER_REQ_RESERVED = "reqReserved";
	/**
	 * 保留域
	 */
	public static final String RESPONSE_PARAMETER_RESERVED = "reserved";
	/**
	 * 响应码
	 */
	public static final String RESPONSE_PARAMETER_RESP_CODE = "respCode";
	/**
	 * 响应信息
	 */
	public static final String RESPONSE_PARAMETER_RESP_MSG = "respMsg";
	/**
	 * 清算金额
	 */
	public static final String RESPONSE_PARAMETER_SETTLE_AMT = "settleAmt";
	/**
	 * 清算币种
	 */
	public static final String RESPONSE_PARAMETER_SETTLE_CURRENCY_CODE = "settleCurrencyCode";
	/**
	 * 清算日期
	 */
	public static final String RESPONSE_PARAMETER_SETTLE_DATE = "settleDate";
	/**
	 * 系统跟踪号
	 */
	public static final String RESPONSE_PARAMETER_TRACE_NO = "traceNo";
	/**
	 * 交易传输时间
	 */
	public static final String RESPONSE_PARAMETER_TRACE_TIME = "traceTime";
	/**
	 * 兑换日期
	 */
	public static final String RESPONSE_PARAMETER_EXCHANGE_DATE = "exchangeDate";
	/**
	 * 汇率
	 */
	public static final String RESPONSE_PARAMETER_EXCHANGE_RATE = "exchangeRate";
	/**
	 * 帐号
	 */
	public static final String RESPONSE_PARAMETER_ACC_NO = "accNo";
	/**
	 * 支付卡类型
	 */
	public static final String RESPONSE_PARAMETER_PAY_CARD_TYPE = "payCardType";
	/**
	 * 支付方式
	 */
	public static final String RESPONSE_PARAMETER_PAY_TYPE = "payType";
	/**
	 * 支付卡标识
	 */
	public static final String RESPONSE_PARAMETER_PAY_CARD_NO = "payCardNo";
	/**
	 * 支付卡名称
	 */
	public static final String RESPONSE_PARAMETER_PAY_CARD_ISSUE_NAME = "payCardIssueName";
	/**
	 * 绑定标识号
	 */
	public static final String RESPONSE_PARAMETER_BIND_ID = "bindId";
	/**
	 * VPC交易信息域:语音支付时使用
	 */
	public static final String RESPONSE_PARAMETER_VPC_TRANS_DATA = "vpcTransData";
	/**
	 * 交易类型
	 */
	public static final String RESPONSE_PARAMETER_TXN_TYPE = "txnType";
	/**
	 * 请求交易流水号
	 */
	public static final String RESPONSE_PARAMETER_QUERY_ID = "queryId";

	public static final String RESPONSE_PARAMETER_TN = "tn";
	/**
	 * 交易标识：退款
	 */
	public static final String TXN_TYPE_REFUND = "04";
}
