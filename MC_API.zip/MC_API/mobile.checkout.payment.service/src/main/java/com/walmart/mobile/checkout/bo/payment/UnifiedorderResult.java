package com.walmart.mobile.checkout.bo.payment;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * 统一下单微信返回的参数组
 * 
 */
@XmlRootElement(name = "xml")
public class UnifiedorderResult {

	private String appid;// appid

	private String errCode;// 错误代码

	private String errCodeDes;// 错误返回的信息描述

	private String mchId;// 商家id

	private String nonceStr;// 随机字符串

	private String prepayId;// 微信生成的预支付回话标识，用于后续接口调用中使用，该值有效期为2小时

	private String resultCode;// 错误码

	private String returnCode;// 返回状态码SUCCESS/FAIL此字段是通信标识，非交易标识，交易是否成功需要查看result_code来判断

	private String returnMsg;// 返回信息

	private String sign;// 签名

	private String tradeType;// 调用接口提交的交易类型，取值如下：JSAPI，NATIVE，APP

	@XmlElement(name = "appid")
	public String getAppid() {
		return appid;
	}

	@XmlElement(name = "err_code")
	public String getErrCode() {
		return errCode;
	}

	@XmlElement(name = "err_code_des")
	public String getErrCodeDes() {
		return errCodeDes;
	}

	@XmlElement(name = "mch_id")
	public String getMchId() {
		return mchId;
	}

	@XmlElement(name = "nonce_str")
	public String getNonceStr() {
		return nonceStr;
	}

	@XmlElement(name = "prepay_id")
	public String getPrepayId() {
		return prepayId;
	}

	@XmlElement(name = "result_code")
	public String getResultCode() {
		return resultCode;
	}

	@XmlElement(name = "return_code")
	public String getReturnCode() {
		return returnCode;
	}

	@XmlElement(name = "return_msg")
	public String getReturnMsg() {
		return returnMsg;
	}

	public String getSign() {
		return sign;
	}

	@XmlElement(name = "trade_type")
	public String getTradeType() {
		return tradeType;
	}

	public void setAppid(String appid) {
		this.appid = appid;
	}

	public void setErrCode(String errCode) {
		this.errCode = errCode;
	}

	public void setErrCodeDes(String errCodeDes) {
		this.errCodeDes = errCodeDes;
	}

	public void setMchId(String mchId) {
		this.mchId = mchId;
	}

	public void setNonceStr(String nonceStr) {
		this.nonceStr = nonceStr;
	}

	public void setPrepayId(String prepayId) {
		this.prepayId = prepayId;
	}

	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}

	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}

	public void setReturnMsg(String returnMsg) {
		this.returnMsg = returnMsg;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	public void setTradeType(String tradeType) {
		this.tradeType = tradeType;
	}
}
