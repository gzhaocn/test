package com.walmart.mobile.checkout.utils.payment.alipay;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import com.walmart.mobile.checkout.constant.AlipayConstants;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.utils.PropertyUtils;

public class AlipayItemEntity {

	private AlipayItemEntity() {
	}

	/** 合作者身份ID */
	private static final String PARTNER = AlipayConstants.PARTNER;

	/** 卖家支付宝账号 */
	private static final String SELLER_ID = AlipayConstants.SELLRR;
	/** 接口名称 */
	private static final String SERVICE = "mobile.securitypay.pay";
	/** 支付类型 */
	private static final String PAYMENT_TYPE = "1";
	/** 参数编码字符集 */
	private static final String INPUT_CHARSET = "utf-8";
	/** 未付款交易的超时时间(1m～15d) */
	private static final String IT_B_PAY = "30m";
	/** 签名方式 */
	private static final String SIGN_TYPE = "RSA";
	/** 服务器异步通知页面路径(可空) */
	// private static String notify_url;
	/** 客户端号(可空) */
	private static final String APP_ID = "app_id";
	/** 授权令牌(可空) */
	private static final String EXTERN_TOKEN = "extern_token";
	/** 客户端来源(可空) */
	private static final String APPENV = "appenv";

	public static String getOrderInfo(String orderId, String subject, String body, String amount)
			throws UnsupportedEncodingException, GlobalErrorInfoException {
		StringBuilder sb = new StringBuilder();
		// 默认国内支付
		sb.append("partner=\"" + PARTNER + "\"");
		sb.append("&seller_id=\"" + SELLER_ID + "\"");
		sb.append("&total_fee=\"" + amount + "\"");
		sb.append("&service=\"" + SERVICE + "\"");
		sb.append("&payment_type=\"" + PAYMENT_TYPE + "\"");
		sb.append("&_input_charset=\"" + INPUT_CHARSET + "\"");
		sb.append("&it_b_pay=\"" + IT_B_PAY + "\"");
		sb.append("&notify_url=\"" + PropertyUtils.getConfigValue("alipay.payment.notify_url") + "\"");
		sb.append("&app_id=\"" + APP_ID + "\"");
		sb.append("&extern_token=\"" + EXTERN_TOKEN + "\"");
		sb.append("&appenv=\"" + APPENV + "\"");
		sb.append("&show_url=\"" + PropertyUtils.getConfigValue("alipay.payment.show_url") + "\"");
		sb.append("&out_trade_no=\"" + orderId + "\"");
		sb.append("&subject=\"" + subject + "\"");
		sb.append("&body=\"" + body + "\"");
		sb.append("&return_url=\"" + PropertyUtils.getConfigValue("alipay.payment.show_url") + "\"");
		String orderInfo = new String(sb);
		String sign = URLEncoder.encode(RSA.sign(orderInfo, AlipayConstants.PRIVATE_KEY, AlipayConstants.INPUT_CHARSET),
				INPUT_CHARSET);
		orderInfo += "&sign=\"" + sign + "\"";
		orderInfo += "&sign_type=\"" + SIGN_TYPE + "\"";
		return orderInfo;
	}

}
