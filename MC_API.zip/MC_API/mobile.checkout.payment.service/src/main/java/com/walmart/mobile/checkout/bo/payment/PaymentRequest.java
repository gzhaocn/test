package com.walmart.mobile.checkout.bo.payment;

import java.io.Serializable;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "支付请求参数模型(微信&银联&礼品卡)")
public class PaymentRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4495390416470667625L;

	@ApiModelProperty(value = "订单编码", required = true)
	String orderId;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

}
