package com.walmart.mobile.checkout.service.http.util;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

public class HttpRequestUtil {

	private HttpRequestUtil(){}
	/**
	 * 
	 * @param requestURL  请求的url
	 * @param restTemplate rest请求模板
	 * @param jsonData  请求数据，json格式
	 * @return
	 */
	public static String sendRequestByPostMethod(String requestURL , RestTemplate restTemplate ,String jsonData ){
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		HttpEntity<String> entity = new HttpEntity<>(jsonData, headers);
		return restTemplate.postForObject(requestURL, entity, String.class);
	}
	
}
