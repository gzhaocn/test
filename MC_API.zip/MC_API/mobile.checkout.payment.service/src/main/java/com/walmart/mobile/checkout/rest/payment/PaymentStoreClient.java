package com.walmart.mobile.checkout.rest.payment;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.walmart.mobile.checkout.bo.payment.StoreVo;

@FeignClient("storeService")
@FunctionalInterface
public interface PaymentStoreClient {

	@RequestMapping(value = "/findByStoreId")
	StoreVo findByStoreId(@RequestParam(value = "storeId") Integer storeId);

}