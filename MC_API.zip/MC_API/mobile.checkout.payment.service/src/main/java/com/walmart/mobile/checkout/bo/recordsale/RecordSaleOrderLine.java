package com.walmart.mobile.checkout.bo.recordsale;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class RecordSaleOrderLine implements Serializable {

	private static final long serialVersionUID = 8268818402112803833L;

	private int lineItemType;

	private String itemNbr;

	private String itemDesc;

	private String upcNbr;

	private Integer reportCode;

	private Integer deptNbr;

	private Tax tax;

	private int quantity;

	private BigDecimal basePrice;

	private BigDecimal itemAmount ;
	
	private List<LinkSave> linkSaves = new ArrayList<>();

	private Weight totalWeight;

	public int getLineItemType() {
		return lineItemType;
	}

	public void setLineItemType(int lineItemType) {
		this.lineItemType = lineItemType;
	}

	public String getItemNbr() {
		return itemNbr;
	}

	public void setItemNbr(String itemNbr) {
		this.itemNbr = itemNbr;
	}

	public String getItemDesc() {
		return itemDesc;
	}

	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}

	public String getUpcNbr() {
		return upcNbr;
	}

	public void setUpcNbr(String upcNbr) {
		this.upcNbr = upcNbr;
	}

	public Integer getReportCode() {
		return reportCode;
	}

	public void setReportCode(Integer reportCode) {
		this.reportCode = reportCode;
	}

	public Integer getDeptNbr() {
		return deptNbr;
	}

	public void setDeptNbr(Integer deptNbr) {
		this.deptNbr = deptNbr;
	}

	public Tax getTax() {
		return tax;
	}

	public void setTax(Tax tax) {
		this.tax = tax;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public BigDecimal getBasePrice() {
		return basePrice;
	}

	public void setBasePrice(BigDecimal basePrice) {
		this.basePrice = basePrice;
	}

	public List<LinkSave> getLinkSaves() {
		return linkSaves;
	}

	public void setLinkSaves(List<LinkSave> linkSaves) {
		this.linkSaves = linkSaves;
	}

	public Weight getTotalWeight() {
		return totalWeight;
	}

	public void setTotalWeight(Weight totalWeight) {
		this.totalWeight = totalWeight;
	}

	public BigDecimal getItemAmount() {
		return itemAmount;
	}

	public void setItemAmount(BigDecimal itemAmount) {
		this.itemAmount = itemAmount;
	}

}
