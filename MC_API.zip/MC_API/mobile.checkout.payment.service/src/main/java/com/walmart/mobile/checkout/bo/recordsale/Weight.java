package com.walmart.mobile.checkout.bo.recordsale;

import java.io.Serializable;
import java.math.BigDecimal;

public class Weight implements Serializable {

	private static final long serialVersionUID = 7018518547980882285L;

	private BigDecimal amount;

	private String uom;

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

}
