package com.walmart.mobile.checkout.enumcode.payment;

public class PaymentConstants {

	public static final String RESPONSE_PARAMETER_RETURN_CODE = "return_code";

	public static final String PAY_RESPONSE_RETURN_MSG = "return_msg";
	/**
	 * Successfully pay, return this string
	 */
	public static final String PAY_SUCCESS_RESPONSE_TEXT = "SUCCESS";

	public static final String PAY_FAIL_RESPONSE_TEXT = "FAIL";

	public static final String PAY_OK_RESPONSE_TEXT = "OK";

	public static final String RETURN_CODE_SUCCESS = "SUCCESS";

	public static final String RETURN_CODE_FAIL = "FAIL";

	/**
	 * dagId在订单号规则中出现的开始位置，从此位置向后截取3位即为dagId.
	 */
	public static final int ORDER_ID_PATTERN_OF_DAG_ID_INDEX = 7;

	public static final String ORDERID = "orderId";

	private PaymentConstants() {
	}
}
