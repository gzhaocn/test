package com.walmart.mobile.checkout.service.payment;

import static org.junit.Assert.assertTrue;

import java.math.BigInteger;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.config.MainConfig;
import com.walmart.mobile.checkout.constant.AlipayConstants;
import com.walmart.mobile.checkout.dag.DagHost;
import com.walmart.mobile.checkout.dag.HostData;
import com.walmart.mobile.checkout.datasource.DynamicDataSource;
import com.walmart.mobile.checkout.domain.payment.AlipayNotification;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MainConfig.class })
@WebAppConfiguration
public class AlipayNotificationServiceTest {

	@Autowired
	AlipayNotificationService alipayNotificationService;

	private String out_trade_no = "082215222612710";

	@Autowired
	@Qualifier("dynamicDataSource")
	public DynamicDataSource dynamicDataSource;

	@Value("${ddr.request.param}")
	private String ddrParam;

	@Value("${ddr.request.url}")
	private String ddrUrl;

	@Autowired
	private RestTemplate restTemplate;

	private void initDatasourceRouter() {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<>(ddrParam, headers);
		String result = restTemplate.postForObject(ddrUrl, entity, String.class);
		List<DagHost> dss = JSONObject.parseObject(result, HostData.class).getData();
		Map<Object, Object> dataSources = new HashMap<>(16);
		for (int i = 0; i < dss.size(); i++) {
			DagHost dh = dss.get(i);
			String key = dh.getDagId();

			dataSources.put(key, dh.getDataSource());
			if (i == 0) {
				dynamicDataSource.setDefaultTargetDataSource(dh.getDataSource());
			}
		}
		dynamicDataSource.setTargetDataSources(dataSources);
		dynamicDataSource.afterPropertiesSet();

	}

	@PostConstruct
	private void init() {
		initDatasourceRouter();

	}

	@Test
	public void create() {

		Map<String, String> properties = new HashMap<String, String>(26);

		properties.put("discount", "0");
		properties.put("payment_type", "1");
		properties.put("subject", "苹果手机山寨国产红苹果手机Hiph");
		properties.put("trade_no", "2014040311001004370000361525");
		properties.put("buyer_email", "dlwdgl@gmail.com");
		properties.put("gmt_create", "2013-08-22");
		properties.put("notify_type", "trade_status_sync");
		properties.put("quantity", "1");
		properties.put("out_trade_no", "082215222612710");
		properties.put("seller_id", "2088501624816263");
		properties.put("notify_time", "2013-08-22");
		properties.put("discount", "山寨国产红苹果手机HiphoneI9");

		properties.put("trade_status", "TRADE_SUCCESS");
		properties.put("is_total_fee_adjust", "N");
		properties.put("total_fee", "1.00");
		properties.put("gmt_payment", "2013-08-22");
		properties.put("seller_email", "alipayrisk18@alipay.com");
		properties.put("buyer_id", "2088602315385429");
		properties.put("notify_id", "64ce1b6ab92d00ede0ee56ade98fdf2f4c");
		properties.put("sign_type", "RSA");
		properties.put("sign",
				"1glihU9DPWee+UJ82u3+mw3Bdnr9u01at0M/xJnPsGuHh+JA5bk3zbWaoWhU6GmLab3dIM4JNdktTcEUI9/FBGhgfLO39BKX/eBCFQ3bXAmIZn4l26fiwoO613BptT44GTEtnPiQ6+tnLsGlVSrFZaLB9FVhrGfipH2SWJcnwYs=");
		AlipayNotification entity = null;

		entity = alipayNotificationService.create(properties);

		assertTrue(entity != null);

		assertTrue(entity.getTradeId().compareTo("2014040311001004370000361525") == 0);

		BigInteger orderId = BigInteger.valueOf(105615010L);
		properties = new HashMap<String, String>(26);
		properties.put("discount", "0.00");
		properties.put("payment_type", "1");
		properties.put("subject", "itemName");
		properties.put("trade_no", "2014100957995823");
		properties.put("out_trade_no", "105615010");
		properties.put("buyer_email", "15012700225");
		properties.put("gmt_create", "2014-10-09 13:40:42");
		properties.put("notify_type", "trade_status_sync");
		properties.put("quantity", "1");
		properties.put("out_trade_no", "b820d30ce3b146f0ba3e2db922d804c8");
		properties.put("seller_id", out_trade_no);
		properties.put("notify_time", "2014-10-09 15:04:44");
		properties.put("body", "itemDetail");
		properties.put("trade_status", AlipayConstants.TRADE_STATUS_TRADE_FINISHED);
		properties.put("is_total_fee_adjust", "Y");
		properties.put("total_fee", "0.01");
		properties.put("gmt_payment", "2013-08-22");
		properties.put("seller_email", "18233333304@163.com");
		properties.put("price", "0.01");
		properties.put("buyer_id", "2088702000692231");
		properties.put("notify_id", "af8dcef50431409296eb5ca8104ab5b53a");
		properties.put("use_coupon", "N");
		properties.put("sign_type", "RSA");
		properties.put("sign",
				"AM+fzSLBAGZiHg84TpoDSEcyahjm279vfyMfnD+XYFTbhf99h7SrivxdYVAK6zYXTGf6PjLpiGDYHUduXsAQoo8lljHAzfxMeASnxwR6iCCAJvTcpiizeocD1HtpiRP+qbJnc8hb3eczK0V8hTTSKrDwWeyygWLkF535FdVpMNY=");
		properties.put("external_transaction_id", "0");

		Map<String, Object> params = new HashMap<String, Object>(2);
		params.put("orderId", orderId.toString());
		params.put("tradeStatus", AlipayConstants.TRADE_STATUS_TRADE_FINISHED); // Alipay的回调存在重试操作(2次)，测试并发重试是否会导致订单状态变迁异常.
		entity = alipayNotificationService.selectByOrderAndTradeStatus(params);
		if (entity == null) {
			alipayNotificationService.create(properties);
		}

	}

	@Test
	public void update() {
		Map<String, String> properties = new HashMap<String, String>(26);
		properties.put("discount", "0.00");
		properties.put("payment_type", "1");
		properties.put("subject", "itemName");
		properties.put("trade_no", "2014100957995823");
		properties.put("out_trade_no", "105615010");
		properties.put("buyer_email", "15012700225");
		properties.put("gmt_create", "2014-10-09 13:40:42");
		properties.put("notify_type", "trade_status_sync");
		properties.put("quantity", "1");
		properties.put("out_trade_no", out_trade_no);
		properties.put("seller_id", "2088011992118558");
		properties.put("notify_time", "2014-10-09 15:04:44");
		properties.put("body", "itemDetail");
		properties.put("trade_status", "TRADE_FINISHED");
		properties.put("is_total_fee_adjust", "Y");
		properties.put("total_fee", "0.01");
		properties.put("gmt_payment", "2013-08-22");
		properties.put("seller_email", "18233333304@163.com");
		properties.put("price", "0.01");
		properties.put("buyer_id", "2088702000692231");
		properties.put("notify_id", "af8dcef50431409296eb5ca8104ab5b53a");
		properties.put("use_coupon", "N");
		properties.put("sign_type", "RSA");
		properties.put("sign",
				"AM+fzSLBAGZiHg84TpoDSEcyahjm279vfyMfnD+XYFTbhf99h7SrivxdYVAK6zYXTGf6PjLpiGDYHUduXsAQoo8lljHAzfxMeASnxwR6iCCAJvTcpiizeocD1HtpiRP+qbJnc8hb3eczK0V8hTTSKrDwWeyygWLkF535FdVpMNY=");
		properties.put("external_transaction_id", "0");
		properties.put("updated_by", "JUnit");
		alipayNotificationService.update(properties);
	}

}
