package com.walmart.mobile.checkout.service.payment;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.util.Assert;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.config.MainConfig;
import com.walmart.mobile.checkout.dag.DagHost;
import com.walmart.mobile.checkout.dag.HostData;
import com.walmart.mobile.checkout.datasource.DynamicDataSource;
import com.walmart.mobile.checkout.domain.payment.WechatNotification;
import com.walmart.mobile.checkout.mapper.payment.WechatNotificationMapper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MainConfig.class })
@WebAppConfiguration
public class WechatNotificationServiceTest {

	@Autowired
	private WechatNotificationService wechatNotificationService;
	@Autowired
	private WechatNotificationMapper wechatNotificationMapper;

	private String orderId = "01059170010012778417";
	private WechatNotification wechatNotification;

	@Autowired
	@Qualifier("dynamicDataSource")
	public DynamicDataSource dynamicDataSource;

	@Value("${ddr.request.param}")
	private String ddrParam;

	@Value("${ddr.request.url}")
	private String ddrUrl;

	@Autowired
	private RestTemplate restTemplate;

	private void initDatasourceRouter() {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<>(ddrParam, headers);
		String result = restTemplate.postForObject(ddrUrl, entity, String.class);
		List<DagHost> dss = JSONObject.parseObject(result, HostData.class).getData();
		Map<Object, Object> dataSources = new HashMap<>(16);
		for (int i = 0; i < dss.size(); i++) {
			DagHost dh = dss.get(i);
			String key = dh.getDagId();

			dataSources.put(key, dh.getDataSource());
			if (i == 0) {
				dynamicDataSource.setDefaultTargetDataSource(dh.getDataSource());
			}
		}
		dynamicDataSource.setTargetDataSources(dataSources);
		dynamicDataSource.afterPropertiesSet();

	}

	@PostConstruct
	private void init() {
		initDatasourceRouter();

	}

	@Test
	public void testGetReturnWeiXinPay() {
		String xml = "<xml>" + "<appid><![CDATA[wx2421b1c4370ec43b]]></appid>   "
				+ "<attach><![CDATA[支付测试]]></attach>                           "
				+ "<bank_type><![CDATA[CFT]]></bank_type>                                    "
				+ "<fee_type><![CDATA[CNY]]></fee_type>                                      "
				+ "<cash_fee_type><![CDATA[CNY]]></cash_fee_type>                                      "
				+ "<is_subscribe><![CDATA[Y]]></is_subscribe>                                "
				+ "<mch_id><![CDATA[10000100]]></mch_id>                                     "
				+ "<nonce_str><![CDATA[5d2b6c2a8db53831f7eda20af46e531c]]></nonce_str>       "
				+ "<openid><![CDATA[oUpF8uMEb4qRXf22hE3X68TekukE]]></openid>                 "
				+ "<out_trade_no><![CDATA[" + orderId + "]]></out_trade_no>                       "
				+ "<result_code><![CDATA[SUCCESS]]></result_code>                            "
				+ "<return_code><![CDATA[SUCCESS]]></return_code>                            "
				+ "<return_msg><![CDATA[OK]]></return_msg>                            "
				+ "<sign><![CDATA[DA9C4533E3BC85A326D9803B8F6E0E61]]></sign>                 "
				+ "<sub_mch_id><![CDATA[10000100]]></sub_mch_id>                             "
				+ "<time_end><![CDATA[20140903131540]]></time_end>                           "
				+ "<total_fee>1</total_fee>                                                  "
				+ "<coupon_fee>0</coupon_fee>                                      "
				+ "<cash_fee>0</cash_fee>                                                  "
				+ "<trade_type><![CDATA[JSAPI]]></trade_type>                                "
				+ "<transaction_id><![CDATA[1004400740201409030005092168]]></transaction_id> " + "</xml>";
		Map<String, Object> map = wechatNotificationService.getReturnWeiXinPay(xml);
		wechatNotification = (WechatNotification) map.get("wechatNotification");
		Assert.isTrue(wechatNotification != null, "OK");
		Assert.isTrue("SUCCESS".equals(map.get("returnCode")), "OK");
		Assert.isTrue("OK".equals(map.get("returnMsg")), "OK");
		wechatNotificationService.create(wechatNotification);
		WechatNotification dbWechatNotification = wechatNotificationService.getByOutTradeNo(orderId);
		Assert.isTrue(dbWechatNotification != null, "OK");
	}

	@Test
	public void testXmlReturnApplyInfo() {
		String exResult = "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>";
		String xmlReturnApplyInfo = wechatNotificationService.xmlReturnApplyInfo("SUCCESS", "OK");
		Assert.isTrue(exResult.equals(xmlReturnApplyInfo), "OK");
		exResult = "<xml><return_code><![CDATA[SUCCESS]]></return_code></xml>";
		xmlReturnApplyInfo = wechatNotificationService.xmlReturnApplyInfo("SUCCESS", null);
		Assert.isTrue(exResult.equals(xmlReturnApplyInfo), "OK");
		xmlReturnApplyInfo = wechatNotificationService.xmlReturnApplyInfo(null, "OK");
		Assert.isTrue("".equals(xmlReturnApplyInfo), "OK");
	}

	@After
	public void teardown() {
		wechatNotificationMapper.deleteByPrimaryKey(orderId);
	}

}
