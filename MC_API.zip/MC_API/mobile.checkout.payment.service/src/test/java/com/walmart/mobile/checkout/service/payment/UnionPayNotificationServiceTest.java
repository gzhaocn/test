package com.walmart.mobile.checkout.service.payment;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.util.Assert;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.config.MainConfig;
import com.walmart.mobile.checkout.dag.DagHost;
import com.walmart.mobile.checkout.dag.HostData;
import com.walmart.mobile.checkout.datasource.DynamicDataSource;
import com.walmart.mobile.checkout.mapper.payment.UnionpayNotificationMapper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MainConfig.class })
@WebAppConfiguration
public class UnionPayNotificationServiceTest {

	@Autowired
	private UnionpayNotificationService unionpayNotificationService;

	@Autowired
	private UnionpayNotificationMapper unionpayNotificationMapper;

	@Autowired
	@Qualifier("dynamicDataSource")
	public DynamicDataSource dynamicDataSource;

	@Value("${ddr.request.param}")
	private String ddrParam;

	@Value("${ddr.request.url}")
	private String ddrUrl;

	@Autowired
	private RestTemplate restTemplate;

	private void initDatasourceRouter() {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<>(ddrParam, headers);
		String result = restTemplate.postForObject(ddrUrl, entity, String.class);
		List<DagHost> dss = JSONObject.parseObject(result, HostData.class).getData();
		Map<Object, Object> dataSources = new HashMap<>(16);
		for (int i = 0; i < dss.size(); i++) {
			DagHost dh = dss.get(i);
			String key = dh.getDagId();
			dataSources.put(key, dh.getDataSource());
			if (i == 0) {
				dynamicDataSource.setDefaultTargetDataSource(dh.getDataSource());
			}
		}
		dynamicDataSource.setTargetDataSources(dataSources);
		dynamicDataSource.afterPropertiesSet();

	}

	@PostConstruct
	private void init() {
		initDatasourceRouter();

	}

	@Test
	public void create() {

		String orderId = "02489170010000002254";

		Map<String, String> properties = new HashMap<String, String>(33);
		properties.put("version", "version");
		properties.put("encoding", "encoding");
		properties.put("certId", "cert_id");
		properties.put("queryId", "000000");
		properties.put("signMethod", "signMethod");
		properties.put("signature", "signature");
		properties.put("txnType", "01");
		properties.put("txnSubType", "01");
		properties.put("bizType", "000201");
		properties.put("accessType", "0");
		properties.put("merId", "merId");
		properties.put("orderId", orderId);
		properties.put("txnTime", "txn_time");
		properties.put("txnAmt", "txn_amt");
		properties.put("currencyCode", "156");
		properties.put("reqReserved", "req_reserved");
		properties.put("reserved", "reserved");
		properties.put("respCode", "00");
		properties.put("respMsg", "交易成功(0000000)");
		properties.put("settleAmount", "0.00");
		properties.put("settleCurrencyCode", "156");
		properties.put("settleDate", "0207");
		properties.put("traceNo", "000000");
		properties.put("traceTime", "trace_time");
		properties.put("exchangeRate", "0");
		properties.put("exchangeDate", "0207");
		properties.put("accNo", "acc_no");
		properties.put("payCardType", "01");
		properties.put("payType", "0201");
		properties.put("payCardNo", "pay_card_no");
		properties.put("payCardIssueName", "pay_card_issue_name");
		properties.put("bindId", "bind_id");
		properties.put("vpcTransData", "00000");
		unionpayNotificationService.createNotification(properties);

		int result = unionpayNotificationMapper.deleteByPrimaryKey(orderId);
		Assert.isTrue(result == 1, "OK");
	}

}
