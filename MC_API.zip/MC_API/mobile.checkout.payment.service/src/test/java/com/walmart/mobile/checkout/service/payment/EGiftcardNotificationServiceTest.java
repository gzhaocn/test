package com.walmart.mobile.checkout.service.payment;

import static org.junit.Assert.assertTrue;

import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.config.MainConfig;
import com.walmart.mobile.checkout.dag.DagHost;
import com.walmart.mobile.checkout.dag.HostData;
import com.walmart.mobile.checkout.datasource.DynamicDataSource;
import com.walmart.mobile.checkout.domain.payment.EGiftcardNotification;
import com.walmart.mobile.checkout.mapper.payment.EGiftcardNotificationMapper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MainConfig.class })
@WebAppConfiguration
public class EGiftcardNotificationServiceTest {

	@Autowired
	EGiftCardPaymentService eGiftCardPaymentService;

	@Autowired
	private EGiftcardNotificationService eGiftcardNotificationService;

	@Autowired
	private EGiftcardNotificationMapper eGiftcardNotificationMapper;

	@Autowired
	@Qualifier("dynamicDataSource")
	public DynamicDataSource dynamicDataSource;

	@Value("${ddr.request.param}")
	private String ddrParam;

	@Value("${ddr.request.url}")
	private String ddrUrl;

	@Autowired
	private RestTemplate restTemplate;

	private void initDatasourceRouter() {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<>(ddrParam, headers);
		String result = restTemplate.postForObject(ddrUrl, entity, String.class);
		List<DagHost> dss = JSONObject.parseObject(result, HostData.class).getData();
		Map<Object, Object> dataSources = new HashMap<>(16);
		for (int i = 0; i < dss.size(); i++) {
			DagHost dh = dss.get(i);
			String key = dh.getDagId();
			dataSources.put(key, dh.getDataSource());
			if (i == 0) {
				dynamicDataSource.setDefaultTargetDataSource(dh.getDataSource());
			}
		}
		dynamicDataSource.setTargetDataSources(dataSources);
		dynamicDataSource.afterPropertiesSet();

	}

	@PostConstruct
	private void init() {
		initDatasourceRouter();

	}

	@Test
	public void createAndDelete() throws NoSuchAlgorithmException {
		Map<String, String> properties = new HashMap<String, String>(16);
		properties.put("type", "type");
		properties.put("merId", "mer_id");
		properties.put("orderId", "00000150020012098016");
		properties.put("orderId", "105615010");
		properties.put("amount", "amount");
		properties.put("tranId", "tran_id");
		properties.put("tranDate", "0207");
		properties.put("tranTime", "020345");
		properties.put("mac", "mac");
		properties.put("returnCode", "00");

		EGiftcardNotification eGiftcardInsert = eGiftcardNotificationService.createEGiftcardNotification(properties);
		EGiftcardNotification eGiftcardSelect = eGiftcardNotificationService
				.selectEgiftcardNotificationByOrderId("105615010");
		assertTrue(eGiftcardInsert.getOrderId().equals(eGiftcardSelect.getOrderId()));

		eGiftcardNotificationMapper.deleteByPrimaryKey("105615010");

	}

}
