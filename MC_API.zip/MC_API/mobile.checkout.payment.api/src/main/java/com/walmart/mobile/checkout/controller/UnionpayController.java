package com.walmart.mobile.checkout.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.unionpay.acp.sdk.HttpClient;
import com.unionpay.acp.sdk.LogUtil;
import com.unionpay.acp.sdk.SDKConfig;
import com.unionpay.acp.sdk.SDKConstants;
import com.unionpay.acp.sdk.SDKUtil;
import com.walmart.mobile.checkout.annotation.PrivilegeInfo;
import com.walmart.mobile.checkout.bo.payment.OrderVo;
import com.walmart.mobile.checkout.bo.payment.PaymentRequest;
import com.walmart.mobile.checkout.constant.AlipayConstants;
import com.walmart.mobile.checkout.constant.UpmpConstants;
import com.walmart.mobile.checkout.constant.order.OrderStatus;
import com.walmart.mobile.checkout.constant.recordsale.RecordSaleConstants;
import com.walmart.mobile.checkout.enumcode.payment.PaymentConstants;
import com.walmart.mobile.checkout.enumcode.payment.PaymentErrorInfoEnum;
import com.walmart.mobile.checkout.enumcode.payment.PaymentTypeEnum;
import com.walmart.mobile.checkout.enumcode.payment.UnionpayConstants;
import com.walmart.mobile.checkout.exception.handler.ResultBody;
import com.walmart.mobile.checkout.handler.send.RecordsaleSendHandler;
import com.walmart.mobile.checkout.rest.payment.PaymentOrderClient;
import com.walmart.mobile.checkout.service.payment.PaymentUpdateService;
import com.walmart.mobile.checkout.service.payment.UnionpayNotificationService;
import com.walmart.mobile.checkout.service.recordsale.RecordSaleService;
import com.walmart.mobile.checkout.statemachine.OrderEventTypeEnum;
import com.walmart.mobile.checkout.utils.HTTPHelper;
import com.walmart.mobile.checkout.utils.ThreadLocalContextHolder;
import com.walmart.mobile.checkout.utils.payment.union.UnionpayHelper;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Controller
@RequestMapping
public class UnionpayController {
	private static final Logger LOG = LoggerFactory.getLogger(UnionpayController.class);

	private static boolean isLoadUnionpayProperties = false;



	@Value("${payment.amount.test}")
	private String paymentAmount;
	
	@Value("${recordsale.resource.type}")
	private String resourceType;
	
	@Autowired
	private RecordsaleSendHandler recordsaleSendHandler;
	
	@Autowired
	private RecordSaleService recordSaleService;

	@Autowired
	private PaymentOrderClient paymentOrderClient;

	@Autowired
	private UnionpayNotificationService unionpayNotificationService;

	@Autowired
	private PaymentUpdateService paymentUpdateService;



	@PrivilegeInfo
	@ApiOperation(value = "union payment parameter create", notes = "创建支付参数(银联)")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"),
			@ApiResponse(code = -401, message = "没有权限操作"), @ApiResponse(code = -402, message = "订单已支付，请不要重复支付"),
			@ApiResponse(code = -409, message = "银联支付参数校验失败"), @ApiResponse(code = -414, message = "订单超时") })
	@RequestMapping(value = "/payment/union/paymentparams", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody getPaymentInfo(@RequestBody PaymentRequest paymentRequest, HttpServletRequest request)
			throws IOException {

		String orderId = paymentRequest.getOrderId();

		String dagId = orderId.substring(PaymentConstants.ORDER_ID_PATTERN_OF_DAG_ID_INDEX,
				PaymentConstants.ORDER_ID_PATTERN_OF_DAG_ID_INDEX + 3);

		ThreadLocalContextHolder.switchDataSoureByDagId(dagId);

		OrderVo orderVo = paymentOrderClient.getOrderByOrderId(orderId);

		if (paymentUpdateService.isTimeOut(orderVo.getCreatedTime())) {
			LOG.info("订单已超时, 订单号[{}]，当前支付方式[{}]", orderVo.getOrderId(), PaymentTypeEnum.UNIONPAY);
			return new ResultBody(null, PaymentErrorInfoEnum.ORDER_IS_TIMEOUT.getCode(), "订单已超时，不能支付");
		}

		if (orderVo.getStatus() >= OrderStatus.PAID) {
			LOG.info("订单已支付，请不要重复支付, 订单号[{}]，当前支付方式[{}]", orderVo.getOrderId(), PaymentTypeEnum.UNIONPAY);
			return new ResultBody(null, PaymentErrorInfoEnum.ORDER_HAVE_BEAN_PAID.getCode(), "订单已支付，请不要重复支付");
		}

		// get totalAmount from DB，银联的金额以[分]为单位.
		String amount = String.valueOf(orderVo.getAmount().doubleValue());
		amount =getYuanToCent(amount);
		LOG.info(" need real amount :{}" , amount);
		if("1".equals(paymentAmount)){
			amount = "1";
		}

		LOG.info("Build unionpay request.");

		// 组装请求报文
		Map<String, String> data = setData(orderVo, amount);

		// 交易请求url 从配置文件读取
		String requestAppUrl = SDKConfig.getConfig().getAppRequestUrl();

		String resultString = "";
		if (LOG.isInfoEnabled()) {
			LOG.info("requestUrl====" + requestAppUrl);
			LOG.info("submitFromData====" + data.toString());
		}

		ResultBody msg = new ResultBody();
		HttpClient hc = new HttpClient(requestAppUrl, 30000, 30000);
		try {
			int status = hc.send(data, UnionpayHelper.ENCODING);
			if (HttpStatus.OK.value() == status) {
				resultString = hc.getResult();
			}
		} catch (Exception e) {
			LOG.error("UnionPay failed to create http connection", e.getMessage(), e);
			throw new IOException("unionpay connection failure");
		}
		// 验证签名
		signValidate(data, resultString, msg);
		return msg;
	}

	/**
	 * 银联支付 公用同一个接口
	 * 
	 * @param request
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/payment/unionpay/callback", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResponseEntity<String> unionpayCallBack(HttpServletRequest request) throws IOException {
		Map<String, String> parameters = HTTPHelper.parameters(request.getParameterMap());

		if (!isLoadUnionpayProperties) {
			SDKConfig.getConfig().loadPropertiesFromSrc();
			setLoadUnionpayProperties(true);
		}

		LogUtil.writeLog("BackRcvResponse接收后台通知");
		String encoding = request.getParameter(SDKConstants.param_encoding);
		request.setCharacterEncoding(encoding);

		// 获取请求参数中所有的信息
		Map<String, String> reqParam = getAllRequestParam(request);
		// 打印请求报文
		LogUtil.printRequestLog(reqParam);

		Map<String, String> validData = getValidateMap(reqParam, encoding);

		// 验证签名
		if (!SDKUtil.validate(validData, encoding)) {
			LogUtil.writeLog("验证签名结果[失败].");
		} else {
			// 因为银联退款orderId不能传orderId进来，现在退款里面传了batchNo当orderId所以切换数据源的时候需要根据支付或退款来切数据源
			// 目前不做退款
			String orderId = validData.get(PaymentConstants.ORDERID);
			String dagId = orderId.substring(PaymentConstants.ORDER_ID_PATTERN_OF_DAG_ID_INDEX,
					PaymentConstants.ORDER_ID_PATTERN_OF_DAG_ID_INDEX + 3);
			ThreadLocalContextHolder.put("dagId", dagId);
			LogUtil.writeLog("验证签名结果[成功].");
			String queryId = parameters.get(UnionpayConstants.RESPONSE_PARAMETER_QUERY_ID);
			String transType = parameters.get(UnionpayConstants.RESPONSE_PARAMETER_TXN_TYPE);

			OrderVo order = paymentOrderClient.getOrderByOrderId(orderId);

			// 只有交易成功的回调才会触发.
			// 此时应该直接更新订单状态为支付成功
			if (!unionpayNotificationService.isExsitForQn(queryId, transType)) {
				unionpayNotificationService.createNotification(parameters);

				if (UpmpConstants.TRANS_TYPE_TRADE.equals(parameters.get("txnType"))
						&& UpmpConstants.TRANS_STATUS_SUCCESS.equals(parameters.get("respCode"))) {
					int result = paymentUpdateService.doUpdateStatus(orderId, order.getVersion(),
							OrderEventTypeEnum.PAYROLLBACK.getCode(),BigDecimal.ZERO, PaymentTypeEnum.UNIONPAY);
					LOG.info("update payment status : {} , orderID : {}", result, orderId);
			
					if (result == 1) {
						String postData = recordSaleService.sendRecordSale(orderId, resourceType,
								RecordSaleConstants.MOBILE_CHECKOUT_ORDER_TYPE,OrderStatus.PAID);
						if (postData != null) {
							recordsaleSendHandler.recordsaleSendMessage(postData);
						}
						LOG.info("UNIONPAY callback then send recordsale message to mq  , orderID : {}", orderId);
					}
					 
				}

			} else {
				return new ResponseEntity<>(AlipayConstants.PAY_FAILED_RESPONSE_TEXT, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}

		LogUtil.writeLog("BackRcvResponse接收后台通知结束");
		return new ResponseEntity<>(AlipayConstants.PAY_SUCCESS_RESPONSE_TEXT, HttpStatus.OK);
	}

	/**
	 * 验证签名
	 */
	private void signValidate(Map<String, String> data, String resultString, ResultBody msg) {
		// 打印返回报文
		LOG.info("请求报文=[{}]", data.toString());
		LOG.info("打印返回报文：{}", resultString);
		if (null != resultString && !"".equals(resultString)) {
			// 将返回结果转换为map
			Map<String, String> resData = SDKUtil.convertResultStringToMap(resultString);
			if (SDKUtil.validate(resData, UnionpayHelper.ENCODING)) {
				LOG.info("UnionPay 验证签名成功");
				// 服务器应答签名验证成功
				String respCode = resData.get(UnionpayConstants.RESPONSE_PARAMETER_RESP_CODE);
				if (UpmpConstants.RESPONSE_CODE_SUCCESS.equals(respCode)) {
					Map<String, Object> resultMap = new HashMap<>(16);
					resultMap.put(UnionpayConstants.RESPONSE_PARAMETER_TN,
							resData.get(UnionpayConstants.RESPONSE_PARAMETER_TN));
					msg.setResult(resultMap);
				} else {
					String respMsg = resData.get(UnionpayConstants.RESPONSE_PARAMETER_RESP_MSG);
					LOG.error("UnionPay is failed, responseCode[{}], responseMsg[{}]", respCode, respMsg);
					// respCode =
					// 12，重复交易。其错误代码可在如下站点查询https://open.unionpay.com/ajweb/help/respCode/respCodeList
					msg.setCode("-409");
					msg.setMessage(
							String.format("UnionPay is failed, responseCode[%s], responseMsg[%s]", respCode, respMsg));
				}
			} else {
				LOG.error("UnionPay 验证签名失败");
				msg.setCode("-409");
				msg.setMessage("UnionPay 验证签名失败");
			}

		}
	}

	/**
	 * 组装请求报文
	 */
	private Map<String, String> setData(OrderVo orderToPaid, String amount) {
		Map<String, String> data = new HashMap<>(16);
		// 版本号
		data.put("version", "5.0.0");
		// 字符集编码 默认"UTF-8"
		data.put("encoding", "UTF-8");
		// 签名方法 01 RSA
		data.put("signMethod", "01");
		// 交易类型 01-消费
		data.put("txnType", "01");
		// 交易子类型 01:自助消费 02:订购 03:分期付款
		data.put("txnSubType", "01");
		// 业务类型
		data.put("bizType", "000201");
		// 渠道类型，07-PC，08-手机
		data.put("channelType", "08");
		// 后台通知地址
		data.put("backUrl", UpmpConstants.merBackEndUrl);
		// 接入类型，商户接入填0 0- 商户 ， 1： 收单， 2：平台商户
		data.put("accessType", "0");
		// 商户号码，请改成自己的商户号
		data.put("merId", UpmpConstants.merId);
		// 商户订单号，8-40位数字字母
		data.put("orderId", orderToPaid.getOrderId());
		// 订单发送时间，取系统时间
		data.put("txnTime", new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()));
		// 交易金额，单位分
		data.put("txnAmt", amount);
		// 交易币种
		data.put("currencyCode", "156");
		// 请求方保留域，透传字段，查询、通知、对账文件中均会原样出现
		data.put("reqReserved", "请求交易");
		// 订单描述，可不上送，上送时控件中会显示该信息
		data.put("orderDesc", "订单描述");

		data = UnionpayHelper.signData(data);
		return data;
	}

	/**
	 * 获取请求参数中所有的信息
	 *
	 * @param request
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	private Map<String, String> getAllRequestParam(final HttpServletRequest request)
			throws UnsupportedEncodingException {
		Map<String, String> res = new HashMap<>(16);
		Enumeration<?> temp = request.getParameterNames();
		if (null != temp) {
			while (temp.hasMoreElements()) {
				String en = (String) temp.nextElement();
				String value = request.getParameter(en);
				res.put(en, value);
				if (null == res.get(en) || "".equals(res.get(en))) {
					res.remove(en);
				}
			}
		}
		return res;
	}

	private Map<String, String> getValidateMap(Map<String, String> reqParam, String encoding)
			throws UnsupportedEncodingException {
		Map<String, String> validData = new HashMap<>(reqParam.size());

		if (!reqParam.isEmpty()) {
			Iterator<Entry<String, String>> it = reqParam.entrySet().iterator();
			while (it.hasNext()) {
				Entry<String, String> e = it.next();
				String key = e.getKey();
				String value = e.getValue();
				value = new String(value.getBytes(encoding), encoding);
				validData.put(key, value);
			}
		}

		return validData;
	}

	public static boolean isLoadUnionpayProperties() {
		return isLoadUnionpayProperties;
	}

	public static void setLoadUnionpayProperties(boolean isLoadUnionpayProperties) {
		UnionpayController.isLoadUnionpayProperties = isLoadUnionpayProperties;
	}

	private  String getYuanToCent(String money) {

		BigDecimal b1 = new BigDecimal(money);
		BigDecimal b2 = new BigDecimal("100");
		NumberFormat numberFormat = NumberFormat.getIntegerInstance();
		numberFormat.setGroupingUsed(false);

		return numberFormat.format(b1.multiply(b2).doubleValue());
	}
}
