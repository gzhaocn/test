package com.walmart.mobile.checkout.controller;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.walmart.mobile.checkout.bo.payment.PaymentRequest;
import com.walmart.mobile.checkout.constant.order.OrderStatus;
import com.walmart.mobile.checkout.constant.recordsale.RecordSaleConstants;
import com.walmart.mobile.checkout.enumcode.payment.PaymentConstants;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.exception.handler.ResultBody;
import com.walmart.mobile.checkout.handler.send.RecordsaleSendHandler;
import com.walmart.mobile.checkout.service.recordsale.RecordSaleService;
import com.walmart.mobile.checkout.utils.ThreadLocalContextHolder;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Controller
@RequestMapping("rsretry")
public class RsRetryController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(RsRetryController.class.getName());

	@Autowired
	private RecordSaleService recordSaleService;


	@Value("${recordsale.resource.type}")
	private String resourceType;
	
	@Value("${recordsale.open.test}")
	private String openTest;
	
	
	@Autowired
	private RecordsaleSendHandler recordsaleSendHandler;
	
	@ApiOperation(value = "send recordsale message", notes = "通过订单号发送消息到recordsale")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"),
			 })
	@RequestMapping(value = "/recordsale/retry", method = RequestMethod.POST)
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public ResultBody sendRecordsaleMsg(@RequestBody PaymentRequest paymentRequest, HttpServletRequest request)
			throws GlobalErrorInfoException {
	     if("1".equals(openTest)){
	    		String dagId = paymentRequest.getOrderId().substring(PaymentConstants.ORDER_ID_PATTERN_OF_DAG_ID_INDEX,
	    				PaymentConstants.ORDER_ID_PATTERN_OF_DAG_ID_INDEX + 3);

	    		ThreadLocalContextHolder.put("dagId", dagId);
			String postData = recordSaleService.sendRecordSale(paymentRequest.getOrderId(), resourceType,
					RecordSaleConstants.MOBILE_CHECKOUT_ORDER_TYPE,OrderStatus.PAID);
			if (postData != null) {
				recordsaleSendHandler.recordsaleSendMessage(postData);
			}
	     }else{
	    	 LOGGER.info("接口已经停用"); 
	     }
	     return new  ResultBody();
	}

	
}
