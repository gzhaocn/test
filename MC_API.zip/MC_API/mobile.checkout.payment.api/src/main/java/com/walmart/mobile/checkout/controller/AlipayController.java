package com.walmart.mobile.checkout.controller;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.walmart.mobile.checkout.annotation.PrivilegeInfo;
import com.walmart.mobile.checkout.bo.payment.AliPaymentRequest;
import com.walmart.mobile.checkout.bo.payment.OrderVo;
import com.walmart.mobile.checkout.bo.payment.PaymentSyncNotification;
import com.walmart.mobile.checkout.constant.AlipayConstants;
import com.walmart.mobile.checkout.constant.GlobalErrorInfoEnum;
import com.walmart.mobile.checkout.constant.order.OrderStatus;
import com.walmart.mobile.checkout.constant.recordsale.RecordSaleConstants;
import com.walmart.mobile.checkout.domain.payment.AlipayNotification;
import com.walmart.mobile.checkout.enumcode.payment.PaymentConstants;
import com.walmart.mobile.checkout.enumcode.payment.PaymentErrorInfoEnum;
import com.walmart.mobile.checkout.enumcode.payment.PaymentTypeEnum;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.exception.handler.ResultBody;
import com.walmart.mobile.checkout.handler.send.RecordsaleSendHandler;
import com.walmart.mobile.checkout.rest.payment.PaymentOrderClient;
import com.walmart.mobile.checkout.service.payment.AlipayNotificationService;
import com.walmart.mobile.checkout.service.payment.PaymentUpdateService;
import com.walmart.mobile.checkout.service.recordsale.RecordSaleService;
import com.walmart.mobile.checkout.statemachine.OrderEventTypeEnum;
import com.walmart.mobile.checkout.utils.HTTPHelper;
import com.walmart.mobile.checkout.utils.ThreadLocalContextHolder;
import com.walmart.mobile.checkout.utils.payment.alipay.AlipayItemEntity;
import com.walmart.mobile.checkout.utils.payment.alipay.AlipayNotify;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Controller
@RequestMapping
public class AlipayController {

	private static final Logger LOGGER = LoggerFactory.getLogger(AlipayController.class.getName());


	
	@Value("${payment.amount.test}")
	private String paymentAmount;

	@Value("${recordsale.resource.type}")
	private String resourceType;

	@Autowired
	private PaymentOrderClient paymentOrderClient;

	@Autowired
	private PaymentUpdateService paymentUpdateService; 

	@Autowired
	private AlipayNotificationService alipayNotificationService;
	@Autowired
	private RecordsaleSendHandler recordsaleSendHandler;
	
	@Autowired
	private RecordSaleService recordSaleService;


	@PrivilegeInfo
	@ApiOperation(value = "alipay payment parameter create", notes = "创建支付参数(支付宝)")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"),
			@ApiResponse(code = -401, message = "没有权限操作"), @ApiResponse(code = -402, message = "订单已支付，请不要重复支付"),
			@ApiResponse(code = -405, message = "支付失败"), @ApiResponse(code = -414, message = "订单超时") })
	@RequestMapping(value = "/payment/alipay/paymentparams", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody getPaymentInfo(@RequestBody AliPaymentRequest aliPaymentRequest, HttpServletRequest request)
			throws GlobalErrorInfoException {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("alipay getPaymentInfo start");
		}

		String orderId = aliPaymentRequest.getOrderId();

		String dagId = orderId.substring(PaymentConstants.ORDER_ID_PATTERN_OF_DAG_ID_INDEX,
				PaymentConstants.ORDER_ID_PATTERN_OF_DAG_ID_INDEX + 3);

		ThreadLocalContextHolder.switchDataSoureByDagId(dagId);

		OrderVo orderVo = paymentOrderClient.getOrderByOrderId(orderId);

		if (paymentUpdateService.isTimeOut(orderVo.getCreatedTime())) {
			LOGGER.info("订单已超时, 订单号[{}]，当前支付方式[{}]", orderVo.getOrderId(), PaymentTypeEnum.ALIPAY);
			return new ResultBody(null, PaymentErrorInfoEnum.ORDER_IS_TIMEOUT.getCode(), "订单已超时，不能支付");
		}

		if (orderVo.getStatus() >= OrderStatus.PAID) {
			LOGGER.info("订单已支付，请不要重复支付, 订单号[{}]，当前支付方式[{}]", orderVo.getOrderId(), PaymentTypeEnum.ALIPAY);
			return new ResultBody(null, PaymentErrorInfoEnum.ORDER_HAVE_BEAN_PAID.getCode(), "订单已支付，请不要重复支付");
		}

		String subject = aliPaymentRequest.getSubject();
		String body = aliPaymentRequest.getBody();
		String amount =  orderVo.getAmount().toString() ;
		if("1".equals(paymentAmount)){
			amount = "0.01";
		}
		String result = null;
		try {
			result = AlipayItemEntity.getOrderInfo(orderId, subject, body, amount);
		} catch (UnsupportedEncodingException e) {
			throw new GlobalErrorInfoException(GlobalErrorInfoEnum.FAILED, e);
		}
		LOGGER.info("payment result url = {} ", result);

		return new ResultBody(result);
	}

	@ApiOperation(value = "(H5) client call back  ", notes = "客户端支付回调(H5)")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"),
			@ApiResponse(code = -402, message = "订单已支付，请不要重复支付"), @ApiResponse(code = -403, message = "订单状态修改失败") })
	@RequestMapping(value = "/payment/H5/paidAsyncNotify", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody paidAsyncNotify(@RequestBody PaymentSyncNotification notification, HttpServletRequest request)
			throws GlobalErrorInfoException {
		if (!notification.isValid()) {
			throw new IllegalArgumentException(ToStringBuilder.reflectionToString(notification));
		}

		String orderId = notification.getOrderId();
		String dagId = orderId.substring(PaymentConstants.ORDER_ID_PATTERN_OF_DAG_ID_INDEX,
				PaymentConstants.ORDER_ID_PATTERN_OF_DAG_ID_INDEX + 3);

		ThreadLocalContextHolder.put("dagId", dagId);

		OrderVo order = paymentOrderClient.getOrderByOrderId(orderId);

		// 由于支付回调请求和paidSyncNotify请求并没有先后顺序，那么支付回调请求先于本请求达到服务器端时
		// 订单状态已经被更新为30，故在此检测是否已是30状态，如果是则不做任何操作直接返回
		// 在有master商品时，order有可能为空
		if (order == null || order.getStatus() == OrderStatus.PAID) {
			throw new GlobalErrorInfoException(PaymentErrorInfoEnum.ORDER_HAVE_BEAN_PAID);
		}

		boolean successful;
		switch (notification.getPayType()) {
		case PaymentTypeEnum.ALIPAY:
			successful = StringUtils.equals("9000", notification.getCode());
			break;
		case PaymentTypeEnum.UNIONPAY:
			successful = StringUtils.equals("success", notification.getCode());
			break;
		case PaymentTypeEnum.EGIFTCARD:
			successful = StringUtils.equals("00", notification.getCode());
			break;
		case PaymentTypeEnum.WECHATPAY:
			successful = StringUtils.equals("0", notification.getCode());
			break;
		default:
			successful = false;
		}

		boolean failToUpdate = false;
		boolean cancelToUpdate = false;

		if (!successful) {
			switch (notification.getPayType()) {
			case PaymentTypeEnum.ALIPAY:
				cancelToUpdate = StringUtils.equals("6001", notification.getCode());
				break;
			case PaymentTypeEnum.UNIONPAY:
				cancelToUpdate = StringUtils.equals("cancel", notification.getCode());
				failToUpdate = StringUtils.equals("fail", notification.getCode());
				break;
			case PaymentTypeEnum.EGIFTCARD:
				cancelToUpdate = true;
				break;
			case PaymentTypeEnum.WECHATPAY:
				cancelToUpdate = StringUtils.equals("-2", notification.getCode());
				break;
			default:
				cancelToUpdate = true;
			}
		}
		if (successful || (!cancelToUpdate && !failToUpdate)) {
			try {
				OrderVo orderNow = paymentOrderClient.getOrderByOrderId(orderId);
				paymentUpdateService.doUpdate(orderId, orderNow.getVersion(), OrderEventTypeEnum.PAY.getCode(),BigDecimal.ZERO,
						notification.getPayType());
			} catch (GlobalErrorInfoException e) {
				LOGGER.info("PaidSyncNofify update payment2 orderId={}, payType={}, code={}", orderId,
						notification.getPayType(), notification.getCode(), e);
				throw new GlobalErrorInfoException(PaymentErrorInfoEnum.ORDER_UPDATE_STATUS_FAIL);
			}
		}
		return new ResultBody();

	}

	@ApiOperation(value = "alipay payment callback", notes = "支付宝支付回调", hidden = true)
	@RequestMapping(value = "/payment/alipay/callback", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResponseEntity<String> alipayCallBack(HttpServletRequest request) throws GlobalErrorInfoException {
		Map<String, String> parameters = parameters(request.getParameterMap());

		if (!AlipayNotify.verify(parameters)) {
			throw new GlobalErrorInfoException(PaymentErrorInfoEnum.PAYMENT_VERIFICATION_ERROR);
		}
		String orderId = parameters.get(AlipayConstants.RESPONSE_PARAMETER_OUT_TRADE_NO);

		String dagId = orderId.substring(PaymentConstants.ORDER_ID_PATTERN_OF_DAG_ID_INDEX,
				PaymentConstants.ORDER_ID_PATTERN_OF_DAG_ID_INDEX + 3);
		ThreadLocalContextHolder.put("dagId", dagId);

		Map<String, Object> params = new HashMap<>(2);
		params.put("orderId", orderId);
		params.put("tradeStatus", parameters.get(AlipayConstants.RESPONSE_PARAMETER_TRADE_STATUS));

		AlipayNotification entity = alipayNotificationService.selectByOrderAndTradeStatus(params);
		// 避免相同的状态重复保存，因为退款也会回调此接口，如果保存两条TRADE_SUCCESS会导致拆单订单退款异常。
		if (entity != null) {
			return new ResponseEntity<>(AlipayConstants.PAY_SUCCESS_RESPONSE_TEXT, HTTPHelper.createResponseHeaders(),
					HttpStatus.OK);
		}
		OrderVo order = paymentOrderClient.getOrderByOrderId(orderId);

		// 防止支付宝重复发起异步回调通知
		if (order.getStatus() >= OrderStatus.PAID) {
			return new ResponseEntity<>(AlipayConstants.PAY_SUCCESS_RESPONSE_TEXT, HTTPHelper.createResponseHeaders(),
					HttpStatus.OK);
		}

		entity = alipayNotificationService.create(parameters);
		order.setPayType(PaymentTypeEnum.ALIPAY);
		// 只在交易成功和支付成功的情况下将订单状态更新为已支付
		String tradeStatus = entity.getTradeStatus();
		if (AlipayConstants.TRADE_STATUS_TRADE_SUCCESS.equals(tradeStatus)) {
			int result = paymentUpdateService.doUpdateStatus(orderId, order.getVersion(),
					OrderEventTypeEnum.PAYROLLBACK.getCode(),BigDecimal.ZERO, PaymentTypeEnum.ALIPAY);
			LOGGER.info("update payment status : {} , orderID : {}", result, orderId);
			
			if (result == 1) {
				String postData = recordSaleService.sendRecordSale(orderId, resourceType,
						RecordSaleConstants.MOBILE_CHECKOUT_ORDER_TYPE,OrderStatus.PAID);
				if (postData != null) {
					recordsaleSendHandler.recordsaleSendMessage(postData);
				}
				LOGGER.info("alipay callback then send recordsale message to mq  , orderID : {}", orderId);
			}
			
		}

		return new ResponseEntity<>(AlipayConstants.PAY_SUCCESS_RESPONSE_TEXT, HTTPHelper.createResponseHeaders(),
				HttpStatus.OK);
	}

	private Map<String, String> parameters(Map<String, String[]> parameter) {
		Map<String, String> params = new HashMap<>(16);
		for (Entry<String, String[]> paramsEntry : parameter.entrySet()) {
			if (paramsEntry.getValue() != null) {
				params.put(paramsEntry.getKey(), paramsEntry.getValue()[0]);
			}
		}
		return params;
	}

}
