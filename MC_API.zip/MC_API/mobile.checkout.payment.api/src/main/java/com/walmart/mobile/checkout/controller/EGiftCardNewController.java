package com.walmart.mobile.checkout.controller;

import java.math.BigDecimal;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.bo.payment.OrderVo;
import com.walmart.mobile.checkout.bo.payment.PaymentRequest;
import com.walmart.mobile.checkout.constant.order.OrderStatus;
import com.walmart.mobile.checkout.domain.payment.EGiftcardNewNotification;
import com.walmart.mobile.checkout.enumcode.payment.PaymentConstants;
import com.walmart.mobile.checkout.enumcode.payment.PaymentErrorInfoEnum;
import com.walmart.mobile.checkout.enumcode.payment.PaymentTypeEnum;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.exception.handler.ResultBody;
import com.walmart.mobile.checkout.handler.send.RecordsaleSendHandler;
import com.walmart.mobile.checkout.rest.payment.PaymentOrderClient;
import com.walmart.mobile.checkout.service.http.util.HttpRequestUtil;
import com.walmart.mobile.checkout.service.payment.EGiftCardNewService;
import com.walmart.mobile.checkout.service.payment.PaymentUpdateService;
import com.walmart.mobile.checkout.service.recordsale.RecordSaleService;
import com.walmart.mobile.checkout.statemachine.OrderEventTypeEnum;
import com.walmart.mobile.checkout.utils.ThreadLocalContextHolder;

import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Controller
@RequestMapping
public class EGiftCardNewController {

	private static final Logger LOGGER = LoggerFactory.getLogger(EGiftCardNewController.class);

	@Autowired
	RestTemplate restTemplate;

	/**
	 * dagId在订单号规则中出现的开始位置，从此位置向后截取3位即为dagId.
	 */
	public static final int ORDER_ID_PATTERN_OF_DAG_ID_INDEX = 7;

	// storeId在订单号规则中出现的开始位置，从此位置向后截取4位即为storeId.
	public static final int ORDER_ID_PATTERN_OF_STORE_ID_INDEX = 1;

	@Value("${recordsale.resource.type}")
	private String resourceType;
	
	@Autowired
	private RecordsaleSendHandler recordsaleSendHandler;
	
	@Autowired
	private RecordSaleService recordSaleService;
	
	@Autowired
	EGiftCardNewService eGiftCardNewService;

	@Autowired
	private PaymentOrderClient paymentOrderClient;


	@Autowired
	private PaymentUpdateService paymentUpdateService;

	


	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"),
			@ApiResponse(code = -401, message = "没有权限操作"), @ApiResponse(code = -402, message = "订单已支付，请不要重复支付"),
			@ApiResponse(code = -413, message = "礼品卡参数异常"), @ApiResponse(code = -414, message = "订单超时") 
	       , @ApiResponse(code = -415, message = "订单统一下单失败")})
	@RequestMapping(value = "/payment/new/egiftcard/paymentparams", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody getEgiftCardUnifiedOrder(@RequestBody PaymentRequest paymentRequest, HttpServletRequest request)
			throws GlobalErrorInfoException {

		String orderId = paymentRequest.getOrderId();
		String dagId = orderId.substring(ORDER_ID_PATTERN_OF_DAG_ID_INDEX, ORDER_ID_PATTERN_OF_DAG_ID_INDEX + 3);
		ThreadLocalContextHolder.switchDataSoureByDagId(dagId);
		OrderVo orderVo = paymentOrderClient.getOrderByOrderId(orderId);

		if (paymentUpdateService.isTimeOut(orderVo.getCreatedTime())) {
			LOGGER.info("订单已超时, 订单号[{}]，当前支付方式[{}]", orderVo.getOrderId(), PaymentTypeEnum.EGIFTCARD);
			return new ResultBody(null, PaymentErrorInfoEnum.ORDER_IS_TIMEOUT.getCode(), "订单已超时，不能支付");
		}

		if (orderVo.getStatus() >= OrderStatus.PAID) {
			LOGGER.info("订单已支付，请不要重复支付, 订单号[{}]，当前支付方式[{}]", orderVo.getOrderId(), PaymentTypeEnum.EGIFTCARD);
			return new ResultBody(null, PaymentErrorInfoEnum.ORDER_HAVE_BEAN_PAID.getCode(), "订单已支付，请不要重复支付");
		}
		ResultBody resultBody = new ResultBody();
		try {
			String result = HttpRequestUtil.sendRequestByPostMethod(eGiftCardNewService.getEgiftcardUrl("unifiedOrder", orderVo), restTemplate, eGiftCardNewService.getEgiftcardParameter(orderVo));
			
			LOGGER.info("egiftcard orderid:{} , unifiedOrder result : {} ",orderId,  result);
			JSONObject rootObject = JSON.parseObject(result);
			if("0".equals(rootObject.getString("errcode"))){
				resultBody.setResult(rootObject.getJSONObject("data"));
			}else{
				resultBody.setCode("-415");
				resultBody.setResult(rootObject.getString("errmsg"));
			}
			
		} catch (Exception e) {
			throw new GlobalErrorInfoException(PaymentErrorInfoEnum.EGIFT_PAY_PARAMTER_ERROR, e);
		}
		return resultBody;
	}

	@RequestMapping(value = "/payment/new/egiftcard/payNotify", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public String createEGiftcardNotification(@RequestBody EGiftcardNewNotification egiftcardNewNotification, HttpServletRequest request) {
		try {
			
				String orderId = egiftcardNewNotification.getChannelTradeNo();
				String dagId = orderId.substring(PaymentConstants.ORDER_ID_PATTERN_OF_DAG_ID_INDEX,
						PaymentConstants.ORDER_ID_PATTERN_OF_DAG_ID_INDEX + 3);
				ThreadLocalContextHolder.switchDataSoureByDagId(dagId);

				EGiftcardNewNotification dbEGiftcardNotification = eGiftCardNewService.selectEgiftcardNotificationByOrderId(orderId);
				
				if (dbEGiftcardNotification == null) {
				
					if(!eGiftCardNewService.checkNotify(egiftcardNewNotification)){
						LOGGER.info("egift card check sign fail  , orderID : {}", orderId);
						return eGiftCardNewService.setResponseString("-1", "check sign fail");
					}
					
					eGiftCardNewService.createEGiftcardNotification(egiftcardNewNotification);
					OrderVo order = paymentOrderClient.getOrderByOrderId(orderId);
					int result = paymentUpdateService.doUpdateStatus(orderId, order.getVersion(),
							OrderEventTypeEnum.PAYROLLBACK.getCode(),BigDecimal.ZERO, PaymentTypeEnum.EGIFTCARD);
					LOGGER.info("update payment status : {} , orderID : {}", result, orderId);
				
//					if (result == 1) {
//						String postData = recordSaleService.sendRecordSale(orderId, resourceType,
//								RecordSaleConstants.MOBILE_CHECKOUT_ORDER_TYPE,OrderStatus.PAID);
//						if (postData != null) {
//							recordsaleSendHandler.recordsaleSendMessage(postData);
//						}
//						LOGGER.info("egift card callback then send recordsale message to mq  , orderID : {}", orderId);
//					}
						
					return eGiftCardNewService.setResponseString("0", "egiftcard payment callback success");	
					
				}else{
					return eGiftCardNewService.setResponseString("0", "egiftcard payment  has been callback");
				}
				
		} catch (Exception e) {
			LOGGER.error("礼品卡支付回调异常 ：", e);
			return eGiftCardNewService.setResponseString("-1", "egiftcard payment callback fail");
		}
	}
	
	
	
	
}
