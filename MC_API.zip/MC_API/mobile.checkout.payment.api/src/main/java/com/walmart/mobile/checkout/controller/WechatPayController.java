package com.walmart.mobile.checkout.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.io.IOException;
import java.math.BigDecimal;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.xml.parsers.ParserConfigurationException;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.xml.sax.SAXException;

import com.walmart.mobile.checkout.annotation.PrivilegeInfo;
import com.walmart.mobile.checkout.bo.payment.OrderVo;
import com.walmart.mobile.checkout.bo.payment.PaymentRequest;
import com.walmart.mobile.checkout.bo.payment.PaymentSyncNotification;
import com.walmart.mobile.checkout.bo.payment.Unifiedorder;
import com.walmart.mobile.checkout.bo.payment.UnifiedorderResult;
import com.walmart.mobile.checkout.bo.payment.UnifiedorderResultBo;
import com.walmart.mobile.checkout.constant.AppConstants;
import com.walmart.mobile.checkout.constant.GlobalErrorInfoEnum;
import com.walmart.mobile.checkout.constant.WechatConstants;
import com.walmart.mobile.checkout.constant.order.OrderStatus;
import com.walmart.mobile.checkout.constant.recordsale.RecordSaleConstants;
import com.walmart.mobile.checkout.domain.payment.WechatNotification;
import com.walmart.mobile.checkout.enumcode.payment.PaymentConstants;
import com.walmart.mobile.checkout.enumcode.payment.PaymentErrorInfoEnum;
import com.walmart.mobile.checkout.enumcode.payment.PaymentTypeEnum;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.exception.handler.ResultBody;
import com.walmart.mobile.checkout.handler.send.CreaditW5SendHandler;
import com.walmart.mobile.checkout.handler.send.OrderStatusSendHandler;
import com.walmart.mobile.checkout.handler.send.RecordsaleSendHandler;
import com.walmart.mobile.checkout.rest.UserClient;
import com.walmart.mobile.checkout.rest.payment.PaymentOrderClient;
import com.walmart.mobile.checkout.service.payment.PaymentUpdateService;
import com.walmart.mobile.checkout.service.payment.WechatNotificationService;
import com.walmart.mobile.checkout.service.recordsale.RecordSaleService;
import com.walmart.mobile.checkout.statemachine.OrderEventTypeEnum;
import com.walmart.mobile.checkout.utils.HTTPHelper;
import com.walmart.mobile.checkout.utils.HttpsRequest;
import com.walmart.mobile.checkout.utils.JaxbUtil;
import com.walmart.mobile.checkout.utils.ThreadLocalContextHolder;
import com.walmart.mobile.checkout.utils.payment.wechat.RandomStringGeneratorUtil;
import com.walmart.mobile.checkout.utils.payment.wechat.Signature;
import com.walmart.mobile.checkout.utils.payment.wechat.Util;
import com.walmart.mobile.checkout.utils.payment.wechat.WechatDateUtil;

@Controller
@RequestMapping("payment")
public class WechatPayController {
	private static final Logger LOGGER = LoggerFactory.getLogger(WechatPayController.class);

	@Value("${payment.amount.test}")
	private String paymentAmount;

	@Value("${recordsale.resource.type}")
	private String resourceType;

	@Autowired
	private RecordsaleSendHandler recordsaleSendHandler;

	@Autowired
	private UserClient userClient;
	@Autowired
	private RecordSaleService recordSaleService;

	@Autowired
	private PaymentOrderClient paymentOrderClient;

	@Autowired
	private PaymentUpdateService paymentUpdateService;

	@Autowired
	private WechatNotificationService wechatNotificationService;

	@Autowired
	private OrderStatusSendHandler orderStatusSendHandler;
	@Autowired
	CreaditW5SendHandler creaditW5SendHandler;

	/**
	 * 接收client消息，server在调用微信支付 统一下单接口后返回数据给到客户端 错误码
	 * server在调用统一下单后，还要签名给client端调起支付接口用，详见
	 * https://pay.weixin.qq.com/wiki/doc/api/app/app.php?chapter=8_5
	 *
	 *
	 * NOAUTH 商户无此接口权限 商户未开通此接口权限 请商户前往申请此接口权限 NOTENOUGH 余额不足 用户帐号余额不足
	 * 用户帐号余额不足，请用户充值或更换支付卡后再支付 ORDERPAID 商户订单已支付 商户订单已支付，无需重复操作 商户订单已支付，无需更多操作
	 * ORDERCLOSED 订单已关闭 当前订单已关闭，无法支付 当前订单已关闭，请重新下单 SYSTEMERROR 系统错误 系统超时
	 * 系统异常，请用相同参数重新调用 APPID_NOT_EXIST APPID不存在 参数中缺少APPID 请检查APPID是否正确
	 * MCHID_NOT_EXIST MCHID不存在 参数中缺少MCHID 请检查MCHID是否正确 APPID_MCHID_NOT_MATCH
	 * appid和mch_id不匹配 appid和mch_id不匹配 请确认appid和mch_id是否匹配 LACK_PARAMS 缺少参数
	 * 缺少必要的请求参数 请检查参数是否齐全 OUT_TRADE_NO_USED 商户订单号重复 同一笔交易不能多次提交 请核实商户订单号是否重复提交
	 * SIGNERROR 签名错误 参数签名结果不正确 请检查签名参数和方法是否都符合签名算法要求 XML_FORMAT_ERROR XML格式错误
	 * XML格式错误 请检查XML参数格式是否正确 REQUIRE_POST_METHOD 请使用post方法 未使用post传递参数
	 * 请检查请求参数是否通过post方法提交 POST_DATA_EMPTY post数据为空 post数据不能为空 请检查post数据是否为空
	 * NOT_UTF8 编码格式错误 未使用指定编码格式 请使用NOT_UTF8编码格式
	 * 
	 * @throws GlobalErrorInfoException
	 *
	 */
	@PrivilegeInfo
	@ApiOperation(value = "wechat payment parameter create", notes = "创建支付参数(微信支付)")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -401, message = "没有权限操作"), @ApiResponse(code = -402, message = "订单已支付，请不要重复支付"),
			@ApiResponse(code = -403, message = "微信统一下单接口异常，无返回数据"), @ApiResponse(code = -404, message = "连接超时"), @ApiResponse(code = -405, message = "支付失败"),
			@ApiResponse(code = -414, message = "订单超时") })
	@RequestMapping(value = "/paymentparams", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody getPaymentInfo(@RequestBody PaymentRequest paymentRequest, HttpServletRequest request) throws GlobalErrorInfoException {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("getWechatPaymentInfo start");
		}
		String appid = WechatConstants.getAppid();
		String mchId = WechatConstants.getMchid();
		String payUrl = WechatConstants.getPayApi();
		String notifyUrl = WechatConstants.getNotifyUrl();

		String orderId = paymentRequest.getOrderId();

		String dagId = orderId.substring(PaymentConstants.ORDER_ID_PATTERN_OF_DAG_ID_INDEX, PaymentConstants.ORDER_ID_PATTERN_OF_DAG_ID_INDEX + 3);

		ThreadLocalContextHolder.switchDataSoureByDagId(dagId);

		String userId = ThreadLocalContextHolder.getUserId();

		String openid = userClient.getAllThirdPartyByUserIdAndType(userId, AppConstants.LOGIN_TYPE);

		// String openid = ThreadLocalContextHolder.get(AppConstants.OPENID,
		// String.class);

		OrderVo orderVo = paymentOrderClient.getOrderByOrderId(orderId);

		if (paymentUpdateService.isTimeOut(orderVo.getCreatedTime())) {
			LOGGER.info("订单已超时, 订单号[{}]，当前支付方式[{}]", orderVo.getOrderId(), PaymentTypeEnum.WECHATPAY);
			return new ResultBody(null, PaymentErrorInfoEnum.ORDER_IS_TIMEOUT.getCode(), "订单已超时，不能支付");
		}

		if (orderVo.getStatus() >= OrderStatus.PAID) {
			LOGGER.info("订单已支付，请不要重复支付, 订单号[{}]，当前支付方式[{}]", orderVo.getOrderId(), PaymentTypeEnum.WECHATPAY);
			return new ResultBody(null, PaymentErrorInfoEnum.ORDER_HAVE_BEAN_PAID.getCode(), "订单已支付，请不要重复支付");
		}

		// 参数组

		String nonceStr = RandomStringGeneratorUtil.getRandomStringByLength(32);
		LOGGER.info("随机字符串是：{} , openid:{}", nonceStr, openid);
		String body = "Mobilecheckout"; // 商品描述
		// String detail = ""; // 商品详情
		String attach = "微信小程序订单"; // 附加数据

		BigDecimal amount = (new BigDecimal("100")).multiply(orderVo.getAmount());
		int totalFee = amount.intValue();

		if ("1".equals(paymentAmount)) {
			totalFee = 1;
		}

		String spbillCreateIp = HTTPHelper.getIpAddr(request);
		String timeStart = WechatDateUtil.timeStart();
		String timeExpire = WechatDateUtil.timeExpire();
		String tradeType = "JSAPI";

		// 参数：开始生成签名
		Map<String, Object> parameters = setSignParameters(appid, mchId, notifyUrl, orderId, nonceStr, body, attach, totalFee, spbillCreateIp, timeStart, timeExpire, tradeType, openid);

		String sign = Signature.getSign(parameters);
		LOGGER.info("签名是：{} ", sign);

		// 封装发送给微信统一下单接口的对象
		Unifiedorder unifiedorder = new Unifiedorder(orderId, nonceStr, body, attach, totalFee, spbillCreateIp, timeStart, timeExpire, tradeType, sign, notifyUrl, appid, mchId, openid);

		// 发送微信统一下单接口
		HttpsRequest hq;
		try {
			hq = new HttpsRequest();
		} catch (UnrecoverableKeyException | KeyManagementException | NoSuchAlgorithmException | KeyStoreException | IOException e) {
			throw new GlobalErrorInfoException(GlobalErrorInfoEnum.FAILED, e);
		}
		String payRes;
		try {
			payRes = hq.sendPost(payUrl, unifiedorder);
		} catch (UnrecoverableKeyException | KeyManagementException | KeyStoreException | NoSuchAlgorithmException | IOException e) {
			throw new GlobalErrorInfoException(PaymentErrorInfoEnum.PAID_HAS_NO_RESULT, e);
		}

		LOGGER.info("the weixin response is {} ", payRes);

		// 返回结果签名校验并返回给client
		ResultBody msg = new ResultBody();
		try {
			returnMsg(appid, orderId, payRes, msg);
		} catch (ParserConfigurationException | IOException | SAXException e) {
			throw new GlobalErrorInfoException(GlobalErrorInfoEnum.FAILED, e);
		}

		return msg;
	}

	private void returnMsg(String appid, String orderId, String payRes, ResultBody msg) throws ParserConfigurationException, IOException, SAXException, GlobalErrorInfoException {
		// 将微信返回的xml封装成对象
		JaxbUtil resultBinder = new JaxbUtil();
		UnifiedorderResult unifiedorderResult = resultBinder.fromXml(payRes, UnifiedorderResult.class);

		String returnCode = unifiedorderResult.getReturnCode();
		String resultCode = unifiedorderResult.getResultCode();

		// 封装驼峰写法的数据给客户端，兼容客户端之前代码
		String timeStamp = String.valueOf(System.currentTimeMillis() / 1000);
		UnifiedorderResultBo unifiedorderResultBo = new UnifiedorderResultBo(unifiedorderResult, timeStamp);

		if (PaymentConstants.RETURN_CODE_FAIL.equals(returnCode)) {
			msg.setCode(PaymentErrorInfoEnum.WECHAT_CONNECTION_ERROR.getCode());
			msg.setMessage("微信统一下单接口返回通信失败");
			msg.setResult(unifiedorderResultBo);

			LOGGER.info("订单： {} 调用微信统一下单接口返回通信失败 , 失败原因： {} ", orderId, unifiedorderResult.getErrCode());

		} else if (PaymentConstants.RETURN_CODE_SUCCESS.equals(returnCode) && PaymentConstants.RETURN_CODE_FAIL.equals(resultCode)) {
			msg.setCode(PaymentErrorInfoEnum.PAID_FAIL.getCode());
			msg.setMessage("微信统一下单接口返回交易失败");
			msg.setResult(unifiedorderResultBo);
			if (!"ORDERPAID".equals(unifiedorderResult.getErrCode())) {
				LOGGER.info("订单：{} 调用微信统一下单接口返回交易失败", "失败原因,微信统一下单返回交易code：{} ", orderId, unifiedorderResult.getErrCode() + unifiedorderResult.getErrCodeDes());
			}
		} else if (PaymentConstants.RETURN_CODE_SUCCESS.equals(resultCode) && PaymentConstants.RETURN_CODE_SUCCESS.equals(returnCode) && Signature.checkIsSignValidFromResponseString(payRes, true)) {
			// 再次签名给调起支付接口
			String clientSign = getClientSign(appid, unifiedorderResult, timeStamp);
			unifiedorderResult.setSign(clientSign);
			msg.setResult(unifiedorderResultBo);
		}
	}

	/**
	 * 客户端支付签名
	 *
	 * @param appid
	 * @param mch_id
	 * @param unifiedorderResult
	 * @param timeStamp
	 * @return
	 */
	private String getClientSign(String appid, UnifiedorderResult unifiedorderResult, String timeStamp) {
		Map<String, Object> clientParameters = new HashMap<>(5);
		clientParameters.put("appId", appid);
		clientParameters.put("timeStamp", timeStamp);
		clientParameters.put("nonceStr", unifiedorderResult.getNonceStr());
		clientParameters.put("package", "prepay_id=" + unifiedorderResult.getPrepayId());
		clientParameters.put("signType", "MD5");
		return Signature.getSign(clientParameters);
	}

	/**
	 * 组装开始生成签名参数
	 *
	 * @param orderId
	 * @param nonce_str
	 * @param body
	 * @param detail
	 * @param attach
	 * @param total_fee
	 * @param spbill_create_ip
	 * @param time_start
	 * @param time_expire
	 * @param trade_type
	 * @return
	 */
	private Map<String, Object> setSignParameters(String appId, String mchId, String notifyUrl, String orderId, String nonceStr, String body, String attach, int totalFee, String spbillCreateIp,
			String timeStart, String timeExpire, String tradeType, String openid) {
		Map<String, Object> parameters = new HashMap<>(13);
		parameters.put("appid", appId);
		parameters.put("mch_id", mchId);
		parameters.put("nonce_str", nonceStr);
		parameters.put("body", body);
		parameters.put("attach", attach);
		parameters.put("out_trade_no", orderId);
		parameters.put("spbill_create_ip", spbillCreateIp);
		parameters.put("total_fee", totalFee);
		parameters.put("time_start", timeStart);
		parameters.put("time_expire", timeExpire);
		parameters.put("notify_url", notifyUrl);
		parameters.put("trade_type", tradeType);
		parameters.put("openid", openid);

		return parameters;
	}

	@ApiOperation(value = "client call back ", notes = "客户端支付回调")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -402, message = "订单已支付，请不要重复支付"), @ApiResponse(code = -403, message = "订单状态修改失败") })
	@RequestMapping(value = "/paidSyncNofify", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody paidSyncNotify(@RequestBody PaymentSyncNotification notification, HttpServletRequest request) throws GlobalErrorInfoException {

		ResultBody resultBody = new ResultBody();
		if (!notification.isValid()) {
			throw new IllegalArgumentException(ToStringBuilder.reflectionToString(notification));
		}

		String orderId = notification.getOrderId();
		String dagId = orderId.substring(PaymentConstants.ORDER_ID_PATTERN_OF_DAG_ID_INDEX, PaymentConstants.ORDER_ID_PATTERN_OF_DAG_ID_INDEX + 3);

		ThreadLocalContextHolder.put("dagId", dagId);

		OrderVo order = paymentOrderClient.getOrderByOrderId(orderId);
		// 由于支付回调请求和paidSyncNotify请求并没有先后顺序，那么支付回调请求先于本请求达到服务器端时
		// 订单状态已经被更新为30，故在此检测是否已是30状态，如果是则不做任何操作直接返回
		// 在有master商品时，order有可能为空
		if (order == null || order.getStatus() == OrderStatus.PAID) {
			throw new GlobalErrorInfoException(PaymentErrorInfoEnum.ORDER_HAVE_BEAN_PAID);
		}

		if (StringUtils.equals("0", notification.getCode()) || !(StringUtils.equals("-2", notification.getCode()))) {
			try {
				OrderVo orderNow = paymentOrderClient.getOrderByOrderId(orderId);

				paymentUpdateService.doUpdate(orderId, orderNow.getVersion(), OrderEventTypeEnum.PAY.getCode(), BigDecimal.ZERO, PaymentTypeEnum.WECHATPAY);
				LOGGER.info("PaidSyncNofify update payment1 orderId={}, payType={}, code={}", orderId, notification.getPayType(), notification.getCode());
			} catch (GlobalErrorInfoException e) {
				LOGGER.info("PaidSyncNofify update payment2 orderId={}, payType={}, code={}", orderId, notification.getPayType(), notification.getCode(), e);
				throw new GlobalErrorInfoException(PaymentErrorInfoEnum.ORDER_UPDATE_STATUS_FAIL);
			}
		}
		return resultBody;

	}

	/**
	 * @param request
	 * @return String
	 * @throws GlobalErrorInfoException
	 * @throws IOException
	 * @throws SAXException
	 * @throws ParserConfigurationException
	 * @throws Exception
	 * 
	 */
	@ApiOperation(value = "wechat payment callback", notes = "微信支付回调", hidden = true)
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功") })
	@RequestMapping(value = "/wechat/callback", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public String wechat(HttpServletRequest request) throws GlobalErrorInfoException {

		String requestBodyString;
		try {
			requestBodyString = Util.inputStreamToString(request.getInputStream());
		} catch (IOException e) {
			throw new GlobalErrorInfoException(GlobalErrorInfoEnum.FAILED, e);
		}
		LOGGER.info("微信支付回调 body is{}：\n", requestBodyString);
		Map<String, Object> map = wechatNotificationService.getReturnWeiXinPay(requestBodyString);

		if (!PaymentConstants.PAY_SUCCESS_RESPONSE_TEXT.equals(map.get("returnCode"))) {
			LOGGER.info("微信支付回调通信失败 ");
			return wechatNotificationService.xmlReturnApplyInfo(PaymentConstants.PAY_FAIL_RESPONSE_TEXT, (String) map.get("returnMsg"));
		}

		if (!Signature.checkIsSignValidFromResponseString(requestBodyString, true)) {
			return wechatNotificationService.xmlReturnApplyInfo(PaymentConstants.PAY_FAIL_RESPONSE_TEXT, "签名失败");
		}

		WechatNotification wechatNotification = (WechatNotification) map.get("wechatNotification");

		String orderId = wechatNotification.getOrderId();

		String dagId = orderId.substring(PaymentConstants.ORDER_ID_PATTERN_OF_DAG_ID_INDEX, PaymentConstants.ORDER_ID_PATTERN_OF_DAG_ID_INDEX + 3);

		ThreadLocalContextHolder.put("dagId", dagId);

		WechatNotification entity = wechatNotificationService.getByOutTradeNo(orderId);
		// 避免相同的状态重复保存。
		if (entity != null) {
			return wechatNotificationService.xmlReturnApplyInfo(PaymentConstants.PAY_SUCCESS_RESPONSE_TEXT, PaymentConstants.PAY_OK_RESPONSE_TEXT);
		}
		OrderVo order = paymentOrderClient.getOrderByOrderId(orderId);

		// 防止微信重复发起异步回调通知
		if (order.getStatus() >= OrderStatus.PAID) {
			return wechatNotificationService.xmlReturnApplyInfo(PaymentConstants.PAY_SUCCESS_RESPONSE_TEXT, PaymentConstants.PAY_OK_RESPONSE_TEXT);
		}

		String resultCode = wechatNotification.getResultCode();

		if (PaymentConstants.PAY_SUCCESS_RESPONSE_TEXT.equals(resultCode)) {
			wechatNotificationService.create(wechatNotification);
			BigDecimal paymentCouponFee = BigDecimal.ZERO;
			if (wechatNotification.getCouponFee() != null) {
				paymentCouponFee = new BigDecimal(wechatNotification.getCouponFee()).divide(new BigDecimal(100));
			}
			// 只在支付成功的情况下将订单状态更新为已支付
			int result = paymentUpdateService.doUpdateStatus(orderId, order.getVersion(), OrderEventTypeEnum.PAYROLLBACK.getCode(), paymentCouponFee, PaymentTypeEnum.WECHATPAY);
			LOGGER.info("update payment status : {} , orderID : {} , CouponFee :{} ,paymentCouponFee:{} ", result, orderId, wechatNotification.getCouponFee(), paymentCouponFee);

			if (result == 1) {
				String postData = recordSaleService.sendRecordSale(orderId, resourceType, RecordSaleConstants.MOBILE_CHECKOUT_ORDER_TYPE, OrderStatus.PAID);
				if (postData != null) {
					recordsaleSendHandler.recordsaleSendMessage(postData);
				}
				LOGGER.info("WECHATPAY callback then send recordsale message to mq  , orderID : {}", orderId);

				orderStatusSendHandler.sendMessage(orderId);
				LOGGER.info("orderid : {}  , send complete status message", orderId);
			}

		} else {
			return wechatNotificationService.xmlReturnApplyInfo(PaymentConstants.PAY_FAIL_RESPONSE_TEXT, "业务结果失败");
		}
		// 发送用来统计月均交易
		String userId = order.getUserId();
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("userId", userId);
		jsonObject.put("dagId", dagId);
		creaditW5SendHandler.sendMessage(jsonObject.toString());

		return wechatNotificationService.xmlReturnApplyInfo(PaymentConstants.PAY_SUCCESS_RESPONSE_TEXT, PaymentConstants.PAY_OK_RESPONSE_TEXT);
	}

}
