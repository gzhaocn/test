package com.walmart.mobile.checkout.controller;

import java.math.BigDecimal;
import java.security.NoSuchAlgorithmException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.walmart.mobile.checkout.annotation.PrivilegeInfo;
import com.walmart.mobile.checkout.bo.payment.OrderVo;
import com.walmart.mobile.checkout.bo.payment.PaymentRequest;
import com.walmart.mobile.checkout.constant.AlipayConstants;
import com.walmart.mobile.checkout.constant.AppConstants;
import com.walmart.mobile.checkout.constant.order.OrderStatus;
import com.walmart.mobile.checkout.constant.recordsale.RecordSaleConstants;
import com.walmart.mobile.checkout.domain.payment.EGiftcardNotification;
import com.walmart.mobile.checkout.enumcode.payment.PaymentConstants;
import com.walmart.mobile.checkout.enumcode.payment.PaymentErrorInfoEnum;
import com.walmart.mobile.checkout.enumcode.payment.PaymentTypeEnum;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.exception.handler.ResultBody;
import com.walmart.mobile.checkout.handler.send.RecordsaleSendHandler;
import com.walmart.mobile.checkout.rest.payment.PaymentOrderClient;
import com.walmart.mobile.checkout.service.payment.EGiftCardPaymentService;
import com.walmart.mobile.checkout.service.payment.EGiftcardNotificationService;
import com.walmart.mobile.checkout.service.payment.PaymentUpdateService;
import com.walmart.mobile.checkout.service.recordsale.RecordSaleService;
import com.walmart.mobile.checkout.statemachine.OrderEventTypeEnum;
import com.walmart.mobile.checkout.utils.HTTPHelper;
import com.walmart.mobile.checkout.utils.ThreadLocalContextHolder;

import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Controller
@RequestMapping
public class EGiftCardController {

	private static final Logger LOGGER = LoggerFactory.getLogger(EGiftCardController.class);


	@Value("${recordsale.resource.type}")
	private String resourceType;
	
	@Autowired
	private RecordsaleSendHandler recordsaleSendHandler;
	
	@Autowired
	private RecordSaleService recordSaleService;
	
	@Autowired
	EGiftCardPaymentService eGiftCardPaymentService;

	@Autowired
	private PaymentOrderClient paymentOrderClient;

	@Autowired
	private EGiftcardNotificationService eGiftcardNotificationService;

	@Autowired
	private PaymentUpdateService paymentUpdateService;

	

	private static final String PAY_SUCCESS_CODE = "00";

	@PrivilegeInfo
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"),
			@ApiResponse(code = -401, message = "没有权限操作"), @ApiResponse(code = -402, message = "订单已支付，请不要重复支付"),
			@ApiResponse(code = -413, message = "礼品卡参数异常"), @ApiResponse(code = -414, message = "订单超时") })
	@RequestMapping(value = "/payment/egiftcard/paymentparams", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody getUrl(@RequestBody PaymentRequest paymentRequest, HttpServletRequest request)
			throws GlobalErrorInfoException {

		String orderId = paymentRequest.getOrderId();
		OrderVo orderVo = paymentOrderClient.getOrderByOrderId(orderId);

		if (paymentUpdateService.isTimeOut(orderVo.getCreatedTime())) {
			LOGGER.info("订单已超时, 订单号[{}]，当前支付方式[{}]", orderVo.getOrderId(), PaymentTypeEnum.EGIFTCARD);
			return new ResultBody(null, PaymentErrorInfoEnum.ORDER_IS_TIMEOUT.getCode(), "订单已超时，不能支付");
		}

		String userId = ThreadLocalContextHolder.getUserId();
		if (orderVo.getStatus() >= OrderStatus.PAID) {
			LOGGER.info("订单已支付，请不要重复支付, 订单号[{}]，当前支付方式[{}]", orderVo.getOrderId(), PaymentTypeEnum.EGIFTCARD);
			return new ResultBody(null, PaymentErrorInfoEnum.ORDER_HAVE_BEAN_PAID.getCode(), "订单已支付，请不要重复支付");
		}
		ResultBody resultBody = new ResultBody();
		try {
			resultBody.setResult(eGiftCardPaymentService.getPayUrl(userId, orderId));
		} catch (Exception e) {
			throw new GlobalErrorInfoException(PaymentErrorInfoEnum.EGIFT_PAY_PARAMTER_ERROR, e);
		}
		return resultBody;
	}

	@RequestMapping(value = "/payment/egiftcard/callback", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResponseEntity<String> createEGiftcardNotification(HttpServletRequest request) {
		Map<String, String> parameters = HTTPHelper.parameters(request.getParameterMap());
		try {
			if (eGiftCardPaymentService.isReturnedFromEgiftcard(parameters)) {
				String orderId = parameters.get(PaymentConstants.ORDERID);
				String dagId = orderId.substring(PaymentConstants.ORDER_ID_PATTERN_OF_DAG_ID_INDEX,
						PaymentConstants.ORDER_ID_PATTERN_OF_DAG_ID_INDEX + 3);
				ThreadLocalContextHolder.switchDataSoureByDagId(dagId);

				EGiftcardNotification eGiftcardNotification = eGiftcardNotificationService
						.selectEgiftcardNotificationByOrderId(orderId);
				if (eGiftcardNotification == null) {
					EGiftcardNotification entity = eGiftcardNotificationService.createEGiftcardNotification(parameters);

					if (PAY_SUCCESS_CODE.equals(entity.getReturnCode())) {
						OrderVo order = paymentOrderClient.getOrderByOrderId(orderId);
						int result = paymentUpdateService.doUpdateStatus(orderId, order.getVersion(),
								OrderEventTypeEnum.PAYROLLBACK.getCode(),BigDecimal.ZERO, PaymentTypeEnum.EGIFTCARD);
						LOGGER.info("update payment status : {} , orderID : {}", result, orderId);
					
						if (result == 1) {
							String postData = recordSaleService.sendRecordSale(orderId, resourceType,
									RecordSaleConstants.MOBILE_CHECKOUT_ORDER_TYPE,OrderStatus.PAID);
							if (postData != null) {
								recordsaleSendHandler.recordsaleSendMessage(postData);
							}
							LOGGER.info("egift card callback then send recordsale message to mq  , orderID : {}", orderId);
						}
						
						
					}
				}
				return new ResponseEntity<>(AlipayConstants.PAY_SUCCESS_RESPONSE_TEXT, HttpStatus.OK);
			} else {
				return new ResponseEntity<>(AlipayConstants.PAY_FAILED_RESPONSE_TEXT, HttpStatus.BAD_REQUEST);
			}
		} catch (NoSuchAlgorithmException e) {
			LOGGER.error("礼品卡支付回调异常 ：", e);
			return new ResponseEntity<>(AlipayConstants.PAY_FAILED_RESPONSE_TEXT, HttpStatus.BAD_REQUEST);
		}
	}
}
