package com.walmart.mobile.checkout.controller;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.servlet.http.Cookie;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;

import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.bo.payment.AliPaymentRequest;
import com.walmart.mobile.checkout.bo.payment.OrderVo;
import com.walmart.mobile.checkout.config.MainConfig;
import com.walmart.mobile.checkout.dag.DagHost;
import com.walmart.mobile.checkout.dag.HostData;
import com.walmart.mobile.checkout.datasource.DynamicDataSource;
import com.walmart.mobile.checkout.exception.handler.ResultBody;
import com.walmart.mobile.checkout.rest.payment.PaymentOrderClient;

/*@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { MainConfig.class })*/
public class AlipayControllerTest {
	protected MockHttpServletResponse response;

	protected MockMvc mockMVC;

	@Autowired
	private WebApplicationContext wac;

	@Autowired
	private PaymentOrderClient paymentOrderClient;

	@Autowired
	@Qualifier("dynamicDataSource")
	public DynamicDataSource dynamicDataSource;

	@Value("${ddr.request.param}")
	private String ddrParam;

	@Value("${ddr.request.url}")
	private String ddrUrl;

	@Autowired
	private RestTemplate restTemplate;

	private void initDatasourceRouter() {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<>(ddrParam, headers);
		String result = restTemplate.postForObject(ddrUrl, entity, String.class);
		List<DagHost> dss = JSONObject.parseObject(result, HostData.class).getData();
		Map<Object, Object> dataSources = new HashMap<>(16);
		for (int i = 0; i < dss.size(); i++) {
			DagHost dh = dss.get(i);
			String key = dh.getDagId();

			dataSources.put(key, dh.getDataSource());
			if (i == 0) {
				dynamicDataSource.setDefaultTargetDataSource(dh.getDataSource());
			}
		}
		dynamicDataSource.setTargetDataSources(dataSources);
		dynamicDataSource.afterPropertiesSet();

	}

	@PostConstruct
	private void init() {
		initDatasourceRouter();

	}

	@Before
	public void before() {
		mockMVC = MockMvcBuilders.webAppContextSetup(wac).build();
		MockitoAnnotations.initMocks(this);
	}

//	@Test
	public void getPaymentInfoTest() throws Exception {

		Cookie[] cookies = new Cookie[3];

		/**
		 * userId:D0A7CEAF7E4044AD882FBDD79AD27861
		 */
		Cookie cookie1 = new Cookie("dagId", "001");
		Cookie cookie2 = new Cookie("token", "d44604d392924e5c924c649ab78d1c90");
		Cookie cookie3 = new Cookie("appType", "6");
		cookies[0] = cookie1;
		cookies[1] = cookie2;
		cookies[2] = cookie3;

		OrderVo order = paymentOrderClient.getOrderByOrderId("11059170010000061112");
		order.setCreatedTime(new Date());
		order.setStatus(10);
		paymentOrderClient.updateByPrimaryKeySelective(order);

		AliPaymentRequest aliPaymentRequest = new AliPaymentRequest();
		aliPaymentRequest.setBody("Test");
		aliPaymentRequest.setOrderId("11059170010000061112");
		aliPaymentRequest.setSubject("Test");
		String requestJson = JSONObject.toJSONString(aliPaymentRequest);
		String responseString = mockMVC
				.perform(MockMvcRequestBuilders.post("/payment/alipay/paymentparams")
						.contentType(MediaType.APPLICATION_JSON).cookie(cookies).content(requestJson))
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
		ResultBody resultBody = JSONObject.parseObject(responseString, ResultBody.class);
		Assert.assertTrue("", resultBody.getCode().equals("0"));

	}

}
