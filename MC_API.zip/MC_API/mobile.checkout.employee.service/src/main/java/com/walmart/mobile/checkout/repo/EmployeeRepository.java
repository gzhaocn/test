package com.walmart.mobile.checkout.repo;

import java.math.BigInteger;

import org.springframework.data.repository.CrudRepository;

import com.walmart.mobile.checkout.entity.Employee;

public interface EmployeeRepository extends CrudRepository<Employee, BigInteger> {
	Employee findByAccountNbr(String accountNbr);

	Employee findByBindingUserId(String userId);
}