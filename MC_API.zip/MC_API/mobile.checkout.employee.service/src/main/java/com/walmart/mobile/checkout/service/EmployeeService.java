package com.walmart.mobile.checkout.service;

import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.walmart.mobile.checkout.bo.DiscountCardParam;
import com.walmart.mobile.checkout.constant.EmployeeErrorInfoEnum;
import com.walmart.mobile.checkout.entity.Employee;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.repo.EmployeeRepository;
import com.walmart.mobile.checkout.utils.DateUtil;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;

	public Employee findByUserId(String userId) {
		if (StringUtils.isEmpty(userId)) {
			return null;
		}
		return employeeRepository.findByBindingUserId(userId);
	}

	public Employee findByAccountNbr(String accountNbr) {
		return employeeRepository.findByAccountNbr(accountNbr);
	}

	public void checkUserBind(Employee employee) throws GlobalErrorInfoException {
		if (employee != null) {
			throw new GlobalErrorInfoException(EmployeeErrorInfoEnum.USERT_ALREADY_EXIST_BIND);
		}
	}

	public void checkBind(DiscountCardParam discountCardParam, Employee employee) throws GlobalErrorInfoException {
		if (employee == null) {
			throw new GlobalErrorInfoException(EmployeeErrorInfoEnum.DISCOUNT_CARD_NOT_FOUND);
		}
		if (StringUtils.isNotEmpty(employee.getBindingUserId())) {
			throw new GlobalErrorInfoException(EmployeeErrorInfoEnum.DISCOUNT_CARD_ALREADY_EXIST);
		}
		if (!employee.getAccountNbr().equals(discountCardParam.getAccountNbr())
				|| !DateUtil.formateDate(employee.getBirthDate()).equals(discountCardParam.getBirthDate())
				|| !employee.getFirstName().equalsIgnoreCase(discountCardParam.getFirstName())
				|| !employee.getLastName().equalsIgnoreCase(discountCardParam.getLastName())) {
			throw new GlobalErrorInfoException(EmployeeErrorInfoEnum.VIFIFY_DISCOUNT_CARD_FAILED);
		}
	}

	public Integer getEmployeeDiscount(String userId) {
		Employee employee = findByUserId(userId);
		return employee == null ? null : employee.getDiscountPct().intValue();
	}
	
	public Employee getEmployeeCard(String userId) {
		return  findByUserId(userId);
	}

	public void bindDiscountCard(Employee employee, String userId) throws GlobalErrorInfoException {
		saveDiscountCard(employee, userId);
	}

	public void unbindDiscountCard(Employee employee) {
		saveDiscountCard(employee, null);
	}

	private void saveDiscountCard(Employee employee, String userId) {
		Date date = new Date();
		employee.setBindingTime(StringUtils.isEmpty(userId) ? null : date);
		employee.setBindingUserId(userId);
		employee.setUpdatedTime(date);
		employeeRepository.save(employee);
	}
}
