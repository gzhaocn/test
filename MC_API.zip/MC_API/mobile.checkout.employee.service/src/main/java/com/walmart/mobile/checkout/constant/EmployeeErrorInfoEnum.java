package com.walmart.mobile.checkout.constant;

import com.walmart.mobile.checkout.exception.handler.ErrorInfoInterface;

/**
 * 系统及业务级别的错误码
 */
public enum EmployeeErrorInfoEnum implements ErrorInfoInterface {
	USERT_ALREADY_EXIST_BIND("-1100", "已经绑定员工折扣卡"), DISCOUNT_CARD_NOT_EMPTY("-1101", "员工折扣卡验证字段为空"), DISCOUNT_CARD_NOT_FOUND("-1102",
			"员工卡未找到"), DISCOUNT_CARD_ALREADY_EXIST("-1103", "员工折扣卡已被绑定"), VIFIFY_DISCOUNT_CARD_FAILED("-1104", "员工折扣卡信息验证不通过");

	private String code;

	private String message;

	EmployeeErrorInfoEnum(String code, String message) {
		this.code = code;
		this.message = message;
	}

	@Override
	public String getCode() {
		return this.code;
	}

	@Override
	public String getMessage() {
		return this.message;
	}
}
