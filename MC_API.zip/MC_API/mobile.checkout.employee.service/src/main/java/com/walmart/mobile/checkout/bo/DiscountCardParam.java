package com.walmart.mobile.checkout.bo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "绑定员工折扣卡参数")
public class DiscountCardParam {

	@ApiModelProperty(value = "折扣卡号")
	private String accountNbr;
	@ApiModelProperty(value = "折扣卡上的姓")
	private String lastName;
	@ApiModelProperty(value = "折扣卡上的名")
	private String firstName;
	@ApiModelProperty(value = "员工生日,格式:2011-10-10")
	private String birthDate;

	public String getAccountNbr() {
		return accountNbr;
	}

	public void setAccountNbr(String accountNbr) {
		this.accountNbr = accountNbr;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
}
