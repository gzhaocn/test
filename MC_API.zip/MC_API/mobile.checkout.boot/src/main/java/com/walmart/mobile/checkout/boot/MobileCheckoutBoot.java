package com.walmart.mobile.checkout.boot;

import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.ApplicationContext;

import com.walmart.mobile.checkout.config.MainConfig;
import com.walmart.mobile.checkout.selector.CustomImportSelector;

import ch.qos.logback.core.joran.spi.JoranException;

public class MobileCheckoutBoot extends SpringBootServletInitializer {
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(getClasses());
	}

	public static void main(String[] args) throws JoranException {
		String ssl = new CustomImportSelector().getProperties().getProperty("sms.ssl");
		System.setProperty("javax.net.ssl.trustStore", ApplicationContext.class.getResource(ssl).getPath());
		new MobileCheckoutBoot().configure(new SpringApplicationBuilder()).run(args);
		
	}

	private Class<?>[] getClasses() {
		Class<?>[] clazzs = { MainConfig.class };
		return clazzs;
	}
}
