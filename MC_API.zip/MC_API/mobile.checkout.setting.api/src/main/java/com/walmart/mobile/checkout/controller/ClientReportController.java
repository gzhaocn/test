package com.walmart.mobile.checkout.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.walmart.mobile.checkout.annotation.PrivilegeInfo;
import com.walmart.mobile.checkout.constant.SettingErrorInfoEnum;
import com.walmart.mobile.checkout.entity.ClientReport;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.exception.handler.ResultBody;
import com.walmart.mobile.checkout.service.ClientReportService;
import com.walmart.mobile.checkout.service.DictionaryService;

@RestController
@RequestMapping("/client")
public class ClientReportController {

	private static final Logger LOGGER = LoggerFactory.getLogger(ClientReportController.class.getName());

	@Autowired
	private ClientReportService clientReportService;

	@Autowired
	private DictionaryService dictionaryService;

	@ApiOperation(value = "report", notes = "客户端日志上报接口")
	@RequestMapping(value = "/report", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	@ApiResponses({ @ApiResponse(code = -700, message = "日志列表为空") })
	public ResultBody report(@RequestBody List<ClientReport> clientReportList, HttpServletRequest request) throws GlobalErrorInfoException {
		if (clientReportList == null || clientReportList.isEmpty()) {
			throw new GlobalErrorInfoException(SettingErrorInfoEnum.LIST_IS_EMPTY);
		}
		clientReportService.saveClientReportList(clientReportList);
		return new ResultBody();
	}

	@ApiOperation(value = "checkVersion", notes = "检查apk版本接口")
	@RequestMapping(value = "/checkVersion", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody checkVersion(HttpServletRequest request) throws GlobalErrorInfoException {
		return new ResultBody(dictionaryService.findByTypeAndSubType("exitUpgradeConfig", "android"));
	}

	@ApiOperation(value = "checkMonitorVersion", notes = "检查monitor apk版本接口")
	@RequestMapping(value = "/checkMonitorVersion", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody checkMonitorVersion(HttpServletRequest request) throws GlobalErrorInfoException {
		return new ResultBody(dictionaryService.findByTypeAndSubType("monitorUpgradeConfig", "android"));
	}

	@ApiOperation(value = "burialPoint", notes = "客户端上报埋点数据")
	@RequestMapping(value = "/burialPoint", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	@PrivilegeInfo
	public ResultBody burialPoint(@RequestBody String burialPointJson, HttpServletRequest request) throws GlobalErrorInfoException {
		LOGGER.info("burialPointString : {}", burialPointJson);
		return new ResultBody();
	}

}
