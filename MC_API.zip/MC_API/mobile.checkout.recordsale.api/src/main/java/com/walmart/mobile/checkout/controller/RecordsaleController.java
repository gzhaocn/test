package com.walmart.mobile.checkout.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.walmart.mobile.checkout.bo.recordsale.RecordSaleReq;
import com.walmart.mobile.checkout.constant.recordsale.RecordSaleConstants;
import com.walmart.mobile.checkout.domain.order.Order;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.exception.handler.ResultBody;
import com.walmart.mobile.checkout.service.OrderService;
import com.walmart.mobile.checkout.service.refund.RefundService;
import com.walmart.mobile.checkout.utils.ThreadLocalContextHolder;

@Controller
@RequestMapping("recordsale")
public class RecordsaleController {
	private static final Logger LOGGER = LoggerFactory.getLogger(RecordsaleController.class.getName());

	@Value("${recordsale.resource.type}")
	private String resourceType;

	public static final int EGIFTCARD = 4;

	// 电子个人发票 Electronic personal invoice
	public static final int ELECTRONIC_PERSONAL_INVOICE = 3;

	// 电子单位发票
	public static final int ELECTRONIC_UNIT_INVOICE = 4;

	// 线下已开纸质发票
	public static final String INVOICE_OPENED = "-1";

	/**
	 * dagId在订单号规则中出现的开始位置，从此位置向后截取3位即为dagId.
	 */
	public static final int ORDER_ID_PATTERN_OF_DAG_ID_INDEX = 7;

	// storeId在订单号规则中出现的开始位置，从此位置向后截取4位即为storeId.
	public static final int ORDER_ID_PATTERN_OF_STORE_ID_INDEX = 1;

	@Autowired
	private OrderService orderService;

	@Autowired
	private RefundService refundService;

	@ApiOperation(value = "recordsale callback to update tc number", notes = "更新小票号")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -801, message = "更新小票号失败") })
	@RequestMapping(value = "/updateTcNumber", method = RequestMethod.POST)
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public ResultBody updateTcNumber(@RequestBody List<RecordSaleReq> recordSaleReqList, HttpServletRequest request) throws GlobalErrorInfoException {

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("updateTcNumber start");
		}
		ResultBody resultBody = new ResultBody();
		String orderId = null;
		try {
			for (RecordSaleReq recordSaleReq : recordSaleReqList) {
				// 时间偏移8小时
				Calendar ca = Calendar.getInstance();
				ca.setTime(recordSaleReq.getTransTime());
				ca.add(Calendar.HOUR_OF_DAY, -8);
				orderId = recordSaleReq.getOrderId();
				int result =  0 ;
				String dagId = orderId.substring(ORDER_ID_PATTERN_OF_DAG_ID_INDEX, ORDER_ID_PATTERN_OF_DAG_ID_INDEX + 3);
				ThreadLocalContextHolder.switchDataSoureByDagId(dagId);
				if (RecordSaleConstants.MOBILE_CHECKOUT_REVERSE_ORDER.equals(recordSaleReq.getRsOrderType())) {
					LOGGER.info("reverse tcnumber : {} ,batchNo : {}  ", recordSaleReq.getTcNumber(), orderId);
					 result = refundService.updateRefundReverseTcNumber(orderId, recordSaleReq.getTcNumber(), ca.getTime());
					LOGGER.info("reverse tcnumber : {} ,orderid : {} , update tcnumber result : {} ", recordSaleReq.getTcNumber(), orderId, result);
				} else {
					int count = 0 ;
					
					while(count  < 3){
						result = updateTcNumberResult(orderId, ca, recordSaleReq, count);
						if(result  == 1){
							break ;
						}
					}
					// 发送延迟修改订单状态,如果更新失败，返回给rcs失败的结果
					if (result != 1 ) {
						resultBody.setCode("-801");
						resultBody.setMessage("updateTcNumber fail, version is change");
					}
				}
				resultBody.setResult(orderId);
			}
		} catch (Exception e) {
			LOGGER.error("updateTcNumber error :  list : {}", recordSaleReqList, e);
			resultBody.setCode("-801");
			resultBody.setMessage(e.getMessage());
			resultBody.setResult(orderId);
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("updateTcNumber end");
		}
		return resultBody;

	}

	private int updateTcNumberResult(String orderId, Calendar ca , RecordSaleReq recordSaleReq , int count){
		
		Order order = orderService.getOrderByOrderId(orderId);
		count ++ ;
		int result =  0;
		try {
			result = orderService.updateTcNumber(orderId, ca.getTime(), recordSaleReq.getSequenceNumber(), recordSaleReq.getRegisterNumber(), recordSaleReq.getTcNumber(),
					order.getVersion());
		} catch (Exception e) {
			LOGGER.error("orderid {} update error , {} " ,orderId , e);
			result = 0 ;
		}
		LOGGER.info("tcnumber : {} ,orderid : {} , update tcnumber result : {} ,version :{} ", recordSaleReq.getTcNumber(), orderId, result, order.getVersion());
		return result ;
	}
}
