package com.walmart.mobile.checkout.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.walmart.mobile.checkout.bo.refund.RefundModifyParamter;
import com.walmart.mobile.checkout.constant.AppConstants;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.exception.handler.ResultBody;
import com.walmart.mobile.checkout.service.refund.RefundService;
import com.walmart.mobile.checkout.utils.ThreadLocalContextHolder;
import com.walmart.mobile.checkout.utils.order.OrderUtils;

@Controller
@RequestMapping("/refund")
public class RefundController {

	@Autowired
	private RefundService refundService;

	@ApiOperation(value = "updateRefundStatus", notes = "修改refund状态")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功") })
	@RequestMapping(value = "/updateRefundStatus", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody updateRefundStatus(HttpServletRequest request, @RequestBody RefundModifyParamter refundModifyParamter) throws GlobalErrorInfoException {
		refundService.refundCheckSum(refundModifyParamter);
		ThreadLocalContextHolder.put(AppConstants.DAGID, OrderUtils.getDagId(refundModifyParamter.getOrderId()));
		refundService.updateRefundAndOrderStatus(refundModifyParamter);
		return new ResultBody();
	}

}
