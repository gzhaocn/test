package com.walmart.mobile.checkout.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.walmart.mobile.checkout.entity.StoreShoppingBag;
import com.walmart.mobile.checkout.repo.StoreShoppingBagRepository;

@Service
public class StoreShoppingBagService {
	@Autowired
	private StoreShoppingBagRepository storeShoppingBagRepository;

	public List<StoreShoppingBag> getShoppingBagByStoreId(Integer storeId) {
		return storeShoppingBagRepository.findByStoreId(storeId);
	}
}
