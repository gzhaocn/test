package com.walmart.mobile.checkout.entity;

import java.math.BigInteger;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.walmart.mobile.checkout.entity.document.Base3AttrDocument;

@JsonInclude(Include.NON_NULL)
@Document(collection = "store_shopping_bag")
public class StoreShoppingBag extends Base3AttrDocument<BigInteger> {

	@Field("store_id")
	private Integer storeId;
	@Field("item_number")
	private Long itemNumber;
	@Field("upc")
	private Long upc;
	@Field("desc_online")
	private String descOnline;
	@Field("product_id")
	private Long productId;

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public String getDescOnline() {
		return descOnline;
	}

	public void setDescOnline(String descOnline) {
		this.descOnline = descOnline;
	}

	public Long getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(Long itemNumber) {
		this.itemNumber = itemNumber;
	}

	public Long getUpc() {
		return upc;
	}

	public void setUpc(Long upc) {
		this.upc = upc;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

}
