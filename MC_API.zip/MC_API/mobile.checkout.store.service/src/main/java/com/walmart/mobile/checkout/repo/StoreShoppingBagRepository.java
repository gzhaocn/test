package com.walmart.mobile.checkout.repo;

import java.math.BigInteger;
import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.walmart.mobile.checkout.entity.StoreShoppingBag;

/**
 * 
 * @author Feixuhui
 */
public interface StoreShoppingBagRepository extends CrudRepository<StoreShoppingBag, BigInteger> {

	List<StoreShoppingBag> findByStoreId(Integer storeId);

}
