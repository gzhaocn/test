package com.walmart.mobile.checkout.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.walmart.mobile.checkout.entity.Store;
import com.walmart.mobile.checkout.repo.StoreRepository;

@Service
public class StoreService {
	@Autowired
	private StoreRepository storeRepository;

	public Iterable<Store> findByStatusIn(List<Integer> statusList) {
		return storeRepository.findByStatusIn(statusList);
	}

	public Store findByStoreId(Integer storeId) {
		return storeRepository.findByStoreId(storeId);
	}
}
