package controller;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;


public class StoreControllerTest extends BaseControllerTest {

	@Test
	public void getStoreTest() throws Exception {
		String restUrl = "/stores";
		response = mockMVC.perform(MockMvcRequestBuilders.get(restUrl).characterEncoding("utf-8")).andExpect(MockMvcResultMatchers.status().isOk()).andReturn().getResponse();
		String result = response.getContentAsString();
		Assert.assertNotNull(result);
	}

	@Test
	public void getStoreVersionTest() throws Exception {
		String restUrl = "/stores/version";
		response = mockMVC.perform(MockMvcRequestBuilders.post(restUrl).characterEncoding("utf-8")).andExpect(MockMvcResultMatchers.status().isOk()).andReturn().getResponse();
		String result = response.getContentAsString();
		Assert.assertNotNull(result);
	}

	// @Test
	// public void getCitiesTest() throws Exception {
	// String restUrl = "/cities/normal";
	// response =
	// mockMVC.perform(MockMvcRequestBuilders.get(restUrl).characterEncoding("utf-8")).andExpect(MockMvcResultMatchers.status().isOk()).andReturn().getResponse();
	// String result = response.getContentAsString();
	// Assert.assertNotNull(result);
	// }
	//
	// @Test
	// public void getCitiesVersionTest() throws Exception {
	// String restUrl = "/cities/version";
	// response =
	// mockMVC.perform(MockMvcRequestBuilders.post(restUrl).characterEncoding("utf-8")).andExpect(MockMvcResultMatchers.status().isOk()).andReturn().getResponse();
	// String result = response.getContentAsString();
	// Assert.assertNotNull(result);
	// }

}
