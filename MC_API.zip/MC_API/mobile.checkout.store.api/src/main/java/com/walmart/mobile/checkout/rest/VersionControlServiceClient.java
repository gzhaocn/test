package com.walmart.mobile.checkout.rest;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.walmart.mobile.checkout.bo.VersionControl;

@FeignClient("versionControlService")
public interface VersionControlServiceClient {

	@RequestMapping(method = RequestMethod.GET, value = "/findOne")
	VersionControl findOne(@RequestParam(value = "id") String id);

}