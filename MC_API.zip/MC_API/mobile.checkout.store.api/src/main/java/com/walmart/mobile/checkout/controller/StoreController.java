package com.walmart.mobile.checkout.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.bo.VersionControl;
import com.walmart.mobile.checkout.entity.Store;
import com.walmart.mobile.checkout.exception.handler.ResultBody;
import com.walmart.mobile.checkout.rest.VersionControlServiceClient;
import com.walmart.mobile.checkout.service.StoreService;

@Controller
public class StoreController {
	@Autowired
	private VersionControlServiceClient versionControlService;

	@Autowired
	private StoreService storeService;

	@ApiOperation(value = "get all stores ", notes = "查询所有的门店")
	@RequestMapping(value = "stores", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody getStores(HttpServletRequest request) {
		VersionControl version = versionControlService.findOne("storeVersionAll");
		JSONObject resultBody = new JSONObject();
		resultBody.put("data", storeService.findByStatusIn(Arrays.asList(Store.STATUS_OPEN)));
		resultBody.put("dataVersion", version.getVersion());
		return new ResultBody(resultBody);
	}

	@ApiOperation(value = "Get version about stores in a city", notes = "查询所有的门店的版本号")
	@RequestMapping(value = "stores/version", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody getStoreVersion(HttpServletRequest request) {
		return new ResultBody(versionControlService.findOne("storeVersionAll"));
	}

	@ApiOperation(value = "Get deliveryCoverage3km", notes = "查询门店的配送区域")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -801, message = " 门店不存在") })
	@RequestMapping(value = "stores/deliveryCoverage3km/{storeId}", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody getDeliveryCoverage3km(@PathVariable(value = "storeId") Integer storeId, HttpServletRequest request) {
		Store store = storeService.findByStoreId(storeId);
		if (store == null || CollectionUtils.isEmpty(store.getDeliveryCoverage3km())) {
			return new ResultBody(null, "-801", "store's deliveryCoverage3km is not exist!");
		} else {
			return new ResultBody(store.getDeliveryCoverage3km());
		}
	}

}
