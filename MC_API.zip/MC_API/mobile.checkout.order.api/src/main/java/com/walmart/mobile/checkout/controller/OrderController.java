package com.walmart.mobile.checkout.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.walmart.mobile.checkout.annotation.PrivilegeInfo;
import com.walmart.mobile.checkout.bo.order.OrderBo;
import com.walmart.mobile.checkout.bo.order.OrderCancelParameter;
import com.walmart.mobile.checkout.bo.order.OrderCreateResult;
import com.walmart.mobile.checkout.bo.order.OrderInformation;
import com.walmart.mobile.checkout.bo.order.OrderInvoiceInfoParamter;
import com.walmart.mobile.checkout.bo.order.OrderListQueryParameter;
import com.walmart.mobile.checkout.bo.order.OrderParameter;
import com.walmart.mobile.checkout.bo.order.OrderRejectItem;
import com.walmart.mobile.checkout.bo.order.OrderRejectItemParameter;
import com.walmart.mobile.checkout.bo.order.QueryOrderRecordSalesParamter;
import com.walmart.mobile.checkout.constant.AppConstants;
import com.walmart.mobile.checkout.constant.GlobalErrorInfoEnum;
import com.walmart.mobile.checkout.constant.order.InvoiceCons;
import com.walmart.mobile.checkout.constant.order.OrderCons;
import com.walmart.mobile.checkout.constant.order.OrderErrorInfoEnum;
import com.walmart.mobile.checkout.domain.order.Order;
import com.walmart.mobile.checkout.domain.order.OrderLine;
import com.walmart.mobile.checkout.domain.refund.Refund;
import com.walmart.mobile.checkout.entity.Store;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.exception.handler.ResultBody;
import com.walmart.mobile.checkout.handler.send.InvoiceSendHandler;
import com.walmart.mobile.checkout.rest.order.DeliveryServiceClient;
import com.walmart.mobile.checkout.rest.order.UserCreditInfoClient;
import com.walmart.mobile.checkout.service.OrderService;
import com.walmart.mobile.checkout.service.OrderValidationService;
import com.walmart.mobile.checkout.service.StoreService;
import com.walmart.mobile.checkout.service.invoice.InvoiceService;
import com.walmart.mobile.checkout.service.refund.RefundService;
import com.walmart.mobile.checkout.utils.ThreadLocalContextHolder;
import com.walmart.mobile.checkout.utils.order.OrderUtils;

@Controller
@RequestMapping("/orders")
public class OrderController {
	@Autowired
	private OrderValidationService orderValidationService;
	@Autowired
	private OrderService orderService;
	@Autowired
	private InvoiceService invoiceService;
	@Autowired
	private StoreService storeService;
	@Autowired
	private InvoiceSendHandler invoiceSendHandler;
	@Autowired
	RefundService refundService;
	@Autowired
	DeliveryServiceClient deliveryServiceClient;
	@Autowired
	UserCreditInfoClient userCreditInfoClient;

	private static final Logger LOG = LoggerFactory.getLogger(OrderController.class);

	@ApiOperation(value = "createOrder", notes = "创建订单")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -200, message = "GP数据不存在"), @ApiResponse(code = -201, message = "product数据不存在"),
			@ApiResponse(code = -2, message = "没有权限"), @ApiResponse(code = -203, message = "订单amount不一致"), @ApiResponse(code = -204, message = "discount不一致"),
			@ApiResponse(code = -205, message = "缺货"), @ApiResponse(code = -206, message = "商品gp改变"), @ApiResponse(code = -207, message = "商品价格改变"), @ApiResponse(code = -208, message = "库存短缺"),
			@ApiResponse(code = -209, message = "客户端与服务端gpDiscount不一致"), @ApiResponse(code = -210, message = "gp group超过一个"), @ApiResponse(code = -211, message = "称重商品价格与条码不一致"),
			@ApiResponse(code = -218, message = "超过限购数量"), @ApiResponse(code = -222, message = "orderParamter不能为空"), @ApiResponse(code = -223, message = "orderlines不能为空"),
			@ApiResponse(code = -224, message = "延保信息不存在"), @ApiResponse(code = -227, message = "商品数量不能为0和负数"), @ApiResponse(code = -260, message = "order amount不能为空"),
			@ApiResponse(code = -261, message = "客户端与服务端延保价格不一致"), @ApiResponse(code = -262, message = "延保信息发生改变"), @ApiResponse(code = -273, message = "运费不一致"),
			@ApiResponse(code = -274, message = "部分商品不能配送"), @ApiResponse(code = -275, message = "选择商品配送时，配送地址和运费商品信息不能为空"), @ApiResponse(code = -276, message = "选择商品配送时,运费阀值不能为空"),
			@ApiResponse(code = -277, message = "运费大于0时,运费商品信息不能为空"), @ApiResponse(code = -278, message = "没有选择商品配送时,填了运费商品") })
	@PrivilegeInfo
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody createOrder(HttpServletRequest request, @RequestBody OrderParameter orderParameter) throws GlobalErrorInfoException {
		String dagId = ThreadLocalContextHolder.get(AppConstants.DAGID, String.class);
		String mobilePhone = ThreadLocalContextHolder.get(AppConstants.MOBILE_PHONE, String.class);
		orderParameter.setUserId(ThreadLocalContextHolder.getUserId());
		orderParameter.setDagId(dagId);
		orderParameter.setMobilePhone(mobilePhone);

		orderValidationService.checkOrderParameter(orderParameter);
		orderValidationService.prepareValidateHandler(orderParameter);
		orderValidationService.prepareEwsOrderLineList(orderParameter);
		orderValidationService.verify(orderParameter);
		orderValidationService.prepareShippingFeeItem(orderParameter);

		OrderCreateResult createOrderResult = orderService.create(orderParameter);
		orderService.sendOrderDeliveryMessage(createOrderResult, orderParameter);
		return new ResultBody(new OrderCreateResult(createOrderResult.getOrderId(), createOrderResult.getOrderDate()));
	}

	/**
	 * 分页查询订单列表
	 * 
	 * @param {"start": 0,"row": 20}
	 * @return
	 * @throws GlobalErrorInfoException
	 * @throws IOException
	 */
	@ApiOperation(value = "queryOrderListV2", notes = "查询订单列表")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -214, message = "用户找不到该订单信息") })
	@PrivilegeInfo
	@RequestMapping(value = "/list/v2", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody queryOrderListV2(HttpServletRequest request, @RequestBody OrderListQueryParameter orderListQueryParameter) throws GlobalErrorInfoException {

		String userId = ThreadLocalContextHolder.getUserId();

		List<OrderBo> orderList = orderService.getOrderListByPaginationV2(orderListQueryParameter.getStart(), orderListQueryParameter.getRow(), userId);
		if (orderList == null) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDER_NOT_EXIST);
		}
		return new ResultBody(orderList);
	}

	/**
	 * 分页查询订单列表
	 * 
	 * @param {"start": 0,"row": 20}
	 * @return
	 * @throws GlobalErrorInfoException
	 * @throws IOException
	 */
	@ApiOperation(value = "queryOrderList", notes = "查询订单列表(前端v2版本发布一段时间后，准备删除)")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -214, message = "用户找不到该订单信息") })
	@PrivilegeInfo
	@RequestMapping(value = "/list", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody queryOrderList(HttpServletRequest request, @RequestBody OrderListQueryParameter orderListQueryParameter) throws GlobalErrorInfoException {

		String userId = ThreadLocalContextHolder.getUserId();

		List<OrderBo> orderList = orderService.getOrderListByPagination(orderListQueryParameter.getStart(), orderListQueryParameter.getRow(), userId);
		if (orderList == null) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDER_NOT_EXIST);
		}
		return new ResultBody(orderList);
	}

	/**
	 * 查询订单信息
	 * 
	 * @param
	 * @return
	 * @throws GlobalErrorInfoException
	 * @throws IOException
	 */
	@ApiOperation(value = "queryOrder", notes = "查询订单列表_job使用")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -214, message = "用户找不到该订单信息"), @ApiResponse(code = -215, message = "checkSum不通过"),
			@ApiResponse(code = -225, message = "checksum加密失败"), })
	@RequestMapping(value = "/queryOrderInformation", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody queryOrderInformation(HttpServletRequest request, @RequestBody QueryOrderRecordSalesParamter queryOrderRecordSalesParamter) throws GlobalErrorInfoException {
		/**
		 * 加密校验
		 */

		orderValidationService.queryOrderInformationCheckSum(queryOrderRecordSalesParamter.getAppKey(), queryOrderRecordSalesParamter.getVersion(), queryOrderRecordSalesParamter.getFormat(),
				queryOrderRecordSalesParamter.getTimeStamp(), queryOrderRecordSalesParamter.getOrderId(), queryOrderRecordSalesParamter.getSign());

		ThreadLocalContextHolder.put(AppConstants.DAGID, OrderUtils.getDagId(queryOrderRecordSalesParamter.getOrderId()));
		Order order = orderService.getOrderByOrderId(queryOrderRecordSalesParamter.getOrderId());
		if (order == null) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDER_NOT_EXIST);
		}
		/**
		 * Integer status = order.getStatus(); if (order.getStatus() ==
		 * OrderStatus.PAID) { orderService.updateStatusByOrder(order); status =
		 * OrderStatus.COMPLETE; }
		 */
		return new ResultBody(new OrderInformation(order.getStatus(), order.getTcNumber()));
	}

	/**
	 * 过机后修改订单状态
	 * 
	 * @param
	 * @return
	 * @throws GlobalErrorInfoException
	 * @throws IOException
	 */
	@ApiOperation(value = "recordSalesOrderToComplete", notes = "支付订单修改状态到完成，没有扫描出场使用")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -214, message = "用户找不到该订单信息"), @ApiResponse(code = -215, message = "checkSum不通过"),
			@ApiResponse(code = -225, message = "checksum加密失败"), })
	@RequestMapping(value = "/recordSalesOrderToComplete", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody recordSalesOrderToComplete(HttpServletRequest request, @RequestBody QueryOrderRecordSalesParamter queryOrderRecordSalesParamter) throws GlobalErrorInfoException {
		/**
		 * 加密校验
		 */
		orderValidationService.queryOrderInformationCheckSum(queryOrderRecordSalesParamter.getAppKey(), queryOrderRecordSalesParamter.getVersion(), queryOrderRecordSalesParamter.getFormat(),
				queryOrderRecordSalesParamter.getTimeStamp(), queryOrderRecordSalesParamter.getOrderId(), queryOrderRecordSalesParamter.getSign());

		ThreadLocalContextHolder.put(AppConstants.DAGID, OrderUtils.getDagId(queryOrderRecordSalesParamter.getOrderId()));
		/**
		 * Order order =
		 * orderService.getOrderByOrderId(queryOrderRecordSalesParamter
		 * .getOrderId());
		 */
		String orderId = queryOrderRecordSalesParamter.getOrderId();
		OrderBo order = orderService.requestOrderDetailByUserIdAndOrderIdForPassMachine(null, orderId);
		if (order == null) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDER_NOT_EXIST);
		}
		orderService.updateStatusByOrder(order);

		// 0 不需要1纸质发票 3电子个人发票 4电子单位发票
		if ((InvoiceCons.ELECTRONIC_PERSONAL_INVOICE == order.getInvoiceType() || InvoiceCons.ELECTRONIC_UNIT_INVOICE == order.getInvoiceType()) && order.getPayType() != InvoiceCons.EGIFTCARD) {
			if (InvoiceCons.INVOICE_OPENED.equals(order.getInvoiceNo())) {
				LOG.info("invoice has been opened or tcNumber is null , orderId : {}", orderId);
			} else {
				List<Refund> refundList = refundService.getOrderRefundList(order.getOrderId());
				String invoiceMessage = invoiceService.sendInvoiceInfo(order, InvoiceCons.NEED_REPLACE_APPLYKEY,
						StringUtils.isBlank(order.getTcNumber()) ? InvoiceCons.TC_NUMBER_NULL : order.getTcNumber(), refundList);
				invoiceSendHandler.invoiceSendMessage(invoiceMessage);
				LOG.info("send invoice mq message : {}", invoiceMessage);
			}
		}

		return new ResultBody();
	}

	/**
	 * 查看某一个订单的详情
	 * 
	 * @param id
	 * @param request
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	@ApiOperation(value = "getOrderDetails", notes = "查询订单详情")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -214, message = "用户找不到该订单信息") })
	@PrivilegeInfo
	@RequestMapping(value = "/{orderId}", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody getOrderDetails(@PathVariable(value = "orderId") String orderId, HttpServletRequest request) throws GlobalErrorInfoException {
		String userId = ThreadLocalContextHolder.getUserId();
		OrderBo order = orderService.requestOrderDetailByUserIdAndOrderId(userId, orderId);
		if (order == null) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDER_NOT_EXIST);
		}
		return new ResultBody(order);
	}

	/**
	 * 未支付订单取消
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@ApiOperation(value = "orderCancel", notes = "未支付订单取消")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -212, message = "订单状态不允许转换"), @ApiResponse(code = -214, message = "用户找不到该订单信息"),
			@ApiResponse(code = -2, message = "用户没有该订单权限"), @ApiResponse(code = -216, message = "orderId必须传值") })
	@PrivilegeInfo
	@RequestMapping(value = "/cancel", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody orderCancel(HttpServletRequest request, @RequestBody OrderCancelParameter orderCancelParameter) throws GlobalErrorInfoException {
		String userId = ThreadLocalContextHolder.getUserId();

		if (StringUtils.isBlank(orderCancelParameter.getOrderId())) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDERID_IS_BLANK);
		}
		Order order = orderService.selectOrderByUserIdAndOrderId(userId, orderCancelParameter.getOrderId());
		if (order == null) {
			throw new GlobalErrorInfoException(GlobalErrorInfoEnum.USER_UNAUTHORIZED);
		}
		orderService.unPaidCancel(order, orderCancelParameter.getCancelReason());
		/**
		 * 运单状态设置为取消
		 */
		if (order.getDeliveryFlag() != null && order.getDeliveryFlag() == 1) {
			boolean flag = deliveryServiceClient.cancelDelivery(order.getOrderId());
			LOG.info("deliveryServiceClient cancelDelivery function  orderId is {},flag is {}", order.getOrderId(), flag);
		}
		return new ResultBody();
	}

	/**
	 * 生成发票
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@ApiOperation(value = "generateInvoice", notes = "生成发票")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -216, message = "订单ID不能为空"), @ApiResponse(code = -2, message = "用户没有该订单权限"),
			@ApiResponse(code = -250, message = "过机未完成,不能生成发票"), @ApiResponse(code = -228, message = "已开纸质发票"), @ApiResponse(code = -251, message = "支付方式为礼品卡,不能生成发票"),
			@ApiResponse(code = -254, message = "门店不支持电子发票"), @ApiResponse(code = -256, message = "所有商品已退货，不能开发票"), @ApiResponse(code = -257, message = "有商品在申请退货，不能开发票"),
			@ApiResponse(code = -270, message = "订单状态为支付取消中和支付取消的订单不允许申请") })
	@PrivilegeInfo
	@RequestMapping(value = "/generateInvoice", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody generateInvoice(HttpServletRequest request, @RequestBody OrderInvoiceInfoParamter orderInvoiceInfoParamter) throws GlobalErrorInfoException {
		String userId = ThreadLocalContextHolder.getUserId();

		if (StringUtils.isBlank(orderInvoiceInfoParamter.getOrderId())) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ORDERID_IS_BLANK);
		}
		OrderBo order = orderService.requestOrderDetailByUserIdAndOrderIdForPassMachine(userId, orderInvoiceInfoParamter.getOrderId());
		orderValidationService.generateInvoiceVerify(order);

		/**
		 * 判断门店是否支持电子发票
		 */
		Store store = storeService.findByStoreId(order.getStoreId());
		if (store.geteInvoiceFlag() != OrderCons.SUPPORT_EINVOICE_FLAG) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.STORE_NOT_SUPPOERT_E_INVOICE);
		}

		List<Refund> refundList = refundService.getOrderRefundList(order.getOrderId());
		if (CollectionUtils.isNotEmpty(refundList)) {
			Refund refund = refundList.stream().filter(x -> x.getRefundStatus() == 0).findAny().orElse(null);
			if (refund != null) {
				throw new GlobalErrorInfoException(OrderErrorInfoEnum.SOME_ITEM_IS_APPLY_REFUND);
			}
		}

		order.setInvoiceTitle(orderInvoiceInfoParamter.getInvoiceTitle());
		order.setInvoiceType(orderInvoiceInfoParamter.getInvoiceType());
		order.setTaxCode(orderInvoiceInfoParamter.getTaxCode());
		order.setInvoiceEmail(orderInvoiceInfoParamter.getInvoiceEmail());
		String invoiceMessage = invoiceService.sendInvoiceInfo(order, OrderCons.NEED_REPLACE_APPLYKEY, order.getTcNumber(), refundList);
		if (StringUtils.isBlank(invoiceMessage)) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.ALL_ITEM_HAS_REFUND);
		}

		orderService.updateByPrimaryKeySelective(order);

		invoiceSendHandler.invoiceSendMessage(invoiceMessage);

		return new ResultBody();
	}

	/**
	 * 退货申请
	 * 
	 * @param id
	 * @param request
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	@PrivilegeInfo
	@ApiOperation(value = "rejectItemApply", notes = "退货申请")
	@ApiResponses({ @ApiResponse(response = ResultBody.class, code = 0, message = "成功"), @ApiResponse(code = -263, message = "退货列表不能为空"), @ApiResponse(code = -214, message = "订单不存在"),
			@ApiResponse(code = -264, message = "超过订单退货期限"), @ApiResponse(code = -265, message = "退货商品数量不能为0"), @ApiResponse(code = -266, message = "退货商品数量超过订单商品数量"),
			@ApiResponse(code = -270, message = "订单状态为支付取消中和支付取消的订单不允许退货申请"), @ApiResponse(code = -271, message = "当前状态的订单不允许申请退货") })
	@RequestMapping(value = "/rejectItemApply", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResultBody rejectItemApply(HttpServletRequest request, @RequestBody OrderRejectItem orderRejectItem) throws GlobalErrorInfoException {

		List<OrderRejectItemParameter> rejectItemList = orderRejectItem.getOrderRejectItemParameterList();
		if (CollectionUtils.isEmpty(rejectItemList)) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.REJECT_ITEM_LIST_IS_EMPTY);
		}
		String orderId = orderRejectItem.getOrderId();
		Order order = orderService.getOrderByOrderId(orderId);
		List<OrderLine> orderLineList = orderService.selectOrderLineListByOrderId(orderId);
		OrderLine orderLine = orderLineList.stream().filter(x -> x.getReturnBy() != null).findAny().orElse(null);
		Date returnBy = orderLine.getReturnBy();

		orderValidationService.rejectItemApplyVerify(order, returnBy);
		BigDecimal refundedAmount = refundService.selectRequestAmount(order.getOrderId());
		BigDecimal orderAmount = orderService.calcOrderAmount(order);
		LOG.info("the refundedAmount is {} ,orderAmount is {} ", refundedAmount, orderAmount);
		List<Refund> refundList = refundService.rejectItemApply(orderRejectItem, rejectItemList, order, refundedAmount, orderAmount);
		refundService.insertBatchRefund(refundList);
		return new ResultBody();
	}
}
