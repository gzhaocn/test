package orderController;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.servlet.http.Cookie;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;

import com.alibaba.druid.util.StringUtils;
import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.bo.order.DeliveryParameter;
import com.walmart.mobile.checkout.bo.order.OrderCancelParameter;
import com.walmart.mobile.checkout.bo.order.OrderLineParameter;
import com.walmart.mobile.checkout.bo.order.OrderListQueryParameter;
import com.walmart.mobile.checkout.bo.order.OrderParameter;
import com.walmart.mobile.checkout.bo.order.ShippingFeeItemParameter;
import com.walmart.mobile.checkout.config.MainConfig;
import com.walmart.mobile.checkout.constant.order.OrderStatus;
import com.walmart.mobile.checkout.dag.DagHost;
import com.walmart.mobile.checkout.dag.HostData;
import com.walmart.mobile.checkout.datasource.DynamicDataSource;
import com.walmart.mobile.checkout.domain.order.Order;
import com.walmart.mobile.checkout.domain.route.Route;
import com.walmart.mobile.checkout.exception.handler.ResultBody;
import com.walmart.mobile.checkout.service.OrderService;
import com.walmart.mobile.checkout.service.UserService;
import com.walmart.mobile.checkout.utils.ThreadLocalContextHolder;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { MainConfig.class })
public class OrderControllerTest {
	protected MockHttpServletResponse response;

	protected MockMvc mockMVC;

	@Autowired
	private WebApplicationContext wac;

	@Autowired
	private OrderService orderService;

	@Autowired
	private UserService userService;

	@Autowired
	@Qualifier("userDynamicDataSource")
	public DynamicDataSource userDynamicDataSource;

	@Autowired
	@Qualifier("dynamicDataSource")
	public DynamicDataSource dynamicDataSource;

	@Value("${ddr.request.param}")
	private String ddrParam;

	@Value("${ddr.request.url}")
	private String ddrUrl;

	@Autowired
	private RestTemplate restTemplate;

	// private String dagId;

	private void initDatasourceRouter() {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<>(ddrParam, headers);
		String result = restTemplate.postForObject(ddrUrl, entity, String.class);
		List<DagHost> dss = JSONObject.parseObject(result, HostData.class).getData();
		Map<Object, Object> dataSources = new HashMap<>(16);
		for (int i = 0; i < dss.size(); i++) {
			DagHost dh = dss.get(i);
			String key = dh.getDagId();
			dataSources.put(key, dh.getDataSource());
		}
		dynamicDataSource.setTargetDataSources(dataSources);
		dynamicDataSource.afterPropertiesSet();

	}

	private void initUserDatasourceRouter() {

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<>(ddrParam, headers);
		String result = restTemplate.postForObject(ddrUrl, entity, String.class);
		DagHost.triggerUserDag(true);
		List<DagHost> dss = JSONObject.parseObject(result, HostData.class).getData();
		Map<Object, Object> dataSources = new HashMap<>(16);
		for (int i = 0; i < dss.size(); i++) {
			DagHost dh = dss.get(i);
			String key = dh.getDagId();
			dataSources.put(key, dh.getDataSource());
		}
		userDynamicDataSource.setTargetDataSources(dataSources);
		userDynamicDataSource.afterPropertiesSet();
		DagHost.triggerUserDag(false);
	}

	@PostConstruct
	private void init() {
		initUserDatasourceRouter();
		initDatasourceRouter();
	}

	@Before
	/*
	 * @Transactional(value = "userDynamicSqlServerTransactionManager")
	 * 
	 * @Rollback(true)
	 */
	public void before() throws Exception {
		mockMVC = MockMvcBuilders.webAppContextSetup(wac).build();
		MockitoAnnotations.initMocks(this);
		/*
		 * String token = orderCreateTest4();
		 * ThreadLocalContextHolder.put("token", token);
		 */
	}

	// @Test
	public void queryOrderListTest() throws Exception {
		String restUrl = "/orders/list";
		Cookie[] cookies = new Cookie[3];
		/**
		 * userId:D0A7CEAF7E4044AD882FBDD79AD27861
		 */
		Cookie cookie1 = new Cookie("dagId", "001");
		Cookie cookie2 = new Cookie("token", "d44604d392924e5c924c649ab78d1c90");
		Cookie cookie3 = new Cookie("appType", "6");
		cookies[0] = cookie1;
		cookies[1] = cookie2;
		cookies[2] = cookie3;

		OrderListQueryParameter orderListQueryParameter = new OrderListQueryParameter();
		orderListQueryParameter.setRow(10);
		orderListQueryParameter.setStart(0);
		// 。。。设置值
		String requestJson = JSONObject.toJSONString(orderListQueryParameter);
		String responseString = mockMVC.perform(MockMvcRequestBuilders.post(restUrl).contentType(MediaType.APPLICATION_JSON).cookie(cookies).content(requestJson))// .andDo(print())
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();

		ResultBody resultBody = JSONObject.parseObject(responseString, ResultBody.class);
		Assert.assertTrue("", resultBody.getCode().equals("0"));

	}

	// @Test
	public void getOrderDetailsTest() throws Exception {
		String restUrl1 = "/orders/11059170010000061112";
		Cookie[] cookies = new Cookie[3];
		/**
		 * userId:D0A7CEAF7E4044AD882FBDD79AD27861
		 */
		Cookie cookie1 = new Cookie("dagId", "001");
		Cookie cookie2 = new Cookie("token", "d44604d392924e5c924c649ab78d1c90");
		Cookie cookie3 = new Cookie("appType", "6");
		cookies[0] = cookie1;
		cookies[1] = cookie2;
		cookies[2] = cookie3;

		String responseString = mockMVC.perform(MockMvcRequestBuilders.post(restUrl1).contentType(MediaType.APPLICATION_JSON).cookie(cookies))// .andDo(print())
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();

		ResultBody resultBody = JSONObject.parseObject(responseString, ResultBody.class);
		Assert.assertTrue("", resultBody.getCode().equals("0"));

	}

	// @Test
	public void orderCancelTest() throws Exception {

		ThreadLocalContextHolder.put("dagId", "001");
		Order order = orderService.getOrderByOrderId("11059170010000061112");
		order.setStatus(OrderStatus.UNPAID);
		orderService.updateByPrimaryKeySelective(order);

		String restUrl2 = "/orders/cancel";
		Cookie[] cookies = new Cookie[3];
		/**
		 * userId:D0A7CEAF7E4044AD882FBDD79AD27861
		 */
		Cookie cookie1 = new Cookie("dagId", "001");
		Cookie cookie2 = new Cookie("token", "d44604d392924e5c924c649ab78d1c90");
		Cookie cookie3 = new Cookie("appType", "6");
		cookies[0] = cookie1;
		cookies[1] = cookie2;
		cookies[2] = cookie3;

		OrderCancelParameter orderCancelParameter = new OrderCancelParameter();
		orderCancelParameter.setOrderId("11059170010000061112");
		orderCancelParameter.setCancelReason(0);

		// 。。。设置值
		String requestJson = JSONObject.toJSONString(orderCancelParameter);
		String responseString = mockMVC.perform(MockMvcRequestBuilders.post(restUrl2).contentType(MediaType.APPLICATION_JSON).cookie(cookies).content(requestJson))// .andDo(print())
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();

		ResultBody resultBody = JSONObject.parseObject(responseString, ResultBody.class);
		Assert.assertTrue("", resultBody.getCode().equals("0"));

		order = orderService.getOrderByOrderId("11059170010000061112");
		order.setStatus(OrderStatus.UNPAID);
		orderService.updateByPrimaryKeySelective(order);

	}

	// @Test
	public void orderCancelTest2() throws Exception {
		String restUrl2 = "/orders/cancel";
		Cookie[] cookies = new Cookie[3];
		/**
		 * userId:D0A7CEAF7E4044AD882FBDD79AD27861
		 */
		Cookie cookie1 = new Cookie("dagId", "001");
		Cookie cookie2 = new Cookie("token", "d44604d392924e5c924c649ab78d1c90");
		Cookie cookie3 = new Cookie("appType", "6");
		cookies[0] = cookie1;
		cookies[1] = cookie2;
		cookies[2] = cookie3;

		OrderCancelParameter orderCancelParameter = new OrderCancelParameter();
		orderCancelParameter.setOrderId("110591700100000611123");
		orderCancelParameter.setCancelReason(0);

		// 。。。设置值
		String requestJson = JSONObject.toJSONString(orderCancelParameter);
		String responseString = mockMVC.perform(MockMvcRequestBuilders.post(restUrl2).contentType(MediaType.APPLICATION_JSON).cookie(cookies).content(requestJson))// .andDo(print())
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();

		ResultBody resultBody = JSONObject.parseObject(responseString, ResultBody.class);
		Assert.assertTrue("", resultBody.getCode().equals("-2"));

	}

	// @Test
	public void orderCancelTest3() throws Exception {
		String restUrl2 = "/orders/cancel";
		Cookie[] cookies = new Cookie[3];
		/**
		 * userId:D0A7CEAF7E4044AD882FBDD79AD27861
		 */
		Cookie cookie1 = new Cookie("dagId", "001");
		Cookie cookie2 = new Cookie("token", "d44604d392924e5c924c649ab78d1c90");
		Cookie cookie3 = new Cookie("appType", "6");
		cookies[0] = cookie1;
		cookies[1] = cookie2;
		cookies[2] = cookie3;

		OrderCancelParameter orderCancelParameter = new OrderCancelParameter();
		// orderCancelParameter.setOrderId("110591700100000611123");
		orderCancelParameter.setCancelReason(0);

		// 。。。设置值
		String requestJson = JSONObject.toJSONString(orderCancelParameter);
		String responseString = mockMVC.perform(MockMvcRequestBuilders.post(restUrl2).contentType(MediaType.APPLICATION_JSON).cookie(cookies).content(requestJson))// .andDo(print())
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();

		ResultBody resultBody = JSONObject.parseObject(responseString, ResultBody.class);
		Assert.assertTrue("", resultBody.getCode().equals("-216"));

	}

	@Test
	public void orderCreateTest() throws Exception {

		String restUrl3 = "/orders/create";
		Cookie[] cookies = new Cookie[3];
		Cookie cookie1 = new Cookie("dagId", "001");
		Cookie cookie2 = new Cookie("token", "b522ebdba1a948deaa4711ce4d889362");
		// Cookie cookie2 = new Cookie("token",
		// ThreadLocalContextHolder.get("token", String.class));
		Cookie cookie3 = new Cookie("appType", "6");
		cookies[0] = cookie1;
		cookies[1] = cookie2;
		cookies[2] = cookie3;

		OrderParameter orderParameter = new OrderParameter();
		orderParameter.setOrderType(2);
		orderParameter.setShortNameCn("香蜜湖店");

		List<OrderLineParameter> orderLines = new ArrayList<>();
		OrderLineParameter orderLineParameter = new OrderLineParameter();
		orderLineParameter.setItemType(0);
		orderLineParameter.setProductId(3000000539912L);
		orderLineParameter.setPriceWithTax(new BigDecimal("9.9"));
		orderLineParameter.setOrderWeight(BigDecimal.ZERO);
		orderLineParameter.setDescOnline("test");
		orderLineParameter.setOrderQuantity(1);

		orderLineParameter.setBarCode(806614L);
		orderLineParameter.setGpOffers(null);
		orderLineParameter.setGpDiscount(BigDecimal.ZERO);
		orderLineParameter.setItemAmount(BigDecimal.ZERO);
		orderLineParameter.setCartItemId(1L);
		orderLineParameter.setThumbnailUrl("");
		orderLines.add(orderLineParameter);

		orderParameter.setOrderLines(orderLines);
		orderParameter.setInvoiceType(0);
		orderParameter.setTotalGpDiscount(BigDecimal.ZERO);
		orderParameter.setInvoiceTitle("");
		orderParameter.setAmount(new BigDecimal("9.9"));
		orderParameter.setStoreId(9999);
		orderParameter.setShippingFee(BigDecimal.ZERO);
		orderParameter.setPackagingFee(BigDecimal.ZERO);

		// 。。。设置值
		String requestJson = JSONObject.toJSONString(orderParameter);
		String responseString = mockMVC.perform(MockMvcRequestBuilders.post(restUrl3).contentType(MediaType.APPLICATION_JSON).cookie(cookies).content(requestJson))// .andDo(print())
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();

		ResultBody resultBody = JSONObject.parseObject(responseString, ResultBody.class);
//		Assert.assertTrue("", resultBody.getCode().equals("0"));

	}

	@Test
	public void orderCreateTest2() throws Exception {

		String restUrl3 = "/orders/create";
		Cookie[] cookies = new Cookie[3];
		Cookie cookie1 = new Cookie("dagId", "001");
		Cookie cookie2 = new Cookie("token", "b522ebdba1a948deaa4711ce4d889362");
		// Cookie cookie2 = new Cookie("token",
		// ThreadLocalContextHolder.get("token", String.class));
		Cookie cookie3 = new Cookie("appType", "6");
		cookies[0] = cookie1;
		cookies[1] = cookie2;
		cookies[2] = cookie3;

		OrderParameter orderParameter = new OrderParameter();
		orderParameter.setOrderType(2);
		orderParameter.setShortNameCn("香蜜湖店");
		orderParameter.setPackagingFee(new BigDecimal("0"));
		// orderParameter.setShippingFee(new BigDecimal("65"));
		orderParameter.setShippingFee(new BigDecimal("0"));
		List<OrderLineParameter> orderLines = new ArrayList<>();
		OrderLineParameter orderLineParameter = new OrderLineParameter();
		orderLineParameter.setItemType(0);
		orderLineParameter.setProductId(3000000539912L);
		orderLineParameter.setPriceWithTax(new BigDecimal("9.9"));
		orderLineParameter.setOrderWeight(BigDecimal.ZERO);
		orderLineParameter.setDescOnline("test");
		orderLineParameter.setOrderQuantity(40);
		orderLineParameter.setDeliveryFlag(1);
		orderLineParameter.setDeliveryRequestQuantity(5);

		orderLineParameter.setBarCode(806614L);
		orderLineParameter.setGpOffers(null);
		orderLineParameter.setGpDiscount(BigDecimal.ZERO);
		orderLineParameter.setItemAmount(BigDecimal.ZERO);
		orderLineParameter.setCartItemId(1L);
		orderLineParameter.setThumbnailUrl("");
		orderLines.add(orderLineParameter);

		orderParameter.setOrderLines(orderLines);
		orderParameter.setInvoiceType(0);
		orderParameter.setTotalGpDiscount(BigDecimal.ZERO);
		orderParameter.setInvoiceTitle("");
		orderParameter.setAmount(new BigDecimal("396"));
		orderParameter.setStoreId(9999);
		orderParameter.setPackagingFee(BigDecimal.ZERO);

		/*
		 * ShippingFeeItemParameter shippingFeeItemLine = new
		 * ShippingFeeItemParameter(); shippingFeeItemLine.setCartItemId(1L);
		 * shippingFeeItemLine.setOrderQuantity(1);
		 * shippingFeeItemLine.setPriceWithTax(new BigDecimal("65"));
		 * shippingFeeItemLine.setProductId(31007929830002L);
		 * shippingFeeItemLine.setUpc(7929830002L);
		 * orderParameter.setShippingFeeItemLine(shippingFeeItemLine);
		 */

		DeliveryParameter delivery = new DeliveryParameter();
		delivery.setAddress("test");
		delivery.setCity("sz");
		delivery.setDeliveryDate(new Date());
		delivery.setDeliveryInstruction("remark");
		delivery.setDeliveryName("test2");
		delivery.setDeliveryPhone("13424323255");
		delivery.setDistrict("bt");
		delivery.setLatitude(12d);
		delivery.setLongitude(13d);
		delivery.setZipcode("825463");
		orderParameter.setDelivery(delivery);

		// 。。。设置值
		String requestJson = JSONObject.toJSONString(orderParameter);
		String responseString = mockMVC.perform(MockMvcRequestBuilders.post(restUrl3).contentType(MediaType.APPLICATION_JSON).cookie(cookies).content(requestJson))// .andDo(print())
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();

		ResultBody resultBody = JSONObject.parseObject(responseString, ResultBody.class);
//		Assert.assertTrue("", resultBody.getCode().equals("0"));

	}

	@Test
	public void orderCreateTest3() throws Exception {

		String restUrl3 = "/orders/create";
		Cookie[] cookies = new Cookie[3];
		Cookie cookie1 = new Cookie("dagId", "001");
		Cookie cookie2 = new Cookie("token", "b522ebdba1a948deaa4711ce4d889362");
		// Cookie cookie2 = new Cookie("token",
		// ThreadLocalContextHolder.get("token", String.class));
		Cookie cookie3 = new Cookie("appType", "6");
		cookies[0] = cookie1;
		cookies[1] = cookie2;
		cookies[2] = cookie3;

		OrderParameter orderParameter = new OrderParameter();
		orderParameter.setOrderType(2);
		orderParameter.setShortNameCn("香蜜湖店");
		orderParameter.setPackagingFee(new BigDecimal("0"));
		orderParameter.setShippingFee(new BigDecimal("65"));
		// orderParameter.setShippingFee(new BigDecimal("0"));
		List<OrderLineParameter> orderLines = new ArrayList<>();
		OrderLineParameter orderLineParameter = new OrderLineParameter();
		orderLineParameter.setItemType(0);
		orderLineParameter.setProductId(3000000539912L);
		orderLineParameter.setPriceWithTax(new BigDecimal("9.9"));
		orderLineParameter.setOrderWeight(BigDecimal.ZERO);
		orderLineParameter.setDescOnline("test");
		orderLineParameter.setOrderQuantity(10);
		orderLineParameter.setDeliveryFlag(1);
		orderLineParameter.setDeliveryRequestQuantity(5);

		orderLineParameter.setBarCode(806614L);
		orderLineParameter.setGpOffers(null);
		orderLineParameter.setGpDiscount(BigDecimal.ZERO);
		orderLineParameter.setItemAmount(BigDecimal.ZERO);
		orderLineParameter.setCartItemId(1L);
		orderLineParameter.setThumbnailUrl("");
		orderLines.add(orderLineParameter);

		orderParameter.setOrderLines(orderLines);
		orderParameter.setInvoiceType(0);
		orderParameter.setTotalGpDiscount(BigDecimal.ZERO);
		orderParameter.setInvoiceTitle("");
		orderParameter.setAmount(new BigDecimal("164"));
		orderParameter.setStoreId(9999);
		orderParameter.setPackagingFee(BigDecimal.ZERO);

		ShippingFeeItemParameter shippingFeeItemLine = new ShippingFeeItemParameter();
		shippingFeeItemLine.setCartItemId(1L);
		shippingFeeItemLine.setOrderQuantity(1);
		shippingFeeItemLine.setPriceWithTax(new BigDecimal("65"));
		shippingFeeItemLine.setProductId(31007929830002L);
		shippingFeeItemLine.setUpc(7929830002L);
		orderParameter.setShippingFeeItemLine(shippingFeeItemLine);

		DeliveryParameter delivery = new DeliveryParameter();
		delivery.setAddress("test");
		delivery.setCity("sz");
		delivery.setDeliveryDate(new Date());
		delivery.setDeliveryInstruction("remark");
		delivery.setDeliveryName("test2");
		delivery.setDeliveryPhone("13424323255");
		delivery.setDistrict("bt");
		delivery.setLatitude(12d);
		delivery.setLongitude(13d);
		delivery.setZipcode("825463");
		orderParameter.setDelivery(delivery);

		// 。。。设置值
		String requestJson = JSONObject.toJSONString(orderParameter);
		String responseString = mockMVC.perform(MockMvcRequestBuilders.post(restUrl3).contentType(MediaType.APPLICATION_JSON).cookie(cookies).content(requestJson))// .andDo(print())
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();

		ResultBody resultBody = JSONObject.parseObject(responseString, ResultBody.class);
//		Assert.assertTrue("", resultBody.getCode().equals("0"));

	}

	public String orderCreateTest4() throws Exception {
		ThreadLocalContextHolder.put("dagId", "001");
		Route openIdRoute = new Route();
		openIdRoute.setUserId("testmock");
		openIdRoute.setDagId("001");
		String tokencookie = userService.createUserInfo(openIdRoute, "testopenId", "13424323255", "test");
		return (StringUtils.subString(tokencookie, "token=", ";dagId="));

	}

}
