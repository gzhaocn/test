package com.walmart.mobile.checkout.service.promotion;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;

import com.walmart.mobile.checkout.bo.promotion.GpCartItem;
import com.walmart.mobile.checkout.entity.promotion.GpOffer;
import com.walmart.mobile.checkout.entity.promotion.Group;
import com.walmart.mobile.checkout.entity.promotion.TieredDiscount;
import com.walmart.mobile.checkout.repo.GpOfferRepository;

/*@RunWith(SpringJUnit4ClassRunner.class)
 @WebAppConfiguration
 @ContextConfiguration(classes = { MainConfig.class })*/
public class GlobalPromotionServiceTest {

	@Autowired
	GpOfferRepository gpOfferRepository;

	@Autowired
	PromotionService promotionService;

	public List<GpOffer> initGpOfferData() throws ParseException {

		List<GpOffer> gpOfferList = new ArrayList<>();

		// 构建GpOffer 对象
		// 0 买立减 非多组

		GpOffer gpOffer00 = new GpOffer();
		gpOffer00.setGpOfferId(1100000);
		gpOffer00.setGpTypeCode(0);
		gpOffer00.setBeginDate(new SimpleDateFormat("yyyy-MM-dd").parse("2015-07-13"));
		gpOffer00.setEndDate(new SimpleDateFormat("yyyy-MM-dd").parse("2015-10-13"));
		gpOffer00.setDiscountFactor(5.0f);
		gpOffer00.setStatus(0);
		List<Group> groups00 = new ArrayList<Group>();
		Group group00 = new Group();
		group00.setGroupSeq(1);
		group00.setThresholdQty(2);
		groups00.add(group00);
		gpOffer00.setGroups(groups00);
		gpOffer00.setPromotionDescEn("");
		gpOffer00.setPromotionDescCn("购买参加本活动的任意商品每满2件立减5元");

		gpOfferList.add(gpOffer00);

		// 5 满立减 单组
		GpOffer gpOffer50 = new GpOffer();
		gpOffer50.setGpOfferId(1100050);
		gpOffer50.setGpTypeCode(105);
		gpOffer50.setBeginDate(new SimpleDateFormat("yyyy-MM-dd").parse("2015-07-13"));
		gpOffer50.setEndDate(new SimpleDateFormat("yyyy-MM-dd").parse("2015-10-13"));
		gpOffer50.setDiscountFactor(5.0f);
		gpOffer50.setStatus(0);
		List<Group> groups50 = new ArrayList<Group>();
		Group group50 = new Group();
		group50.setGroupSeq(1);
		group50.setThresholdQty(100);
		groups50.add(group50);
		gpOffer50.setGroups(groups50);
		gpOffer50.setPromotionDescEn("");
		gpOffer50.setPromotionDescCn("购买参加本活动的任意商品每满100元立减5元");

		gpOfferList.add(gpOffer50);

		// 0 买立减 多组
		GpOffer gpOffer01 = new GpOffer();
		gpOffer01.setGpOfferId(1100001);
		gpOffer01.setGpTypeCode(0);
		gpOffer01.setBeginDate(new SimpleDateFormat("yyyy-MM-dd").parse("2015-07-13"));
		gpOffer01.setEndDate(new SimpleDateFormat("yyyy-MM-dd").parse("2015-10-13"));
		gpOffer01.setDiscountFactor(200.0f);
		gpOffer01.setStatus(0);
		List<Group> groups01 = new ArrayList<Group>();
		Group group01 = new Group();
		group01.setGroupSeq(1);
		group01.setThresholdQty(1);
		groups01.add(group01);

		Group group02 = new Group();
		group02.setGroupSeq(2);
		group02.setThresholdQty(1);
		groups01.add(group02);

		gpOffer01.setGroups(groups01);
		gpOffer01.setPromotionDescEn("");
		gpOffer01.setPromotionDescCn("购买参加本活动任意商品满1组减200元（2件为1组:需包含第1类任意1件，第2类任意1件）");

		gpOfferList.add(gpOffer01);

		// 1-折扣
		GpOffer gpOffer10 = new GpOffer();
		gpOffer10.setGpOfferId(1100010);
		gpOffer10.setGpTypeCode(1);
		gpOffer10.setBeginDate(new SimpleDateFormat("yyyy-MM-dd").parse("2015-07-13"));
		gpOffer10.setEndDate(new SimpleDateFormat("yyyy-MM-dd").parse("2015-10-13"));
		gpOffer10.setDiscountFactor(12.0f);
		gpOffer10.setStatus(0);
		List<Group> groups10 = new ArrayList<Group>();
		Group group10 = new Group();
		group10.setGroupSeq(1);
		group10.setThresholdQty(2);
		groups10.add(group10);
		gpOffer10.setGroups(groups10);
		gpOffer10.setPromotionDescEn("");
		gpOffer10.setPromotionDescCn("购买参加本活动的任意商品2件及以上享8.8折");

		gpOfferList.add(gpOffer10);

		// 2-阶梯式现金返还,买更多减更多
		GpOffer gpOffer20 = new GpOffer();
		gpOffer20.setGpOfferId(1100020);
		gpOffer20.setGpTypeCode(2);
		gpOffer20.setBeginDate(new SimpleDateFormat("yyyy-MM-dd").parse("2015-07-13"));
		gpOffer20.setEndDate(new SimpleDateFormat("yyyy-MM-dd").parse("2015-10-13"));
		gpOffer20.setDiscountFactor(0.0f); // 阶梯式不使用
		gpOffer20.setStatus(0);
		List<Group> groups20 = new ArrayList<Group>();
		Group group20 = new Group();
		group20.setGroupSeq(1);
		group20.setThresholdQty(0); // 阶梯式不使用

		// 构造阶梯式参数设置
		List<TieredDiscount> tieredDiscountList20 = new ArrayList<TieredDiscount>();
		TieredDiscount tieredDisoucnt200 = new TieredDiscount();
		tieredDisoucnt200.setThresholdQty(2);
		tieredDisoucnt200.setDiscountFactor(new BigDecimal("5.0"));
		TieredDiscount tieredDisoucnt201 = new TieredDiscount();
		tieredDisoucnt201.setThresholdQty(5);
		tieredDisoucnt201.setDiscountFactor(new BigDecimal("15.0"));
		tieredDiscountList20.add(tieredDisoucnt200);
		tieredDiscountList20.add(tieredDisoucnt201);

		group20.setTieredDiscount(tieredDiscountList20);

		groups20.add(group20);
		gpOffer20.setGroups(groups20);
		gpOffer20.setPromotionDescEn("");
		gpOffer20.setPromotionDescCn("购买参加本活动的任意商品满2件立减5元;满5件立减15元");

		gpOfferList.add(gpOffer20);

		// 2-阶梯式满立减,买更多减更多
		GpOffer gpOffer60 = new GpOffer();
		gpOffer60.setGpOfferId(1100060);
		gpOffer60.setGpTypeCode(106);
		gpOffer60.setBeginDate(new SimpleDateFormat("yyyy-MM-dd").parse("2015-07-13"));
		gpOffer60.setEndDate(new SimpleDateFormat("yyyy-MM-dd").parse("2015-10-13"));
		gpOffer60.setDiscountFactor(0.0f); // 阶梯式不使用
		gpOffer60.setStatus(0);
		List<Group> groups60 = new ArrayList<Group>();
		Group group60 = new Group();
		group60.setGroupSeq(1);
		group60.setThresholdQty(0); // 阶梯式不使用
		group60.setThresholdAmt(new BigDecimal("10"));

		// 构造阶梯式参数设置
		List<TieredDiscount> tieredDiscountList60 = new ArrayList<TieredDiscount>();
		TieredDiscount tieredDisoucnt600 = new TieredDiscount();
		tieredDisoucnt600.setThresholdQty(100);
		tieredDisoucnt600.setThresholdAmt(new BigDecimal("100"));
		tieredDisoucnt600.setDiscountFactor(new BigDecimal("5.0"));
		TieredDiscount tieredDisoucnt601 = new TieredDiscount();
		tieredDisoucnt601.setThresholdQty(150);
		tieredDisoucnt601.setThresholdAmt(new BigDecimal("150"));
		tieredDisoucnt601.setDiscountFactor(new BigDecimal("15.0"));
		tieredDiscountList60.add(tieredDisoucnt600);
		tieredDiscountList60.add(tieredDisoucnt601);
		tieredDisoucnt600.setThresholdAmt(new BigDecimal("150.0"));

		group60.setTieredDiscount(tieredDiscountList60);

		groups60.add(group60);
		gpOffer60.setGroups(groups60);
		gpOffer60.setPromotionDescEn("");
		gpOffer60.setPromotionDescCn("购买参加本活动的任意商品满100元立减5元;满150元立减15元");

		gpOfferList.add(gpOffer60);

		// 3 阶梯式折扣,买更多折更多
		GpOffer gpOffer30 = new GpOffer();
		gpOffer30.setGpOfferId(1100030);
		gpOffer30.setGpTypeCode(3);
		gpOffer30.setBeginDate(new SimpleDateFormat("yyyy-MM-dd").parse("2015-07-13"));
		gpOffer30.setEndDate(new SimpleDateFormat("yyyy-MM-dd").parse("2015-10-13"));
		gpOffer30.setDiscountFactor(0.0f); // 阶梯式不用
		gpOffer30.setStatus(0);
		List<Group> groups30 = new ArrayList<Group>();
		Group group30 = new Group();
		group30.setGroupSeq(1);
		group30.setThresholdQty(0); // 阶梯式不用

		// 构造阶梯式参数设置
		List<TieredDiscount> tieredDiscountList30 = new ArrayList<TieredDiscount>();
		TieredDiscount tieredDisoucnt300 = new TieredDiscount();
		tieredDisoucnt300.setThresholdQty(2);
		tieredDisoucnt300.setDiscountFactor(new BigDecimal("5.0"));
		TieredDiscount tieredDisoucnt301 = new TieredDiscount();
		tieredDisoucnt301.setThresholdQty(5);
		tieredDisoucnt301.setDiscountFactor(new BigDecimal("15.0"));
		tieredDiscountList30.add(tieredDisoucnt300);
		tieredDiscountList30.add(tieredDisoucnt301);
		group30.setTieredDiscount(tieredDiscountList30);

		groups30.add(group30);
		gpOffer30.setGroups(groups30);
		gpOffer30.setPromotionDescEn("");
		gpOffer30.setPromotionDescCn("购买参加本活动的任意商品满2件立享95折;满5件立享85折");

		gpOfferList.add(gpOffer30);

		// 4 固定价格优惠,以N价格买X
		GpOffer gpOffer40 = new GpOffer();
		gpOffer40.setGpOfferId(1100040);
		gpOffer40.setGpTypeCode(4);
		gpOffer40.setBeginDate(new SimpleDateFormat("yyyy-MM-dd").parse("2015-07-13"));
		gpOffer40.setEndDate(new SimpleDateFormat("yyyy-MM-dd").parse("2015-10-13"));
		gpOffer40.setDiscountFactor(15.0f);
		gpOffer40.setStatus(0);
		List<Group> groups40 = new ArrayList<Group>();
		Group group40 = new Group();
		group40.setGroupSeq(1);
		group40.setThresholdQty(2);
		groups40.add(group40);
		gpOffer40.setGroups(groups40);
		gpOffer40.setPromotionDescEn("");
		gpOffer40.setPromotionDescCn("参与本活动的商品任选2件仅需15元");

		gpOfferList.add(gpOffer40);

		gpOfferList = (List<GpOffer>) gpOfferRepository.save(gpOfferList);
		return gpOfferList;
	}

	// @Before
	public void setUp() throws ParseException, InterruptedException {
		initGpOfferData();
		Thread.sleep(2000L);
	}

	// @Test
	public void testcalcDiscount() throws ParseException {

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;

		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// *** 0-买立减
		// *** 买X达到规定个数立减N元
		// *** 买X和Y立减N元
		// *** 1.X可以是同一商品或不同商品
		// *** 2.可以设定不同的商品组
		// *** 可以多倍折扣(买X减N，买2X减2N)
		// *** 可多组（X+Y减N，买2X+4Y减2N）
		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// 0-买立减
		// 购买参加本活动的任意商品每满2件立减5元
		// gpOfferId 为 1000000
		// 单组,不满足条件,1件商品
		items.clear();
		items.add(new GpCartItem(1000000000001L, 1L, 1, new BigDecimal("20.00"), 1100000, 1, new BigDecimal("0.0"), 1000000000001L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("0.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// 0-买立减
		// 购买参加本活动的任意商品每满2件立减5元
		// gpOfferId 为 1000000
		// 单组, 满足条件 , 单倍, 2件商品
		items.clear();
		items.add(new GpCartItem(1000000000001L, 1L, 2, new BigDecimal("20.00"), 1100000, 1, new BigDecimal("5.0"), 1000000000001L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("5.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// 0-买立减
		// 购买参加本活动的任意商品每满2件立减5元
		// gpOfferId 为 1000000
		// 单组,满足条件, 多倍, 5件 商品
		items.clear();
		items.add(new GpCartItem(1000000000001L, 1L, 5, new BigDecimal("20.00"), 1100000, 1, new BigDecimal("10.0"), 1000000000001L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("10.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// 0-买立减
		// 购买参加本活动任意商品满1组减200元（2件为1组:需包含第1类任意1件，第2类任意1件）
		// gpOfferId 为 1000001
		// 多组,不满足条件, 单倍 , 1件商品X和0件商品Y
		items.clear();
		items.add(new GpCartItem(1000000000002L, 2L, 1, new BigDecimal("250.0"), 1100001, 1, new BigDecimal("0.0"), 1000000000002L));
		// items.add(new GpCartItem(101L,0, new BigDecimal("220.0"),1000001,2));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("0.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// 0-买立减
		// 购买参加本活动任意商品满1组减200元（2件为1组:需包含第1类任意1件，第2类任意1件）
		// gpOfferId 为 1000001
		// 多组,不满足条件, 单倍 , 0件商品X和1件商品Y
		items.clear();
		items.add(new GpCartItem(1000000000003L, 3L, 1, new BigDecimal("220.0"), 1100001, 2, new BigDecimal("0.0"), 1000000000003L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("0.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// 0-买立减 // 购买参加本活动任意商品满1组减200元（2件为1组:需包含第1类任意1件，第2类任意1件） // gpOfferId 为
		// 1000001 // 多组,满足条件, 单倍 , X和Y各 1 件 items.clear();
		items.clear();
		items.add(new GpCartItem(1000000000002L, 2L, 1, new BigDecimal("250.0"), 1100001, 1, new BigDecimal("106.38"), 1000000000002L));
		items.add(new GpCartItem(1000000000003L, 3L, 1, new BigDecimal("220.0"), 1100001, 2, new BigDecimal("93.62"), 1000000000003L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("200.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// 0-买立减
		// 购买参加本活动任意商品满1组减200元（2件为1组:需包含第1类任意1件，第2类任意1件）
		// gpOfferId 为 1000001
		// 多组,满足条件, 多倍, 3X+2Y (3件X,2件Y)
		items.clear();
		items.add(new GpCartItem(1000000000002L, 2L, 3, new BigDecimal("250.0"), 1100001, 1, new BigDecimal("252.10"), 1000000000002L));
		items.add(new GpCartItem(1000000000003L, 3L, 2, new BigDecimal("220.0"), 1100001, 2, new BigDecimal("147.90"), 1000000000003L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("400.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// *** 1-折扣
		// *** 买X得N%折扣
		// *** 1.X可以是同一商品或不同商品
		// *** 2.只可建立一个商品组
		// *** 3.只能设定享受优惠的最低商品购买个数，只要满足最低要求，就能享受规定折扣
		// *** 不可多倍折扣
		// *** 不可多组（否则POS计算错误）
		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// 1-折扣 // 购买参加本活动的任意商品2件及以上享8.8折 // gpOfferId 为 1000010 // 单组,不满条件,
		// 1件商品
		items.clear();
		items.add(new GpCartItem(1000000000005L, 5L, 1, new BigDecimal("150"), 1100010, 1, new BigDecimal("0.0"), 1000000000005L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("0.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// 1-折扣 // 购买参加本活动的任意商品2件及以上享8.8折 // gpOfferId 为 1000010 // 单组,满足条件,单倍,
		// 2件商品
		items.clear();
		items.add(new GpCartItem(1000000000005L, 5L, 2, new BigDecimal("150"), 1100010, 1, new BigDecimal("36.0"), 1000000000005L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("36.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// 1-折扣 // 购买参加本活动的任意商品2件及以上享8.8折 // gpOfferId 为 1000010 // 单组,满足条件 ,多倍,
		// 5件商品
		items.clear();
		items.add(new GpCartItem(1000000000005L, 5L, 5, new BigDecimal("150"), 1100010, 1, new BigDecimal("90.0"), 1000000000005L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("90.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// *** 2-阶梯式现金返还
		// *** 买更多减更多
		// *** 买X达到规定个数立减N元
		// *** (立减金额随着商品数量的增加而增加)
		// *** 1. X可以是同一商品或不同商品
		// *** 2. 阶梯最多不超过四级
		// *** 3.设置时需要清楚界定每一级别的商品数量规定
		// *** 不可多倍折扣
		// *** 不可多组（否则POS计算错误）
		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++

		// 2-阶梯式现金返还 // 购买参加本活动的任意商品满2件立减5元;满5件立减15元 // gpOfferId 为 1000020
		// 单组, 不满足条件, 1件商品
		items.clear();
		items.add(new GpCartItem(1000000000006L, 6L, 1, new BigDecimal("99"), 1100020, 1, new BigDecimal("0.0"), 1000000000006L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("0.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// 2-阶梯式现金返还 // 购买参加本活动的任意商品满2件立减5元;满5件立减15元 // gpOfferId 为 1000020
		// 单组 , 满足一级阶梯条件, 2件商口
		items.clear();
		items.add(new GpCartItem(1000000000006L, 6L, 2, new BigDecimal("99"), 1100020, 1, new BigDecimal("5.0"), 1000000000006L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("5.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");
		// 2-阶梯式现金返还 // 购买参加本活动的任意商品满2件立减5元;满5件立减15元 // gpOfferId 为 1000020
		// 单组, 满足1级阶梯倍数,但不满足2级阶梯, 4件商品
		items.clear();
		items.add(new GpCartItem(1000000000006L, 6L, 4, new BigDecimal("99"), 1100020, 1, new BigDecimal("5.0"), 1000000000006L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("5.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// 2-阶梯式现金返还 // 购买参加本活动的任意商品满2件立减5元;满5件立减15元 // gpOfferId 为 1000020
		// 单组, 满足2级阶梯, 5件商品
		items.clear();
		items.add(new GpCartItem(1000000000006L, 6L, 5, new BigDecimal("99"), 1100020, 1, new BigDecimal("15.0"), 1000000000006L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("15.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// 2-阶梯式现金返还 // 购买参加本活动的任意商品满2件立减5元;满5件立减15元 // gpOfferId 为 1000020
		// 单组, 满足1,2级阶梯公倍数, 10件商品
		items.clear();
		items.add(new GpCartItem(1000000000006L, 6L, 10, new BigDecimal("99"), 1100020, 1, new BigDecimal("15.0"), 1000000000006L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("15.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// 2-阶梯式现金返还 // 购买参加本活动的任意商品满2件立减5元;满5件立减15元 // gpOfferId 为 1000020
		// 单组 , 满足2级阶梯倍数,不满足1级阶梯倍数, 15件商品
		items.clear();
		items.add(new GpCartItem(1000000000006L, 6L, 15, new BigDecimal("99"), 1100020, 1, new BigDecimal("15.0"), 1000000000006L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("15.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// *** 3-阶梯式折扣
		// *** 买更多折更多
		// *** 买X得N%折
		// *** (折扣随着商品数量的增加而增加)
		// *** 1.X可以是同一商品或不同商品
		// *** 2.阶梯最多不超过四级
		// *** 3.设置时需要清楚界定每一阶梯享受优惠的最低商品购买个数，只要满足最低要求，就能享受规定折扣
		// *** 不可多倍折扣
		// *** 不可多组（否则POS计算错误）
		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++

		// 3-阶梯式折扣 // 购买参加本活动的任意商品满2件立享95折;满5件立享85折 // gpOfferId 为 1000030 //
		// 单组, 不满足优惠条件, 1件商品
		items.clear();
		items.add(new GpCartItem(1000000000008L, 8L, 1, new BigDecimal("100"), 1100030, 1, new BigDecimal("0.0"), 1000000000008L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("0.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// 3-阶梯式折扣 // 购买参加本活动的任意商品满2件立享95折;满5件立享85折 // gpOfferId 为 1000030 //
		// 单组, 满足1级阶梯条件, 不满足2级阶梯阶梯条件, 2件商品 (2*100*0.05)
		items.clear();
		items.add(new GpCartItem(1000000000008L, 8L, 2, new BigDecimal("100"), 1100030, 1, new BigDecimal("10.0"), 1000000000008L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("10.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// 3-阶梯式折扣 // 购买参加本活动的任意商品满2件立享95折;满5件立享85折 // gpOfferId 为 1000030 //
		// 单组, 满足阶梯条件1的倍数, 不满足阶梯条件2,4件商品 (4*100*0.05)
		items.clear();
		items.add(new GpCartItem(1000000000008L, 8L, 4, new BigDecimal("100"), 1100030, 1, new BigDecimal("20.0"), 1000000000008L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("20.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// 3-阶梯式折扣 // 购买参加本活动的任意商品满2件立享95折;满5件立享85折 // gpOfferId 为 1000030 //
		// 单组, 不满足阶梯条件1的倍数, 满足阶梯条件2, 5件商品 (5*100*0.15)
		items.clear();
		items.add(new GpCartItem(1000000000008L, 8L, 5, new BigDecimal("100"), 1100030, 1, new BigDecimal("75.0"), 1000000000008L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("75.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// 3-阶梯式折扣 // 购买参加本活动的任意商品满2件立享95折;满5件立享85折 // gpOfferId 为 1000030 //
		// 单组, 满足1,2级阶梯公倍数, 10件商品 (10*100*0.15)
		items.clear();
		items.add(new GpCartItem(1000000000008L, 8L, 10, new BigDecimal("100"), 1100030, 1, new BigDecimal("150.0"), 1000000000008L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("150.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// 3-阶梯式折扣 // 购买参加本活动的任意商品满2件立享95折;满5件立享85折 // gpOfferId 为 1000030 //
		// 单组, 满足2级阶梯倍数,不满足1级阶梯倍数, 15件商品 (15*100*0.15)
		items.clear();
		items.add(new GpCartItem(1000000000008L, 8L, 15, new BigDecimal("100"), 1100030, 1, new BigDecimal("225.0"), 1000000000008L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("225.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// *** 4-固定价格优惠
		// *** 以N价格买X
		// *** 1. X可以是同一商品或不同商品
		// *** 2. 只可建立一个商品组
		// *** 2. 任意商品单价*规定商品的个数 > N价格
		// ***
		// 3.如果X为不同的商品而且零售价不同，而顾客购买的数量超过指定的数量且小于折扣再次发生的条件时，则系统会选取指定数量中单价较高的商品进行折扣。
		// *** 4.如果门店进行竞价，且竞价之后商品组合价格低于促销价格，则促销不能发生
		// *** 可以多倍折扣(买X价格N，买2X价格2N)
		// *** 不可多组（否则POS计算错误）
		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// 4-固定价格优惠
		// 参与本活动的商品任选2件仅需15元
		// gpOfferId 为 1000040
		// 单组, 不满足条件,1件商品
		items.clear();
		items.add(new GpCartItem(1000000000010L, 10L, 1, new BigDecimal("10"), 1100040, 1, new BigDecimal("0.0"), 1000000000010L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("0.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// 4-固定价格优惠 // 参与本活动的商品任选2件仅需15元 // gpOfferId 为 1000040 // 单组,
		// 满足单倍条件,2件商品
		items.clear();
		items.add(new GpCartItem(1000000000010L, 10L, 2, new BigDecimal("10"), 1100040, 1, new BigDecimal("5.0"), 1000000000010L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("5.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// 4-固定价格优惠 // 参与本活动的商品任选2件仅需15元 // gpOfferId 为 1000040 // 单组,
		// 满足多倍条件,5件商品
		items.clear();
		items.add(new GpCartItem(1000000000010L, 10L, 5, new BigDecimal("10"), 1100040, 1, new BigDecimal("10.0"), 1000000000010L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("10.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// *** 0-满立减
		// *** 买X达到规定个数立减N元
		// *** 1.X可以是同一商品或不同商品
		// *** 可以多倍折扣(买X减N，买2X减2N)
		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// 0-满立减
		// 购买参加本活动的任意商品每满100元立减5元
		// gpOfferId 为 1000050
		// 单组,不满足条件,1件商品
		items.clear();
		items.add(new GpCartItem(1000000000001L, 1L, 1, new BigDecimal("55.00"), 1100050, 1, new BigDecimal("0.0"), 1000000000001L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("0.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");
		// Assert.isTrue(deviation < 0.01);

		// 0-满立减
		// 购买参加本活动的任意商品每满2件立减5元
		// gpOfferId 为 1000000
		// 单组, 满足条件 , 单倍, 2件商品
		items.clear();
		items.add(new GpCartItem(1000000000001L, 1L, 2, new BigDecimal("55.00"), 1100000, 1, new BigDecimal("5.0"), 1000000000001L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("5.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// 0-满立减
		// 购买参加本活动的任意商品每满2件立减5元
		// gpOfferId 为 1000000
		// 单组,满足条件, 多倍, 5件 商品
		items.clear();
		items.add(new GpCartItem(1000000000001L, 1L, 5, new BigDecimal("55.00"), 1100000, 1, new BigDecimal("10.0"), 1000000000001L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("10.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// *** 2-阶梯式满立减
		// *** 买更多减更多
		// *** 买X达到规定金额立减N元
		// *** (立减金额随着商品总价的增加而增加)
		// *** 1. X可以是同一商品或不同商品
		// *** 2. 阶梯最多不超过四级
		// *** 3.设置时需要清楚界定每一级别的商品数量规定
		// *** 不可多倍折扣
		// *** 不可多组（否则POS计算错误）
		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++

		// 2-阶梯式现金返还 // 购买参加本活动的任意商品满100元立减5元;满150元立减15元 // gpOfferId 为 1000060
		// 单组, 不满足条件, 1件商品
		items.clear();
		items.add(new GpCartItem(1000000000006L, 6L, 1, new BigDecimal("55"), 1100060, 1, new BigDecimal("0.0"),
				1000000000006L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("0.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0,
 "result is error");

		// 2-阶梯式现金返还 // 购买参加本活动的任意商品满2件立减5元;满5件立减15元 // gpOfferId 为 1000020
		// 单组 , 满足一级阶梯条件, 2件商口
		items.clear();
		items.add(new GpCartItem(1000000000006L, 6L, 2, new BigDecimal("55"), 1100020, 1, new BigDecimal("5.0"),
				1000000000006L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("5.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0,
				"result is error");

		// 2-阶梯式现金返还 // 购买参加本活动的任意商品满2件立减5元;满5件立减15元 // gpOfferId 为 1000020
		// 单组, 满足2级阶梯, 5件商品
		items.clear();
		items.add(new GpCartItem(1000000000006L, 6L, 5, new BigDecimal("55"), 1100020, 1, new BigDecimal("15.0"),
				1000000000006L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("15.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0,
				"result is error");
	}

	// @After
	public void clearTestData() {
		List<Integer> offerIdList = Arrays.asList(1100000, 1100001, 1100010, 1100020, 1100030, 1100040, 1100050,
				1100060);
		List<GpOffer> offers = this.gpOfferRepository.findByGpOfferIdIn(offerIdList);

		this.gpOfferRepository.delete(offers);

	}
}
