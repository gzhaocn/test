package com.walmart.mobile.checkout.service.promotion;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.easymock.EasyMock;
import org.easymock.IMocksControl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.Assert;

import com.alibaba.fastjson.JSON;
import com.walmart.mobile.checkout.bo.promotion.CalcDiscountResult;
import com.walmart.mobile.checkout.bo.promotion.GpCartItem;
import com.walmart.mobile.checkout.config.MainConfig;
import com.walmart.mobile.checkout.entity.promotion.GpOffer;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.repo.GpOfferRepository;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { MainConfig.class })
public class GlobalPromotionServiceNewMockTest {
	@Autowired
	private PromotionService promotionService;
	private static final Logger LOG = LoggerFactory.getLogger(GlobalPromotionServiceNewMockTest.class);

	@Test
	public void promotionServiceCalcDiscountTest() throws GlobalErrorInfoException {

		// 40单GP测试：01类型0，满立减（数量），非组合2件
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1463587200000,\"discountFactor\":20.0,\"discountTimes\":0,\"endDate\":1530288000000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000001,\"gpThumbnailUrl\":\"1481606976487.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361119,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满2件立减{20}元\",\"promotionDescCn\":\"满2件立减20元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{20}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		items.add(new GpCartItem(31690309617031L, 690309617031L, 2, new BigDecimal(138), 201000001, 1, new BigDecimal(20), 31690309617031L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest2() throws GlobalErrorInfoException {

		// 41单GP测试：02类型0，满立减（数量），组合0-1
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1460304000000,\"discountFactor\":15.0,\"discountTimes\":0,\"endDate\":1546099200000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000002,\"gpThumbnailUrl\":\"1481606995664.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":4},{\"groupSeq\":2,\"thresholdAmt\":0.0,\"thresholdQty\":5}],\"id\":27842700969924878344958912736,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满1组减{15}元（9件为1组:需包含第1类任意4件，第2类任意5件）\",\"promotionDescCn\":\"满1组减15元（9件为1组:需包含第1类任意4件，第2类任意5件）\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"组合商品减{15}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		items.add(new GpCartItem(31693245062325L, 693245062325L, 3, new BigDecimal(29.9), 201000002, 1, new BigDecimal(0), 31693245062325L));
		items.add(new GpCartItem(31693245068769L, 693245068769L, 5, new BigDecimal(9.9), 201000002, 2, new BigDecimal(0), 31693245068769L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest3() throws GlobalErrorInfoException {

		// 44单GP测试：05类型0，满立减（数量），组合1-1
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1460304000000,\"discountFactor\":15.0,\"discountTimes\":0,\"endDate\":1546099200000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000002,\"gpThumbnailUrl\":\"1481606995664.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":4},{\"groupSeq\":2,\"thresholdAmt\":0.0,\"thresholdQty\":5}],\"id\":27842700969924878344958912736,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满1组减{15}元（9件为1组:需包含第1类任意4件，第2类任意5件）\",\"promotionDescCn\":\"满1组减15元（9件为1组:需包含第1类任意4件，第2类任意5件）\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"组合商品减{15}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		items.add(new GpCartItem(31693245062325L, 693245062325L, 4, new BigDecimal(29.9), 201000002, 1, new BigDecimal(10.61).setScale(2, RoundingMode.HALF_UP), 31693245062325L));
		items.add(new GpCartItem(31693245068769L, 693245068769L, 5, new BigDecimal(9.9), 201000002, 2, new BigDecimal(4.39).setScale(2, RoundingMode.HALF_UP), 31693245068769L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest4() throws GlobalErrorInfoException {

		// 48单GP测试：09类型0，满立减（数量），组合2-2
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1460304000000,\"discountFactor\":15.0,\"discountTimes\":0,\"endDate\":1546099200000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000002,\"gpThumbnailUrl\":\"1481606995664.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":4},{\"groupSeq\":2,\"thresholdAmt\":0.0,\"thresholdQty\":5}],\"id\":27842700969924878344958912736,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满1组减{15}元（9件为1组:需包含第1类任意4件，第2类任意5件）\",\"promotionDescCn\":\"满1组减15元（9件为1组:需包含第1类任意4件，第2类任意5件）\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"组合商品减{15}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31693245062325L, 693245062325L, 8, new BigDecimal(29.9), 201000002, 1, new BigDecimal(21.22).setScale(2, RoundingMode.HALF_UP), 31693245068769L));
		items.add(new GpCartItem(31693245068769L, 693245068769L, 10, new BigDecimal(9.9), 201000002, 2, new BigDecimal(8.78).setScale(2, RoundingMode.HALF_UP), 31693245068769L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest5() throws GlobalErrorInfoException {
		// 49单GP测试：10类型1，折扣，2件未满足
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1466006400000,\"discountFactor\":30.0,\"discountTimes\":0,\"endDate\":1530806400000,\"gpOfferCategoryIds\":[419,314],\"gpOfferId\":201000003,\"gpThumbnailUrl\":\"1481607008575.png\",\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":3}],\"id\":27842700969924878344958912737,\"promotionActualDesc\":\"\",\"promotionDesc\":\"3件及以上享{7}折\",\"promotionDescCn\":\"3件及以上享7折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{7}折\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31694317124631L, 694317124631L, 2, new BigDecimal(139), 201000003, 1, new BigDecimal(0), 31694317124631L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest6() throws GlobalErrorInfoException {
		// 50单GP测试：11类型1，折扣，3件满足
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1466006400000,\"discountFactor\":30.0,\"discountTimes\":0,\"endDate\":1530806400000,\"gpOfferCategoryIds\":[419,314],\"gpOfferId\":201000003,\"gpThumbnailUrl\":\"1481607008575.png\",\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":3}],\"id\":27842700969924878344958912737,\"promotionActualDesc\":\"\",\"promotionDesc\":\"3件及以上享{7}折\",\"promotionDescCn\":\"3件及以上享7折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{7}折\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31694317124631L, 694317124631L, 3, new BigDecimal(139), 201000003, 1, new BigDecimal(125.1).setScale(2, RoundingMode.HALF_UP), 31694317124631L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest7() throws GlobalErrorInfoException {
		// 51单GP测试：12类型1，折扣，4件超过
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1466006400000,\"discountFactor\":30.0,\"discountTimes\":0,\"endDate\":1530806400000,\"gpOfferCategoryIds\":[419,314],\"gpOfferId\":201000003,\"gpThumbnailUrl\":\"1481607008575.png\",\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":3}],\"id\":27842700969924878344958912737,\"promotionActualDesc\":\"\",\"promotionDesc\":\"3件及以上享{7}折\",\"promotionDescCn\":\"3件及以上享7折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{7}折\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31694317124631L, 694317124631L, 4, new BigDecimal(139), 201000003, 1, new BigDecimal(166.8).setScale(2, RoundingMode.HALF_UP), 31694317124631L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest8() throws GlobalErrorInfoException {
		// 52单GP测试：13类型2，阶梯满立减（数量），1件未满足
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":1,\"endDate\":1546185600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000004,\"gpThumbnailUrl\":\"1481607023253.png\",\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":100.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":210.0,\"thresholdAmt\":0.0,\"thresholdQty\":4}]}],\"id\":27842700969924878344958912738,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件减{100}元，4件及以上减{210}元\",\"promotionDescCn\":\"2件减100元，4件及以上减210元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{100}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31691080621674L, 691080621674L, 1, new BigDecimal(749), 201000004, 1, new BigDecimal(0), 31691080621674L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest9() throws GlobalErrorInfoException {
		// 54单GP测试：15类型2，阶梯满立减（数量），3件满足1阶
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":1,\"endDate\":1546185600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000004,\"gpThumbnailUrl\":\"1481607023253.png\",\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":100.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":210.0,\"thresholdAmt\":0.0,\"thresholdQty\":4}]}],\"id\":27842700969924878344958912738,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件减{100}元，4件及以上减{210}元\",\"promotionDescCn\":\"2件减100元，4件及以上减210元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{100}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31691080621674L, 691080621674L, 3, new BigDecimal(749), 201000004, 1, new BigDecimal(100), 31691080621674L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest10() throws GlobalErrorInfoException {
		// 56单GP测试：17类型2，阶梯满立减（数量），5件满足2阶
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":1,\"endDate\":1546185600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000004,\"gpThumbnailUrl\":\"1481607023253.png\",\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":100.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":210.0,\"thresholdAmt\":0.0,\"thresholdQty\":4}]}],\"id\":27842700969924878344958912738,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件减{100}元，4件及以上减{210}元\",\"promotionDescCn\":\"2件减100元，4件及以上减210元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{100}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31691080621674L, 691080621674L, 5, new BigDecimal(749), 201000004, 1, new BigDecimal(210), 31691080621674L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest11() throws GlobalErrorInfoException {
		// 57单GP测试：18类型3，阶梯折扣，1件未满足
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":1,\"endDate\":1546185600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000005,\"gpThumbnailUrl\":\"1481607033811.png\",\"gpTypeCode\":3,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":20.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":25.0,\"thresholdAmt\":0.0,\"thresholdQty\":4}]}],\"id\":27842700969924878344958912739,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件享{8}折，4件及以上享{7.5}折\",\"promotionDescCn\":\"2件享8折，4件及以上享7.5折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{8}折\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31692138453064L, 692138453064L, 1, new BigDecimal(269), 201000005, 1, new BigDecimal(0), 31692138453064L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest12() throws GlobalErrorInfoException {
		// 59单GP测试：20类型3，阶梯折扣，3件满足1阶
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":1,\"endDate\":1546185600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000005,\"gpThumbnailUrl\":\"1481607033811.png\",\"gpTypeCode\":3,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":20.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":25.0,\"thresholdAmt\":0.0,\"thresholdQty\":4}]}],\"id\":27842700969924878344958912739,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件享{8}折，4件及以上享{7.5}折\",\"promotionDescCn\":\"2件享8折，4件及以上享7.5折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{8}折\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31692138453064L, 692138453064L, 3, new BigDecimal(269), 201000005, 1, new BigDecimal(161.4).setScale(2, RoundingMode.HALF_UP), 31692138453064L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest13() throws GlobalErrorInfoException {
		// 60单GP测试：21类型3，阶梯折扣，4件满足2阶
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":1,\"endDate\":1546185600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000005,\"gpThumbnailUrl\":\"1481607033811.png\",\"gpTypeCode\":3,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":20.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":25.0,\"thresholdAmt\":0.0,\"thresholdQty\":4}]}],\"id\":27842700969924878344958912739,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件享{8}折，4件及以上享{7.5}折\",\"promotionDescCn\":\"2件享8折，4件及以上享7.5折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{8}折\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31692138453064L, 692138453064L, 4, new BigDecimal(269), 201000005, 1, new BigDecimal(269), 31692138453064L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest14() throws GlobalErrorInfoException {
		// 62单GP测试：23类型4，固定价格促销，1件未满足
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1466006400000,\"discountFactor\":360.0,\"discountTimes\":0,\"endDate\":1530201600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000006,\"gpThumbnailUrl\":\"1481607046143.png\",\"gpTypeCode\":4,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700969924878344958912740,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件仅需{360}元\",\"promotionDescCn\":\"2件仅需360元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"2件{360}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31692138451361L, 692138451361L, 1, new BigDecimal(199), 201000006, 1, new BigDecimal(0), 31692138451361L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest15() throws GlobalErrorInfoException {
		// 64单GP测试：25类型4，固定价格促销，3件满足1次
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1466006400000,\"discountFactor\":360.0,\"discountTimes\":0,\"endDate\":1530201600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000006,\"gpThumbnailUrl\":\"1481607046143.png\",\"gpTypeCode\":4,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700969924878344958912740,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件仅需{360}元\",\"promotionDescCn\":\"2件仅需360元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"2件{360}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31692138451361L, 692138451361L, 3, new BigDecimal(199), 201000006, 1, new BigDecimal(38), 31692138451361L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest16() throws GlobalErrorInfoException {
		// 66单GP测试：27类型4，固定价格促销，5件满足2次
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1466006400000,\"discountFactor\":360.0,\"discountTimes\":0,\"endDate\":1530201600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000006,\"gpThumbnailUrl\":\"1481607046143.png\",\"gpTypeCode\":4,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700969924878344958912740,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件仅需{360}元\",\"promotionDescCn\":\"2件仅需360元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"2件{360}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31692138451361L, 692138451361L, 5, new BigDecimal(199), 201000006, 1, new BigDecimal(76), 31692138451361L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest17() throws GlobalErrorInfoException {
		// 68单GP测试：29类型6，满立减（金额），n-0.01
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1443628800000,\"discountFactor\":15.0,\"discountTimes\":0,\"endDate\":1475164800000,\"gpOfferId\":20647409,\"gpTypeCode\":4,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361075,\"promotionDesc\":\"参与本活动的商品任选2件仅需15元\",\"promotionDescCn\":\"参与本活动的商品任选2件仅需15元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"2件总价{15}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31692880401122L, 693245068112L, 3, new BigDecimal(3.33), 20647409, 1, new BigDecimal(0), 31692880401122L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest18() throws GlobalErrorInfoException {
		// 69单GP测试：30类型6，满立减（金额），n
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1466611200000,\"discountFactor\":1.0,\"discountTimes\":0,\"endDate\":1530806400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000007,\"gpThumbnailUrl\":\"1481607058600.png\",\"gpTypeCode\":6,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":10.0,\"thresholdQty\":0}],\"id\":27842700969924878344958912741,\"promotionActualDesc\":\"\",\"promotionDesc\":\"每满10元立减{1}元\",\"promotionDescCn\":\"每满10元立减1元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{1}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31692880401122L, 693245068112L, 3, new BigDecimal(3.33), 201000007, 1, new BigDecimal(1), 31692880401122L));
		items.add(new GpCartItem(31002610288451L, 2610288451L, 1, new BigDecimal(0.01), 201000007, 1, new BigDecimal(0), 31002610288451L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest19() throws GlobalErrorInfoException {
		// 71单GP测试：32类型6，满立减（金额），n+0.02
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1466611200000,\"discountFactor\":1.0,\"discountTimes\":0,\"endDate\":1530806400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000007,\"gpThumbnailUrl\":\"1481607058600.png\",\"gpTypeCode\":6,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":10.0,\"thresholdQty\":0}],\"id\":27842700969924878344958912741,\"promotionActualDesc\":\"\",\"promotionDesc\":\"每满10元立减{1}元\",\"promotionDescCn\":\"每满10元立减1元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{1}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31693245068486L, 693245068486L, 3, new BigDecimal(3.32), 201000007, 1, new BigDecimal(0.99).setScale(2, RoundingMode.HALF_UP), 31693245068486L));
		items.add(new GpCartItem(31693245068112L, 693245068112L, 3, new BigDecimal(0.02), 201000007, 1, new BigDecimal(0.01).setScale(2, RoundingMode.HALF_UP), 31693245068112L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest20() throws GlobalErrorInfoException {
		// 73单GP测试：34类型6，满立减（金额），2n-0.01
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1443628800000,\"discountFactor\":15.0,\"discountTimes\":0,\"endDate\":1475164800000,\"gpOfferId\":20647409,\"gpTypeCode\":4,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361075,\"promotionDesc\":\"参与本活动的商品任选2件仅需15元\",\"promotionDescCn\":\"参与本活动的商品任选2件仅需15元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"2件总价{15}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466611200000,\"discountFactor\":1.0,\"discountTimes\":0,\"endDate\":1530806400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000007,\"gpThumbnailUrl\":\"1481607058600.png\",\"gpTypeCode\":6,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":10.0,\"thresholdQty\":0}],\"id\":27842700969924878344958912741,\"promotionActualDesc\":\"\",\"promotionDesc\":\"每满10元立减{1}元\",\"promotionDescCn\":\"每满10元立减1元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{1}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31692880401122L, 692880401122L, 7, new BigDecimal(3.33), 20647409, 1, new BigDecimal(0), 31692880401122L));
		items.add(new GpCartItem(31695006840891L, 695006840891L, 8, new BigDecimal(2.49), 201000007, 1, new BigDecimal(1), 31695006840891L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest21() throws GlobalErrorInfoException {
		// 76单GP测试：37类型6，满立减（金额），2n+0.01
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1466611200000,\"discountFactor\":1.0,\"discountTimes\":0,\"endDate\":1530806400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000007,\"gpThumbnailUrl\":\"1481607058600.png\",\"gpTypeCode\":6,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":10.0,\"thresholdQty\":0}],\"id\":27842700969924878344958912741,\"promotionActualDesc\":\"\",\"promotionDesc\":\"每满10元立减{1}元\",\"promotionDescCn\":\"每满10元立减1元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{1}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31693245068486L, 693245068486L, 6, new BigDecimal(3.32), 201000007, 1, new BigDecimal(1.99).setScale(2, RoundingMode.HALF_UP), 31693245068486L));
		items.add(new GpCartItem(31693245068112L, 693245068112L, 5, new BigDecimal(0.02), 201000007, 1, new BigDecimal(0.01).setScale(2, RoundingMode.HALF_UP), 31693245068112L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest22() throws GlobalErrorInfoException {
		// 77单GP测试：38一分钱分摊
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":10.0,\"discountTimes\":0,\"endDate\":1483027200000,\"gpOfferId\":20709073,\"gpTypeCode\":4,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361077,\"promotionDesc\":\"参与本活动的商品任选2件仅需10元\",\"promotionDescCn\":\"参与本活动的商品任选2件仅需10元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"2件总价{10}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1470240000000,\"discountFactor\":20.0,\"discountTimes\":0,\"endDate\":1471363200000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20991646,\"gpThumbnailUrl\":\"1481699035374.png\",\"gpTypeCode\":6,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":100.0,\"thresholdQty\":0}],\"id\":27842700951478134271249361117,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满100元立减{20}元\",\"promotionDescCn\":\"满100元立减20元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{20}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466611200000,\"discountFactor\":20.0,\"discountTimes\":3,\"endDate\":1530806400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000008,\"gpThumbnailUrl\":\"1481607068917.png\",\"gpTypeCode\":6,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":105.0,\"thresholdQty\":0}],\"id\":27842700969924878344958912742,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满105元立减{20}元\",\"promotionDescCn\":\"满105元立减20元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{20}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31690894628401L, 690894628401L, 1, new BigDecimal(7.75), 20709073, 1, new BigDecimal(0), 31690894628401L));
		items.add(new GpCartItem(31690894628401L, 690894628401L, 1, new BigDecimal(7.75), 20991646, 1, new BigDecimal(0), 31690894628401L));
		items.add(new GpCartItem(31690894628401L, 690894628401L, 1, new BigDecimal(7.75), 201000008, 1, new BigDecimal(0), 31690894628401L));
		items.add(new GpCartItem(31692166980070L, 692166980070L, 1, new BigDecimal(15), 201000008, 1, new BigDecimal(0), 31692166980070L));
		items.add(new GpCartItem(31694317128558L, 694317128558L, 1, new BigDecimal(15), 201000008, 1, new BigDecimal(0), 31694317128558L));
		items.add(new GpCartItem(31692173020260L, 692173020260L, 1, new BigDecimal(15), 201000008, 1, new BigDecimal(0), 31692173020260L));
		items.add(new GpCartItem(31692017792313L, 692017792313L, 1, new BigDecimal(15), 201000008, 1, new BigDecimal(0), 31692017792313L));
		items.add(new GpCartItem(31000004078657L, 4078657L, 1, new BigDecimal(15), 201000008, 1, new BigDecimal(0), 31000004078657L));
		items.add(new GpCartItem(31692219340052L, 692219340052L, 1, new BigDecimal(15), 201000008, 1, new BigDecimal(0), 31692219340052L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest23() throws GlobalErrorInfoException {
		// 78多GP商品下单(1个商品)
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1462204800000,\"discountFactor\":5.0,\"discountTimes\":0,\"endDate\":1467216000000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20779530,\"gpThumbnailUrl\":\"1481698917001.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361087,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满2件立减{5}元\",\"promotionDescCn\":\"满2件立减5元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{5}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1467820800000,\"discountFactor\":40.0,\"discountTimes\":0,\"endDate\":1482854400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20832981,\"gpThumbnailUrl\":\"1481766159995.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361089,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满2件立减{40}元\",\"promotionDescCn\":\"满2件立减40元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满2件减{40}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31000002104306L, 2104306L, 8, new BigDecimal(9.8), 20832981, 1, new BigDecimal(0), 31000002104306L));
		items.add(new GpCartItem(31000002104306L, 2104306L, 8, new BigDecimal(9.8), 20779530, 1, new BigDecimal(20), 31000002104306L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest24() throws GlobalErrorInfoException {
		// 79多GP商品下单(1个商品)
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1467820800000,\"discountFactor\":40.0,\"discountTimes\":0,\"endDate\":1482854400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20832981,\"gpThumbnailUrl\":\"1481766159995.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361089,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满2件立减{40}元\",\"promotionDescCn\":\"满2件立减40元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满2件减{40}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1469030400000,\"discountFactor\":10.0,\"discountTimes\":0,\"endDate\":1482854400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20959184,\"gpThumbnailUrl\":\"1481698939523.png\",\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":6}],\"id\":27842700951478134271249361115,\"promotionActualDesc\":\"\",\"promotionDesc\":\"6件及以上享{9}折\",\"promotionDescCn\":\"6件及以上享9折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满6件享{9}折\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31000002104314L, 2104314L, 4, new BigDecimal(9.8), 20832981, 1, new BigDecimal(0), 31000002104314L));
		items.add(new GpCartItem(31000002104314L, 2104314L, 4, new BigDecimal(9.8), 20959184, 1, new BigDecimal(0), 31000002104314L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest25() throws GlobalErrorInfoException {
		// 80多GP商品下单(1个商品)
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":0,\"endDate\":1483113600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":2015,\"gpThumbnailUrl\":\"1481699046131.png\",\"gpTypeCode\":3,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":30.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":34.0,\"thresholdAmt\":0.0,\"thresholdQty\":3}]}],\"id\":27842700951478134271249361073,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件享{7}折，3件及以上享{6.6}折\",\"promotionDescCn\":\"2件享7折，3件及以上享6.6折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{7}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1460304000000,\"discountFactor\":0.0,\"discountTimes\":0,\"endDate\":1483027200000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20778009,\"gpThumbnailUrl\":\"1481698549232.png\",\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":5,\"tieredDiscount\":[{\"discountFactor\":2.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":4.0,\"thresholdAmt\":0.0,\"thresholdQty\":3}]}],\"id\":27842700951478134271249361081,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件减{2}元，3件及以上减{4}元\",\"promotionDescCn\":\"2件减2元，3件及以上减4元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满{2}件减{2}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31000002719289L, 2719289L, 10, new BigDecimal(9.9), 2015, 1, new BigDecimal(33.66).setScale(2, RoundingMode.HALF_UP), 31000002719289L));
		items.add(new GpCartItem(31000002719289L, 2719289L, 10, new BigDecimal(9.9), 20778009, 1, new BigDecimal(4), 31000002719289L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest26() throws GlobalErrorInfoException {
		// 81多GP商品下单(1个商品)
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1465401600000,\"discountFactor\":100.0,\"discountTimes\":4,\"endDate\":1469808000000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20991580,\"gpThumbnailUrl\":\"1481698991891.png\",\"gpTypeCode\":6,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":498.0,\"thresholdQty\":0}],\"id\":27842700951478134271249361116,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满498元立减{100}元\",\"promotionDescCn\":\"满498元立减100元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{100}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1460304000000,\"discountFactor\":30.0,\"discountTimes\":0,\"endDate\":1483027200000,\"gpOfferCategoryIds\":[419,323],\"gpOfferId\":20991849,\"gpThumbnailUrl\":\"1481699003325.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":1},{\"groupSeq\":2,\"thresholdAmt\":0.0,\"thresholdQty\":1}],\"id\":27842700951478134271249361118,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满1组减{30}元（2件为1组:需包含第1类任意1件，第2类任意1件）\",\"promotionDescCn\":\"满1组减30元（2件为1组:需包含第1类任意1件，第2类任意1件）\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"组合商品减{30}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31000004012277L, 4012277L, 2, new BigDecimal(18.5), 20991580, 1, new BigDecimal(0), 31000004012277L));
		items.add(new GpCartItem(31000004012277L, 4012277L, 2, new BigDecimal(18.5), 20991849, 2, new BigDecimal(0), 31000004012277L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest27() throws GlobalErrorInfoException {
		// 82多GP商品下单(1个商品)
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1475856000000,\"discountFactor\":30.0,\"discountTimes\":0,\"endDate\":1488211200000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20914521,\"gpThumbnailUrl\":\"1481699014021.png\",\"gpTypeCode\":4,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361112,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件仅需{30}元\",\"promotionDescCn\":\"2件仅需30元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"2件总价{30}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1460304000000,\"discountFactor\":30.0,\"discountTimes\":0,\"endDate\":1483027200000,\"gpOfferCategoryIds\":[419,323],\"gpOfferId\":20991849,\"gpThumbnailUrl\":\"1481699003325.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":1},{\"groupSeq\":2,\"thresholdAmt\":0.0,\"thresholdQty\":1}],\"id\":27842700951478134271249361118,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满1组减{30}元（2件为1组:需包含第1类任意1件，第2类任意1件）\",\"promotionDescCn\":\"满1组减30元（2件为1组:需包含第1类任意1件，第2类任意1件）\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"组合商品减{30}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31000004033887L, 4033887L, 1, new BigDecimal(25), 20991849, 2, new BigDecimal(0), 31000004033887L));
		items.add(new GpCartItem(31000004033887L, 4033887L, 1, new BigDecimal(25), 20914521, 1, new BigDecimal(0), 31000004033887L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest28() throws GlobalErrorInfoException {
		// 83多GP商品下单(1个商品)
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1467820800000,\"discountFactor\":40.0,\"discountTimes\":0,\"endDate\":1482854400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20832981,\"gpThumbnailUrl\":\"1481766159995.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361089,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满2件立减{40}元\",\"promotionDescCn\":\"满2件立减40元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满2件减{40}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1469030400000,\"discountFactor\":35.0,\"discountTimes\":0,\"endDate\":1483113600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20846063,\"gpThumbnailUrl\":\"1476683569037.png\",\"gpTypeCode\":4,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361092,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件仅需{35}元\",\"promotionDescCn\":\"2件仅需35元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"2件总价{35}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1469030400000,\"discountFactor\":10.0,\"discountTimes\":0,\"endDate\":1482854400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20959184,\"gpThumbnailUrl\":\"1481698939523.png\",\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":6}],\"id\":27842700951478134271249361115,\"promotionActualDesc\":\"\",\"promotionDesc\":\"6件及以上享{9}折\",\"promotionDescCn\":\"6件及以上享9折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满6件享{9}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1470240000000,\"discountFactor\":20.0,\"discountTimes\":0,\"endDate\":1471363200000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20991646,\"gpThumbnailUrl\":\"1481699035374.png\",\"gpTypeCode\":6,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":100.0,\"thresholdQty\":0}],\"id\":27842700951478134271249361117,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满100元立减{20}元\",\"promotionDescCn\":\"满100元立减20元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{20}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31000004080488L, 4080488L, 7, new BigDecimal(18.5), 20832981, 1, new BigDecimal(120), 31000004080488L));
		items.add(new GpCartItem(31000004080488L, 4080488L, 7, new BigDecimal(18.5), 20846063, 1, new BigDecimal(6), 31000004080488L));
		items.add(new GpCartItem(31000004080488L, 4080488L, 7, new BigDecimal(18.5), 20959184, 1, new BigDecimal(0), 31000004080488L));
		items.add(new GpCartItem(31000004080488L, 4080488L, 7, new BigDecimal(18.5), 20991646, 1, new BigDecimal(0), 31000004080488L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest29() throws GlobalErrorInfoException {
		// 84多GP商品下单(1个商品)
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":0,\"endDate\":1483113600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":2015,\"gpThumbnailUrl\":\"1481699046131.png\",\"gpTypeCode\":3,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":30.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":34.0,\"thresholdAmt\":0.0,\"thresholdQty\":3}]}],\"id\":27842700951478134271249361073,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件享{7}折，3件及以上享{6.6}折\",\"promotionDescCn\":\"2件享7折，3件及以上享6.6折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{7}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1460304000000,\"discountFactor\":0.0,\"discountTimes\":0,\"endDate\":1483027200000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20778009,\"gpThumbnailUrl\":\"1481698549232.png\",\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":5,\"tieredDiscount\":[{\"discountFactor\":2.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":4.0,\"thresholdAmt\":0.0,\"thresholdQty\":3}]}],\"id\":27842700951478134271249361081,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件减{2}元，3件及以上减{4}元\",\"promotionDescCn\":\"2件减2元，3件及以上减4元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满{2}件减{2}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1469030400000,\"discountFactor\":10.0,\"discountTimes\":0,\"endDate\":1482854400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20959184,\"gpThumbnailUrl\":\"1481698939523.png\",\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":6}],\"id\":27842700951478134271249361115,\"promotionActualDesc\":\"\",\"promotionDesc\":\"6件及以上享{9}折\",\"promotionDescCn\":\"6件及以上享9折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满6件享{9}折\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31000008017718L, 8017718L, 1, new BigDecimal(4.3), 2015, 1, new BigDecimal(0), 31000008017718L));
		items.add(new GpCartItem(31000008017718L, 8017718L, 1, new BigDecimal(4.3), 20778009, 1, new BigDecimal(0), 31000008017718L));
		items.add(new GpCartItem(31000008017718L, 8017718L, 1, new BigDecimal(4.3), 20959184, 1, new BigDecimal(0), 31000008017718L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest30() throws GlobalErrorInfoException {
		// 85多GP商品下单(1个商品)
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"beginDate\":1469030400000,\"discountFactor\":30.0,\"discountTimes\":0,\"endDate\":1476720000000,\"gpOfferId\":20846231,\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361095,\"promotionDesc\":\"满2件立减{30}元\",\"promotionDescCn\":\"满2件立减30元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{30}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1475856000000,\"discountFactor\":30.0,\"discountTimes\":0,\"endDate\":1488211200000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20914521,\"gpThumbnailUrl\":\"1481699014021.png\",\"gpTypeCode\":4,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361112,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件仅需{30}元\",\"promotionDescCn\":\"2件仅需30元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"2件总价{30}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31001410008550L, 1410008550L, 4, new BigDecimal(24), 20846231, 1, new BigDecimal(60), 31001410008550L));
		items.add(new GpCartItem(31001410008550L, 1410008550L, 4, new BigDecimal(24), 20914521, 1, new BigDecimal(0), 31001410008550L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest31() throws GlobalErrorInfoException {
		// 86多GP商品下单(1个商品)
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1460304000000,\"discountFactor\":0.0,\"discountTimes\":0,\"endDate\":1483027200000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20778009,\"gpThumbnailUrl\":\"1481698549232.png\",\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":5,\"tieredDiscount\":[{\"discountFactor\":2.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":4.0,\"thresholdAmt\":0.0,\"thresholdQty\":3}]}],\"id\":27842700951478134271249361081,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件减{2}元，3件及以上减{4}元\",\"promotionDescCn\":\"2件减2元，3件及以上减4元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满{2}件减{2}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1463587200000,\"discountFactor\":20.0,\"discountTimes\":0,\"endDate\":1530288000000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000001,\"gpThumbnailUrl\":\"1481606976487.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361119,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满2件立减{20}元\",\"promotionDescCn\":\"满2件立减20元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{20}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31030008723202L, 8723202L, 2, new BigDecimal(210.5), 20778009, 1, new BigDecimal(2), 31030008723202L));
		items.add(new GpCartItem(31030008723202L, 8723202L, 2, new BigDecimal(210.5), 201000001, 1, new BigDecimal(20), 31030008723202L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest32() throws GlobalErrorInfoException {
		// 87多GP商品下单(1个商品)
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"beginDate\":1451577600000,\"discountFactor\":2.0,\"discountTimes\":0,\"endDate\":1483113600000,\"gpOfferId\":2028,\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":1}],\"id\":27842700951478134271249361074,\"promotionDesc\":\"满1件立减{2}元\",\"promotionDescCn\":\"满1件立减2元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{2}元\",\"status\":0},{\"beginDate\":1471190400000,\"discountFactor\":18.0,\"discountTimes\":0,\"endDate\":1475769600000,\"gpOfferId\":20900049,\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361104,\"promotionDesc\":\"满2件立减{18}元\",\"promotionDescCn\":\"满2件立减18元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满2件减{18}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1471449600000,\"discountFactor\":30.0,\"discountTimes\":0,\"endDate\":1479312000000,\"gpOfferCategoryIds\":[352,323],\"gpOfferId\":20900088,\"gpThumbnailUrl\":\"1473660647441.png\",\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361105,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件及以上享{7}折\",\"promotionDescCn\":\"2件及以上享7折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满2件享{7}折\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31212399500000L, 212399500000L, 4, new BigDecimal(5), 2028, 1, new BigDecimal(8), 31212399500000L));
		items.add(new GpCartItem(31212399500000L, 212399500000L, 4, new BigDecimal(5), 20900049, 1, new BigDecimal(0), 31212399500000L));
		items.add(new GpCartItem(31212399500000L, 212399500000L, 4, new BigDecimal(5), 20900088, 1, new BigDecimal(6), 31212399500000L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest33() throws GlobalErrorInfoException {
		// 88多GP商品下单(1个商品)
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":1,\"endDate\":1546185600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000005,\"gpThumbnailUrl\":\"1481607033811.png\",\"gpTypeCode\":3,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":20.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":25.0,\"thresholdAmt\":0.0,\"thresholdQty\":4}]}],\"id\":27842700969924878344958912739,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件享{8}折，4件及以上享{7.5}折\",\"promotionDescCn\":\"2件享8折，4件及以上享7.5折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{8}折\",\"status\":0},{\"beginDate\":1472659200000,\"discountFactor\":80.01,\"discountTimes\":0,\"endDate\":1476028800000,\"gpOfferId\":2100000012,\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700637883485018186983595,\"promotionDesc\":\"满2件立减{80.01}元\",\"promotionDescCn\":\"满2件立减80.01元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满2件立减{80.01}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31400606779627L, 400606779627L, 7, new BigDecimal(50), 201000005, 1, new BigDecimal(87.5).setScale(2, RoundingMode.HALF_UP), 31400606779627L));
		items.add(new GpCartItem(31400606779627L, 400606779627L, 7, new BigDecimal(50), 2100000012, 1, new BigDecimal(240.03).setScale(2, RoundingMode.HALF_UP), 31400606779627L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest34() throws GlobalErrorInfoException {
		// 89多GP商品下单(1个商品)
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"beginDate\":1471190400000,\"discountFactor\":18.0,\"discountTimes\":0,\"endDate\":1475769600000,\"gpOfferId\":20900049,\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361104,\"promotionDesc\":\"满2件立减{18}元\",\"promotionDescCn\":\"满2件立减18元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满2件减{18}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1471449600000,\"discountFactor\":30.0,\"discountTimes\":0,\"endDate\":1479312000000,\"gpOfferCategoryIds\":[352,323],\"gpOfferId\":20900088,\"gpThumbnailUrl\":\"1473660647441.png\",\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361105,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件及以上享{7}折\",\"promotionDescCn\":\"2件及以上享7折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满2件享{7}折\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31425035650106L, 425035650106L, 9, new BigDecimal(10), 20900049, 1, new BigDecimal(72), 31425035650106L));
		items.add(new GpCartItem(31425035650106L, 425035650106L, 9, new BigDecimal(10), 20900088, 1, new BigDecimal(0), 31425035650106L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest35() throws GlobalErrorInfoException {
		// 90多GP商品下单(1个商品)
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1462204800000,\"discountFactor\":5.0,\"discountTimes\":0,\"endDate\":1467216000000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20779530,\"gpThumbnailUrl\":\"1481698917001.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361087,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满2件立减{5}元\",\"promotionDescCn\":\"满2件立减5元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{5}元\",\"status\":0},{\"beginDate\":1473955200000,\"discountFactor\":50.0,\"discountTimes\":0,\"endDate\":1475769600000,\"gpOfferId\":20914954,\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361114,\"promotionDesc\":\"购买参加本活动的任意商品2件及以上享5折\",\"promotionDescCn\":\"购买参加本活动的任意商品2件及以上享5折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满2件享{5}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1473955200000,\"discountFactor\":5.0,\"discountTimes\":0,\"endDate\":1474992000000,\"gpOfferCategoryIds\":[352],\"gpOfferId\":2100000015,\"gpThumbnailUrl\":\"1476436829658.png\",\"gpTypeCode\":6,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":10.0,\"thresholdQty\":0}],\"id\":27842700637883485018186983596,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满10元立减{5}元\",\"promotionDescCn\":\"满10元立减5元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满10元减{5}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31489102870594L, 489102870594L, 7, new BigDecimal(5), 20779530, 1, new BigDecimal(15), 31489102870594L));
		items.add(new GpCartItem(31489102870594L, 489102870594L, 7, new BigDecimal(5), 20914954, 1, new BigDecimal(17.5).setScale(2, RoundingMode.HALF_UP), 31489102870594L));
		items.add(new GpCartItem(31489102870594L, 489102870594L, 7, new BigDecimal(5), 2100000015, 1, new BigDecimal(0), 31489102870594L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest36() throws GlobalErrorInfoException {
		// 91多GP商品下单(1个商品)
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1470672000000,\"discountFactor\":15.0,\"discountTimes\":0,\"endDate\":1480435200000,\"gpOfferCategoryIds\":[352],\"gpOfferId\":20899845,\"gpThumbnailUrl\":\"1476684216430.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361102,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满2件立减{15}元\",\"promotionDescCn\":\"满2件立减15元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满2件减{15}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":1,\"endDate\":1546185600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000004,\"gpThumbnailUrl\":\"1481607023253.png\",\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":100.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":210.0,\"thresholdAmt\":0.0,\"thresholdQty\":4}]}],\"id\":27842700969924878344958912738,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件减{100}元，4件及以上减{210}元\",\"promotionDescCn\":\"2件减100元，4件及以上减210元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{100}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1473955200000,\"discountFactor\":11.0,\"discountTimes\":0,\"endDate\":1474992000000,\"gpOfferCategoryIds\":[352],\"gpOfferId\":2100000016,\"gpThumbnailUrl\":\"1476436829658.png\",\"gpTypeCode\":6,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":10.0,\"thresholdQty\":0}],\"id\":27842700637883485018186983597,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满10元立减{11}元\",\"promotionDescCn\":\"满10元立减11元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满10元立减{11}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31690008202003L, 690008202003L, 6, new BigDecimal(5), 20899845, 1, new BigDecimal(0), 31690008202003L));
		items.add(new GpCartItem(31690008202003L, 690008202003L, 6, new BigDecimal(5), 201000004, 1, new BigDecimal(0), 31690008202003L));
		items.add(new GpCartItem(31690008202003L, 690008202003L, 6, new BigDecimal(5), 2100000016, 1, new BigDecimal(0), 31690008202003L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest37() throws GlobalErrorInfoException {
		// 92多GP商品下单(2个商品)
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1467820800000,\"discountFactor\":40.0,\"discountTimes\":0,\"endDate\":1482854400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20832981,\"gpThumbnailUrl\":\"1481766159995.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361089,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满2件立减{40}元\",\"promotionDescCn\":\"满2件立减40元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满2件减{40}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1469030400000,\"discountFactor\":35.0,\"discountTimes\":0,\"endDate\":1483113600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20846063,\"gpThumbnailUrl\":\"1476683569037.png\",\"gpTypeCode\":4,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361092,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件仅需{35}元\",\"promotionDescCn\":\"2件仅需35元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"2件总价{35}元\",\"status\":0},{\"beginDate\":1469030400000,\"discountFactor\":30.0,\"discountTimes\":0,\"endDate\":1476720000000,\"gpOfferId\":20846231,\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361095,\"promotionDesc\":\"满2件立减{30}元\",\"promotionDescCn\":\"满2件立减30元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{30}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1475856000000,\"discountFactor\":30.0,\"discountTimes\":0,\"endDate\":1488211200000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20914521,\"gpThumbnailUrl\":\"1481699014021.png\",\"gpTypeCode\":4,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361112,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件仅需{30}元\",\"promotionDescCn\":\"2件仅需30元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"2件总价{30}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1469030400000,\"discountFactor\":10.0,\"discountTimes\":0,\"endDate\":1482854400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20959184,\"gpThumbnailUrl\":\"1481698939523.png\",\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":6}],\"id\":27842700951478134271249361115,\"promotionActualDesc\":\"\",\"promotionDesc\":\"6件及以上享{9}折\",\"promotionDescCn\":\"6件及以上享9折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满6件享{9}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1470240000000,\"discountFactor\":20.0,\"discountTimes\":0,\"endDate\":1471363200000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20991646,\"gpThumbnailUrl\":\"1481699035374.png\",\"gpTypeCode\":6,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":100.0,\"thresholdQty\":0}],\"id\":27842700951478134271249361117,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满100元立减{20}元\",\"promotionDescCn\":\"满100元立减20元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{20}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31000004080488L, 4080488L, 1, new BigDecimal(18.5), 20832981, 1, new BigDecimal(0), 31000004080488L));
		items.add(new GpCartItem(31000004080488L, 4080488L, 1, new BigDecimal(18.5), 20846063, 1, new BigDecimal(0), 31000004080488L));
		items.add(new GpCartItem(31000004080488L, 4080488L, 1, new BigDecimal(18.5), 20959184, 1, new BigDecimal(0), 31000004080488L));
		items.add(new GpCartItem(31000004080488L, 4080488L, 1, new BigDecimal(18.5), 20991646, 1, new BigDecimal(0), 31000004080488L));
		items.add(new GpCartItem(31001410008550L, 1410008550L, 1, new BigDecimal(24), 20846231, 1, new BigDecimal(0), 31001410008550L));
		items.add(new GpCartItem(31001410008550L, 1410008550L, 1, new BigDecimal(24), 20914521, 1, new BigDecimal(0), 31001410008550L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest38() throws GlobalErrorInfoException {
		// 93多GP商品下单(2个商品)
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1460304000000,\"discountFactor\":0.0,\"discountTimes\":0,\"endDate\":1483027200000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20778009,\"gpThumbnailUrl\":\"1481698549232.png\",\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":5,\"tieredDiscount\":[{\"discountFactor\":2.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":4.0,\"thresholdAmt\":0.0,\"thresholdQty\":3}]}],\"id\":27842700951478134271249361081,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件减{2}元，3件及以上减{4}元\",\"promotionDescCn\":\"2件减2元，3件及以上减4元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满{2}件减{2}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1462204800000,\"discountFactor\":5.0,\"discountTimes\":0,\"endDate\":1467216000000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20779530,\"gpThumbnailUrl\":\"1481698917001.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361087,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满2件立减{5}元\",\"promotionDescCn\":\"满2件立减5元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{5}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1467820800000,\"discountFactor\":40.0,\"discountTimes\":0,\"endDate\":1482854400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20832981,\"gpThumbnailUrl\":\"1481766159995.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361089,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满2件立减{40}元\",\"promotionDescCn\":\"满2件立减40元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满2件减{40}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1463587200000,\"discountFactor\":20.0,\"discountTimes\":0,\"endDate\":1530288000000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000001,\"gpThumbnailUrl\":\"1481606976487.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361119,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满2件立减{20}元\",\"promotionDescCn\":\"满2件立减20元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{20}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31030008723202L, 30008723202L, 2, new BigDecimal(210.5), 20778009, 1, new BigDecimal(2), 31030008723202L));
		items.add(new GpCartItem(31030008723202L, 30008723202L, 2, new BigDecimal(210.5), 201000001, 1, new BigDecimal(20), 31030008723202L));
		items.add(new GpCartItem(31000002104306L, 2104306L, 9, new BigDecimal(9.8), 20779530, 1, new BigDecimal(20), 31000002104306L));
		items.add(new GpCartItem(31000002104306L, 2104306L, 9, new BigDecimal(9.8), 20832981, 1, new BigDecimal(0), 31000002104306L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest39() throws GlobalErrorInfoException {
		// 94多GP商品下单(2个商品)
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":0,\"endDate\":1483113600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":2015,\"gpThumbnailUrl\":\"1481699046131.png\",\"gpTypeCode\":3,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":30.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":34.0,\"thresholdAmt\":0.0,\"thresholdQty\":3}]}],\"id\":27842700951478134271249361073,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件享{7}折，3件及以上享{6.6}折\",\"promotionDescCn\":\"2件享7折，3件及以上享6.6折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{7}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1460304000000,\"discountFactor\":0.0,\"discountTimes\":0,\"endDate\":1483027200000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20778009,\"gpThumbnailUrl\":\"1481698549232.png\",\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":5,\"tieredDiscount\":[{\"discountFactor\":2.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":4.0,\"thresholdAmt\":0.0,\"thresholdQty\":3}]}],\"id\":27842700951478134271249361081,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件减{2}元，3件及以上减{4}元\",\"promotionDescCn\":\"2件减2元，3件及以上减4元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满{2}件减{2}元\",\"status\":0},{\"beginDate\":1469030400000,\"discountFactor\":30.0,\"discountTimes\":0,\"endDate\":1476720000000,\"gpOfferId\":20846231,\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361095,\"promotionDesc\":\"满2件立减{30}元\",\"promotionDescCn\":\"满2件立减30元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{30}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1475856000000,\"discountFactor\":30.0,\"discountTimes\":0,\"endDate\":1488211200000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20914521,\"gpThumbnailUrl\":\"1481699014021.png\",\"gpTypeCode\":4,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361112,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件仅需{30}元\",\"promotionDescCn\":\"2件仅需30元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"2件总价{30}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1469030400000,\"discountFactor\":10.0,\"discountTimes\":0,\"endDate\":1482854400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20959184,\"gpThumbnailUrl\":\"1481698939523.png\",\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":6}],\"id\":27842700951478134271249361115,\"promotionActualDesc\":\"\",\"promotionDesc\":\"6件及以上享{9}折\",\"promotionDescCn\":\"6件及以上享9折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满6件享{9}折\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31000008017718L, 8017718L, 8, new BigDecimal(4.3), 2015, 1, new BigDecimal(11.70).setScale(2, RoundingMode.HALF_UP), 31000008017718L));
		items.add(new GpCartItem(31000008017718L, 8017718L, 8, new BigDecimal(4.3), 20778009, 1, new BigDecimal(4), 31000008017718L));
		items.add(new GpCartItem(31000008017718L, 8017718L, 8, new BigDecimal(4.3), 20959184, 1, new BigDecimal(3.44).setScale(2, RoundingMode.HALF_UP), 31000008017718L));
		items.add(new GpCartItem(31001410008550L, 1410008550L, 6, new BigDecimal(24), 20846231, 1, new BigDecimal(90), 31001410008550L));
		items.add(new GpCartItem(31001410008550L, 1410008550L, 6, new BigDecimal(24), 20914521, 1, new BigDecimal(0), 31001410008550L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest40() throws GlobalErrorInfoException {
		// 95多GP商品下单(2个商品)
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1475856000000,\"discountFactor\":30.0,\"discountTimes\":0,\"endDate\":1488211200000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20914521,\"gpThumbnailUrl\":\"1481699014021.png\",\"gpTypeCode\":4,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361112,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件仅需{30}元\",\"promotionDescCn\":\"2件仅需30元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"2件总价{30}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1460304000000,\"discountFactor\":30.0,\"discountTimes\":0,\"endDate\":1483027200000,\"gpOfferCategoryIds\":[419,323],\"gpOfferId\":20991849,\"gpThumbnailUrl\":\"1481699003325.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":1},{\"groupSeq\":2,\"thresholdAmt\":0.0,\"thresholdQty\":1}],\"id\":27842700951478134271249361118,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满1组减{30}元（2件为1组:需包含第1类任意1件，第2类任意1件）\",\"promotionDescCn\":\"满1组减30元（2件为1组:需包含第1类任意1件，第2类任意1件）\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"组合商品减{30}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":1,\"endDate\":1546185600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000005,\"gpThumbnailUrl\":\"1481607033811.png\",\"gpTypeCode\":3,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":20.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":25.0,\"thresholdAmt\":0.0,\"thresholdQty\":4}]}],\"id\":27842700969924878344958912739,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件享{8}折，4件及以上享{7.5}折\",\"promotionDescCn\":\"2件享8折，4件及以上享7.5折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{8}折\",\"status\":0},{\"beginDate\":1472659200000,\"discountFactor\":80.01,\"discountTimes\":0,\"endDate\":1476028800000,\"gpOfferId\":2100000012,\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700637883485018186983595,\"promotionDesc\":\"满2件立减{80.01}元\",\"promotionDescCn\":\"满2件立减80.01元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满2件立减{80.01}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31000004033887L, 4033887L, 5, new BigDecimal(25), 20914521, 1, new BigDecimal(40), 31000004033887L));
		items.add(new GpCartItem(31000004033887L, 4033887L, 5, new BigDecimal(25), 20991849, 1, new BigDecimal(0), 31000004033887L));
		items.add(new GpCartItem(31400606779627L, 606779627L, 8, new BigDecimal(50), 201000005, 1, new BigDecimal(100), 31400606779627L));
		items.add(new GpCartItem(31400606779627L, 606779627L, 8, new BigDecimal(50), 2100000012, 1, new BigDecimal(0), 31400606779627L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest41() throws GlobalErrorInfoException {
		// 96多GP商品下单(2个商品)
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1467820800000,\"discountFactor\":40.0,\"discountTimes\":0,\"endDate\":1482854400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20832981,\"gpThumbnailUrl\":\"1481766159995.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361089,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满2件立减{40}元\",\"promotionDescCn\":\"满2件立减40元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满2件减{40}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1469030400000,\"discountFactor\":35.0,\"discountTimes\":0,\"endDate\":1483113600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20846063,\"gpThumbnailUrl\":\"1476683569037.png\",\"gpTypeCode\":4,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361092,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件仅需{35}元\",\"promotionDescCn\":\"2件仅需35元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"2件总价{35}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1469030400000,\"discountFactor\":10.0,\"discountTimes\":0,\"endDate\":1482854400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20959184,\"gpThumbnailUrl\":\"1481698939523.png\",\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":6}],\"id\":27842700951478134271249361115,\"promotionActualDesc\":\"\",\"promotionDesc\":\"6件及以上享{9}折\",\"promotionDescCn\":\"6件及以上享9折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满6件享{9}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1470240000000,\"discountFactor\":20.0,\"discountTimes\":0,\"endDate\":1471363200000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20991646,\"gpThumbnailUrl\":\"1481699035374.png\",\"gpTypeCode\":6,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":100.0,\"thresholdQty\":0}],\"id\":27842700951478134271249361117,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满100元立减{20}元\",\"promotionDescCn\":\"满100元立减20元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{20}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31000002104314L, 2104314L, 9, new BigDecimal(9.8), 20832981, 1, new BigDecimal(0), 31000002104314L));
		items.add(new GpCartItem(31000002104314L, 2104314L, 9, new BigDecimal(9.8), 20959184, 1, new BigDecimal(8.82).setScale(2, RoundingMode.HALF_UP), 31000002104314L));
		items.add(new GpCartItem(31000004080488L, 4080488L, 8, new BigDecimal(18.5), 20832981, 1, new BigDecimal(0), 31000004080488L));
		items.add(new GpCartItem(31000004080488L, 4080488L, 8, new BigDecimal(18.5), 20846063, 1, new BigDecimal(8), 31000004080488L));
		items.add(new GpCartItem(31000004080488L, 4080488L, 8, new BigDecimal(18.5), 20959184, 1, new BigDecimal(14.8).setScale(2, RoundingMode.HALF_UP), 31000004080488L));
		items.add(new GpCartItem(31000004080488L, 4080488L, 8, new BigDecimal(18.5), 20991646, 1, new BigDecimal(20), 31000004080488L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest42() throws GlobalErrorInfoException {
		// 97多GP商品下单(2个商品)
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1460304000000,\"discountFactor\":0.0,\"discountTimes\":0,\"endDate\":1483027200000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20778009,\"gpThumbnailUrl\":\"1481698549232.png\",\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":5,\"tieredDiscount\":[{\"discountFactor\":2.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":4.0,\"thresholdAmt\":0.0,\"thresholdQty\":3}]}],\"id\":27842700951478134271249361081,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件减{2}元，3件及以上减{4}元\",\"promotionDescCn\":\"2件减2元，3件及以上减4元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满{2}件减{2}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1462204800000,\"discountFactor\":5.0,\"discountTimes\":0,\"endDate\":1467216000000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20779530,\"gpThumbnailUrl\":\"1481698917001.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361087,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满2件立减{5}元\",\"promotionDescCn\":\"满2件立减5元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{5}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1467820800000,\"discountFactor\":40.0,\"discountTimes\":0,\"endDate\":1482854400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20832981,\"gpThumbnailUrl\":\"1481766159995.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361089,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满2件立减{40}元\",\"promotionDescCn\":\"满2件立减40元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满2件减{40}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1463587200000,\"discountFactor\":20.0,\"discountTimes\":0,\"endDate\":1530288000000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000001,\"gpThumbnailUrl\":\"1481606976487.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361119,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满2件立减{20}元\",\"promotionDescCn\":\"满2件立减20元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{20}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31030008723202L, 8723202L, 9, new BigDecimal(210.5), 20778009, 1, new BigDecimal(4), 31030008723202L));
		items.add(new GpCartItem(31030008723202L, 8723202L, 9, new BigDecimal(210.5), 201000001, 1, new BigDecimal(80), 31030008723202L));
		items.add(new GpCartItem(31000002104306L, 2104306L, 9, new BigDecimal(9.8), 20832981, 1, new BigDecimal(0), 31000002104306L));
		items.add(new GpCartItem(31000002104306L, 2104306L, 9, new BigDecimal(9.8), 20779530, 1, new BigDecimal(20), 31000002104306L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest43() throws GlobalErrorInfoException {
		// 98多GP商品下单(2个商品)
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1470672000000,\"discountFactor\":15.0,\"discountTimes\":0,\"endDate\":1480435200000,\"gpOfferCategoryIds\":[352],\"gpOfferId\":20899845,\"gpThumbnailUrl\":\"1476684216430.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361102,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满2件立减{15}元\",\"promotionDescCn\":\"满2件立减15元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满2件减{15}元\",\"status\":0},{\"beginDate\":1471190400000,\"discountFactor\":18.0,\"discountTimes\":0,\"endDate\":1475769600000,\"gpOfferId\":20900049,\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361104,\"promotionDesc\":\"满2件立减{18}元\",\"promotionDescCn\":\"满2件立减18元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满2件减{18}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1471449600000,\"discountFactor\":30.0,\"discountTimes\":0,\"endDate\":1479312000000,\"gpOfferCategoryIds\":[352,323],\"gpOfferId\":20900088,\"gpThumbnailUrl\":\"1473660647441.png\",\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361105,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件及以上享{7}折\",\"promotionDescCn\":\"2件及以上享7折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满2件享{7}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":1,\"endDate\":1546185600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000004,\"gpThumbnailUrl\":\"1481607023253.png\",\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":100.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":210.0,\"thresholdAmt\":0.0,\"thresholdQty\":4}]}],\"id\":27842700969924878344958912738,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件减{100}元，4件及以上减{210}元\",\"promotionDescCn\":\"2件减100元，4件及以上减210元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{100}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1473955200000,\"discountFactor\":11.0,\"discountTimes\":0,\"endDate\":1474992000000,\"gpOfferCategoryIds\":[352],\"gpOfferId\":2100000016,\"gpThumbnailUrl\":\"1476436829658.png\",\"gpTypeCode\":6,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":10.0,\"thresholdQty\":0}],\"id\":27842700637883485018186983597,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满10元立减{11}元\",\"promotionDescCn\":\"满10元立减11元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满10元立减{11}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31425035650106L, 425035650106L, 2, new BigDecimal(10), 20900049, 1, new BigDecimal(18), 31425035650106L));
		items.add(new GpCartItem(31425035650106L, 425035650106L, 2, new BigDecimal(10), 20900088, 1, new BigDecimal(0), 31425035650106L));
		items.add(new GpCartItem(31690008202003L, 8202003L, 7, new BigDecimal(5), 20899845, 1, new BigDecimal(0), 31690008202003L));
		items.add(new GpCartItem(31690008202003L, 8202003L, 7, new BigDecimal(5), 201000004, 1, new BigDecimal(0), 31690008202003L));
		items.add(new GpCartItem(31690008202003L, 8202003L, 7, new BigDecimal(5), 2100000016, 1, new BigDecimal(33), 31690008202003L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest44() throws GlobalErrorInfoException {
		// 99多GP商品下单(2个商品)
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":0,\"endDate\":1483113600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":2015,\"gpThumbnailUrl\":\"1481699046131.png\",\"gpTypeCode\":3,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":30.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":34.0,\"thresholdAmt\":0.0,\"thresholdQty\":3}]}],\"id\":27842700951478134271249361073,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件享{7}折，3件及以上享{6.6}折\",\"promotionDescCn\":\"2件享7折，3件及以上享6.6折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{7}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1460304000000,\"discountFactor\":0.0,\"discountTimes\":0,\"endDate\":1483027200000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20778009,\"gpThumbnailUrl\":\"1481698549232.png\",\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":5,\"tieredDiscount\":[{\"discountFactor\":2.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":4.0,\"thresholdAmt\":0.0,\"thresholdQty\":3}]}],\"id\":27842700951478134271249361081,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件减{2}元，3件及以上减{4}元\",\"promotionDescCn\":\"2件减2元，3件及以上减4元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满{2}件减{2}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1467820800000,\"discountFactor\":40.0,\"discountTimes\":0,\"endDate\":1482854400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20832981,\"gpThumbnailUrl\":\"1481766159995.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361089,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满2件立减{40}元\",\"promotionDescCn\":\"满2件立减40元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满2件减{40}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1469030400000,\"discountFactor\":10.0,\"discountTimes\":0,\"endDate\":1482854400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20959184,\"gpThumbnailUrl\":\"1481698939523.png\",\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":6}],\"id\":27842700951478134271249361115,\"promotionActualDesc\":\"\",\"promotionDesc\":\"6件及以上享{9}折\",\"promotionDescCn\":\"6件及以上享9折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满6件享{9}折\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31000008017718L, 8017718L, 10, new BigDecimal(4.3), 2015, 1, new BigDecimal(14.62).setScale(2, RoundingMode.HALF_UP), 31000008017718L));
		items.add(new GpCartItem(31000008017718L, 8017718L, 10, new BigDecimal(4.3), 20778009, 1, new BigDecimal(4), 31000008017718L));
		items.add(new GpCartItem(31000008017718L, 8017718L, 10, new BigDecimal(4.3), 20959184, 1, new BigDecimal(4.3).setScale(2, RoundingMode.HALF_UP), 31000008017718L));

		items.add(new GpCartItem(31000002104314L, 2104314L, 7, new BigDecimal(9.8), 20832981, 1, new BigDecimal(0), 31000002104314L));
		items.add(new GpCartItem(31000002104314L, 2104314L, 7, new BigDecimal(9.8), 20959184, 1, new BigDecimal(6.86).setScale(2, RoundingMode.HALF_UP), 31000002104314L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest45() throws GlobalErrorInfoException {
		// 99多GP商品下单(2个商品)
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":0,\"endDate\":1483113600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":2015,\"gpThumbnailUrl\":\"1481699046131.png\",\"gpTypeCode\":3,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":30.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":34.0,\"thresholdAmt\":0.0,\"thresholdQty\":3}]}],\"id\":27842700951478134271249361073,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件享{7}折，3件及以上享{6.6}折\",\"promotionDescCn\":\"2件享7折，3件及以上享6.6折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{7}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1460304000000,\"discountFactor\":0.0,\"discountTimes\":0,\"endDate\":1483027200000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20778009,\"gpThumbnailUrl\":\"1481698549232.png\",\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":5,\"tieredDiscount\":[{\"discountFactor\":2.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":4.0,\"thresholdAmt\":0.0,\"thresholdQty\":3}]}],\"id\":27842700951478134271249361081,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件减{2}元，3件及以上减{4}元\",\"promotionDescCn\":\"2件减2元，3件及以上减4元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满{2}件减{2}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1467820800000,\"discountFactor\":40.0,\"discountTimes\":0,\"endDate\":1482854400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20832981,\"gpThumbnailUrl\":\"1481766159995.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361089,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满2件立减{40}元\",\"promotionDescCn\":\"满2件立减40元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满2件减{40}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1469030400000,\"discountFactor\":10.0,\"discountTimes\":0,\"endDate\":1482854400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20959184,\"gpThumbnailUrl\":\"1481698939523.png\",\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":6}],\"id\":27842700951478134271249361115,\"promotionActualDesc\":\"\",\"promotionDesc\":\"6件及以上享{9}折\",\"promotionDescCn\":\"6件及以上享9折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满6件享{9}折\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31000008017718L, 8017718L, 10, new BigDecimal(4.3), 2015, 1, new BigDecimal(14.62).setScale(2, RoundingMode.HALF_UP), 31000008017718L));
		items.add(new GpCartItem(31000008017718L, 8017718L, 10, new BigDecimal(4.3), 20778009, 1, new BigDecimal(4), 31000008017718L));
		items.add(new GpCartItem(31000008017718L, 8017718L, 10, new BigDecimal(4.3), 20959184, 1, new BigDecimal(4.3).setScale(2, RoundingMode.HALF_UP), 31000008017718L));

		items.add(new GpCartItem(31000002104314L, 2104314L, 7, new BigDecimal(9.8), 20832981, 1, new BigDecimal(0), 31000002104314L));
		items.add(new GpCartItem(31000002104314L, 2104314L, 7, new BigDecimal(9.8), 20959184, 1, new BigDecimal(6.86).setScale(2, RoundingMode.HALF_UP), 31000002104314L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest46() throws GlobalErrorInfoException {
		// 105多GP商品下单(3个商品)
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":0,\"endDate\":1483113600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":2015,\"gpThumbnailUrl\":\"1481699046131.png\",\"gpTypeCode\":3,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":30.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":34.0,\"thresholdAmt\":0.0,\"thresholdQty\":3}]}],\"id\":27842700951478134271249361073,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件享{7}折，3件及以上享{6.6}折\",\"promotionDescCn\":\"2件享7折，3件及以上享6.6折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{7}折\",\"status\":0},{\"beginDate\":1451577600000,\"discountFactor\":2.0,\"discountTimes\":0,\"endDate\":1483113600000,\"gpOfferId\":2028,\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":1}],\"id\":27842700951478134271249361074,\"promotionDesc\":\"满1件立减{2}元\",\"promotionDescCn\":\"满1件立减2元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{2}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1460304000000,\"discountFactor\":0.0,\"discountTimes\":0,\"endDate\":1483027200000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20778009,\"gpThumbnailUrl\":\"1481698549232.png\",\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":5,\"tieredDiscount\":[{\"discountFactor\":2.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":4.0,\"thresholdAmt\":0.0,\"thresholdQty\":3}]}],\"id\":27842700951478134271249361081,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件减{2}元，3件及以上减{4}元\",\"promotionDescCn\":\"2件减2元，3件及以上减4元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满{2}件减{2}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1462204800000,\"discountFactor\":5.0,\"discountTimes\":0,\"endDate\":1467216000000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20779530,\"gpThumbnailUrl\":\"1481698917001.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361087,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满2件立减{5}元\",\"promotionDescCn\":\"满2件立减5元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{5}元\",\"status\":0},{\"beginDate\":1471190400000,\"discountFactor\":18.0,\"discountTimes\":0,\"endDate\":1475769600000,\"gpOfferId\":20900049,\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361104,\"promotionDesc\":\"满2件立减{18}元\",\"promotionDescCn\":\"满2件立减18元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满2件减{18}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1471449600000,\"discountFactor\":30.0,\"discountTimes\":0,\"endDate\":1479312000000,\"gpOfferCategoryIds\":[352,323],\"gpOfferId\":20900088,\"gpThumbnailUrl\":\"1473660647441.png\",\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361105,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件及以上享{7}折\",\"promotionDescCn\":\"2件及以上享7折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满2件享{7}折\",\"status\":0},{\"beginDate\":1473955200000,\"discountFactor\":50.0,\"discountTimes\":0,\"endDate\":1475769600000,\"gpOfferId\":20914954,\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361114,\"promotionDesc\":\"购买参加本活动的任意商品2件及以上享5折\",\"promotionDescCn\":\"购买参加本活动的任意商品2件及以上享5折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满2件享{5}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1469030400000,\"discountFactor\":10.0,\"discountTimes\":0,\"endDate\":1482854400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":20959184,\"gpThumbnailUrl\":\"1481698939523.png\",\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":6}],\"id\":27842700951478134271249361115,\"promotionActualDesc\":\"\",\"promotionDesc\":\"6件及以上享{9}折\",\"promotionDescCn\":\"6件及以上享9折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满6件享{9}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1473955200000,\"discountFactor\":5.0,\"discountTimes\":0,\"endDate\":1474992000000,\"gpOfferCategoryIds\":[352],\"gpOfferId\":2011000015,\"gpThumbnailUrl\":\"1476436829658.png\",\"gpTypeCode\":6,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":10.0,\"thresholdQty\":0}],\"id\":27842700969924878344958912750,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满10元立减{5}元\",\"promotionDescCn\":\"满10元立减5元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满10元减{5}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31212399500000L, 212399500000L, 8, new BigDecimal(5), 2028, 1, new BigDecimal(16), 31212399500000L));
		items.add(new GpCartItem(31212399500000L, 212399500000L, 8, new BigDecimal(5), 20900049, 1, new BigDecimal(0), 31212399500000L));
		items.add(new GpCartItem(31212399500000L, 212399500000L, 8, new BigDecimal(5), 20900088, 1, new BigDecimal(12), 31212399500000L));
		items.add(new GpCartItem(31000008017718L, 8017718L, 4, new BigDecimal(4.3), 2015, 1, new BigDecimal(5.85).setScale(2, RoundingMode.HALF_UP), 31000008017718L));
		items.add(new GpCartItem(31000008017718L, 8017718L, 4, new BigDecimal(4.3), 20778009, 1, new BigDecimal(4), 31000008017718L));
		items.add(new GpCartItem(31000008017718L, 8017718L, 4, new BigDecimal(4.3), 20959184, 1, new BigDecimal(0), 31000008017718L));
		items.add(new GpCartItem(31489102870594L, 489102870594L, 4, new BigDecimal(5), 20779530, 1, new BigDecimal(10), 31489102870594L));
		items.add(new GpCartItem(31489102870594L, 489102870594L, 4, new BigDecimal(5), 20914954, 1, new BigDecimal(0), 31489102870594L));
		items.add(new GpCartItem(31489102870594L, 489102870594L, 4, new BigDecimal(5), 2011000015, 1, new BigDecimal(0), 31489102870594L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest47() throws GlobalErrorInfoException {
		// 108多GP商品下单(itemA满足)+(itemB1满足)
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1463587200000,\"discountFactor\":20.0,\"discountTimes\":0,\"endDate\":1530288000000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000001,\"gpThumbnailUrl\":\"1481606976487.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361119,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满2件立减{20}元\",\"promotionDescCn\":\"满2件立减20元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{20}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1460304000000,\"discountFactor\":15.0,\"discountTimes\":0,\"endDate\":1546099200000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000002,\"gpThumbnailUrl\":\"1481606995664.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":4},{\"groupSeq\":2,\"thresholdAmt\":0.0,\"thresholdQty\":5}],\"id\":27842700969924878344958912736,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满1组减{15}元（9件为1组:需包含第1类任意4件，第2类任意5件）\",\"promotionDescCn\":\"满1组减15元（9件为1组:需包含第1类任意4件，第2类任意5件）\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"组合商品减{15}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466006400000,\"discountFactor\":30.0,\"discountTimes\":0,\"endDate\":1530806400000,\"gpOfferCategoryIds\":[419,314],\"gpOfferId\":201000003,\"gpThumbnailUrl\":\"1481607008575.png\",\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":3}],\"id\":27842700969924878344958912737,\"promotionActualDesc\":\"\",\"promotionDesc\":\"3件及以上享{7}折\",\"promotionDescCn\":\"3件及以上享7折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{7}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":1,\"endDate\":1546185600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000004,\"gpThumbnailUrl\":\"1481607023253.png\",\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":100.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":210.0,\"thresholdAmt\":0.0,\"thresholdQty\":4}]}],\"id\":27842700969924878344958912738,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件减{100}元，4件及以上减{210}元\",\"promotionDescCn\":\"2件减100元，4件及以上减210元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{100}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":1,\"endDate\":1546185600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000005,\"gpThumbnailUrl\":\"1481607033811.png\",\"gpTypeCode\":3,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":20.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":25.0,\"thresholdAmt\":0.0,\"thresholdQty\":4}]}],\"id\":27842700969924878344958912739,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件享{8}折，4件及以上享{7.5}折\",\"promotionDescCn\":\"2件享8折，4件及以上享7.5折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{8}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466006400000,\"discountFactor\":360.0,\"discountTimes\":0,\"endDate\":1530201600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000006,\"gpThumbnailUrl\":\"1481607046143.png\",\"gpTypeCode\":4,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700969924878344958912740,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件仅需{360}元\",\"promotionDescCn\":\"2件仅需360元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"2件{360}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466611200000,\"discountFactor\":20.0,\"discountTimes\":3,\"endDate\":1530806400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000008,\"gpThumbnailUrl\":\"1481607068917.png\",\"gpTypeCode\":6,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":105.0,\"thresholdQty\":0}],\"id\":27842700969924878344958912742,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满105元立减{20}元\",\"promotionDescCn\":\"满105元立减20元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{20}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1463587200000,\"discountFactor\":21.0,\"discountTimes\":0,\"endDate\":1530288000000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":2011000001,\"gpThumbnailUrl\":\"1481606976487.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700969924878344958912743,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满2件立减{21}元\",\"promotionDescCn\":\"满2件立减21元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{21}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466006400000,\"discountFactor\":29.0,\"discountTimes\":0,\"endDate\":1530806400000,\"gpOfferCategoryIds\":[419,314],\"gpOfferId\":2011000003,\"gpThumbnailUrl\":\"1481607008575.png\",\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":3}],\"id\":27842700969924878344958912744,\"promotionActualDesc\":\"\",\"promotionDesc\":\"3件及以上享{7.1}折\",\"promotionDescCn\":\"3件及以上享7.1折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{7.1}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":1,\"endDate\":1546185600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":2011000004,\"gpThumbnailUrl\":\"1481607023253.png\",\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":101.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":211.0,\"thresholdAmt\":0.0,\"thresholdQty\":4}]}],\"id\":27842700969924878344958912745,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件减{101}元，4件及以上减{211}元\",\"promotionDescCn\":\"2件减101元，4件及以上减211元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{101}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":1,\"endDate\":1546185600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":2011000005,\"gpThumbnailUrl\":\"1481607033811.png\",\"gpTypeCode\":3,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":19.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":24.0,\"thresholdAmt\":0.0,\"thresholdQty\":4}]}],\"id\":27842700969924878344958912746,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件享{8.1}折，4件及以上享{7.6}折\",\"promotionDescCn\":\"2件享8.1折，4件及以上享7.6折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{8.1}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466006400000,\"discountFactor\":361.0,\"discountTimes\":0,\"endDate\":1530201600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":2011000006,\"gpThumbnailUrl\":\"1481607046143.png\",\"gpTypeCode\":4,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700969924878344958912747,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件仅需{361}元\",\"promotionDescCn\":\"2件仅需361元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"2件{361}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466611200000,\"discountFactor\":21.0,\"discountTimes\":3,\"endDate\":1530806400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":2011000008,\"gpThumbnailUrl\":\"1481607068917.png\",\"gpTypeCode\":6,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":105.0,\"thresholdQty\":0}],\"id\":27842700969924878344958912748,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满105元立减{21}元\",\"promotionDescCn\":\"满105元立减21元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{21}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31001538805804L, 1538805804L, 3, new BigDecimal(198), 201000001, 1, new BigDecimal(20), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 3, new BigDecimal(198), 201000002, 1, new BigDecimal(0), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 3, new BigDecimal(198), 201000003, 1, new BigDecimal(178.2).setScale(2, RoundingMode.HALF_UP), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 3, new BigDecimal(198), 201000004, 1, new BigDecimal(100), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 3, new BigDecimal(198), 201000005, 1, new BigDecimal(118.8).setScale(2, RoundingMode.HALF_UP), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 3, new BigDecimal(198), 201000006, 1, new BigDecimal(36), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 3, new BigDecimal(198), 201000008, 1, new BigDecimal(60), 31001538805804L));
		items.add(new GpCartItem(31001538805802L, 1538805802L, 3, new BigDecimal(200), 2011000001, 1, new BigDecimal(21), 31001538805802L));
		items.add(new GpCartItem(31001538805802L, 1538805802L, 3, new BigDecimal(200), 2011000003, 1, new BigDecimal(174), 31001538805802L));
		items.add(new GpCartItem(31001538805802L, 1538805802L, 3, new BigDecimal(200), 2011000004, 1, new BigDecimal(101), 31001538805802L));
		items.add(new GpCartItem(31001538805802L, 1538805802L, 3, new BigDecimal(200), 2011000005, 1, new BigDecimal(114), 31001538805802L));
		items.add(new GpCartItem(31001538805802L, 1538805802L, 3, new BigDecimal(200), 2011000006, 1, new BigDecimal(39), 31001538805802L));
		items.add(new GpCartItem(31001538805802L, 1538805802L, 3, new BigDecimal(200), 2011000008, 1, new BigDecimal(63), 31001538805802L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest48() throws GlobalErrorInfoException {
		// 109多GP商品下单(itemA触发边界)+(itemB1满足)
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1463587200000,\"discountFactor\":20.0,\"discountTimes\":0,\"endDate\":1530288000000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000001,\"gpThumbnailUrl\":\"1481606976487.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361119,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满2件立减{20}元\",\"promotionDescCn\":\"满2件立减20元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{20}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1460304000000,\"discountFactor\":15.0,\"discountTimes\":0,\"endDate\":1546099200000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000002,\"gpThumbnailUrl\":\"1481606995664.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":4},{\"groupSeq\":2,\"thresholdAmt\":0.0,\"thresholdQty\":5}],\"id\":27842700969924878344958912736,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满1组减{15}元（9件为1组:需包含第1类任意4件，第2类任意5件）\",\"promotionDescCn\":\"满1组减15元（9件为1组:需包含第1类任意4件，第2类任意5件）\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"组合商品减{15}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466006400000,\"discountFactor\":30.0,\"discountTimes\":0,\"endDate\":1530806400000,\"gpOfferCategoryIds\":[419,314],\"gpOfferId\":201000003,\"gpThumbnailUrl\":\"1481607008575.png\",\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":3}],\"id\":27842700969924878344958912737,\"promotionActualDesc\":\"\",\"promotionDesc\":\"3件及以上享{7}折\",\"promotionDescCn\":\"3件及以上享7折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{7}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":1,\"endDate\":1546185600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000004,\"gpThumbnailUrl\":\"1481607023253.png\",\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":100.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":210.0,\"thresholdAmt\":0.0,\"thresholdQty\":4}]}],\"id\":27842700969924878344958912738,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件减{100}元，4件及以上减{210}元\",\"promotionDescCn\":\"2件减100元，4件及以上减210元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{100}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":1,\"endDate\":1546185600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000005,\"gpThumbnailUrl\":\"1481607033811.png\",\"gpTypeCode\":3,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":20.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":25.0,\"thresholdAmt\":0.0,\"thresholdQty\":4}]}],\"id\":27842700969924878344958912739,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件享{8}折，4件及以上享{7.5}折\",\"promotionDescCn\":\"2件享8折，4件及以上享7.5折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{8}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466006400000,\"discountFactor\":360.0,\"discountTimes\":0,\"endDate\":1530201600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000006,\"gpThumbnailUrl\":\"1481607046143.png\",\"gpTypeCode\":4,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700969924878344958912740,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件仅需{360}元\",\"promotionDescCn\":\"2件仅需360元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"2件{360}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466611200000,\"discountFactor\":20.0,\"discountTimes\":3,\"endDate\":1530806400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000008,\"gpThumbnailUrl\":\"1481607068917.png\",\"gpTypeCode\":6,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":105.0,\"thresholdQty\":0}],\"id\":27842700969924878344958912742,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满105元立减{20}元\",\"promotionDescCn\":\"满105元立减20元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{20}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1463587200000,\"discountFactor\":21.0,\"discountTimes\":0,\"endDate\":1530288000000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":2011000001,\"gpThumbnailUrl\":\"1481606976487.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700969924878344958912743,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满2件立减{21}元\",\"promotionDescCn\":\"满2件立减21元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{21}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466006400000,\"discountFactor\":29.0,\"discountTimes\":0,\"endDate\":1530806400000,\"gpOfferCategoryIds\":[419,314],\"gpOfferId\":2011000003,\"gpThumbnailUrl\":\"1481607008575.png\",\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":3}],\"id\":27842700969924878344958912744,\"promotionActualDesc\":\"\",\"promotionDesc\":\"3件及以上享{7.1}折\",\"promotionDescCn\":\"3件及以上享7.1折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{7.1}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":1,\"endDate\":1546185600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":2011000004,\"gpThumbnailUrl\":\"1481607023253.png\",\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":101.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":211.0,\"thresholdAmt\":0.0,\"thresholdQty\":4}]}],\"id\":27842700969924878344958912745,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件减{101}元，4件及以上减{211}元\",\"promotionDescCn\":\"2件减101元，4件及以上减211元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{101}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":1,\"endDate\":1546185600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":2011000005,\"gpThumbnailUrl\":\"1481607033811.png\",\"gpTypeCode\":3,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":19.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":24.0,\"thresholdAmt\":0.0,\"thresholdQty\":4}]}],\"id\":27842700969924878344958912746,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件享{8.1}折，4件及以上享{7.6}折\",\"promotionDescCn\":\"2件享8.1折，4件及以上享7.6折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{8.1}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466006400000,\"discountFactor\":361.0,\"discountTimes\":0,\"endDate\":1530201600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":2011000006,\"gpThumbnailUrl\":\"1481607046143.png\",\"gpTypeCode\":4,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700969924878344958912747,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件仅需{361}元\",\"promotionDescCn\":\"2件仅需361元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"2件{361}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466611200000,\"discountFactor\":21.0,\"discountTimes\":3,\"endDate\":1530806400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":2011000008,\"gpThumbnailUrl\":\"1481607068917.png\",\"gpTypeCode\":6,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":105.0,\"thresholdQty\":0}],\"id\":27842700969924878344958912748,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满105元立减{21}元\",\"promotionDescCn\":\"满105元立减21元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{21}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000001, 1, new BigDecimal(40), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000002, 1, new BigDecimal(0), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000003, 1, new BigDecimal(237.6).setScale(2, RoundingMode.HALF_UP), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000004, 1, new BigDecimal(210), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000005, 1, new BigDecimal(198), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000006, 1, new BigDecimal(72), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000008, 1, new BigDecimal(0), 31001538805804L));
		items.add(new GpCartItem(31001538805802L, 1538805802L, 3, new BigDecimal(200), 2011000001, 1, new BigDecimal(21), 31001538805802L));
		items.add(new GpCartItem(31001538805802L, 1538805802L, 3, new BigDecimal(200), 2011000003, 1, new BigDecimal(174), 31001538805802L));
		items.add(new GpCartItem(31001538805802L, 1538805802L, 3, new BigDecimal(200), 2011000004, 1, new BigDecimal(101), 31001538805802L));
		items.add(new GpCartItem(31001538805802L, 1538805802L, 3, new BigDecimal(200), 2011000005, 1, new BigDecimal(114), 31001538805802L));
		items.add(new GpCartItem(31001538805802L, 1538805802L, 3, new BigDecimal(200), 2011000006, 1, new BigDecimal(39), 31001538805802L));
		items.add(new GpCartItem(31001538805802L, 1538805802L, 3, new BigDecimal(200), 2011000008, 1, new BigDecimal(63), 31001538805802L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest49() throws GlobalErrorInfoException {
		// 110多GP商品下单(itemA触发边界)+(itemB2触发边界)
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1463587200000,\"discountFactor\":20.0,\"discountTimes\":0,\"endDate\":1530288000000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000001,\"gpThumbnailUrl\":\"1481606976487.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361119,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满2件立减{20}元\",\"promotionDescCn\":\"满2件立减20元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{20}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1460304000000,\"discountFactor\":15.0,\"discountTimes\":0,\"endDate\":1546099200000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000002,\"gpThumbnailUrl\":\"1481606995664.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":4},{\"groupSeq\":2,\"thresholdAmt\":0.0,\"thresholdQty\":5}],\"id\":27842700969924878344958912736,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满1组减{15}元（9件为1组:需包含第1类任意4件，第2类任意5件）\",\"promotionDescCn\":\"满1组减15元（9件为1组:需包含第1类任意4件，第2类任意5件）\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"组合商品减{15}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466006400000,\"discountFactor\":30.0,\"discountTimes\":0,\"endDate\":1530806400000,\"gpOfferCategoryIds\":[419,314],\"gpOfferId\":201000003,\"gpThumbnailUrl\":\"1481607008575.png\",\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":3}],\"id\":27842700969924878344958912737,\"promotionActualDesc\":\"\",\"promotionDesc\":\"3件及以上享{7}折\",\"promotionDescCn\":\"3件及以上享7折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{7}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":1,\"endDate\":1546185600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000004,\"gpThumbnailUrl\":\"1481607023253.png\",\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":100.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":210.0,\"thresholdAmt\":0.0,\"thresholdQty\":4}]}],\"id\":27842700969924878344958912738,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件减{100}元，4件及以上减{210}元\",\"promotionDescCn\":\"2件减100元，4件及以上减210元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{100}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":1,\"endDate\":1546185600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000005,\"gpThumbnailUrl\":\"1481607033811.png\",\"gpTypeCode\":3,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":20.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":25.0,\"thresholdAmt\":0.0,\"thresholdQty\":4}]}],\"id\":27842700969924878344958912739,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件享{8}折，4件及以上享{7.5}折\",\"promotionDescCn\":\"2件享8折，4件及以上享7.5折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{8}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466006400000,\"discountFactor\":360.0,\"discountTimes\":0,\"endDate\":1530201600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000006,\"gpThumbnailUrl\":\"1481607046143.png\",\"gpTypeCode\":4,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700969924878344958912740,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件仅需{360}元\",\"promotionDescCn\":\"2件仅需360元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"2件{360}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466611200000,\"discountFactor\":20.0,\"discountTimes\":3,\"endDate\":1530806400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000008,\"gpThumbnailUrl\":\"1481607068917.png\",\"gpTypeCode\":6,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":105.0,\"thresholdQty\":0}],\"id\":27842700969924878344958912742,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满105元立减{20}元\",\"promotionDescCn\":\"满105元立减20元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{20}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1463587200000,\"discountFactor\":21.0,\"discountTimes\":0,\"endDate\":1530288000000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":2011000001,\"gpThumbnailUrl\":\"1481606976487.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700969924878344958912743,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满2件立减{21}元\",\"promotionDescCn\":\"满2件立减21元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{21}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466006400000,\"discountFactor\":29.0,\"discountTimes\":0,\"endDate\":1530806400000,\"gpOfferCategoryIds\":[419,314],\"gpOfferId\":2011000003,\"gpThumbnailUrl\":\"1481607008575.png\",\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":3}],\"id\":27842700969924878344958912744,\"promotionActualDesc\":\"\",\"promotionDesc\":\"3件及以上享{7.1}折\",\"promotionDescCn\":\"3件及以上享7.1折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{7.1}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":1,\"endDate\":1546185600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":2011000004,\"gpThumbnailUrl\":\"1481607023253.png\",\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":101.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":211.0,\"thresholdAmt\":0.0,\"thresholdQty\":4}]}],\"id\":27842700969924878344958912745,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件减{101}元，4件及以上减{211}元\",\"promotionDescCn\":\"2件减101元，4件及以上减211元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{101}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":1,\"endDate\":1546185600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":2011000005,\"gpThumbnailUrl\":\"1481607033811.png\",\"gpTypeCode\":3,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":19.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":24.0,\"thresholdAmt\":0.0,\"thresholdQty\":4}]}],\"id\":27842700969924878344958912746,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件享{8.1}折，4件及以上享{7.6}折\",\"promotionDescCn\":\"2件享8.1折，4件及以上享7.6折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{8.1}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466006400000,\"discountFactor\":361.0,\"discountTimes\":0,\"endDate\":1530201600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":2011000006,\"gpThumbnailUrl\":\"1481607046143.png\",\"gpTypeCode\":4,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700969924878344958912747,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件仅需{361}元\",\"promotionDescCn\":\"2件仅需361元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"2件{361}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466611200000,\"discountFactor\":21.0,\"discountTimes\":3,\"endDate\":1530806400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":2011000008,\"gpThumbnailUrl\":\"1481607068917.png\",\"gpTypeCode\":6,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":105.0,\"thresholdQty\":0}],\"id\":27842700969924878344958912748,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满105元立减{21}元\",\"promotionDescCn\":\"满105元立减21元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{21}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000001, 1, new BigDecimal(40), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000002, 1, new BigDecimal(0), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000003, 1, new BigDecimal(237.6).setScale(2, RoundingMode.HALF_UP), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000004, 1, new BigDecimal(210), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000005, 1, new BigDecimal(198), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000006, 1, new BigDecimal(72), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000008, 1, new BigDecimal(0), 31001538805804L));
		items.add(new GpCartItem(31030008718001L, 30008718001L, 3, new BigDecimal(200), 2011000001, 1, new BigDecimal(21), 31030008718001L));
		items.add(new GpCartItem(31030008718001L, 30008718001L, 3, new BigDecimal(200), 2011000003, 1, new BigDecimal(174), 31030008718001L));
		items.add(new GpCartItem(31030008718001L, 30008718001L, 3, new BigDecimal(200), 2011000004, 1, new BigDecimal(101), 31030008718001L));
		items.add(new GpCartItem(31030008718001L, 30008718001L, 3, new BigDecimal(200), 2011000005, 1, new BigDecimal(114), 31030008718001L));
		items.add(new GpCartItem(31030008718001L, 30008718001L, 3, new BigDecimal(200), 2011000006, 1, new BigDecimal(39), 31030008718001L));
		items.add(new GpCartItem(31030008718001L, 30008718001L, 3, new BigDecimal(200), 2011000008, 1, new BigDecimal(63), 31030008718001L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest50() throws GlobalErrorInfoException {
		// 111多GP商品下单(itemA触发边界)+(itemB3触发边界)
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1463587200000,\"discountFactor\":20.0,\"discountTimes\":0,\"endDate\":1530288000000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000001,\"gpThumbnailUrl\":\"1481606976487.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361119,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满2件立减{20}元\",\"promotionDescCn\":\"满2件立减20元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{20}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1460304000000,\"discountFactor\":15.0,\"discountTimes\":0,\"endDate\":1546099200000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000002,\"gpThumbnailUrl\":\"1481606995664.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":4},{\"groupSeq\":2,\"thresholdAmt\":0.0,\"thresholdQty\":5}],\"id\":27842700969924878344958912736,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满1组减{15}元（9件为1组:需包含第1类任意4件，第2类任意5件）\",\"promotionDescCn\":\"满1组减15元（9件为1组:需包含第1类任意4件，第2类任意5件）\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"组合商品减{15}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466006400000,\"discountFactor\":30.0,\"discountTimes\":0,\"endDate\":1530806400000,\"gpOfferCategoryIds\":[419,314],\"gpOfferId\":201000003,\"gpThumbnailUrl\":\"1481607008575.png\",\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":3}],\"id\":27842700969924878344958912737,\"promotionActualDesc\":\"\",\"promotionDesc\":\"3件及以上享{7}折\",\"promotionDescCn\":\"3件及以上享7折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{7}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":1,\"endDate\":1546185600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000004,\"gpThumbnailUrl\":\"1481607023253.png\",\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":100.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":210.0,\"thresholdAmt\":0.0,\"thresholdQty\":4}]}],\"id\":27842700969924878344958912738,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件减{100}元，4件及以上减{210}元\",\"promotionDescCn\":\"2件减100元，4件及以上减210元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{100}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":1,\"endDate\":1546185600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000005,\"gpThumbnailUrl\":\"1481607033811.png\",\"gpTypeCode\":3,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":20.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":25.0,\"thresholdAmt\":0.0,\"thresholdQty\":4}]}],\"id\":27842700969924878344958912739,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件享{8}折，4件及以上享{7.5}折\",\"promotionDescCn\":\"2件享8折，4件及以上享7.5折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{8}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466006400000,\"discountFactor\":360.0,\"discountTimes\":0,\"endDate\":1530201600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000006,\"gpThumbnailUrl\":\"1481607046143.png\",\"gpTypeCode\":4,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700969924878344958912740,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件仅需{360}元\",\"promotionDescCn\":\"2件仅需360元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"2件{360}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466611200000,\"discountFactor\":20.0,\"discountTimes\":3,\"endDate\":1530806400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000008,\"gpThumbnailUrl\":\"1481607068917.png\",\"gpTypeCode\":6,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":105.0,\"thresholdQty\":0}],\"id\":27842700969924878344958912742,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满105元立减{20}元\",\"promotionDescCn\":\"满105元立减20元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{20}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1463587200000,\"discountFactor\":21.0,\"discountTimes\":0,\"endDate\":1530288000000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":2011000001,\"gpThumbnailUrl\":\"1481606976487.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700969924878344958912743,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满2件立减{21}元\",\"promotionDescCn\":\"满2件立减21元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{21}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466006400000,\"discountFactor\":29.0,\"discountTimes\":0,\"endDate\":1530806400000,\"gpOfferCategoryIds\":[419,314],\"gpOfferId\":2011000003,\"gpThumbnailUrl\":\"1481607008575.png\",\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":3}],\"id\":27842700969924878344958912744,\"promotionActualDesc\":\"\",\"promotionDesc\":\"3件及以上享{7.1}折\",\"promotionDescCn\":\"3件及以上享7.1折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{7.1}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":1,\"endDate\":1546185600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":2011000004,\"gpThumbnailUrl\":\"1481607023253.png\",\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":101.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":211.0,\"thresholdAmt\":0.0,\"thresholdQty\":4}]}],\"id\":27842700969924878344958912745,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件减{101}元，4件及以上减{211}元\",\"promotionDescCn\":\"2件减101元，4件及以上减211元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{101}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":1,\"endDate\":1546185600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":2011000005,\"gpThumbnailUrl\":\"1481607033811.png\",\"gpTypeCode\":3,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":19.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":24.0,\"thresholdAmt\":0.0,\"thresholdQty\":4}]}],\"id\":27842700969924878344958912746,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件享{8.1}折，4件及以上享{7.6}折\",\"promotionDescCn\":\"2件享8.1折，4件及以上享7.6折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{8.1}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466006400000,\"discountFactor\":361.0,\"discountTimes\":0,\"endDate\":1530201600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":2011000006,\"gpThumbnailUrl\":\"1481607046143.png\",\"gpTypeCode\":4,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700969924878344958912747,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件仅需{361}元\",\"promotionDescCn\":\"2件仅需361元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"2件{361}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466611200000,\"discountFactor\":50.0,\"discountTimes\":5,\"endDate\":1530806400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":2012000008,\"gpThumbnailUrl\":\"1481607068917.png\",\"gpTypeCode\":6,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":105.0,\"thresholdQty\":0}],\"id\":27842700637883485018186983598,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满105元立减{50}元\",\"promotionDescCn\":\"满105元立减50元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"满105元减{50}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000001, 1, new BigDecimal(40), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000002, 1, new BigDecimal(0), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000003, 1, new BigDecimal(237.6).setScale(2, RoundingMode.HALF_UP), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000004, 1, new BigDecimal(210), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000005, 1, new BigDecimal(198), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000006, 1, new BigDecimal(72), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000008, 1, new BigDecimal(0), 31001538805804L));
		items.add(new GpCartItem(31691462121086L, 691462121086L, 3, new BigDecimal(200), 2011000001, 1, new BigDecimal(21), 31691462121086L));
		items.add(new GpCartItem(31691462121086L, 691462121086L, 3, new BigDecimal(200), 2011000003, 1, new BigDecimal(174), 31691462121086L));
		items.add(new GpCartItem(31691462121086L, 691462121086L, 3, new BigDecimal(200), 2011000004, 1, new BigDecimal(101), 31691462121086L));
		items.add(new GpCartItem(31691462121086L, 691462121086L, 3, new BigDecimal(200), 2011000005, 1, new BigDecimal(114), 31691462121086L));
		items.add(new GpCartItem(31691462121086L, 691462121086L, 3, new BigDecimal(200), 2011000006, 1, new BigDecimal(39), 31691462121086L));
		items.add(new GpCartItem(31691462121086L, 691462121086L, 3, new BigDecimal(200), 2012000008, 1, new BigDecimal(0), 31691462121086L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest51() throws GlobalErrorInfoException {
		// 112多GP商品下单(itemA触发边界)
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1463587200000,\"discountFactor\":20.0,\"discountTimes\":0,\"endDate\":1530288000000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000001,\"gpThumbnailUrl\":\"1481606976487.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361119,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满2件立减{20}元\",\"promotionDescCn\":\"满2件立减20元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{20}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1460304000000,\"discountFactor\":15.0,\"discountTimes\":0,\"endDate\":1546099200000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000002,\"gpThumbnailUrl\":\"1481606995664.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":4},{\"groupSeq\":2,\"thresholdAmt\":0.0,\"thresholdQty\":5}],\"id\":27842700969924878344958912736,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满1组减{15}元（9件为1组:需包含第1类任意4件，第2类任意5件）\",\"promotionDescCn\":\"满1组减15元（9件为1组:需包含第1类任意4件，第2类任意5件）\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"组合商品减{15}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466006400000,\"discountFactor\":30.0,\"discountTimes\":0,\"endDate\":1530806400000,\"gpOfferCategoryIds\":[419,314],\"gpOfferId\":201000003,\"gpThumbnailUrl\":\"1481607008575.png\",\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":3}],\"id\":27842700969924878344958912737,\"promotionActualDesc\":\"\",\"promotionDesc\":\"3件及以上享{7}折\",\"promotionDescCn\":\"3件及以上享7折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{7}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":1,\"endDate\":1546185600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000004,\"gpThumbnailUrl\":\"1481607023253.png\",\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":100.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":210.0,\"thresholdAmt\":0.0,\"thresholdQty\":4}]}],\"id\":27842700969924878344958912738,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件减{100}元，4件及以上减{210}元\",\"promotionDescCn\":\"2件减100元，4件及以上减210元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{100}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":1,\"endDate\":1546185600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000005,\"gpThumbnailUrl\":\"1481607033811.png\",\"gpTypeCode\":3,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":20.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":25.0,\"thresholdAmt\":0.0,\"thresholdQty\":4}]}],\"id\":27842700969924878344958912739,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件享{8}折，4件及以上享{7.5}折\",\"promotionDescCn\":\"2件享8折，4件及以上享7.5折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{8}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466006400000,\"discountFactor\":360.0,\"discountTimes\":0,\"endDate\":1530201600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000006,\"gpThumbnailUrl\":\"1481607046143.png\",\"gpTypeCode\":4,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700969924878344958912740,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件仅需{360}元\",\"promotionDescCn\":\"2件仅需360元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"2件{360}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466611200000,\"discountFactor\":20.0,\"discountTimes\":3,\"endDate\":1530806400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000008,\"gpThumbnailUrl\":\"1481607068917.png\",\"gpTypeCode\":6,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":105.0,\"thresholdQty\":0}],\"id\":27842700969924878344958912742,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满105元立减{20}元\",\"promotionDescCn\":\"满105元立减20元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{20}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000001, 1, new BigDecimal(40), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000002, 1, new BigDecimal(0), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000003, 1, new BigDecimal(237.6).setScale(2, RoundingMode.HALF_UP), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000004, 1, new BigDecimal(210), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000005, 1, new BigDecimal(198), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000006, 1, new BigDecimal(72), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000008, 1, new BigDecimal(0), 31001538805804L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest52() throws GlobalErrorInfoException {
		// 113 多GP异常测试(itemA满足)
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"backgroundColor\":3451600,\"beginDate\":1463587200000,\"discountFactor\":20.0,\"discountTimes\":0,\"endDate\":1530288000000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000001,\"gpThumbnailUrl\":\"1481606976487.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700951478134271249361119,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满2件立减{20}元\",\"promotionDescCn\":\"满2件立减20元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{20}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1460304000000,\"discountFactor\":15.0,\"discountTimes\":0,\"endDate\":1546099200000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000002,\"gpThumbnailUrl\":\"1481606995664.png\",\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":4},{\"groupSeq\":2,\"thresholdAmt\":0.0,\"thresholdQty\":5}],\"id\":27842700969924878344958912736,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满1组减{15}元（9件为1组:需包含第1类任意4件，第2类任意5件）\",\"promotionDescCn\":\"满1组减15元（9件为1组:需包含第1类任意4件，第2类任意5件）\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"组合商品减{15}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466006400000,\"discountFactor\":30.0,\"discountTimes\":0,\"endDate\":1530806400000,\"gpOfferCategoryIds\":[419,314],\"gpOfferId\":201000003,\"gpThumbnailUrl\":\"1481607008575.png\",\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":3}],\"id\":27842700969924878344958912737,\"promotionActualDesc\":\"\",\"promotionDesc\":\"3件及以上享{7}折\",\"promotionDescCn\":\"3件及以上享7折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{7}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":1,\"endDate\":1546185600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000004,\"gpThumbnailUrl\":\"1481607023253.png\",\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":100.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":210.0,\"thresholdAmt\":0.0,\"thresholdQty\":4}]}],\"id\":27842700969924878344958912738,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件减{100}元，4件及以上减{210}元\",\"promotionDescCn\":\"2件减100元，4件及以上减210元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{100}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1451577600000,\"discountFactor\":0.0,\"discountTimes\":1,\"endDate\":1546185600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000005,\"gpThumbnailUrl\":\"1481607033811.png\",\"gpTypeCode\":3,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":20.0,\"thresholdAmt\":0.0,\"thresholdQty\":2},{\"discountFactor\":25.0,\"thresholdAmt\":0.0,\"thresholdQty\":4}]}],\"id\":27842700969924878344958912739,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件享{8}折，4件及以上享{7.5}折\",\"promotionDescCn\":\"2件享8折，4件及以上享7.5折\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{8}折\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466006400000,\"discountFactor\":360.0,\"discountTimes\":0,\"endDate\":1530201600000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000006,\"gpThumbnailUrl\":\"1481607046143.png\",\"gpTypeCode\":4,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":0.0,\"thresholdQty\":2}],\"id\":27842700969924878344958912740,\"promotionActualDesc\":\"\",\"promotionDesc\":\"2件仅需{360}元\",\"promotionDescCn\":\"2件仅需360元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"2件{360}元\",\"status\":0},{\"backgroundColor\":3451600,\"beginDate\":1466611200000,\"discountFactor\":20.0,\"discountTimes\":3,\"endDate\":1530806400000,\"gpOfferCategoryIds\":[419],\"gpOfferId\":201000008,\"gpThumbnailUrl\":\"1481607068917.png\",\"gpTypeCode\":6,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":105.0,\"thresholdQty\":0}],\"id\":27842700969924878344958912742,\"promotionActualDesc\":\"\",\"promotionDesc\":\"满105元立减{20}元\",\"promotionDescCn\":\"满105元立减20元\",\"promotionDescEn\":\"\",\"promotionTitleCn\":\"{20}元\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers); // 回放动作
		mocksControl.replay(); // 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class); // 执行测试方法

		items.add(new GpCartItem(31001538805804L, 1538805804L, 3, new BigDecimal(198), 201000001, 1, new BigDecimal(20), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 3, new BigDecimal(198), 201000002, 1, new BigDecimal(0), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 3, new BigDecimal(198), 201000003, 1, new BigDecimal(178.2).setScale(2, RoundingMode.HALF_UP), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 3, new BigDecimal(198), 201000004, 1, new BigDecimal(100), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 3, new BigDecimal(198), 201000005, 1, new BigDecimal(118.8).setScale(2, RoundingMode.HALF_UP), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 3, new BigDecimal(198), 201000006, 1, new BigDecimal(36), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 3, new BigDecimal(198), 201000008, 1, new BigDecimal(60), 31001538805804L));
		calAndValidGp(items);

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}


	private void calAndValidGp(List<GpCartItem> items) {
		BigDecimal totalDiscount = BigDecimal.ZERO;
		CalcDiscountResult calcDiscountResult = promotionService.calculateInItemLevel(items);
		Map<Integer, List<GpCartItem>> returnItems = calcDiscountResult.getGpOfferDiscounts();
		for (GpCartItem gpCartItem : items) {
			totalDiscount = totalDiscount.add(gpCartItem.getClientDiscount());
			if (returnItems != null && !returnItems.isEmpty()) {
				List<GpCartItem> gpCartItemList = returnItems.get(gpCartItem.getGpOfferId());
				LOG.info("the gpOfferId is =================== {}", gpCartItem.getGpOfferId());
				for (GpCartItem calGpCartItem : gpCartItemList) {
					if (gpCartItem.getProductId().equals(calGpCartItem.getProductId())) {
						Assert.isTrue(gpCartItem.getClientDiscount().compareTo(calGpCartItem.getGpDiscount()) == 0, "");
					}
				}
			}
		}
		Assert.isTrue(totalDiscount.compareTo(calcDiscountResult.getTotalDiscount()) == 0, "result error");
	}

}