package com.walmart.mobile.checkout.service.promotion;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.easymock.EasyMock;
import org.easymock.IMocksControl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.Assert;

import com.alibaba.fastjson.JSON;
import com.walmart.mobile.checkout.bo.promotion.GpCartItem;
import com.walmart.mobile.checkout.config.MainConfig;
import com.walmart.mobile.checkout.entity.promotion.GpOffer;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.repo.GpOfferRepository;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MainConfig.class })
@WebAppConfiguration
public class GlobalPromotionServiceMockTest {
	@Autowired
	PromotionService promotionService;


	@Test
	public void promotionServiceCalcDiscountTest1() throws GlobalErrorInfoException {
		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// *** 0-买立减
		// *** 买X达到规定个数立减N元
		// *** 买X和Y立减N元
		// *** 1.X可以是同一商品或不同商品
		// *** 2.可以设定不同的商品组
		// *** 可以多倍折扣(买X减N，买2X减2N)
		// *** 可多组（X+Y减N，买2X+4Y减2N）
		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// 0-买立减
		// 购买参加本活动的任意商品每满2件立减5元
		// gpOfferId 为 1000000
		// 单组,不满足条件,1件商品

		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = " [{\"beginDate\":1436716800000,\"discountFactor\":5.0,\"endDate\":1444665600000,\"gpOfferId\":1100000,\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":2}],\"id\":27955661842130692903563027876,\"promotionDesc\":\"购买参加本活动的任意商品每满2件立减5元\",\"promotionDescCn\":\"购买参加本活动的任意商品每满2件立减5元\",\"promotionDescEn\":\"\",\"status\":0},{\"beginDate\":1436716800000,\"discountFactor\":200.0,\"endDate\":1444665600000,\"gpOfferId\":1100001,\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":1},{\"groupSeq\":2,\"thresholdQty\":1}],\"id\":27955661842130692903563027878,\"promotionDesc\":\"购买参加本活动任意商品满1组减200元（2件为1组:需包含第1类任意1件，第2类任意1件）\",\"promotionDescCn\":\"购买参加本活动任意商品满1组减200元（2件为1组:需包含第1类任意1件，第2类任意1件）\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000001L, 1L, 1, new BigDecimal("20.00"), 1100000, 1, new BigDecimal("0.0"), 1000000000001L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("0.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest2() throws GlobalErrorInfoException {
		// 0-买立减
		// 购买参加本活动的任意商品每满2件立减5元
		// gpOfferId 为 1000000
		// 单组, 满足条件 , 单倍, 2件商品

		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = " [{\"beginDate\":1436716800000,\"discountFactor\":5.0,\"endDate\":1444665600000,\"gpOfferId\":1100000,\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":2}],\"id\":27955661842130692903563027876,\"promotionDesc\":\"购买参加本活动的任意商品每满2件立减5元\",\"promotionDescCn\":\"购买参加本活动的任意商品每满2件立减5元\",\"promotionDescEn\":\"\",\"status\":0},{\"beginDate\":1436716800000,\"discountFactor\":200.0,\"endDate\":1444665600000,\"gpOfferId\":1100001,\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":1},{\"groupSeq\":2,\"thresholdQty\":1}],\"id\":27955661842130692903563027878,\"promotionDesc\":\"购买参加本活动任意商品满1组减200元（2件为1组:需包含第1类任意1件，第2类任意1件）\",\"promotionDescCn\":\"购买参加本活动任意商品满1组减200元（2件为1组:需包含第1类任意1件，第2类任意1件）\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000001L, 1L, 2, new BigDecimal("20.00"), 1100000, 1, new BigDecimal("5.0"), 1000000000001L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("5.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest3() throws GlobalErrorInfoException {
		// 0-买立减
		// 购买参加本活动的任意商品每满2件立减5元
		// gpOfferId 为 1000000
		// 单组,满足条件, 多倍, 5件 商品
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = " [{\"beginDate\":1436716800000,\"discountFactor\":5.0,\"endDate\":1444665600000,\"gpOfferId\":1100000,\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":2}],\"id\":27955661842130692903563027876,\"promotionDesc\":\"购买参加本活动的任意商品每满2件立减5元\",\"promotionDescCn\":\"购买参加本活动的任意商品每满2件立减5元\",\"promotionDescEn\":\"\",\"status\":0},{\"beginDate\":1436716800000,\"discountFactor\":200.0,\"endDate\":1444665600000,\"gpOfferId\":1100001,\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":1},{\"groupSeq\":2,\"thresholdQty\":1}],\"id\":27955661842130692903563027878,\"promotionDesc\":\"购买参加本活动任意商品满1组减200元（2件为1组:需包含第1类任意1件，第2类任意1件）\",\"promotionDescCn\":\"购买参加本活动任意商品满1组减200元（2件为1组:需包含第1类任意1件，第2类任意1件）\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000001L, 1L, 5, new BigDecimal("20.00"), 1100000, 1, new BigDecimal("10.0"), 1000000000001L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("10.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest4() throws GlobalErrorInfoException {
		// 0-买立减
		// 购买参加本活动任意商品满1组减200元（2件为1组:需包含第1类任意1件，第2类任意1件）
		// gpOfferId 为 1000001
		// 多组,不满足条件, 单倍 , 1件商品X和0件商品Y
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"beginDate\":1436716800000,\"discountFactor\":200.0,\"endDate\":1444665600000,\"gpOfferId\":1100001,\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":1},{\"groupSeq\":2,\"thresholdQty\":1}],\"id\":27955674238342710458929367096,\"promotionDesc\":\"购买参加本活动任意商品满1组减200元（2件为1组:需包含第1类任意1件，第2类任意1件）\",\"promotionDescCn\":\"购买参加本活动任意商品满1组减200元（2件为1组:需包含第1类任意1件，第2类任意1件）\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000002L, 2L, 1, new BigDecimal("250.0"), 1100001, 1, new BigDecimal("0.0"), 1000000000002L));
		// items.add(new GpCartItem(101L,0, new BigDecimal("220.0"),1000001,2));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("0.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest5() throws GlobalErrorInfoException {
		// 0-买立减
		// 购买参加本活动任意商品满1组减200元（2件为1组:需包含第1类任意1件，第2类任意1件）
		// gpOfferId 为 1000001
		// 多组,不满足条件, 单倍 , 0件商品X和1件商品Y
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"beginDate\":1436716800000,\"discountFactor\":200.0,\"endDate\":1444665600000,\"gpOfferId\":1100001,\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":1},{\"groupSeq\":2,\"thresholdQty\":1}],\"id\":27955674238342710458929367096,\"promotionDesc\":\"购买参加本活动任意商品满1组减200元（2件为1组:需包含第1类任意1件，第2类任意1件）\",\"promotionDescCn\":\"购买参加本活动任意商品满1组减200元（2件为1组:需包含第1类任意1件，第2类任意1件）\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000003L, 3L, 1, new BigDecimal("220.0"), 1100001, 2, new BigDecimal("0.0"), 1000000000003L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("0.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest6() throws GlobalErrorInfoException {
		// 0-买立减 // 购买参加本活动任意商品满1组减200元（2件为1组:需包含第1类任意1件，第2类任意1件） // gpOfferId 为
		// 1000001 // 多组,满足条件, 单倍 , X和Y各 1 件
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"beginDate\":1436716800000,\"discountFactor\":200.0,\"endDate\":1444665600000,\"gpOfferId\":1100001,\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":1},{\"groupSeq\":2,\"thresholdQty\":1}],\"id\":27955674238342710458929367096,\"promotionDesc\":\"购买参加本活动任意商品满1组减200元（2件为1组:需包含第1类任意1件，第2类任意1件）\",\"promotionDescCn\":\"购买参加本活动任意商品满1组减200元（2件为1组:需包含第1类任意1件，第2类任意1件）\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000002L, 2L, 1, new BigDecimal("250.0"), 1100001, 1, new BigDecimal("106.38"), 1000000000002L));
		items.add(new GpCartItem(1000000000003L, 3L, 1, new BigDecimal("220.0"), 1100001, 2, new BigDecimal("93.62"), 1000000000003L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("200.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest7() throws GlobalErrorInfoException {
		// 0-买立减
		// 购买参加本活动任意商品满1组减200元（2件为1组:需包含第1类任意1件，第2类任意1件）
		// gpOfferId 为 1000001
		// 多组,满足条件, 多倍, 3X+2Y (3件X,2件Y)
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"beginDate\":1436716800000,\"discountFactor\":200.0,\"endDate\":1444665600000,\"gpOfferId\":1100001,\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":1},{\"groupSeq\":2,\"thresholdQty\":1}],\"id\":27955674238342710458929367096,\"promotionDesc\":\"购买参加本活动任意商品满1组减200元（2件为1组:需包含第1类任意1件，第2类任意1件）\",\"promotionDescCn\":\"购买参加本活动任意商品满1组减200元（2件为1组:需包含第1类任意1件，第2类任意1件）\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000002L, 2L, 3, new BigDecimal("250.0"), 1100001, 1, new BigDecimal("252.10"), 1000000000002L));
		items.add(new GpCartItem(1000000000003L, 3L, 2, new BigDecimal("220.0"), 1100001, 2, new BigDecimal("147.90"), 1000000000003L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("400.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest8() throws GlobalErrorInfoException {
		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// *** 1-折扣
		// *** 买X得N%折扣
		// *** 1.X可以是同一商品或不同商品
		// *** 2.只可建立一个商品组
		// *** 3.只能设定享受优惠的最低商品购买个数，只要满足最低要求，就能享受规定折扣
		// *** 不可多倍折扣
		// *** 不可多组（否则POS计算错误）
		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// 1-折扣 // 购买参加本活动的任意商品2件及以上享8.8折 // gpOfferId 为 1000010 // 单组,不满条件,
		// 1件商品
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"beginDate\":1436716800000,\"discountFactor\":12.0,\"endDate\":1444665600000,\"gpOfferId\":1100010,\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":2}],\"id\":27955682078208941818979830731,\"promotionDesc\":\"购买参加本活动的任意商品2件及以上享8.8折\",\"promotionDescCn\":\"购买参加本活动的任意商品2件及以上享8.8折\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000005L, 5L, 1, new BigDecimal("150"), 1100010, 1, new BigDecimal("0.0"), 1000000000005L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("0.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest9() throws GlobalErrorInfoException {
		// 1-折扣 // 购买参加本活动的任意商品2件及以上享8.8折 // gpOfferId 为 1000010 // 单组,满足条件,单倍,
		// 2件商品
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"beginDate\":1436716800000,\"discountFactor\":12.0,\"endDate\":1444665600000,\"gpOfferId\":1100010,\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":2}],\"id\":27955682078208941818979830731,\"promotionDesc\":\"购买参加本活动的任意商品2件及以上享8.8折\",\"promotionDescCn\":\"购买参加本活动的任意商品2件及以上享8.8折\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000005L, 5L, 2, new BigDecimal("150"), 1100010, 1, new BigDecimal("36.0"), 1000000000005L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("36.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest10() throws GlobalErrorInfoException {

		// 1-折扣 // 购买参加本活动的任意商品2件及以上享8.8折 // gpOfferId 为 1000010 // 单组,满足条件 ,多倍,
		// 5件商品
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"beginDate\":1436716800000,\"discountFactor\":12.0,\"endDate\":1444665600000,\"gpOfferId\":1100010,\"gpTypeCode\":1,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":2}],\"id\":27955682078208941818979830731,\"promotionDesc\":\"购买参加本活动的任意商品2件及以上享8.8折\",\"promotionDescCn\":\"购买参加本活动的任意商品2件及以上享8.8折\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000005L, 5L, 5, new BigDecimal("150"), 1100010, 1, new BigDecimal("90.0"), 1000000000005L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("90.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest11() throws GlobalErrorInfoException {
		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// *** 2-阶梯式现金返还
		// *** 买更多减更多
		// *** 买X达到规定个数立减N元
		// *** (立减金额随着商品数量的增加而增加)
		// *** 1. X可以是同一商品或不同商品
		// *** 2. 阶梯最多不超过四级
		// *** 3.设置时需要清楚界定每一级别的商品数量规定
		// *** 不可多倍折扣
		// *** 不可多组（否则POS计算错误）
		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++

		// 2-阶梯式现金返还 // 购买参加本活动的任意商品满2件立减5元;满5件立减15元 // gpOfferId 为 1000020
		// 单组, 不满足条件, 1件商品
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"beginDate\":1436716800000,\"discountFactor\":0.0,\"endDate\":1444665600000,\"gpOfferId\":1100020,\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":5.0,\"thresholdQty\":2},{\"discountFactor\":15.0,\"thresholdQty\":5}]}],\"id\":27955688350101926880551456274,\"promotionDesc\":\"购买参加本活动的任意商品满2件立减5元;满5件立减15元\",\"promotionDescCn\":\"购买参加本活动的任意商品满2件立减5元;满5件立减15元\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000006L, 6L, 1, new BigDecimal("99"), 1100020, 1, new BigDecimal("0.0"), 1000000000006L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("0.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest12() throws GlobalErrorInfoException {
		// 2-阶梯式现金返还 // 购买参加本活动的任意商品满2件立减5元;满5件立减15元 // gpOfferId 为 1000020
		// 单组 , 满足一级阶梯条件, 2件商口
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"beginDate\":1436716800000,\"discountFactor\":0.0,\"endDate\":1444665600000,\"gpOfferId\":1100020,\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":5.0,\"thresholdQty\":2},{\"discountFactor\":15.0,\"thresholdQty\":5}]}],\"id\":27955688350101926880551456274,\"promotionDesc\":\"购买参加本活动的任意商品满2件立减5元;满5件立减15元\",\"promotionDescCn\":\"购买参加本活动的任意商品满2件立减5元;满5件立减15元\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000006L, 6L, 2, new BigDecimal("99"), 1100020, 1, new BigDecimal("5.0"), 1000000000006L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("5.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest13() throws GlobalErrorInfoException {
		// 2-阶梯式现金返还 // 购买参加本活动的任意商品满2件立减5元;满5件立减15元 // gpOfferId 为 1000020
		// 单组, 满足1级阶梯倍数,但不满足2级阶梯, 4件商品
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"beginDate\":1436716800000,\"discountFactor\":0.0,\"endDate\":1444665600000,\"gpOfferId\":1100020,\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":5.0,\"thresholdQty\":2},{\"discountFactor\":15.0,\"thresholdQty\":5}]}],\"id\":27955688350101926880551456274,\"promotionDesc\":\"购买参加本活动的任意商品满2件立减5元;满5件立减15元\",\"promotionDescCn\":\"购买参加本活动的任意商品满2件立减5元;满5件立减15元\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000006L, 6L, 4, new BigDecimal("99"), 1100020, 1, new BigDecimal("5.0"), 1000000000006L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("5.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest14() throws GlobalErrorInfoException {
		// 2-阶梯式现金返还 // 购买参加本活动的任意商品满2件立减5元;满5件立减15元 // gpOfferId 为 1000020
		// 单组, 满足2级阶梯, 5件商品
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"beginDate\":1436716800000,\"discountFactor\":0.0,\"endDate\":1444665600000,\"gpOfferId\":1100020,\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":5.0,\"thresholdQty\":2},{\"discountFactor\":15.0,\"thresholdQty\":5}]}],\"id\":27955688350101926880551456274,\"promotionDesc\":\"购买参加本活动的任意商品满2件立减5元;满5件立减15元\",\"promotionDescCn\":\"购买参加本活动的任意商品满2件立减5元;满5件立减15元\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000006L, 6L, 5, new BigDecimal("99"), 1100020, 1, new BigDecimal("15.0"), 1000000000006L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("15.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest15() throws GlobalErrorInfoException {
		// 2-阶梯式现金返还 // 购买参加本活动的任意商品满2件立减5元;满5件立减15元 // gpOfferId 为 1000020
		// 单组, 满足1,2级阶梯公倍数, 10件商品
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"beginDate\":1436716800000,\"discountFactor\":0.0,\"endDate\":1444665600000,\"gpOfferId\":1100020,\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":5.0,\"thresholdQty\":2},{\"discountFactor\":15.0,\"thresholdQty\":5}]}],\"id\":27955688350101926880551456274,\"promotionDesc\":\"购买参加本活动的任意商品满2件立减5元;满5件立减15元\",\"promotionDescCn\":\"购买参加本活动的任意商品满2件立减5元;满5件立减15元\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000006L, 6L, 10, new BigDecimal("99"), 1100020, 1, new BigDecimal("15.0"), 1000000000006L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("15.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest16() throws GlobalErrorInfoException {
		// 2-阶梯式现金返还 // 购买参加本活动的任意商品满2件立减5元;满5件立减15元 // gpOfferId 为 1000020
		// 单组 , 满足2级阶梯倍数,不满足1级阶梯倍数, 15件商品
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"beginDate\":1436716800000,\"discountFactor\":0.0,\"endDate\":1444665600000,\"gpOfferId\":1100020,\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":5.0,\"thresholdQty\":2},{\"discountFactor\":15.0,\"thresholdQty\":5}]}],\"id\":27955688350101926880551456274,\"promotionDesc\":\"购买参加本活动的任意商品满2件立减5元;满5件立减15元\",\"promotionDescCn\":\"购买参加本活动的任意商品满2件立减5元;满5件立减15元\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000006L, 6L, 15, new BigDecimal("99"), 1100020, 1, new BigDecimal("15.0"), 1000000000006L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("15.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest17() throws GlobalErrorInfoException {
		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// *** 3-阶梯式折扣
		// *** 买更多折更多
		// *** 买X得N%折
		// *** (折扣随着商品数量的增加而增加)
		// *** 1.X可以是同一商品或不同商品
		// *** 2.阶梯最多不超过四级
		// *** 3.设置时需要清楚界定每一阶梯享受优惠的最低商品购买个数，只要满足最低要求，就能享受规定折扣
		// *** 不可多倍折扣
		// *** 不可多组（否则POS计算错误）
		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++

		// 3-阶梯式折扣 // 购买参加本活动的任意商品满2件立享95折;满5件立享85折 // gpOfferId 为 1000030 //
		// 单组, 不满足优惠条件, 1件商品
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"beginDate\":1436716800000,\"discountFactor\":0.0,\"endDate\":1444665600000,\"gpOfferId\":1100030,\"gpTypeCode\":3,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":5.0,\"thresholdQty\":2},{\"discountFactor\":15.0,\"thresholdQty\":5}]}],\"id\":27955696448222575221601764495,\"promotionDesc\":\"购买参加本活动的任意商品满2件立享95折;满5件立享85折\",\"promotionDescCn\":\"购买参加本活动的任意商品满2件立享95折;满5件立享85折\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000008L, 8L, 1, new BigDecimal("100"), 1100030, 1, new BigDecimal("0.0"), 1000000000008L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("0.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest18() throws GlobalErrorInfoException {
		// 3-阶梯式折扣 // 购买参加本活动的任意商品满2件立享95折;满5件立享85折 // gpOfferId 为 1000030 //
		// 单组, 满足1级阶梯条件, 不满足2级阶梯阶梯条件, 2件商品 (2*100*0.05)
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"beginDate\":1436716800000,\"discountFactor\":0.0,\"endDate\":1444665600000,\"gpOfferId\":1100030,\"gpTypeCode\":3,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":5.0,\"thresholdQty\":2},{\"discountFactor\":15.0,\"thresholdQty\":5}]}],\"id\":27955696448222575221601764495,\"promotionDesc\":\"购买参加本活动的任意商品满2件立享95折;满5件立享85折\",\"promotionDescCn\":\"购买参加本活动的任意商品满2件立享95折;满5件立享85折\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000008L, 8L, 2, new BigDecimal("100"), 1100030, 1, new BigDecimal("10.0"), 1000000000008L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("10.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest19() throws GlobalErrorInfoException {
		// 3-阶梯式折扣 // 购买参加本活动的任意商品满2件立享95折;满5件立享85折 // gpOfferId 为 1000030 //
		// 单组, 满足阶梯条件1的倍数, 不满足阶梯条件2,4件商品 (4*100*0.05)
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"beginDate\":1436716800000,\"discountFactor\":0.0,\"endDate\":1444665600000,\"gpOfferId\":1100030,\"gpTypeCode\":3,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":5.0,\"thresholdQty\":2},{\"discountFactor\":15.0,\"thresholdQty\":5}]}],\"id\":27955696448222575221601764495,\"promotionDesc\":\"购买参加本活动的任意商品满2件立享95折;满5件立享85折\",\"promotionDescCn\":\"购买参加本活动的任意商品满2件立享95折;满5件立享85折\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000008L, 8L, 4, new BigDecimal("100"), 1100030, 1, new BigDecimal("20.0"), 1000000000008L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("20.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest20() throws GlobalErrorInfoException {
		// 3-阶梯式折扣 // 购买参加本活动的任意商品满2件立享95折;满5件立享85折 // gpOfferId 为 1000030 //
		// 单组, 不满足阶梯条件1的倍数, 满足阶梯条件2, 5件商品 (5*100*0.15)
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"beginDate\":1436716800000,\"discountFactor\":0.0,\"endDate\":1444665600000,\"gpOfferId\":1100030,\"gpTypeCode\":3,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":5.0,\"thresholdQty\":2},{\"discountFactor\":15.0,\"thresholdQty\":5}]}],\"id\":27955696448222575221601764495,\"promotionDesc\":\"购买参加本活动的任意商品满2件立享95折;满5件立享85折\",\"promotionDescCn\":\"购买参加本活动的任意商品满2件立享95折;满5件立享85折\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000008L, 8L, 5, new BigDecimal("100"), 1100030, 1, new BigDecimal("75.0"), 1000000000008L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("75.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest21() throws GlobalErrorInfoException {
		// 3-阶梯式折扣 // 购买参加本活动的任意商品满2件立享95折;满5件立享85折 // gpOfferId 为 1000030 //
		// 单组, 满足1,2级阶梯公倍数, 10件商品 (10*100*0.15)
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"beginDate\":1436716800000,\"discountFactor\":0.0,\"endDate\":1444665600000,\"gpOfferId\":1100030,\"gpTypeCode\":3,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":5.0,\"thresholdQty\":2},{\"discountFactor\":15.0,\"thresholdQty\":5}]}],\"id\":27955696448222575221601764495,\"promotionDesc\":\"购买参加本活动的任意商品满2件立享95折;满5件立享85折\",\"promotionDescCn\":\"购买参加本活动的任意商品满2件立享95折;满5件立享85折\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000008L, 8L, 10, new BigDecimal("100"), 1100030, 1, new BigDecimal("150.0"), 1000000000008L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("150.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest22() throws GlobalErrorInfoException {
		// 3-阶梯式折扣 // 购买参加本活动的任意商品满2件立享95折;满5件立享85折 // gpOfferId 为 1000030 //
		// 单组, 满足2级阶梯倍数,不满足1级阶梯倍数, 15件商品 (15*100*0.15)
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"beginDate\":1436716800000,\"discountFactor\":0.0,\"endDate\":1444665600000,\"gpOfferId\":1100030,\"gpTypeCode\":3,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":5.0,\"thresholdQty\":2},{\"discountFactor\":15.0,\"thresholdQty\":5}]}],\"id\":27955696448222575221601764495,\"promotionDesc\":\"购买参加本活动的任意商品满2件立享95折;满5件立享85折\",\"promotionDescCn\":\"购买参加本活动的任意商品满2件立享95折;满5件立享85折\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000008L, 8L, 15, new BigDecimal("100"), 1100030, 1, new BigDecimal("225.0"), 1000000000008L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("225.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest23() throws GlobalErrorInfoException {
		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// *** 4-固定价格优惠
		// *** 以N价格买X
		// *** 1. X可以是同一商品或不同商品
		// *** 2. 只可建立一个商品组
		// *** 2. 任意商品单价*规定商品的个数 > N价格
		// ***
		// 3.如果X为不同的商品而且零售价不同，而顾客购买的数量超过指定的数量且小于折扣再次发生的条件时，则系统会选取指定数量中单价较高的商品进行折扣。
		// *** 4.如果门店进行竞价，且竞价之后商品组合价格低于促销价格，则促销不能发生
		// *** 可以多倍折扣(买X价格N，买2X价格2N)
		// *** 不可多组（否则POS计算错误）
		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// 4-固定价格优惠
		// 参与本活动的商品任选2件仅需15元
		// gpOfferId 为 1000040
		// 单组, 不满足条件,1件商品
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"beginDate\":1436716800000,\"discountFactor\":15.0,\"endDate\":1444665600000,\"gpOfferId\":1100040,\"gpTypeCode\":4,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":2}],\"id\":27955703162837418043094903148,\"promotionDesc\":\"参与本活动的商品任选2件仅需15元\",\"promotionDescCn\":\"参与本活动的商品任选2件仅需15元\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000010L, 10L, 1, new BigDecimal("10"), 1100040, 1, new BigDecimal("0.0"), 1000000000010L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("0.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest24() throws GlobalErrorInfoException {
		// 4-固定价格优惠 // 参与本活动的商品任选2件仅需15元 // gpOfferId 为 1000040 // 单组,
		// 满足单倍条件,2件商品
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"beginDate\":1436716800000,\"discountFactor\":15.0,\"endDate\":1444665600000,\"gpOfferId\":1100040,\"gpTypeCode\":4,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":2}],\"id\":27955703162837418043094903148,\"promotionDesc\":\"参与本活动的商品任选2件仅需15元\",\"promotionDescCn\":\"参与本活动的商品任选2件仅需15元\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000010L, 10L, 2, new BigDecimal("10"), 1100040, 1, new BigDecimal("5.0"), 1000000000010L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("5.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest25() throws GlobalErrorInfoException {
		// 4-固定价格优惠 // 参与本活动的商品任选2件仅需15元 // gpOfferId 为 1000040 // 单组,
		// 满足多倍条件,5件商品
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"beginDate\":1436716800000,\"discountFactor\":15.0,\"endDate\":1444665600000,\"gpOfferId\":1100040,\"gpTypeCode\":4,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":2}],\"id\":27955703162837418043094903148,\"promotionDesc\":\"参与本活动的商品任选2件仅需15元\",\"promotionDescCn\":\"参与本活动的商品任选2件仅需15元\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000010L, 10L, 5, new BigDecimal("10"), 1100040, 1, new BigDecimal("10.0"), 1000000000010L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("10.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest26() throws GlobalErrorInfoException {
		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// *** 0-满立减
		// *** 买X达到规定个数立减N元
		// *** 1.X可以是同一商品或不同商品
		// *** 可以多倍折扣(买X减N，买2X减2N)
		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// 0-满立减
		// 购买参加本活动的任意商品每满100元立减5元
		// gpOfferId 为 1000050
		// 单组,不满足条件,1件商品
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"beginDate\":1436716800000,\"discountFactor\":5.0,\"endDate\":1444665600000,\"gpOfferId\":1100050,\"gpTypeCode\":105,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":100}],\"id\":27955707829863668654896304163,\"promotionDesc\":\"购买参加本活动的任意商品每满100元立减5元\",\"promotionDescCn\":\"购买参加本活动的任意商品每满100元立减5元\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000001L, 1L, 1, new BigDecimal("55.00"), 1100050, 1, new BigDecimal("0.0"), 1000000000001L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("0.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest27() throws GlobalErrorInfoException {
		// 0-满立减
		// 购买参加本活动的任意商品每满2件立减5元
		// gpOfferId 为 1000000
		// 单组, 满足条件 , 单倍, 2件商品

		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = " [{\"beginDate\":1436716800000,\"discountFactor\":5.0,\"endDate\":1444665600000,\"gpOfferId\":1100000,\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":2}],\"id\":27955661842130692903563027876,\"promotionDesc\":\"购买参加本活动的任意商品每满2件立减5元\",\"promotionDescCn\":\"购买参加本活动的任意商品每满2件立减5元\",\"promotionDescEn\":\"\",\"status\":0},{\"beginDate\":1436716800000,\"discountFactor\":200.0,\"endDate\":1444665600000,\"gpOfferId\":1100001,\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":1},{\"groupSeq\":2,\"thresholdQty\":1}],\"id\":27955661842130692903563027878,\"promotionDesc\":\"购买参加本活动任意商品满1组减200元（2件为1组:需包含第1类任意1件，第2类任意1件）\",\"promotionDescCn\":\"购买参加本活动任意商品满1组减200元（2件为1组:需包含第1类任意1件，第2类任意1件）\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000001L, 1L, 2, new BigDecimal("55.00"), 1100000, 1, new BigDecimal("5.0"), 1000000000001L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("5.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest28() throws GlobalErrorInfoException {

		// 0-满立减
		// 购买参加本活动的任意商品每满2件立减5元
		// gpOfferId 为 1000000
		// 单组,满足条件, 多倍, 5件 商品

		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = " [{\"beginDate\":1436716800000,\"discountFactor\":5.0,\"endDate\":1444665600000,\"gpOfferId\":1100000,\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":2}],\"id\":27955661842130692903563027876,\"promotionDesc\":\"购买参加本活动的任意商品每满2件立减5元\",\"promotionDescCn\":\"购买参加本活动的任意商品每满2件立减5元\",\"promotionDescEn\":\"\",\"status\":0},{\"beginDate\":1436716800000,\"discountFactor\":200.0,\"endDate\":1444665600000,\"gpOfferId\":1100001,\"gpTypeCode\":0,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":1},{\"groupSeq\":2,\"thresholdQty\":1}],\"id\":27955661842130692903563027878,\"promotionDesc\":\"购买参加本活动任意商品满1组减200元（2件为1组:需包含第1类任意1件，第2类任意1件）\",\"promotionDescCn\":\"购买参加本活动任意商品满1组减200元（2件为1组:需包含第1类任意1件，第2类任意1件）\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000001L, 1L, 5, new BigDecimal("55.00"), 1100000, 1, new BigDecimal("10.0"), 1000000000001L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("10.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest29() throws GlobalErrorInfoException {

		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// *** 2-阶梯式满立减
		// *** 买更多减更多
		// *** 买X达到规定金额立减N元
		// *** (立减金额随着商品总价的增加而增加)
		// *** 1. X可以是同一商品或不同商品
		// *** 2. 阶梯最多不超过四级
		// *** 3.设置时需要清楚界定每一级别的商品数量规定
		// *** 不可多倍折扣
		// *** 不可多组（否则POS计算错误）
		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++

		// 2-阶梯式现金返还 // 购买参加本活动的任意商品满100元立减5元;满150元立减15元 // gpOfferId 为 1000060
		// 单组, 不满足条件, 1件商品

		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"beginDate\":1436716800000,\"discountFactor\":0.0,\"endDate\":1444665600000,\"gpOfferId\":1100060,\"gpTypeCode\":106,\"groups\":[{\"groupSeq\":1,\"thresholdAmt\":10,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":5.0,\"thresholdAmt\":150.0,\"thresholdQty\":100},{\"discountFactor\":15.0,\"thresholdAmt\":150,\"thresholdQty\":150}]}],\"id\":27955716555173615376776938803,\"promotionDesc\":\"购买参加本活动的任意商品满100元立减5元;满150元立减15元\",\"promotionDescCn\":\"购买参加本活动的任意商品满100元立减5元;满150元立减15元\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000006L, 6L, 1, new BigDecimal("55"), 1100060, 1, new BigDecimal("0.0"), 1000000000006L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("0.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest30() throws GlobalErrorInfoException {
		// 2-阶梯式现金返还 // 购买参加本活动的任意商品满2件立减5元;满5件立减15元 // gpOfferId 为 1000020
		// 单组 , 满足一级阶梯条件, 2件商口
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"beginDate\":1436716800000,\"discountFactor\":0.0,\"endDate\":1444665600000,\"gpOfferId\":1100020,\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":5.0,\"thresholdQty\":2},{\"discountFactor\":15.0,\"thresholdQty\":5}]}],\"id\":27955688350101926880551456274,\"promotionDesc\":\"购买参加本活动的任意商品满2件立减5元;满5件立减15元\",\"promotionDescCn\":\"购买参加本活动的任意商品满2件立减5元;满5件立减15元\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000006L, 6L, 2, new BigDecimal("55"), 1100020, 1, new BigDecimal("5.0"), 1000000000006L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("5.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	@Test
	public void promotionServiceCalcDiscountTest31() throws GlobalErrorInfoException {

		// 2-阶梯式现金返还 // 购买参加本活动的任意商品满2件立减5元;满5件立减15元 // gpOfferId 为 1000020
		// 单组, 满足2级阶梯, 5件商品
		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = "[{\"beginDate\":1436716800000,\"discountFactor\":0.0,\"endDate\":1444665600000,\"gpOfferId\":1100020,\"gpTypeCode\":2,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":0,\"tieredDiscount\":[{\"discountFactor\":5.0,\"thresholdQty\":2},{\"discountFactor\":15.0,\"thresholdQty\":5}]}],\"id\":27955688350101926880551456274,\"promotionDesc\":\"购买参加本活动的任意商品满2件立减5元;满5件立减15元\",\"promotionDescCn\":\"购买参加本活动的任意商品满2件立减5元;满5件立减15元\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(1000000000006L, 6L, 5, new BigDecimal("55"), 1100020, 1, new BigDecimal("15.0"), 1000000000006L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("15.0")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result is error");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	

}
