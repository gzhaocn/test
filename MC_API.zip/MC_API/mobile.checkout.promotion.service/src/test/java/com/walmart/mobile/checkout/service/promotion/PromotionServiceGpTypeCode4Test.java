package com.walmart.mobile.checkout.service.promotion;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;

import com.walmart.mobile.checkout.bo.promotion.GpCartItem;
import com.walmart.mobile.checkout.entity.promotion.GpOffer;
import com.walmart.mobile.checkout.entity.promotion.Group;
import com.walmart.mobile.checkout.repo.GpOfferRepository;

/*@RunWith(SpringJUnit4ClassRunner.class)
 @WebAppConfiguration
 @ContextConfiguration(classes = { MainConfig.class })*/
public class PromotionServiceGpTypeCode4Test {

	@Autowired
	GpOfferRepository gpOfferRepository;

	@Autowired
	PromotionService promotionService;

	public List<GpOffer> initGpOfferData() throws ParseException {

		List<GpOffer> gpOfferList = new ArrayList<>();

		
		// 4 固定价格优惠,以N价格买X
		GpOffer gpOffer70 = new GpOffer();
		gpOffer70.setGpOfferId(1100070);
		gpOffer70.setGpTypeCode(4);
		gpOffer70.setBeginDate(new SimpleDateFormat("yyyy-MM-dd").parse("2015-07-13"));
		gpOffer70.setEndDate(new SimpleDateFormat("yyyy-MM-dd").parse("2015-10-13"));
		gpOffer70.setDiscountFactor(7.0f);
		gpOffer70.setStatus(0);
		
		List<Group> groups70 = new ArrayList<Group>();
		Group group70 = new Group();
		group70.setGroupSeq(1);
		group70.setThresholdQty(3);
		groups70.add(group70);
		
		gpOffer70.setGroups(groups70);
		gpOffer70.setPromotionDescEn("");
		gpOffer70.setPromotionDescCn("参与本活动的商品任选3件仅需7元");

		gpOfferList.add(gpOffer70);

		gpOfferList = (List<GpOffer>) gpOfferRepository.save(gpOfferList);
		return gpOfferList;
	}

	// @Before
	public void setUp() throws ParseException, InterruptedException {
		initGpOfferData();
		Thread.sleep(2000L);
	}

	// @Test

	public void testCalcDiscount() throws ParseException {
		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;

		
		items.clear();
		items.add(new GpCartItem(31692138451362L, 1L, 1, new BigDecimal("200.03"), 1100070, 1, new BigDecimal("197.53"),
				31692138451362L));
		items.add(new GpCartItem(31692138451363L, 2L, 1, new BigDecimal("180.03"), 1100070, 1, new BigDecimal("177.78"),
				31692138451363L));
		items.add(new GpCartItem(31692138451364L, 3L, 1, new BigDecimal("180.04"), 1100070, 1, new BigDecimal("177.79"),
				31692138451364L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("553.1")).compareTo(new BigDecimal(Double.toString(discount))) == 0,
				"result error");
		
		
		items.clear();
		items.add(new GpCartItem(31692138451361L, 4L, 1, new BigDecimal("160.15"), 1100070, 1, new BigDecimal("99.73"),
				31692138451361L));
		items.add(new GpCartItem(31692138451362L, 1L, 2, new BigDecimal("200.03"), 1100070, 1, new BigDecimal("249.14"),
				31692138451362L));
		items.add(new GpCartItem(31692138451363L, 2L, 1, new BigDecimal("180.03"), 1100070, 1, new BigDecimal("112.11"),
				31692138451363L));
		items.add(new GpCartItem(31692138451364L, 3L, 1, new BigDecimal("180.04"), 1100070, 1, new BigDecimal("112.12"),
				31692138451364L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("573.1")).compareTo(new BigDecimal(Double.toString(discount))) == 0,
				"result error");

	}

	// @After
	public void clearTestData() {
		List<Integer> offerIdList = Arrays.asList(1100070);
		List<GpOffer> offers = this.gpOfferRepository.findByGpOfferIdIn(offerIdList);

		this.gpOfferRepository.delete(offers);

	}
}
