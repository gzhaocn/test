package com.walmart.mobile.checkout.service.promotion;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;

import com.walmart.mobile.checkout.bo.promotion.CalcDiscountResult;
import com.walmart.mobile.checkout.bo.promotion.GpCartItem;
import com.walmart.mobile.checkout.entity.promotion.GpOffer;

/*@RunWith(SpringJUnit4ClassRunner.class)
 @WebAppConfiguration
 @ContextConfiguration(classes = { MainConfig.class })*/
public class GlobalPromotionServiceNewTest {
	private static final Logger LOG = LoggerFactory.getLogger(GlobalPromotionServiceNewTest.class);

	@Autowired
	private GpOfferService gpOfferService;
	@Autowired
	private PromotionService promotionService;

	public void initGpOfferData() throws ParseException {
		List<Integer> offerIdList = Arrays.asList(20899635, 20832981, 20899715, 20846231, 20846270, 20709073, 20899960,
				20914521, 20671060, 20778009, 20914000, 20914283, 20900104, 20778007, 2015, 20779530, 20900100,
				20899807, 20899845, 20845798, 20914012, 20807753, 20845993, 201000003, 201000004, 201000005, 20991580,
				201000006, 201000001, 2028, 20778830, 201000002, 201000007, 201000008, 20846212, 20778829, 20778828,
				20914185, 20900049, 2011000008, 20777895, 20900088, 2011000006, 2011000007, 20762874, 2011000004,
				2011000005, 20899707, 2011000003, 2011000001, 20991849, 2100000012, 20914954, 2100000015, 20846063,
				2100000016, 20846140, 20647409, 20885758, 20914597, 20991646, 20959184, 20778019, 20778817, 2011000015);
		List<GpOffer> offerList = gpOfferService.findByGpOfferIdInAndStatus(offerIdList, 1);
		for (GpOffer gpOffer : offerList) {
			gpOffer.setStatus(0);
		}
		gpOfferService.gpOfferListsave(offerList);
	}

	// @Before
	public void setUp() throws ParseException, InterruptedException {
		initGpOfferData();
	}

	// @Test
	public void testcalcDiscountV7() throws ParseException {

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		calAndValidGp(items);

		// 40单GP测试：01类型0，满立减（数量），非组合2件
		items.clear();
		items.add(new GpCartItem(31690309617031L, 690309617031L, 2, new BigDecimal(138), 201000001, 1, new BigDecimal(20), 31690309617031L));
		calAndValidGp(items);
		// 41单GP测试：02类型0，满立减（数量），组合0-1
		items.clear();
		items.add(new GpCartItem(31693245062325L, 693245062325L, 3, new BigDecimal(29.9), 201000002, 1, new BigDecimal(0), 31693245062325L));
		items.add(new GpCartItem(31693245068769L, 693245068769L, 5, new BigDecimal(9.9), 201000002, 2, new BigDecimal(0), 31693245068769L));
		calAndValidGp(items);
		// 44单GP测试：05类型0，满立减（数量），组合1-1
		items.clear();
		items.add(new GpCartItem(31693245062325L, 693245062325L, 4, new BigDecimal(29.9), 201000002, 1, new BigDecimal(10.61).setScale(2, RoundingMode.HALF_UP), 31693245062325L));
		items.add(new GpCartItem(31693245068769L, 693245068769L, 5, new BigDecimal(9.9), 201000002, 2, new BigDecimal(4.39).setScale(2, RoundingMode.HALF_UP), 31693245068769L));
		calAndValidGp(items);
		// 48单GP测试：09类型0，满立减（数量），组合2-2
		items.clear();
		items.add(new GpCartItem(31693245062325L, 693245062325L, 8, new BigDecimal(29.9), 201000002, 1, new BigDecimal(21.22).setScale(2, RoundingMode.HALF_UP), 31693245068769L));
		items.add(new GpCartItem(31693245068769L, 693245068769L, 10, new BigDecimal(9.9), 201000002, 2, new BigDecimal(8.78).setScale(2, RoundingMode.HALF_UP), 31693245068769L));
		calAndValidGp(items);
		// 49单GP测试：10类型1，折扣，2件未满足
		items.clear();
		items.add(new GpCartItem(31694317124631L, 694317124631L, 2, new BigDecimal(139), 201000003, 1, new BigDecimal(0), 31694317124631L));
		calAndValidGp(items);
		// 50单GP测试：11类型1，折扣，3件满足
		items.clear();
		items.add(new GpCartItem(31694317124631L, 694317124631L, 3, new BigDecimal(139), 201000003, 1, new BigDecimal(125.1).setScale(2, RoundingMode.HALF_UP), 31694317124631L));
		calAndValidGp(items);
		// 51单GP测试：12类型1，折扣，4件超过
		items.clear();
		items.add(new GpCartItem(31694317124631L, 694317124631L, 4, new BigDecimal(139), 201000003, 1, new BigDecimal(166.8).setScale(2, RoundingMode.HALF_UP), 31694317124631L));
		calAndValidGp(items);
		// 52单GP测试：13类型2，阶梯满立减（数量），1件未满足
		items.clear();
		items.add(new GpCartItem(31691080621674L, 691080621674L, 1, new BigDecimal(749), 201000004, 1, new BigDecimal(0), 31691080621674L));
		calAndValidGp(items);
		// 54单GP测试：15类型2，阶梯满立减（数量），3件满足1阶
		items.clear();
		items.add(new GpCartItem(31691080621674L, 691080621674L, 3, new BigDecimal(749), 201000004, 1, new BigDecimal(100), 31691080621674L));
		calAndValidGp(items);
		// 56单GP测试：17类型2，阶梯满立减（数量），5件满足2阶
		items.clear();
		items.add(new GpCartItem(31691080621674L, 691080621674L, 5, new BigDecimal(749), 201000004, 1, new BigDecimal(210), 31691080621674L));
		calAndValidGp(items);
		// 57单GP测试：18类型3，阶梯折扣，1件未满足
		items.clear();
		items.add(new GpCartItem(31692138453064L, 692138453064L, 1, new BigDecimal(269), 201000005, 1, new BigDecimal(0), 31692138453064L));
		calAndValidGp(items);
		// 59单GP测试：20类型3，阶梯折扣，3件满足1阶
		items.clear();
		items.add(new GpCartItem(31692138453064L, 692138453064L, 3, new BigDecimal(269), 201000005, 1, new BigDecimal(161.4).setScale(2, RoundingMode.HALF_UP), 31692138453064L));
		calAndValidGp(items);
		// 60单GP测试：21类型3，阶梯折扣，4件满足2阶
		items.clear();
		items.add(new GpCartItem(31692138453064L, 692138453064L, 4, new BigDecimal(269), 201000005, 1, new BigDecimal(269), 31692138453064L));
		calAndValidGp(items);
		// 62单GP测试：23类型4，固定价格促销，1件未满足
		items.clear();
		items.add(new GpCartItem(31692138451361L, 692138451361L, 1, new BigDecimal(199), 201000006, 1, new BigDecimal(0), 31692138451361L));
		calAndValidGp(items);
		// 64单GP测试：25类型4，固定价格促销，3件满足1次
		items.clear();
		items.add(new GpCartItem(31692138451361L, 692138451361L, 3, new BigDecimal(199), 201000006, 1, new BigDecimal(38), 31692138451361L));
		calAndValidGp(items);
		// 66单GP测试：27类型4，固定价格促销，5件满足2次
		items.clear();
		items.add(new GpCartItem(31692138451361L, 692138451361L, 5, new BigDecimal(199), 201000006, 1, new BigDecimal(76), 31692138451361L));
		calAndValidGp(items);
		// 68单GP测试：29类型6，满立减（金额），n-0.01
		items.clear();
		items.add(new GpCartItem(31692880401122L, 693245068112L, 3, new BigDecimal(3.33), 20647409, 1, new BigDecimal(0), 31692880401122L));
		calAndValidGp(items);
		// 69单GP测试：30类型6，满立减（金额），n
		items.clear();
		items.add(new GpCartItem(31692880401122L, 693245068112L, 3, new BigDecimal(3.33), 201000007, 1, new BigDecimal(1), 31692880401122L));
		items.add(new GpCartItem(31002610288451L, 2610288451L, 1, new BigDecimal(0.01), 201000007, 1, new BigDecimal(0), 31002610288451L));
		calAndValidGp(items);
		// 71单GP测试：32类型6，满立减（金额），n+0.02
		items.clear();
		items.add(new GpCartItem(31693245068486L, 693245068486L, 3, new BigDecimal(3.32), 201000007, 1, new BigDecimal(0.99).setScale(2, RoundingMode.HALF_UP), 31693245068486L));
		items.add(new GpCartItem(31693245068112L, 693245068112L, 3, new BigDecimal(0.02), 201000007, 1, new BigDecimal(0.01).setScale(2, RoundingMode.HALF_UP), 31693245068112L));
		calAndValidGp(items);
		// 73单GP测试：34类型6，满立减（金额），2n-0.01
		items.clear();
		items.add(new GpCartItem(31692880401122L, 692880401122L, 7, new BigDecimal(3.33), 20647409, 1, new BigDecimal(0), 31692880401122L));
		items.add(new GpCartItem(31695006840891L, 695006840891L, 8, new BigDecimal(2.49), 201000007, 1, new BigDecimal(1), 31695006840891L));
		calAndValidGp(items);
		// 76单GP测试：37类型6，满立减（金额），2n+0.01
		items.clear();
		items.add(new GpCartItem(31693245068486L, 693245068486L, 6, new BigDecimal(3.32), 201000007, 1, new BigDecimal(1.99).setScale(2, RoundingMode.HALF_UP), 31693245068486L));
		items.add(new GpCartItem(31693245068112L, 693245068112L, 5, new BigDecimal(0.02), 201000007, 1, new BigDecimal(0.01).setScale(2, RoundingMode.HALF_UP), 31693245068112L));
		calAndValidGp(items);
		// 77单GP测试：38一分钱分摊
		items.clear();
		items.add(new GpCartItem(31690894628401L, 690894628401L, 1, new BigDecimal(7.75), 20709073, 1, new BigDecimal(0), 31690894628401L));
		items.add(new GpCartItem(31690894628401L, 690894628401L, 1, new BigDecimal(7.75), 20991646, 1, new BigDecimal(0), 31690894628401L));
		items.add(new GpCartItem(31690894628401L, 690894628401L, 1, new BigDecimal(7.75), 201000008, 1, new BigDecimal(0), 31690894628401L));
		items.add(new GpCartItem(31692166980070L, 692166980070L, 1, new BigDecimal(15), 201000008, 1, new BigDecimal(0), 31692166980070L));
		items.add(new GpCartItem(31694317128558L, 694317128558L, 1, new BigDecimal(15), 201000008, 1, new BigDecimal(0), 31694317128558L));
		items.add(new GpCartItem(31692173020260L, 692173020260L, 1, new BigDecimal(15), 201000008, 1, new BigDecimal(0), 31692173020260L));
		items.add(new GpCartItem(31692017792313L, 692017792313L, 1, new BigDecimal(15), 201000008, 1, new BigDecimal(0), 31692017792313L));
		items.add(new GpCartItem(31000004078657L, 4078657L, 1, new BigDecimal(15), 201000008, 1, new BigDecimal(0), 31000004078657L));
		items.add(new GpCartItem(31692219340052L, 692219340052L, 1, new BigDecimal(15), 201000008, 1, new BigDecimal(0), 31692219340052L));
		calAndValidGp(items);
		// 78多GP商品下单(1个商品)
		items.clear();
		items.add(new GpCartItem(31000002104306L, 2104306L, 8, new BigDecimal(9.8), 20832981, 1, new BigDecimal(0), 31000002104306L));
		items.add(new GpCartItem(31000002104306L, 2104306L, 8, new BigDecimal(9.8), 20779530, 1, new BigDecimal(20), 31000002104306L));
		calAndValidGp(items);
		// 79多GP商品下单(1个商品)
		items.clear();
		items.add(new GpCartItem(31000002104314L, 2104314L, 4, new BigDecimal(9.8), 20832981, 1, new BigDecimal(0), 31000002104314L));
		items.add(new GpCartItem(31000002104314L, 2104314L, 4, new BigDecimal(9.8), 20959184, 1, new BigDecimal(0), 31000002104314L));
		calAndValidGp(items);
		// 80多GP商品下单(1个商品)
		items.clear();
		items.add(new GpCartItem(31000002719289L, 2719289L, 10, new BigDecimal(9.9), 2015, 1, new BigDecimal(33.66).setScale(2, RoundingMode.HALF_UP), 31000002719289L));
		items.add(new GpCartItem(31000002719289L, 2719289L, 10, new BigDecimal(9.9), 20778009, 1, new BigDecimal(4), 31000002719289L));
		calAndValidGp(items);
		// 81多GP商品下单(1个商品)
		items.clear();
		items.add(new GpCartItem(31000004012277L, 4012277L, 2, new BigDecimal(18.5), 20991580, 1, new BigDecimal(0), 31000004012277L));
		items.add(new GpCartItem(31000004012277L, 4012277L, 2, new BigDecimal(18.5), 20991849, 2, new BigDecimal(0), 31000004012277L));
		calAndValidGp(items);
		// 82多GP商品下单(1个商品)
		items.clear();
		items.add(new GpCartItem(31000004033887L, 4033887L, 1, new BigDecimal(25), 20991849, 2, new BigDecimal(0), 31000004033887L));
		items.add(new GpCartItem(31000004033887L, 4033887L, 1, new BigDecimal(25), 20914521, 1, new BigDecimal(0), 31000004033887L));
		calAndValidGp(items);
		// 83多GP商品下单(1个商品)
		items.clear();
		items.add(new GpCartItem(31000004080488L, 4080488L, 7, new BigDecimal(18.5), 20832981, 1, new BigDecimal(120), 31000004080488L));
		items.add(new GpCartItem(31000004080488L, 4080488L, 7, new BigDecimal(18.5), 20846063, 1, new BigDecimal(6), 31000004080488L));
		items.add(new GpCartItem(31000004080488L, 4080488L, 7, new BigDecimal(18.5), 20959184, 1, new BigDecimal(0), 31000004080488L));
		items.add(new GpCartItem(31000004080488L, 4080488L, 7, new BigDecimal(18.5), 20991646, 1, new BigDecimal(0), 31000004080488L));
		calAndValidGp(items);
		// 84多GP商品下单(1个商品)
		items.clear();
		items.add(new GpCartItem(31000008017718L, 8017718L, 1, new BigDecimal(4.3), 2015, 1, new BigDecimal(0), 31000008017718L));
		items.add(new GpCartItem(31000008017718L, 8017718L, 1, new BigDecimal(4.3), 20778009, 1, new BigDecimal(0), 31000008017718L));
		items.add(new GpCartItem(31000008017718L, 8017718L, 1, new BigDecimal(4.3), 20959184, 1, new BigDecimal(0), 31000008017718L));
		calAndValidGp(items);
		// 85多GP商品下单(1个商品)
		items.clear();
		items.add(new GpCartItem(31001410008550L, 1410008550L, 4, new BigDecimal(24), 20846231, 1, new BigDecimal(60), 31001410008550L));
		items.add(new GpCartItem(31001410008550L, 1410008550L, 4, new BigDecimal(24), 20914521, 1, new BigDecimal(0), 31001410008550L));
		calAndValidGp(items);
		// 86多GP商品下单(1个商品)
		items.clear();
		items.add(new GpCartItem(31030008723202L, 8723202L, 2, new BigDecimal(210.5), 20778009, 1, new BigDecimal(2), 31030008723202L));
		items.add(new GpCartItem(31030008723202L, 8723202L, 2, new BigDecimal(210.5), 201000001, 1, new BigDecimal(20), 31030008723202L));
		calAndValidGp(items);
		// 87多GP商品下单(1个商品)
		items.clear();
		items.add(new GpCartItem(31212399500000L, 212399500000L, 4, new BigDecimal(5), 2028, 1, new BigDecimal(8), 31212399500000L));
		items.add(new GpCartItem(31212399500000L, 212399500000L, 4, new BigDecimal(5), 20900049, 1, new BigDecimal(0), 31212399500000L));
		items.add(new GpCartItem(31212399500000L, 212399500000L, 4, new BigDecimal(5), 20900088, 1, new BigDecimal(6), 31212399500000L));
		calAndValidGp(items);
		// 88多GP商品下单(1个商品)
		items.clear();
		items.add(new GpCartItem(31400606779627L, 400606779627L, 7, new BigDecimal(50), 201000005, 1, new BigDecimal(87.5).setScale(2, RoundingMode.HALF_UP), 31400606779627L));
		items.add(new GpCartItem(31400606779627L, 400606779627L, 7, new BigDecimal(50), 2100000012, 1, new BigDecimal(240.03).setScale(2, RoundingMode.HALF_UP), 31400606779627L));
		calAndValidGp(items);
		// 89多GP商品下单(1个商品)
		items.clear();
		items.add(new GpCartItem(31425035650106L, 425035650106L, 9, new BigDecimal(10), 20900049, 1, new BigDecimal(72), 31425035650106L));
		items.add(new GpCartItem(31425035650106L, 425035650106L, 9, new BigDecimal(10), 20900088, 1, new BigDecimal(0), 31425035650106L));
		calAndValidGp(items);
		// 90多GP商品下单(1个商品)
		items.clear();
		items.add(new GpCartItem(31489102870594L, 489102870594L, 7, new BigDecimal(5), 20779530, 1, new BigDecimal(15), 31489102870594L));
		items.add(new GpCartItem(31489102870594L, 489102870594L, 7, new BigDecimal(5), 20914954, 1, new BigDecimal(17.5).setScale(2, RoundingMode.HALF_UP), 31489102870594L));
		items.add(new GpCartItem(31489102870594L, 489102870594L, 7, new BigDecimal(5), 2100000015, 1, new BigDecimal(0), 31489102870594L));
		calAndValidGp(items);
		// 91多GP商品下单(1个商品)
		items.clear();
		items.add(new GpCartItem(31690008202003L, 690008202003L, 6, new BigDecimal(5), 20899845, 1, new BigDecimal(0), 31690008202003L));
		items.add(new GpCartItem(31690008202003L, 690008202003L, 6, new BigDecimal(5), 201000004, 1, new BigDecimal(0), 31690008202003L));
		items.add(new GpCartItem(31690008202003L, 690008202003L, 6, new BigDecimal(5), 2100000016, 1, new BigDecimal(0), 31690008202003L));
		calAndValidGp(items);
		// 92多GP商品下单(2个商品)
		items.clear();
		items.add(new GpCartItem(31000004080488L, 4080488L, 1, new BigDecimal(18.5), 20832981, 1, new BigDecimal(0), 31000004080488L));
		items.add(new GpCartItem(31000004080488L, 4080488L, 1, new BigDecimal(18.5), 20846063, 1, new BigDecimal(0), 31000004080488L));
		items.add(new GpCartItem(31000004080488L, 4080488L, 1, new BigDecimal(18.5), 20959184, 1, new BigDecimal(0), 31000004080488L));
		items.add(new GpCartItem(31000004080488L, 4080488L, 1, new BigDecimal(18.5), 20991646, 1, new BigDecimal(0), 31000004080488L));
		items.add(new GpCartItem(31001410008550L, 1410008550L, 1, new BigDecimal(24), 20846231, 1, new BigDecimal(0), 31001410008550L));
		items.add(new GpCartItem(31001410008550L, 1410008550L, 1, new BigDecimal(24), 20914521, 1, new BigDecimal(0), 31001410008550L));
		calAndValidGp(items);
		// 93多GP商品下单(2个商品)
		items.clear();
		items.add(new GpCartItem(31030008723202L, 30008723202L, 2, new BigDecimal(210.5), 20778009, 1, new BigDecimal(2), 31030008723202L));
		items.add(new GpCartItem(31030008723202L, 30008723202L, 2, new BigDecimal(210.5), 201000001, 1, new BigDecimal(20), 31030008723202L));
		items.add(new GpCartItem(31000002104306L, 2104306L, 9, new BigDecimal(9.8), 20779530, 1, new BigDecimal(20), 31000002104306L));
		items.add(new GpCartItem(31000002104306L, 2104306L, 9, new BigDecimal(9.8), 20832981, 1, new BigDecimal(0), 31000002104306L));
		calAndValidGp(items);
		// 94多GP商品下单(2个商品)
		items.clear();
		items.add(new GpCartItem(31000008017718L, 8017718L, 8, new BigDecimal(4.3), 2015, 1, new BigDecimal(11.70).setScale(2, RoundingMode.HALF_UP), 31000008017718L));
		items.add(new GpCartItem(31000008017718L, 8017718L, 8, new BigDecimal(4.3), 20778009, 1, new BigDecimal(4), 31000008017718L));
		items.add(new GpCartItem(31000008017718L, 8017718L, 8, new BigDecimal(4.3), 20959184, 1, new BigDecimal(3.44).setScale(2, RoundingMode.HALF_UP), 31000008017718L));
		items.add(new GpCartItem(31001410008550L, 1410008550L, 6, new BigDecimal(24), 20846231, 1, new BigDecimal(90), 31001410008550L));
		items.add(new GpCartItem(31001410008550L, 1410008550L, 6, new BigDecimal(24), 20914521, 1, new BigDecimal(0), 31001410008550L));
		calAndValidGp(items);
		// 95多GP商品下单(2个商品)
		items.clear();
		items.add(new GpCartItem(31000004033887L, 4033887L, 5, new BigDecimal(25), 20914521, 1, new BigDecimal(40), 31000004033887L));
		items.add(new GpCartItem(31000004033887L, 4033887L, 5, new BigDecimal(25), 20991849, 1, new BigDecimal(0), 31000004033887L));
		items.add(new GpCartItem(31400606779627L, 606779627L, 8, new BigDecimal(50), 201000005, 1, new BigDecimal(100), 31400606779627L));
		items.add(new GpCartItem(31400606779627L, 606779627L, 8, new BigDecimal(50), 2100000012, 1, new BigDecimal(0), 31400606779627L));
		calAndValidGp(items);
		// 96多GP商品下单(2个商品)
		items.clear();
		items.add(new GpCartItem(31000002104314L, 2104314L, 9, new BigDecimal(9.8), 20832981, 1, new BigDecimal(0), 31000002104314L));
		items.add(new GpCartItem(31000002104314L, 2104314L, 9, new BigDecimal(9.8), 20959184, 1, new BigDecimal(8.82).setScale(2, RoundingMode.HALF_UP), 31000002104314L));
		items.add(new GpCartItem(31000004080488L, 4080488L, 8, new BigDecimal(18.5), 20832981, 1, new BigDecimal(0), 31000004080488L));
		items.add(new GpCartItem(31000004080488L, 4080488L, 8, new BigDecimal(18.5), 20846063, 1, new BigDecimal(8), 31000004080488L));
		items.add(new GpCartItem(31000004080488L, 4080488L, 8, new BigDecimal(18.5), 20959184, 1, new BigDecimal(14.8).setScale(2, RoundingMode.HALF_UP), 31000004080488L));
		items.add(new GpCartItem(31000004080488L, 4080488L, 8, new BigDecimal(18.5), 20991646, 1, new BigDecimal(20), 31000004080488L));
		calAndValidGp(items);
		// 97多GP商品下单(2个商品)
		items.clear();
		items.add(new GpCartItem(31030008723202L, 8723202L, 9, new BigDecimal(210.5), 20778009, 1, new BigDecimal(4), 31030008723202L));
		items.add(new GpCartItem(31030008723202L, 8723202L, 9, new BigDecimal(210.5), 201000001, 1, new BigDecimal(80), 31030008723202L));
		items.add(new GpCartItem(31000002104306L, 2104306L, 9, new BigDecimal(9.8), 20832981, 1, new BigDecimal(0), 31000002104306L));
		items.add(new GpCartItem(31000002104306L, 2104306L, 9, new BigDecimal(9.8), 20779530, 1, new BigDecimal(20), 31000002104306L));
		calAndValidGp(items);
		// 98多GP商品下单(2个商品)
		items.clear();
		items.add(new GpCartItem(31425035650106L, 425035650106L, 2, new BigDecimal(10), 20900049, 1, new BigDecimal(18), 31425035650106L));
		items.add(new GpCartItem(31425035650106L, 425035650106L, 2, new BigDecimal(10), 20900088, 1, new BigDecimal(0), 31425035650106L));
		items.add(new GpCartItem(31690008202003L, 8202003L, 7, new BigDecimal(5), 20899845, 1, new BigDecimal(0), 31690008202003L));
		items.add(new GpCartItem(31690008202003L, 8202003L, 7, new BigDecimal(5), 201000004, 1, new BigDecimal(0), 31690008202003L));
		items.add(new GpCartItem(31690008202003L, 8202003L, 7, new BigDecimal(5), 2100000016, 1, new BigDecimal(33), 31690008202003L));
		calAndValidGp(items);
		// 99多GP商品下单(2个商品)
		items.clear();
		items.add(new GpCartItem(31000008017718L, 8017718L, 10, new BigDecimal(4.3), 2015, 1, new BigDecimal(14.62).setScale(2, RoundingMode.HALF_UP), 31000008017718L));
		items.add(new GpCartItem(31000008017718L, 8017718L, 10, new BigDecimal(4.3), 20778009, 1, new BigDecimal(4), 31000008017718L));
		items.add(new GpCartItem(31000008017718L, 8017718L, 10, new BigDecimal(4.3), 20959184, 1, new BigDecimal(4.3).setScale(2, RoundingMode.HALF_UP), 31000008017718L));

		items.add(new GpCartItem(31000002104314L, 2104314L, 7, new BigDecimal(9.8), 20832981, 1, new BigDecimal(0), 31000002104314L));
		items.add(new GpCartItem(31000002104314L, 2104314L, 7, new BigDecimal(9.8), 20959184, 1, new BigDecimal(6.86).setScale(2, RoundingMode.HALF_UP), 31000002104314L));
		calAndValidGp(items);
		// 105多GP商品下单(3个商品)
		items.clear();
		items.add(new GpCartItem(31212399500000L, 212399500000L, 8, new BigDecimal(5), 2028, 1, new BigDecimal(16), 31212399500000L));
		items.add(new GpCartItem(31212399500000L, 212399500000L, 8, new BigDecimal(5), 20900049, 1, new BigDecimal(0), 31212399500000L));
		items.add(new GpCartItem(31212399500000L, 212399500000L, 8, new BigDecimal(5), 20900088, 1, new BigDecimal(12), 31212399500000L));
		items.add(new GpCartItem(31000008017718L, 8017718L, 4, new BigDecimal(4.3), 2015, 1, new BigDecimal(5.85).setScale(2, RoundingMode.HALF_UP), 31000008017718L));
		items.add(new GpCartItem(31000008017718L, 8017718L, 4, new BigDecimal(4.3), 20778009, 1, new BigDecimal(4), 31000008017718L));
		items.add(new GpCartItem(31000008017718L, 8017718L, 4, new BigDecimal(4.3), 20959184, 1, new BigDecimal(0), 31000008017718L));
		items.add(new GpCartItem(31489102870594L, 489102870594L, 4, new BigDecimal(5), 20779530, 1, new BigDecimal(10), 31489102870594L));
		items.add(new GpCartItem(31489102870594L, 489102870594L, 4, new BigDecimal(5), 20914954, 1, new BigDecimal(0), 31489102870594L));
		items.add(new GpCartItem(31489102870594L, 489102870594L, 4, new BigDecimal(5), 2011000015, 1, new BigDecimal(0), 31489102870594L));
		calAndValidGp(items);
		// 108多GP商品下单(itemA满足)+(itemB1满足)
		items.clear();
		items.add(new GpCartItem(31001538805804L, 1538805804L, 3, new BigDecimal(198), 201000001, 1, new BigDecimal(20), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 3, new BigDecimal(198), 201000002, 1, new BigDecimal(0), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 3, new BigDecimal(198), 201000003, 1, new BigDecimal(178.2).setScale(2, RoundingMode.HALF_UP), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 3, new BigDecimal(198), 201000004, 1, new BigDecimal(100), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 3, new BigDecimal(198), 201000005, 1, new BigDecimal(118.8).setScale(2, RoundingMode.HALF_UP), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 3, new BigDecimal(198), 201000006, 1, new BigDecimal(36), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 3, new BigDecimal(198), 201000008, 1, new BigDecimal(60), 31001538805804L));
		items.add(new GpCartItem(31001538805802L, 1538805802L, 3, new BigDecimal(200), 2011000001, 1, new BigDecimal(21), 31001538805802L));
		items.add(new GpCartItem(31001538805802L, 1538805802L, 3, new BigDecimal(200), 2011000003, 1, new BigDecimal(174), 31001538805802L));
		items.add(new GpCartItem(31001538805802L, 1538805802L, 3, new BigDecimal(200), 2011000004, 1, new BigDecimal(101), 31001538805802L));
		items.add(new GpCartItem(31001538805802L, 1538805802L, 3, new BigDecimal(200), 2011000005, 1, new BigDecimal(114), 31001538805802L));
		items.add(new GpCartItem(31001538805802L, 1538805802L, 3, new BigDecimal(200), 2011000006, 1, new BigDecimal(39), 31001538805802L));
		items.add(new GpCartItem(31001538805802L, 1538805802L, 3, new BigDecimal(200), 2011000008, 1, new BigDecimal(63), 31001538805802L));
		calAndValidGp(items);
		// 109多GP商品下单(itemA触发边界)+(itemB1满足)
		items.clear();
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000001, 1, new BigDecimal(40), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000002, 1, new BigDecimal(0), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000003, 1, new BigDecimal(237.6).setScale(2, RoundingMode.HALF_UP), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000004, 1, new BigDecimal(210), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000005, 1, new BigDecimal(198), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000006, 1, new BigDecimal(72), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000008, 1, new BigDecimal(0), 31001538805804L));
		items.add(new GpCartItem(31001538805802L, 1538805802L, 3, new BigDecimal(200), 2011000001, 1, new BigDecimal(21), 31001538805802L));
		items.add(new GpCartItem(31001538805802L, 1538805802L, 3, new BigDecimal(200), 2011000003, 1, new BigDecimal(174), 31001538805802L));
		items.add(new GpCartItem(31001538805802L, 1538805802L, 3, new BigDecimal(200), 2011000004, 1, new BigDecimal(101), 31001538805802L));
		items.add(new GpCartItem(31001538805802L, 1538805802L, 3, new BigDecimal(200), 2011000005, 1, new BigDecimal(114), 31001538805802L));
		items.add(new GpCartItem(31001538805802L, 1538805802L, 3, new BigDecimal(200), 2011000006, 1, new BigDecimal(39), 31001538805802L));
		items.add(new GpCartItem(31001538805802L, 1538805802L, 3, new BigDecimal(200), 2011000008, 1, new BigDecimal(63), 31001538805802L));
		calAndValidGp(items);
		// 110多GP商品下单(itemA触发边界)+(itemB2触发边界)
		items.clear();
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000001, 1, new BigDecimal(40), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000002, 1, new BigDecimal(0), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000003, 1, new BigDecimal(237.6).setScale(2, RoundingMode.HALF_UP), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000004, 1, new BigDecimal(210), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000005, 1, new BigDecimal(198), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000006, 1, new BigDecimal(72), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000008, 1, new BigDecimal(0), 31001538805804L));
		items.add(new GpCartItem(31030008718001L, 30008718001L, 3, new BigDecimal(200), 2011000001, 1, new BigDecimal(21), 31030008718001L));
		items.add(new GpCartItem(31030008718001L, 30008718001L, 3, new BigDecimal(200), 2011000003, 1, new BigDecimal(174), 31030008718001L));
		items.add(new GpCartItem(31030008718001L, 30008718001L, 3, new BigDecimal(200), 2011000004, 1, new BigDecimal(101), 31030008718001L));
		items.add(new GpCartItem(31030008718001L, 30008718001L, 3, new BigDecimal(200), 2011000005, 1, new BigDecimal(114), 31030008718001L));
		items.add(new GpCartItem(31030008718001L, 30008718001L, 3, new BigDecimal(200), 2011000006, 1, new BigDecimal(39), 31030008718001L));
		items.add(new GpCartItem(31030008718001L, 30008718001L, 3, new BigDecimal(200), 2011000008, 1, new BigDecimal(63), 31030008718001L));
		calAndValidGp(items);
		// 111多GP商品下单(itemA触发边界)+(itemB3触发边界)
		items.clear();
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000001, 1, new BigDecimal(40),
				31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000002, 1, new BigDecimal(0),
				31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000003, 1,
				new BigDecimal(237.6).setScale(2, RoundingMode.HALF_UP), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000004, 1,
				new BigDecimal(210), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000005, 1,
				new BigDecimal(198), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000006, 1, new BigDecimal(72),
				31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000008, 1, new BigDecimal(0),
				31001538805804L));
		items.add(new GpCartItem(31691462121086L, 691462121086L, 3, new BigDecimal(200), 2011000001, 1,
				new BigDecimal(21), 31691462121086L));
		items.add(new GpCartItem(31691462121086L, 691462121086L, 3, new BigDecimal(200), 2011000003, 1,
				new BigDecimal(174), 31691462121086L));
		items.add(new GpCartItem(31691462121086L, 691462121086L, 3, new BigDecimal(200), 2011000004, 1,
				new BigDecimal(101), 31691462121086L));
		items.add(new GpCartItem(31691462121086L, 691462121086L, 3, new BigDecimal(200), 2011000005, 1,
				new BigDecimal(114), 31691462121086L));
		items.add(new GpCartItem(31691462121086L, 691462121086L, 3, new BigDecimal(200), 2011000006, 1,
				new BigDecimal(39), 31691462121086L));
		items.add(new GpCartItem(31691462121086L, 691462121086L, 3, new BigDecimal(200), 2012000008, 1,
				new BigDecimal(0), 31691462121086L));
		calAndValidGp(items);
		// 112多GP商品下单(itemA触发边界)
		items.clear();
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000001, 1, new BigDecimal(40),
				31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000002, 1, new BigDecimal(0),
				31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000003, 1,
				new BigDecimal(237.6).setScale(2, RoundingMode.HALF_UP), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000004, 1,
				new BigDecimal(210), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000005, 1,
				new BigDecimal(198), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000006, 1, new BigDecimal(72),
				31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 4, new BigDecimal(198), 201000008, 1, new BigDecimal(0),
				31001538805804L));
		calAndValidGp(items);
		// 113 多GP异常测试(itemA满足)
		items.clear();
		items.add(new GpCartItem(31001538805804L, 1538805804L, 3, new BigDecimal(198), 201000001, 1, new BigDecimal(20),
				31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 3, new BigDecimal(198), 201000002, 1, new BigDecimal(0),
				31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 3, new BigDecimal(198), 201000003, 1,
				new BigDecimal(178.2).setScale(2, RoundingMode.HALF_UP), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 3, new BigDecimal(198), 201000004, 1,
				new BigDecimal(100), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 3, new BigDecimal(198), 201000005, 1,
				new BigDecimal(118.8).setScale(2, RoundingMode.HALF_UP), 31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 3, new BigDecimal(198), 201000006, 1, new BigDecimal(36),
				31001538805804L));
		items.add(new GpCartItem(31001538805804L, 1538805804L, 3, new BigDecimal(198), 201000008, 1, new BigDecimal(60),
				31001538805804L));
		calAndValidGp(items);
	}

	private void calAndValidGp(List<GpCartItem> items) {
		BigDecimal totalDiscount = BigDecimal.ZERO;
		CalcDiscountResult calcDiscountResult = promotionService.calculateInItemLevel(items);
		Map<Integer, List<GpCartItem>> returnItems = calcDiscountResult.getGpOfferDiscounts();
		
		for (GpCartItem gpCartItem : items) {
			totalDiscount = totalDiscount.add(gpCartItem.getClientDiscount());
			if(returnItems != null && !returnItems.isEmpty()){
			List<GpCartItem> gpCartItemList = returnItems.get(gpCartItem.getGpOfferId());
			
			LOG.info("the gpOfferId is =================== {}",gpCartItem.getGpOfferId());
			
			for (GpCartItem calGpCartItem : gpCartItemList) {
				if (gpCartItem.getProductId().equals(calGpCartItem.getProductId())) {
					Assert.isTrue(gpCartItem.getClientDiscount().compareTo(calGpCartItem.getGpDiscount()) == 0, "");
				}
			}
			}
		}
		Assert.isTrue(totalDiscount.compareTo(calcDiscountResult.getTotalDiscount()) == 0, "result error");
	}
}