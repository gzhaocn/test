package com.walmart.mobile.checkout.service.promotion;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.walmart.mobile.checkout.bo.promotion.GpCartItem;
import com.walmart.mobile.checkout.utils.CollectionGroupUtil;


public class CollectionGroupUtilTest {
    
    /**
     * 大于分组数量的情况
     */
    @Test
    public void test() {
        List<GpCartItem> allList = new ArrayList<>();
        for (int i = 1; i <= 504; i++) {
        	GpCartItem gpCartItem = new GpCartItem();
        	gpCartItem.setProductId(Long.valueOf(i));
            allList.add(gpCartItem);
        }
        
        List<List<GpCartItem>> groupList = CollectionGroupUtil.groupListByQuantity(allList, 50);
        List<GpCartItem> list = null;
        for (int c = 0; c < groupList.size(); c++) {
            list = groupList.get(c);
            
            System.out.println("1第" + (c + 1) + "组： ");
            for (GpCartItem temp : list) {
                System.out.print(temp.getProductId() + ", ");
            }
            System.out.println();
        }
    }

    /**
     * 小于分组数量的情况
     */
    @Test
    public void test2() {
        List<GpCartItem> allList = new ArrayList<>();
        for (int i = 1; i <= 45; i++) {
        	GpCartItem gpCartItem = new GpCartItem();
        	gpCartItem.setProductId(Long.valueOf(i));
            allList.add(gpCartItem);
        }
        
        List<List<GpCartItem>> groupList = CollectionGroupUtil.groupListByQuantity(allList, 50);
        List<GpCartItem> list = null;
        for (int c = 0; c < groupList.size(); c++) {
            list = groupList.get(c);
            
            System.out.println("2第" + (c + 1) + "组： ");
            for (GpCartItem temp : list) {
                System.out.print(temp.getProductId() + ", ");
            }
            System.out.println();
        }
    }
    
    /**
     * 集合只有一个记录的情况
     */
    @Test
    public void test3() {
        List<GpCartItem> allList = new ArrayList<>();
        for (int i = 1; i <= 1; i++) {
        	GpCartItem gpCartItem = new GpCartItem();
        	gpCartItem.setProductId(Long.valueOf(i));
            allList.add(gpCartItem);
        }
        
        List<List<GpCartItem>> groupList = CollectionGroupUtil.groupListByQuantity(allList, 50);
        List<GpCartItem> list = null;
        for (int c = 0; c < groupList.size(); c++) {
            list = groupList.get(c);
            
            System.out.println("3第" + (c + 1) + "组： ");
            for (GpCartItem temp : list) {
                System.out.print(temp.getProductId() + ", ");
            }
            System.out.println();
        }
    }
    
    /**
     * 空集合的情况
     */
    @Test
    public void test4() {
        List<List<GpCartItem>> groupList = CollectionGroupUtil.groupListByQuantity(null, 50);
        System.out.println("5第null组： ");
        System.out.println(groupList);
        
        groupList = CollectionGroupUtil.groupListByQuantity(new ArrayList<GpCartItem>(), 50);
        System.out.println(groupList);
    }
    
    /**
     * 集合刚满一个分组的情况
     */
    @Test
    public void test5() {
        List<GpCartItem> allList = new ArrayList<>();
        for (int i = 1; i <= 50; i++) {
        	GpCartItem gpCartItem = new GpCartItem();
        	gpCartItem.setProductId(Long.valueOf(i));
            allList.add(gpCartItem);
        }
        
        List<List<GpCartItem>> groupList = CollectionGroupUtil.groupListByQuantity(allList, 50);
        List<GpCartItem> list = null;
        for (int c = 0; c < groupList.size(); c++) {
            list = groupList.get(c);
            
            System.out.println("6第" + (c + 1) + "组： ");
            for (GpCartItem temp : list) {
                System.out.print(temp.getProductId() + ", ");
            }
            System.out.println();
        }
    }
    
}