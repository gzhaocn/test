package com.walmart.mobile.checkout.service.promotion;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.easymock.EasyMock;
import org.easymock.IMocksControl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.Assert;

import com.alibaba.fastjson.JSON;
import com.walmart.mobile.checkout.bo.promotion.GpCartItem;
import com.walmart.mobile.checkout.config.MainConfig;
import com.walmart.mobile.checkout.entity.promotion.GpOffer;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.repo.GpOfferRepository;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MainConfig.class })
@WebAppConfiguration
public class PromotionServiceGpTypeCode4MockTest {
	@Autowired
	PromotionService promotionService;

	@Test
	public void promotionServiceCalcDiscountTest() throws GlobalErrorInfoException {

		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = " [{\"beginDate\":1436716800000,\"discountFactor\":7.0,\"endDate\":1444665600000,\"gpOfferId\":1100070,\"gpTypeCode\":4,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":3}],\"id\":27955649630386115960929400807,\"promotionDesc\":\"参与本活动的商品任选3件仅需7元\",\"promotionDescCn\":\"参与本活动的商品任选3件仅需7元\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(31692138451362L, 1L, 1, new BigDecimal("200.03"), 1100070, 1, new BigDecimal("197.53"), 31692138451362L));
		items.add(new GpCartItem(31692138451363L, 2L, 1, new BigDecimal("180.03"), 1100070, 1, new BigDecimal("177.78"), 31692138451363L));
		items.add(new GpCartItem(31692138451364L, 3L, 1, new BigDecimal("180.04"), 1100070, 1, new BigDecimal("177.79"), 31692138451364L));
		discount = promotionService.calcDiscount(items); //
		Assert.isTrue((new BigDecimal("553.1")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result error");

		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}
	
	@Test
	public void promotionServiceCalcDiscountTest2() throws GlobalErrorInfoException {

		IMocksControl mocksControl = EasyMock.createControl();
		GpOfferRepository mockGpOfferRepository = mocksControl.createMock(GpOfferRepository.class);
		// 创建虚拟对象方法期望的返回值
		String gpOfferJson = " [{\"beginDate\":1436716800000,\"discountFactor\":7.0,\"endDate\":1444665600000,\"gpOfferId\":1100070,\"gpTypeCode\":4,\"groups\":[{\"groupSeq\":1,\"thresholdQty\":3}],\"id\":27955649630386115960929400807,\"promotionDesc\":\"参与本活动的商品任选3件仅需7元\",\"promotionDescCn\":\"参与本活动的商品任选3件仅需7元\",\"promotionDescEn\":\"\",\"status\":0}]";
		List<GpOffer> gOffers = JSON.parseArray(gpOfferJson, GpOffer.class);
		// 录制动作
		EasyMock.expect(mockGpOfferRepository.findByGpOfferIdInAndStatus(EasyMock.anyObject(List.class), EasyMock.anyInt())).andReturn(gOffers);
		// 回放动作
		mocksControl.replay();
		// 用spring提供的方法注入aurowired的字段
		ReflectionTestUtils.setField(promotionService, "gpOfferRepository", mockGpOfferRepository, GpOfferRepository.class);
		// 执行测试方法

		List<GpCartItem> items = new ArrayList<GpCartItem>();
		double discount;
		items.add(new GpCartItem(31692138451361L, 4L, 1, new BigDecimal("160.15"), 1100070, 1, new BigDecimal("99.73"), 31692138451361L));
		items.add(new GpCartItem(31692138451362L, 1L, 2, new BigDecimal("200.03"), 1100070, 1, new BigDecimal("249.14"), 31692138451362L));
		items.add(new GpCartItem(31692138451363L, 2L, 1, new BigDecimal("180.03"), 1100070, 1, new BigDecimal("112.11"), 31692138451363L));
		items.add(new GpCartItem(31692138451364L, 3L, 1, new BigDecimal("180.04"), 1100070, 1, new BigDecimal("112.12"), 31692138451364L));
		discount = promotionService.calcDiscount(items);
		Assert.isTrue((new BigDecimal("573.1")).compareTo(new BigDecimal(Double.toString(discount))) == 0, "result error");
		// 验证是否使用了上面录制的DAO
		EasyMock.verify(mockGpOfferRepository);
		mocksControl.reset();
	}

	

}
