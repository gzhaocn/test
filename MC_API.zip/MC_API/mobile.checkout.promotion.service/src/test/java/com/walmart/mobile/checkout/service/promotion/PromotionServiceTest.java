package com.walmart.mobile.checkout.service.promotion;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;

import com.walmart.mobile.checkout.bo.promotion.GpCartItem;

@RunWith(SpringJUnit4ClassRunner.class)
public class PromotionServiceTest {

	@Test
	public void testPad() {
		// miss
		BigDecimal totalAmt = new BigDecimal(0);
		List<GpCartItem> returnItems = new ArrayList<GpCartItem>();
		for (int i = 0; i < 6; i++) {
			GpCartItem item = new GpCartItem();
			BigDecimal taxPrice = new BigDecimal(10);
			item.setTaxPrice(taxPrice);
			totalAmt = totalAmt.add(taxPrice);
			item.setCartItemId((long) i);
			item.setQty(1);
			item.setUpc((long) i);
			item.setProductId((long) i);
			returnItems.add(item);
		}

		BigDecimal discount = new BigDecimal(2);

		for (int i = 0; i < returnItems.size(); i++) {
			GpCartItem item = returnItems.get(i);
			BigDecimal itemDiscount = new BigDecimal(Integer.toString(item.getQty())).multiply(item.getTaxPrice())
					.multiply(discount).divide(totalAmt, 2, BigDecimal.ROUND_HALF_UP);
			item.setGpDiscount(itemDiscount);
			item.setQty(0);
			returnItems.set(i, item);
		}

		PromotionService.doPadDiscount(returnItems, discount);
		Assert.isTrue(returnItems.get(0).getGpDiscount().compareTo(new BigDecimal("0.34")) == 0, "");
		Assert.isTrue(returnItems.get(1).getGpDiscount().compareTo(new BigDecimal("0.34")) == 0, "");
		Assert.isTrue(returnItems.get(2).getGpDiscount().compareTo(new BigDecimal("0.33")) == 0, "");
		Assert.isTrue(returnItems.get(3).getGpDiscount().compareTo(new BigDecimal("0.33")) == 0, "");
		Assert.isTrue(returnItems.get(4).getGpDiscount().compareTo(new BigDecimal("0.33")) == 0, "");
		Assert.isTrue(returnItems.get(5).getGpDiscount().compareTo(new BigDecimal("0.33")) == 0, "");
		// over
		totalAmt = new BigDecimal(0);
		returnItems = new ArrayList<GpCartItem>();
		for (int i = 0; i < 6; i++) {
			GpCartItem item = new GpCartItem();
			BigDecimal taxPrice = new BigDecimal(10);
			item.setTaxPrice(taxPrice);
			totalAmt = totalAmt.add(taxPrice);
			item.setQty(1);
			item.setCartItemId((long) i);
			item.setUpc((long) i);
			item.setProductId((long) i);
			returnItems.add(item);
		}

		discount = new BigDecimal(4);

		for (int i = 0; i < returnItems.size(); i++) {
			GpCartItem item = returnItems.get(i);
			BigDecimal itemDiscount = new BigDecimal(Integer.toString(item.getQty())).multiply(item.getTaxPrice())
					.multiply(discount).divide(totalAmt, 2, BigDecimal.ROUND_HALF_UP);
			item.setGpDiscount(itemDiscount);
			item.setQty(0);
			returnItems.set(i, item);
		}

		PromotionService.doPadDiscount(returnItems, discount);
		Assert.isTrue(returnItems.get(0).getGpDiscount().compareTo(new BigDecimal("0.66")) == 0, "");
		Assert.isTrue(returnItems.get(1).getGpDiscount().compareTo(new BigDecimal("0.66")) == 0, "");
		Assert.isTrue(returnItems.get(2).getGpDiscount().compareTo(new BigDecimal("0.67")) == 0, "");
		Assert.isTrue(returnItems.get(3).getGpDiscount().compareTo(new BigDecimal("0.67")) == 0, "");
		Assert.isTrue(returnItems.get(4).getGpDiscount().compareTo(new BigDecimal("0.67")) == 0, "");
		Assert.isTrue(returnItems.get(5).getGpDiscount().compareTo(new BigDecimal("0.67")) == 0, "");

		totalAmt = new BigDecimal(0);
		returnItems = new ArrayList<GpCartItem>();
		for (int i = 0; i < 6; i++) {
			GpCartItem item = new GpCartItem();
			BigDecimal taxPrice = new BigDecimal(10);
			item.setTaxPrice(taxPrice);
			totalAmt = totalAmt.add(taxPrice);
			item.setQty(1);
			item.setCartItemId((long) i);
			item.setUpc((long) i);
			item.setUpc((long) i);
			returnItems.add(item);
		}

		discount = new BigDecimal(6);

		// equal
		for (int i = 0; i < returnItems.size(); i++) {
			GpCartItem item = returnItems.get(i);
			BigDecimal itemDiscount = new BigDecimal(Integer.toString(item.getQty())).multiply(item.getTaxPrice())
					.multiply(discount).divide(totalAmt, 2, BigDecimal.ROUND_HALF_UP);
			item.setGpDiscount(itemDiscount);
			item.setQty(0);
			returnItems.set(i, item);
		}

		PromotionService.doPadDiscount(returnItems, discount);
		Assert.isTrue(returnItems.get(0).getGpDiscount().compareTo(new BigDecimal("1")) == 0, "");
		Assert.isTrue(returnItems.get(1).getGpDiscount().compareTo(new BigDecimal("1")) == 0, "");
		Assert.isTrue(returnItems.get(2).getGpDiscount().compareTo(new BigDecimal("1")) == 0, "");
		Assert.isTrue(returnItems.get(3).getGpDiscount().compareTo(new BigDecimal("1")) == 0, "");
		Assert.isTrue(returnItems.get(4).getGpDiscount().compareTo(new BigDecimal("1")) == 0, "");
		Assert.isTrue(returnItems.get(5).getGpDiscount().compareTo(new BigDecimal("1")) == 0, "");

	}

}
