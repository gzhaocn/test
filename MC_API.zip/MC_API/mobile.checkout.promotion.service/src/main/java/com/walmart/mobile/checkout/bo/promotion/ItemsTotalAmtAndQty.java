package com.walmart.mobile.checkout.bo.promotion;

import java.math.BigDecimal;

public class ItemsTotalAmtAndQty {
	private BigDecimal totalAmt; 
	private int totalQty ;
	public BigDecimal getTotalAmt() {
		return totalAmt;
	}
	public void setTotalAmt(BigDecimal totalAmt) {
		this.totalAmt = totalAmt;
	}
	public int getTotalQty() {
		return totalQty;
	}
	public void setTotalQty(int totalQty) {
		this.totalQty = totalQty;
	}

}
