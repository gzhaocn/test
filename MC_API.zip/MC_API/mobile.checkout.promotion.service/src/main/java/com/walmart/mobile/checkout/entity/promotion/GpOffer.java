package com.walmart.mobile.checkout.entity.promotion;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.util.Date;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.walmart.mobile.checkout.entity.document.BaseDocument;

/**
 * gp信息
 * 
 * @author lliao2
 *
 */
@Document(collection = "gp_offer")
public class GpOffer extends BaseDocument<BigInteger> {

	/**
	* 
	*/
	private static final long serialVersionUID = 1L;
	@Field("gp_offer_id")
	private Integer gpOfferId;
	@Field("gp_type_code")
	private Integer gpTypeCode;
	@Field("begin_date")
	private Date beginDate;
	@Field("end_date")
	private Date endDate;
	@Field("discount_factor")
	private Float discountFactor;
	private List<Group> groups;
	@Field("promotion_desc_en")
	private String promotionDescEn;
	@Field("promotion_desc_cn")
	private String promotionDescCn;
	@Field("promotion_actual_desc")
	private String promotionActualDesc;
	@Field("gp_offer_category_ids")
	private List<Long> gpOfferCategoryIds;

	@Field("gp_bk_color")
	private Integer backgroundColor;

	@Field("gp_thumbnail_url")
	private String gpThumbnailUrl;

	@Field("status")
	private Integer status;

	@Field("promotion_title_cn")
	private String promotionTitleCn;

	@Field("updated_time")
	private Date updatedTime;

	@Field("discount_times")
	private Integer discountTimes;

	public String getPromotionDesc() {
		return promotionDescCn;
	}

	public Integer getDiscountTimes() {
		return discountTimes;
	}

	public void setDiscountTimes(Integer discountTimes) {
		this.discountTimes = discountTimes;
	}

	public Integer getGpOfferId() {
		return gpOfferId;
	}

	public Integer getGpTypeCode() {
		return gpTypeCode;
	}

	public Date getBeginDate() {
		return beginDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public Float getDiscountFactor() {

		BigDecimal df = new BigDecimal(discountFactor.toString());
		return df.setScale(2, RoundingMode.HALF_UP).floatValue();
	}

	public List<Group> getGroups() {
		return groups;
	}

	public String getPromotionDescEn() {
		return promotionDescEn == null ? "" : promotionDescEn;
	}

	public String getPromotionDescCn() {
		return promotionDescCn == null ? "" : promotionDescCn.replace("{", "").replace("}", "");
	}

	public void setGpOfferId(Integer gpOfferId) {
		this.gpOfferId = gpOfferId;
	}

	public void setGpTypeCode(Integer gpTypeCode) {
		this.gpTypeCode = gpTypeCode;
	}

	public void setBeginDate(Date beginDate) {
		this.beginDate = beginDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public void setDiscountFactor(Float discountFactor) {
		this.discountFactor = discountFactor;
	}

	public void setGroups(List<Group> groups) {
		this.groups = groups;
	}

	public void setPromotionDescEn(String promotionDescEn) {
		this.promotionDescEn = promotionDescEn;
	}

	public void setPromotionDescCn(String promotionDescCn) {
		this.promotionDescCn = promotionDescCn;
	}

	public Integer getBackgroundColor() {
		return backgroundColor;
	}

	public void setBackgroundColor(Integer backgroundColor) {
		this.backgroundColor = backgroundColor;
	}

	public List<Long> getGpOfferCategoryIds() {
		return gpOfferCategoryIds;
	}

	public void setGpOfferCategoryIds(List<Long> gpOfferCategoryIds) {
		this.gpOfferCategoryIds = gpOfferCategoryIds;
	}

	public String getGpThumbnailUrl() {
		return gpThumbnailUrl;
	}

	public void setGpThumbnailUrl(String gpThumbnailUrl) {
		this.gpThumbnailUrl = gpThumbnailUrl;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getPromotionTitleCn() {
		return promotionTitleCn;
	}

	public void setPromotionTitleCn(String promotionTitleCn) {
		this.promotionTitleCn = promotionTitleCn;
	}

	public Date getUpdatedTime() {
		return updatedTime;
	}

	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}

	public String getPromotionActualDesc() {
		return promotionActualDesc;
	}

	public void setPromotionActualDesc(String promotionActualDesc) {
		this.promotionActualDesc = promotionActualDesc;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((gpOfferId == null) ? 0 : gpOfferId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}

		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}

		GpOffer other = (GpOffer) obj;

		if (gpOfferId == null || other.gpOfferId == null || !(this.gpOfferId.equals(other.gpOfferId))) {
			return false;
		}
		return true;
	}
}
