package com.walmart.mobile.checkout.utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.walmart.mobile.checkout.bo.promotion.GpCartItem;
/**
 * gp_type_code为4,按数量分组,对于最后循环不满足(count + quantity) > list.size()条件的，因为不参与计算，所以直接舍弃
 * @author lliao2
 *
 */
public class CollectionGroupUtil {
	private CollectionGroupUtil(){}
	  public static List<List<GpCartItem>> groupListByQuantity(List<GpCartItem> list, int quantity) {
	        if (list == null || list.isEmpty()) {
	            return Collections.emptyList();
	        }
	        if (quantity <= 0) {
	            new IllegalArgumentException("Wrong quantity.");
	        }
	        List<List<GpCartItem>> wrapList = new ArrayList<>();
	        int count = 0;
	        while (count < list.size()) {
	            wrapList.add( list.subList(count, (count + quantity) > list.size() ? count: count + quantity));
	            count += quantity;
	        }
	        
	        return wrapList;
	    }

}
