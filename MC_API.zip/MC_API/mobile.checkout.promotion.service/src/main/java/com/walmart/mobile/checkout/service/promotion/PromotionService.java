package com.walmart.mobile.checkout.service.promotion;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.beanutils.BeanComparator;
import org.apache.commons.collections.ComparatorUtils;
import org.apache.commons.collections.comparators.ComparableComparator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.walmart.mobile.checkout.bo.promotion.CalcDiscountResult;
import com.walmart.mobile.checkout.bo.promotion.CalcItemsDiscountTimes;
import com.walmart.mobile.checkout.bo.promotion.GpCartItem;
import com.walmart.mobile.checkout.bo.promotion.ItemsTotalAmtAndQty;
import com.walmart.mobile.checkout.constant.AppConstants;
import com.walmart.mobile.checkout.entity.promotion.GpOffer;
import com.walmart.mobile.checkout.entity.promotion.Group;
import com.walmart.mobile.checkout.entity.promotion.TieredDiscount;
import com.walmart.mobile.checkout.enumcode.promotion.PromotionErrorInfoEnum;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoRuntimeException;
import com.walmart.mobile.checkout.repo.GpOfferRepository;
import com.walmart.mobile.checkout.utils.CollectionGroupUtil;

/**
 * promotion服务类
 * 
 * @author lliao2
 *
 */
@Service
public class PromotionService {
	/**
	 * Promotion types
	 */
	private static final int GP_PROMOTION_TYPE_AMT = 0;
	private static final int GP_PROMOTION_TYPE_PCT = 1;
	private static final int GP_PROMOTION_TYPE_AMT_TIERED = 2;
	private static final int GP_PROMOTION_TYPE_PCT_TIERED = 3;
	private static final int GP_PROMOTION_TYPE_FIXED = 4;
	private static final int GP_PROMOTION_TYPE_AMT_ONLINE = 6;

	private static final Logger LOG = LoggerFactory.getLogger(PromotionService.class);
	@Autowired
	private GpOfferRepository gpOfferRepository;

	/**
	 * 计算discount之和
	 * 
	 * @param items
	 * @return
	 */
	public double calcDiscount(List<GpCartItem> items) {

		// 分组中已经将items分摊的gpDiscount设置为了0
		CalcDiscountResult calcDiscountResult = calculateInItemLevel(items); // gp分组并分摊gp到item,计算商品的多gp之和
		return calcDiscountResult.getTotalDiscount().doubleValue();

	}

	/**
	 * 分摊算法
	 * 
	 * @param items
	 * @return
	 */
	public CalcDiscountResult calculateInItemLevel(List<GpCartItem> items) {
		BigDecimal totalDiscount = BigDecimal.ZERO;
		boolean itemLevelDisocuntCompareFlag = true;

		CalcDiscountResult calcDiscountResult = new CalcDiscountResult();
		/** Map<Integer, List<GpCartItem>> returnItems = calculateInItem(items); */

		List<CalcItemsDiscountTimes> calcItemsDiscountTimesList = calculateInItem(items);
		Map<Long, BigDecimal> itemsDiscountMap = new HashMap<>(16);

		if (calcItemsDiscountTimesList == null || calcItemsDiscountTimesList.isEmpty()) {
			return calcDiscountResult;
		}
		for (CalcItemsDiscountTimes calcItemsDiscountTimes : calcItemsDiscountTimesList) {
			try {
				List<GpCartItem> gpCartItemList = calcItemsDiscountTimes.getReturnItems();
				if (gpCartItemList == null || gpCartItemList.isEmpty()) {
					continue;
				}
				boolean exceptionFlag = validateGpOffer(gpCartItemList, itemsDiscountMap);
				totalDiscount = totalDiscount.add(sumItemDiscount(gpCartItemList, itemsDiscountMap, exceptionFlag));
			} catch (GlobalErrorInfoRuntimeException e) {
				LOG.info("error", e);
				LOG.error("calculateInItemLevel cause exception,the code is {}, message is {}", e.getErrorInfo().getCode(), e.getErrorInfo().getMessage());
				itemLevelDisocuntCompareFlag = false;
			}
		}

		Map<Integer, List<GpCartItem>> gpCartItemMap = new HashMap<>(16);
		Map<Integer, Integer> gpCartItemMinTimesMap = new HashMap<>(16);
		for (CalcItemsDiscountTimes calcItemsDiscountTimes : calcItemsDiscountTimesList) {
			gpCartItemMap.put(calcItemsDiscountTimes.getGpOfferId(), calcItemsDiscountTimes.getReturnItems());
			gpCartItemMinTimesMap.put(calcItemsDiscountTimes.getGpOfferId(), calcItemsDiscountTimes.getMinTimes());
		}

		calcDiscountResult.setGpOfferDiscounts(gpCartItemMap);
		calcDiscountResult.setTotalDiscount(totalDiscount);
		calcDiscountResult.setItemLevelDisocuntCompareFlag(itemLevelDisocuntCompareFlag);
		calcDiscountResult.setGpOfferIdMinTimesMap(gpCartItemMinTimesMap);
		return calcDiscountResult;

	}

	/**
	 * 找出validate的gp
	 * 
	 * @param value
	 * @param itemsDiscountMap
	 * @return
	 */
	private boolean validateGpOffer(List<GpCartItem> gpCartItemList, Map<Long, BigDecimal> itemsDiscountMap) {
		boolean exceptionFlag = false;
		for (GpCartItem gpCartItem : gpCartItemList) {
			if (!itemsDiscountMap.containsKey(gpCartItem.getCartItemId())) {
				itemsDiscountMap.put(gpCartItem.getCartItemId(), BigDecimal.ZERO);
			}
			BigDecimal itemDiscount = itemsDiscountMap.get(gpCartItem.getCartItemId()).add(gpCartItem.getGpDiscount()).setScale(2, RoundingMode.HALF_UP);
			BigDecimal itemAmount = gpCartItem.getTaxPrice().multiply(new BigDecimal(gpCartItem.getQty())).setScale(2, RoundingMode.HALF_UP);
			if (itemDiscount.subtract(itemAmount).compareTo(BigDecimal.ZERO) >= 0) {
				exceptionFlag = true;
			}

		}
		return exceptionFlag;
	}

	/**
	 * 计算itemDiscount
	 * 
	 * @param value
	 * @param itemsDiscountMap
	 * @param exceptionFlag
	 * @throws GlobalErrorInfoException
	 */
	private BigDecimal sumItemDiscount(List<GpCartItem> gpCartItemList, Map<Long, BigDecimal> itemsDiscountMap, boolean exceptionFlag) {
		BigDecimal totalDiscount = BigDecimal.ZERO;
		if (exceptionFlag) {
			for (GpCartItem gpCartItem : gpCartItemList) {
				gpCartItem.setGpDiscount(BigDecimal.ZERO);
				// gp不一致，直接中断计算
				if (gpCartItem.getClientDiscount().compareTo(gpCartItem.getGpDiscount()) != 0) {
					LOG.error("clientDiscount not equals serverGpDiscount,productId is {},cartItemId is {},clientDiscount is {}, serverDiscount is {}", gpCartItem.getProductId(),
							gpCartItem.getCartItemId(), gpCartItem.getClientDiscount(), gpCartItem.getGpDiscount());
					throw new GlobalErrorInfoRuntimeException(PromotionErrorInfoEnum.DISCOUNT_NOT_COMPARE);
				}

			}
		} else {
			for (GpCartItem gpCartItem : gpCartItemList) {
				// gp不一致，直接中断计算
				if (gpCartItem.getClientDiscount().compareTo(gpCartItem.getGpDiscount()) != 0) {
					LOG.error("clientDiscount not equals serverGpDiscount,productId is {},cartItemId is {},clientDiscount is {}, serverDiscount is {}", gpCartItem.getProductId(),
							gpCartItem.getCartItemId(), gpCartItem.getClientDiscount(), gpCartItem.getGpDiscount());
					throw new GlobalErrorInfoRuntimeException(PromotionErrorInfoEnum.DISCOUNT_NOT_COMPARE);
				}
				BigDecimal itemDiscount = itemsDiscountMap.get(gpCartItem.getCartItemId()).add(gpCartItem.getGpDiscount()).setScale(2, RoundingMode.HALF_UP);
				itemsDiscountMap.put(gpCartItem.getCartItemId(), itemDiscount);
				totalDiscount = totalDiscount.add(gpCartItem.getGpDiscount());
			}
		}
		return totalDiscount;
	}

	/**
	 * 单gp分摊算法
	 * 
	 * @param items
	 * @return
	 */
	private List<CalcItemsDiscountTimes> calculateInItem(List<GpCartItem> items) {
		List<CalcItemsDiscountTimes> calcOfferReturnItemsList = new ArrayList<>();

		Map<Integer, Map<Integer, List<GpCartItem>>> cartItems = getMatchedOffers(items);
		if (cartItems.isEmpty()) {
			return Collections.emptyList();
		}
		try {
			List<GpOffer> gOffers = gpOfferRepository.findByGpOfferIdInAndStatus(Arrays.asList(cartItems.keySet().toArray(new Integer[0])), AppConstants.OFFER_STATUS_EFFECTIVE);

			for (GpOffer gOffer : gOffers) {

				Map<Integer, List<GpCartItem>> groupMatchedItems = cartItems.get(gOffer.getGpOfferId());
				CalcItemsDiscountTimes calcItemsDiscountTimes;
				switch (gOffer.getGpTypeCode()) {
				case GP_PROMOTION_TYPE_AMT:
					calcItemsDiscountTimes = calculateInItemLevelTypeAMT(gOffer, groupMatchedItems);
					calcOfferReturnItemsList.add(calcItemsDiscountTimes);
					break;
				case GP_PROMOTION_TYPE_PCT:
					calcItemsDiscountTimes = calculateInItemLevelTypePCT(gOffer, groupMatchedItems);
					calcOfferReturnItemsList.add(calcItemsDiscountTimes);
					break;
				case GP_PROMOTION_TYPE_FIXED:
					calcItemsDiscountTimes = calculateInItemLevelTypeFixed(gOffer, groupMatchedItems);
					calcOfferReturnItemsList.add(calcItemsDiscountTimes);
					break;
				case GP_PROMOTION_TYPE_AMT_TIERED:
					calcItemsDiscountTimes = calculateInItemLevelTypeAMTTiered(gOffer, groupMatchedItems);
					calcOfferReturnItemsList.add(calcItemsDiscountTimes);
					break;
				case GP_PROMOTION_TYPE_PCT_TIERED:
					calcItemsDiscountTimes = calculateInItemLevelTypePCTTiered(gOffer, groupMatchedItems);
					calcOfferReturnItemsList.add(calcItemsDiscountTimes);
					break;
				case GP_PROMOTION_TYPE_AMT_ONLINE:
					calcItemsDiscountTimes = calculateInItemLevelTypeAMTOnline(gOffer, groupMatchedItems);
					calcOfferReturnItemsList.add(calcItemsDiscountTimes);
					break;
				default:
					break;
				}
			}

		} catch (Exception ex) {
			StringBuilder logMsg = new StringBuilder();
			logMsg.append("Items:\n");
			for (GpCartItem itemSales : items) {
				logMsg.append("Item#: ");
				logMsg.append(itemSales.getProductId());
				logMsg.append(" Qty: ");
				logMsg.append(itemSales.getQty());
				logMsg.append(" TaxPrice: ");
				logMsg.append(itemSales.getTaxPrice());
				logMsg.append('\n');
			}
			LOG.error("Error occurs while calculate discount.{}", logMsg.toString(), ex);
		}
		calcOfferReturnItemsList.sort((CalcItemsDiscountTimes h1, CalcItemsDiscountTimes h2) -> h1.getGpOfferId().compareTo(h2.getGpOfferId()));

		return calcOfferReturnItemsList;
	}

	/**
	 * 0-满立减 买X达到规定金额立减N元 买X和Y立减N元 1.X可以是同一商品或不同商品 2.可以设定不同的商品组 3.可多倍
	 * 
	 * @param offer
	 * @param groupMatchedItems
	 * @return
	 * @throws Exception
	 */
	private CalcItemsDiscountTimes calculateInItemLevelTypeAMTOnline(GpOffer gOffer, Map<Integer, List<GpCartItem>> groupMatchedItems) {
		List<GpCartItem> returnItems = new ArrayList<>();

		if (gOffer == null || groupMatchedItems.isEmpty()) {
			return null;
		}

		BigDecimal discount;

		int minTimes = Integer.MAX_VALUE;

		int maxTimes = gOffer.getDiscountTimes();

		BigDecimal totalAmt = BigDecimal.ZERO;

		for (Group group : gOffer.getGroups()) {
			if (group == null) {
				continue;
			}

			List<GpCartItem> items = groupMatchedItems.get(group.getGroupSeq());
			if (items == null) {
				items = new ArrayList<>();
			}

			totalAmt = calcItemAmoutByGroup(items, totalAmt);

			returnItems.addAll(items);

			int times = (int) (totalAmt.doubleValue() / group.getThresholdAmt().doubleValue());
			minTimes = maxTimes == 0 ? times : (maxTimes > times ? times : maxTimes);
		}

		discount = (new BigDecimal(Integer.toString(minTimes))).multiply(new BigDecimal(String.valueOf(gOffer.getDiscountFactor())));

		discount = compareDiscountAndTotalAmt(discount, totalAmt, gOffer);

		setItemGpDiscount(returnItems, discount, totalAmt);
		doPadDiscount(returnItems, discount);

		return buildDiscountTimes(returnItems, minTimes, gOffer);

	}

	private BigDecimal compareDiscountAndTotalAmt(BigDecimal discount, BigDecimal totalAmt, GpOffer offer) {
		LOG.info("Warning:  discount amount more than total amount, aborted!{}", offer.getGpOfferId());
		return discount.compareTo(totalAmt) >= 0 ? BigDecimal.ZERO : discount;
	}

	private BigDecimal calcItemAmoutByGroup(List<GpCartItem> items, BigDecimal totalAmt) {

		BigDecimal retTotalAmt = totalAmt;

		for (GpCartItem item : items) {
			retTotalAmt = retTotalAmt.add(new BigDecimal(Integer.toString(item.getQty())).multiply(item.getTaxPrice()));
		}

		return retTotalAmt;
	}

	/**
	 * 设置item分摊gp金额
	 * 
	 * @param returnItems
	 * @param discount
	 * @param totalAmt
	 */
	private void setItemGpDiscount(List<GpCartItem> returnItems, BigDecimal discount, BigDecimal totalAmt) {
		for (int i = 0; i < returnItems.size(); i++) {
			GpCartItem item = returnItems.get(i);
			item.setGpDiscount((new BigDecimal(Integer.toString(item.getQty()))).multiply(new BigDecimal(String.valueOf(item.getTaxPrice()))).multiply(new BigDecimal(String.valueOf(discount)))
					.divide(totalAmt, 2, BigDecimal.ROUND_HALF_UP));

			returnItems.set(i, item);
		}
	}

	/**
	 * 3-阶梯式折??1.X可以是同一商品或不同商??2.阶梯最多不超过四级
	 * 3.设置时需要清楚界定每一阶梯享受优惠的最低商品购买个数，只要满足最低要求，就能享受规定折扣
	 * 
	 * @param offer
	 * @param groupMatchedItems
	 * @return
	 * @throws Exception
	 */

	private CalcItemsDiscountTimes calculateInItemLevelTypePCTTiered(GpOffer offer, Map<Integer/* group_seq */, List<GpCartItem>/* items */> groupMatchedItems) {
		List<GpCartItem> returnItems = new ArrayList<>();

		if (offer == null || groupMatchedItems.isEmpty()) {
			return null;
		}

		BigDecimal totalAmt = BigDecimal.ZERO;
		BigDecimal discount = BigDecimal.ZERO;
		for (Group group : offer.getGroups()) {
			Integer groupSeq = group.getGroupSeq();
			List<GpCartItem> items = groupMatchedItems.get(groupSeq);
			int qty = 0;
			BigDecimal totalGroupAmt = BigDecimal.ZERO;

			if (items != null) {
				for (GpCartItem item : items) {
					qty += item.getQty();
					totalGroupAmt = totalGroupAmt.add((new BigDecimal(Integer.toString(item.getQty()))).multiply(new BigDecimal(String.valueOf(item.getTaxPrice()))));
				}
				returnItems.addAll(items);
			}

			totalAmt = totalAmt.add(totalGroupAmt);
			discount = setGroupDiscount(group, qty, totalGroupAmt);
		}

		discount = compareDiscountAndTotalAmt(discount, totalAmt, offer);

		setItemGpDiscount(returnItems, discount, totalAmt);
		doPadDiscount(returnItems, discount);
		Integer minTimes = discount.compareTo(BigDecimal.ZERO) == 0 ? 0 : 1;
		return buildDiscountTimes(returnItems, minTimes, offer);
	}

	@SuppressWarnings("unchecked")
	private BigDecimal setGroupDiscount(Group group, int qty, BigDecimal totalGroupAmt) {
		BigDecimal discount = BigDecimal.ZERO;
		if (group == null) {
			return discount;
		}

		// re-sort QTYs descending
		// to match most biggest percent
		List<TieredDiscount> tds = group.getTieredDiscount();
		Integer[] minQtys = new Integer[tds.size()];

		for (int i = 0; i < tds.size(); i++) {
			minQtys[i] = tds.get(i).getThresholdQty();
		}

		@SuppressWarnings("rawtypes")
		Comparator cmpQty = ComparableComparator.getInstance();
		cmpQty = ComparatorUtils.reversedComparator(cmpQty);
		Arrays.sort(minQtys, cmpQty);

		BigDecimal maxDiscount = BigDecimal.ZERO;

		int discountQty = 0;

		for (int minQty : minQtys) {
			if (qty >= minQty) {
				discountQty = minQty;
				break;
			}
		}

		for (TieredDiscount td : group.getTieredDiscount()) {
			if (discountQty == td.getThresholdQty()) {
				maxDiscount = td.getDiscountFactor();
				break;
			}
		}

		discount = discount.add(totalGroupAmt).multiply(new BigDecimal(String.valueOf(maxDiscount))).divide(new BigDecimal("100")).setScale(2, BigDecimal.ROUND_HALF_UP);

		return discount;
	}

	/**
	 * 2-阶梯式现金返??1. X可以是同一商品或不同商??2. 阶梯最多不超过四级 3. 设置时需要清楚界定每一级别的商品数量规??4.
	 * 不可多倍折扣（找到满足条件的最大阶梯折扣，只折扣一次）
	 * 
	 * @param offer
	 * @param groupMatchedItems
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	private CalcItemsDiscountTimes calculateInItemLevelTypeAMTTiered(GpOffer offer, Map<Integer/* group_seq */, List<GpCartItem>/* items */> groupMatchedItems) {
		List<GpCartItem> returnItems = new ArrayList<>();
		if (offer == null || groupMatchedItems.isEmpty()) {
			return null;
		}

		BigDecimal totalAmt = BigDecimal.ZERO;
		BigDecimal discount = BigDecimal.ZERO;

		for (Group group : offer.getGroups()) {
			if (group == null) {
				continue;
			}

			List<GpCartItem> items = groupMatchedItems.get(group.getGroupSeq());
			if (items == null) {
				items = new ArrayList<>();
			}

			int qty = 0;

			for (GpCartItem item : items) {
				qty += item.getQty();
				totalAmt = totalAmt.add((new BigDecimal(Integer.toString(item.getQty()))).multiply(new BigDecimal(String.valueOf(item.getTaxPrice()))));
			}

			returnItems.addAll(items);

			List<TieredDiscount> tds = group.getTieredDiscount();
			Integer[] minQtys = new Integer[tds.size()];

			for (int i = 0; i < tds.size(); i++) {
				minQtys[i] = tds.get(i).getThresholdQty();
			}

			// re-sort QTYs descending
			// to match top most biggest qty first
			@SuppressWarnings("rawtypes")
			Comparator cmpQty = ComparableComparator.getInstance();
			cmpQty = ComparatorUtils.reversedComparator(cmpQty);

			Arrays.sort(minQtys, cmpQty);

			discount = adjustDiscountByGroup(discount, group, qty, minQtys);

		}

		discount = compareDiscountAndTotalAmt(discount, totalAmt, offer);

		setItemGpDiscount(returnItems, discount, totalAmt);
		doPadDiscount(returnItems, discount);
		Integer minTimes = discount.compareTo(BigDecimal.ZERO) == 0 ? 0 : 1;

		return buildDiscountTimes(returnItems, minTimes, offer);
	}

	/**
	 * calculateInItemLevelTypeAMTTiered 计算gpDiscount
	 * @param discount
	 * @param group
	 * @param qty
	 * @param minQtys
	 * @return
	 */
	private BigDecimal adjustDiscountByGroup(BigDecimal discount, Group group, int qty, Integer[] minQtys) {

		int discountQty = 0;

		BigDecimal totalDiscount = discount;

		for (int minQty : minQtys) {
			if (qty >= minQty) {
				discountQty = minQty;
				break;
			}
		}

		for (TieredDiscount td : group.getTieredDiscount()) {
			if (discountQty == td.getThresholdQty()) {
				totalDiscount = discount.add(td.getDiscountFactor());
				break;
			}
		}

		return totalDiscount;
	}

	/**
	 * 4-计算固定价格促销 1. X可以是同一商品或不同商??2. 只可建立一个商品组 (有多组且价格不同时无法计?? 2.
	 * 任意商品单价*规定商品的个??> N价格 3.
	 * 如果X为不同的商品而且零售价不同，而顾客购买的数量超过指定的数量且小于折扣再次发生的条件时，则系统会选取指定数量中单价较高的商品进行折扣??4.
	 * 如果门店进行竞价，且竞价之后商品组合价格低于促销价格，则促销不能发生
	 * 
	 * 计算规则： 按照价格排序，按数量拆分items后，按ThresholdQty分组，如果分组后的金额之和大于discountFactor，则累加
	 * discount,否则跳出循环，例2件只需35，买价格为19、18、17、16的4件商品，能获得的最大discount为19+18-35 = 2
	 * 
	 * @param offer
	 * @param groupMatchedItems
	 * @return
	 * @throws GlobalErrorInfoException
	 * @throws Exception
	 */
	private CalcItemsDiscountTimes calculateInItemLevelTypeFixed(GpOffer offer, Map<Integer/* group_seq */, List<GpCartItem>/* items */> groupMatchedItems) throws GlobalErrorInfoException {
		List<GpCartItem> returnItems = new ArrayList<>();

		if (offer == null || (offer.getGroups() == null || offer.getGroups().isEmpty()) || groupMatchedItems.isEmpty()) {
			return null;
		}
		validateOfferGroups(offer);

		Integer groupSeq = groupMatchedItems.keySet().iterator().next();
		List<GpCartItem> items = groupMatchedItems.get(groupSeq);
		returnItems.addAll(items);
		// re-sort items according to price descending to find top items which
		// will be discount
		sortItemsByTaxPrice(items);

		List<GpCartItem> itemsList = new ArrayList<>();
		ItemsTotalAmtAndQty itemsTotalAmtAndQty = buildItemsList(items, itemsList);
		BigDecimal totalAmt = itemsTotalAmtAndQty.getTotalAmt();

		Group group = offer.getGroups().get(0);
		BigDecimal discount = BigDecimal.ZERO;
		int minTimes = 0;

		List<List<GpCartItem>> groupItemsList = CollectionGroupUtil.groupListByQuantity(itemsList, group.getThresholdQty());
		List<GpCartItem> list;
		for (int c = 0; c < groupItemsList.size(); c++) {
			list = groupItemsList.get(c);
			BigDecimal groupTotalAmount = BigDecimal.ZERO;
			for (GpCartItem temp : list) {
				groupTotalAmount = groupTotalAmount.add(temp.getTaxPrice());
			}
			BigDecimal discountFactor = new BigDecimal(String.valueOf(offer.getDiscountFactor()));
			if (groupTotalAmount.compareTo(discountFactor) > 0) {
				discount = discount.add(groupTotalAmount.subtract(discountFactor));
				minTimes = minTimes + 1;
			} else {
				break;
			}
		}

		discount = compareDiscountAndTotalAmt(discount, totalAmt, offer);

		setItemGpDiscount(returnItems, discount, totalAmt);
		doPadDiscount(returnItems, discount);
		return buildDiscountTimes(returnItems, minTimes, offer);
	}

	private void validateOfferGroups(GpOffer offer) throws GlobalErrorInfoException {
		if (offer.getGroups().size() > 1) {
			LOG.error("There can be only one group, but find more than one. Offer: {}", offer.getGpOfferId());
			throw new GlobalErrorInfoException(PromotionErrorInfoEnum.GP_GROUP_NOT_ONLYONE);
		}
	}

	/**
	 * 按数量拆分list,方便后续分组计算
	 * 
	 * @param items
	 * @param itemsList
	 * @return
	 */
	private ItemsTotalAmtAndQty buildItemsList(List<GpCartItem> items, List<GpCartItem> itemsList) {
		BigDecimal totalAmt = BigDecimal.ZERO;
		int totalQty = 0;
		for (GpCartItem gpCartItem : items) {
			int qty = gpCartItem.getQty();
			for (int i = 0; i < qty; i++) {
				GpCartItem gpCartItemQty = new GpCartItem();
				gpCartItemQty.setQty(1);
				gpCartItemQty.setCartItemId(gpCartItem.getCartItemId());
				gpCartItemQty.setTaxPrice(gpCartItem.getTaxPrice());
				gpCartItemQty.setProductId(gpCartItem.getProductId());
				itemsList.add(gpCartItemQty);
			}
			totalQty += gpCartItem.getQty();
			totalAmt = totalAmt.add((new BigDecimal(Integer.toString(gpCartItem.getQty()))).multiply(new BigDecimal(String.valueOf(gpCartItem.getTaxPrice()))));
		}

		ItemsTotalAmtAndQty itemsTotalAmtAndQty = new ItemsTotalAmtAndQty();
		itemsTotalAmtAndQty.setTotalAmt(totalAmt);
		itemsTotalAmtAndQty.setTotalQty(totalQty);
		return itemsTotalAmtAndQty;
	}


	/**
	 * re-sort items according to price descending to find top items which will be discount
	 * @param items
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void sortItemsByTaxPrice(List<GpCartItem> items) {
		Comparator cmpTaxPrice = ComparableComparator.getInstance();
		cmpTaxPrice = ComparatorUtils.reversedComparator(cmpTaxPrice);
		Collections.sort(items, new BeanComparator("taxPrice", cmpTaxPrice));
	}

	/**
	 * 1-折扣 买X得N%折扣 1.X可以是同一商品或不同商??2.只可建立一个商品组
	 * 3.只能设定享受优惠的最低商品购买个数，只要满足最低要求，就能享受规定折扣
	 * 
	 * @param offer
	 * @param groupMatchedItems
	 * @return
	 * @throws GlobalErrorInfoException
	 * @throws Exception
	 */
	private CalcItemsDiscountTimes calculateInItemLevelTypePCT(GpOffer offer, Map<Integer/* group_seq */, List<GpCartItem>/* items */> groupMatchedItems) throws GlobalErrorInfoException {
		List<GpCartItem> returnItems = new ArrayList<>();
		BigDecimal discount = BigDecimal.ZERO;

		if (offer != null && !groupMatchedItems.isEmpty()) {
			validateOfferGroups(offer);
			boolean fulfilled = false;
			BigDecimal totalAmt = BigDecimal.ZERO;
			Integer groupSeq = groupMatchedItems.keySet().iterator().next();
			List<GpCartItem> items = groupMatchedItems.get(groupSeq);
			int qty = 0;
			// total amount
			if (items != null) {
				for (GpCartItem item : items) {
					qty += item.getQty();
					totalAmt = totalAmt.add((new BigDecimal(Integer.toString(item.getQty()))).multiply(new BigDecimal(String.valueOf(item.getTaxPrice()))));
				}
				returnItems.addAll(items);
			}
			// check quantity is fulfilled or not
			Group group = offer.getGroups().get(0);
			if (group != null) {
				fulfilled = qty >= group.getThresholdQty();
			}
			// check quantity is fulfilled or not
			if (fulfilled) {
				discount = totalAmt.multiply(new BigDecimal(String.valueOf(offer.getDiscountFactor()))).divide(new BigDecimal("100")).setScale(2, BigDecimal.ROUND_HALF_UP);
			}
			discount = compareDiscountAndTotalAmt(discount, totalAmt, offer);
			setItemGpDiscount(returnItems, discount, totalAmt);
			doPadDiscount(returnItems, discount);
		}
		Integer minTimes = discount.compareTo(BigDecimal.ZERO) == 0 ? 0 : 1;
		return buildDiscountTimes(returnItems, minTimes, offer);
	}

	/**
	 * 0-买立??买X达到规定个数立减N?? 买X和Y立减N??1.X可以是同一商品或不同商??2.可以设定不同的商品组 3.可多倍折??
	 * 
	 * @param offer
	 * @param groupMatchedItems
	 * @return
	 * @throws Exception
	 */
	private CalcItemsDiscountTimes calculateInItemLevelTypeAMT(GpOffer offer, Map<Integer/* group_seq */, List<GpCartItem>/* items */> groupMatchedItems) {
		List<GpCartItem> returnItems = new ArrayList<>();

		if (offer == null || groupMatchedItems.isEmpty()) {
			return null;
		}
		int minTimes = Integer.MAX_VALUE; // min fulfill condition times
		BigDecimal totalAmt = BigDecimal.ZERO;

		// loop groups
		for (Group group : offer.getGroups()) {
			Integer groupSeq = group.getGroupSeq();
			List<GpCartItem> items = groupMatchedItems.get(groupSeq);
			int qty = 0;

			// calculate items quantity in this group & total amount
			if (items != null) {
				for (GpCartItem item : items) {
					qty += item.getQty();
					totalAmt = totalAmt.add((new BigDecimal(Integer.toString(item.getQty()))).multiply(new BigDecimal(String.valueOf(item.getTaxPrice()))));
				}
				returnItems.addAll(items);
			}

			if (group != null) {
				int times = qty / group.getThresholdQty();
				minTimes = times < minTimes ? times : minTimes;
			}
		}

		// calculate discount
		BigDecimal discount = BigDecimal.ZERO;
		if (minTimes < Integer.MAX_VALUE) {
			discount = (new BigDecimal(Integer.toString(minTimes))).multiply(new BigDecimal(String.valueOf(offer.getDiscountFactor())));
		}

		discount = compareDiscountAndTotalAmt(discount, totalAmt, offer);

		setItemGpDiscount(returnItems, discount, totalAmt);
		doPadDiscount(returnItems, discount);

		return buildDiscountTimes(returnItems, minTimes, offer);
	}

	private CalcItemsDiscountTimes buildDiscountTimes(List<GpCartItem> returnItems, int minTimes, GpOffer offer) {
		CalcItemsDiscountTimes calcItemsDiscountTimes = new CalcItemsDiscountTimes();
		calcItemsDiscountTimes.setMinTimes(minTimes);
		calcItemsDiscountTimes.setReturnItems(returnItems);
		calcItemsDiscountTimes.setGpOfferId(offer.getGpOfferId());
		return calcItemsDiscountTimes;
	}

	/**
	 * 一分钱的平衡
	 * 
	 * @param returnItems
	 * @param totalDiscount
	 */
	public static void doPadDiscount(List<GpCartItem> returnItems, BigDecimal totalDiscount) {

		BigDecimal itemsDiscount = BigDecimal.ZERO;
		for (GpCartItem item : returnItems) {
			itemsDiscount = itemsDiscount.add(item.getGpDiscount());
		}

		BigDecimal diff = totalDiscount.subtract(itemsDiscount);

		if (diff.compareTo(BigDecimal.ZERO) == 0) {
			return;
		}

		int diffCent = Math.abs(diff.multiply(new BigDecimal(100)).intValue());
		int paddingAvg = diffCent / returnItems.size();
		int paddingRemainder = diffCent % returnItems.size();
		BigDecimal padding = diff.signum() > 0 ? new BigDecimal("0.01") : new BigDecimal("-0.01");

		returnItems.sort((GpCartItem gpCartItem1, GpCartItem gpCartItem2) -> gpCartItem1.getCartItemId().compareTo(gpCartItem2.getCartItemId()));

		for (int i = 0; i < returnItems.size(); i++) {
			GpCartItem cartItem = returnItems.get(i);
			BigDecimal itemDiscount = cartItem.getGpDiscount();

			if (paddingAvg > 0) {
				itemDiscount = itemDiscount.add(new BigDecimal(paddingAvg).multiply(padding));
			}

			if (paddingRemainder > 0 && i < paddingRemainder) {
				itemDiscount = itemDiscount.add(padding);
			}

			cartItem.setGpDiscount(itemDiscount);

		}

	}

	private Map<Integer, Map<Integer, List<GpCartItem>>> getMatchedOffers(List<GpCartItem> items) {
		Map<Integer/* offer_id */, Map<Integer/* group_seq */, List<GpCartItem>/* items */>> matchedOffers = new TreeMap<>();

		for (GpCartItem item : items) {
			GpCartItem newItem = new GpCartItem(item.getProductId(), item.getUpc(), item.getQty(), item.getTaxPrice(), item.getGpOfferId(), item.getGroupSeq(), item.getClientDiscount(),
					item.getCartItemId());
			int offerId = item.getGpOfferId();
			int groupSeq = item.getGroupSeq();

			if (offerId >= 0) {
				// get matched items list for offer
				Map<Integer/* group_seq */, List<GpCartItem>/* items */> groupMatchedItems = matchedOffers.get(offerId);
				// if this offer not exist, initiate it first
				if (groupMatchedItems == null) {
					groupMatchedItems = new TreeMap<>();
					matchedOffers.put(offerId, groupMatchedItems);
				}
				// if item list not exist, initiate it first
				List<GpCartItem> gpCartItemList = groupMatchedItems.get(groupSeq);
				if (gpCartItemList == null) {
					gpCartItemList = new ArrayList<>();
					groupMatchedItems.put(groupSeq, gpCartItemList);
				}
				gpCartItemList.add(newItem);
			}
		}

		return matchedOffers;

	}

}