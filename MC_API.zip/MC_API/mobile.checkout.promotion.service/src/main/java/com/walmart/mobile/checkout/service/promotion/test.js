function WMCMap() {
	this.elements = new Array();

	// 获取MAP元素个数
	this.size = function() {
		return this.elements.length;
	}

	// 判断MAP是否为空
	this.isEmpty = function() {
		return (this.elements.length < 1);
	}

	// 删除MAP所有元素
	this.clear = function() {
		this.elements = new Array();
	}

	// 向MAP中增加元素（key, value)
	this.put = function(_key, _value) {
		this.remove(_key);
		this.elements.push({
			key : _key,
			value : _value
		});
	}

	// 删除指定KEY的元素，成功返回True，失败返回False
	this.remove = function(_key) {
		var bln = false;
		try {
			for (i = 0; i < this.elements.length; i++) {
				if (this.elements[i].key == _key) {
					this.elements.splice(i, 1);
					return true;
				}
			}
		} catch (e) {
			bln = false;
		}
		return bln;
	}

	// 获取指定KEY的元素值VALUE，失败返回NULL
	this.get = function(_key) {
		try {
			for (i = 0; i < this.elements.length; i++) {
				if (this.elements[i].key == _key) {
					return this.elements[i].value;
				}
			}
		} catch (e) {
			return null;
		}
	}

	// 获取指定索引的元素（使用element.key，element.value获取KEY和VALUE），失败返回NULL
	this.element = function(_index) {
		if (_index < 0 || _index >= this.elements.length) {
			return null;
		}
		return this.elements[_index];
	}

	// 判断MAP中是否含有指定KEY的元素
	this.containsKey = function(_key) {
		var bln = false;
		try {
			for (i = 0; i < this.elements.length; i++) {
				if (this.elements[i].key == _key) {
					bln = true;
				}
			}
		} catch (e) {
			bln = false;
		}
		return bln;
	}

	// 判断MAP中是否含有指定VALUE的元素
	this.containsValue = function(_value) {
		var bln = false;
		try {
			for (i = 0; i < this.elements.length; i++) {
				if (this.elements[i].value == _value) {
					bln = true;
				}
			}
		} catch (e) {
			bln = false;
		}
		return bln;
	}

	// 获取MAP中所有VALUE的数组（ARRAY）
	this.values = function() {
		var arr = new Array();
		for (i = 0; i < this.elements.length; i++) {
			arr.push(this.elements[i].value);
		}
		return arr;
	}

	// 获取MAP中所有KEY的数组（ARRAY）
	this.keys = function() {
		var arr = new Array();
		for (i = 0; i < this.elements.length; i++) {
			arr.push(this.elements[i].key);
		}
		return arr;
	}
}

Number.prototype.toFixed = function(d) {
	var s = this + "";
	if (!d)
		d = 0;
	if (s.indexOf(".") == -1)
		s += ".";
	s += new Array(d + 1).join("0");
	if (new RegExp("^(-|\\+)?(\\d+(\\.\\d{0," + (d + 1) + "})?)\\d*$").test(s)) {
		var s = "0" + RegExp.$2, pm = RegExp.$1, a = RegExp.$3.length, b = true;
		if (a == d + 2) {
			a = s.match(/\d/g);
			if (parseInt(a[a.length - 1], 10) > 4) {
				for (var i = a.length - 2; i >= 0; i--) {
					a[i] = parseInt(a[i], 10) + 1;
					if (a[i] == 10) {
						a[i] = 0;
						b = i != 1;
					} else
						break;
				}
			}

			s = a.join("").replace(new RegExp("(\\d+)(\\d{" + d + "})\\d$"),
					"$1.$2");
		}

		if (b)
			s = s.substr(1);
		return Number((pm + s).replace(/\.$/, ""));
	}

	return Number(this + "");
};

function accAdd(arg1, arg2) {
	var r1, r2, m, r11, r22;
	var l1, l2;
	try {
		l1 = arg1.toString().split(".")[1];
		r1 = l1.length;
	} catch (e) {
		r1 = 0
	}

	try {
		l2 = arg2.toString().split(".")[1];
		r2 = l2.length;
	} catch (e) {
		r2 = 0
	}

	m = Math.pow(10, Math.max(r1, r2))
	r11 = arg1.toString().split(".")[0].toString();

	if (l1) {
		r11 += l1;
		if (r1 < r2) {
			r11 = parseInt(r11, 10) * Math.pow(10, (r2 - r1));
		}
	} else {
		r11 = parseInt(r11, 10) * m;
	}

	r11 = parseInt(r11, 10);
	r22 = arg2.toString().split(".")[0].toString();

	if (l2) {
		r22 += l2;

		if (r1 > r2) {
			r22 = parseInt(r22, 10) * Math.pow(10, (r1 - r2));
		}
	} else {
		r22 = parseInt(r22, 10) * m;
	}

	r22 = parseInt(r22, 10);

	return (r11 + r22) / m;
}

// var ddd = accAdd(0,0.64);

// 给Number类型增加一个add方法，调用起来更加方便。
Number.prototype.add = function(arg) {
	return accAdd(arg, this);
}

function accSub(arg1, arg2) {
	var r1, r2, m, n, r11, r22;
	var l1, l2;
	try {
		l1 = arg1.toString().split(".")[1];
		r1 = l1.length;
	} catch (e) {
		r1 = 0
	}

	try {
		l2 = arg2.toString().split(".")[1];
		r2 = l2.length;
	} catch (e) {
		r2 = 0
	}

	m = Math.pow(10, Math.max(r1, r2))
	r11 = arg1.toString().split(".")[0].toString();

	if (l1) {
		r11 += l1;
		if (r1 < r2) {
			r11 = parseInt(r11, 10) * Math.pow(10, (r2 - r1));
		}
	} else {
		r11 = parseInt(r11, 10) * m;
	}

	r11 = parseInt(r11, 10);

	r22 = arg2.toString().split(".")[0].toString();

	if (l2) {
		r22 += l2;
		if (r1 > r2) {
			r22 = parseInt(r22, 10) * Math.pow(10, (r1 - r2));
		}
	} else {
		r22 = parseInt(r22, 10) * m;
	}

	r22 = parseInt(r22, 10);

	return (r11 - r22) / m;
}

Number.prototype.sub = function(arg) {
	return accSub(this, arg);
}

function accMul(arg1, arg2) {
	var m = 0, s1 = arg1.toString(), s2 = arg2.toString();

	try {
		m += s1.split(".")[1].length
	} catch (e) {
	}
	try {
		m += s2.split(".")[1].length
	} catch (e) {
	}

	return (Number(s1.replace(".", "")) * Number(s2.replace(".", "")) / Math
			.pow(10, m));
}

// 给Number类型增加一个mul方法，调用起来更加方便。
Number.prototype.mul = function(arg) {
	return accMul(arg, this);
}

function accDiv(arg1, arg2) {
	var t1 = 0, t2 = 0, r1, r2;

	try {
		t1 = arg1.toString().split(".")[1].length
	} catch (e) {
	}
	try {
		t2 = arg2.toString().split(".")[1].length
	} catch (e) {
	}

	with (Math) {
		r1 = Number(arg1.toString().replace(".", ""))
		r2 = Number(arg2.toString().replace(".", ""))
		return ((r1 / r2) * pow(10, t2 - t1));
	}
}

// 给Number类型增加一个div方法，调用起来更加方便。
Number.prototype.div = function(arg) {
	return accDiv(this, arg);
}

PROMOTION_TYPE_AMT = 0; // 买立减
PROMOTION_TYPE_PCT = 1; // 折扣
PROMOTION_TYPE_AMT_TIERED = 2; // 阶梯式现金返还
PROMOTION_TYPE_PCT_TIERED = 3; // 阶梯式折扣
PROMOTION_TYPE_FIXED = 4; // 固定价格优惠
PROMOTION_TYPE_AMT_ONLINE = 6; // 满立减
PROMOTION_TYPE_AMT_ONLINE_TIERED = 106
/**
 * 从data.js根据 offerId 取得对应的offer对象 params: offerId return: offer;
 */

function getOfferById(offerId) {

	// alert(data);
	var offer;
	for (var i = 0; i < data.length; i++) {
		offer = data[i];
		if (offerId == offer.gpOfferId) {
			var groups = offer.groups;

			groups.sort(function(a, b) {
				var r = parseInt(b.groupSeq, 10) - parseInt(a.groupSeq, 10);
				return r;
			});

			offer.groups = groups;
			return offer;
		}
	}

	return;
}

/**
 * 根据购物车商品项生成 offerMap offerMap组成 key 为 offerId, value 为一个Map (groupMap: key 为
 * groupId, value 为购物车项) params: cartItems 数组
 */
function getMapCartItem(cartItems) {
	var offerMap = new WMCMap();
	var groupMap;
	var item;
	var value;

	for (var i = 0; i < cartItems.length; i++) {
		item = cartItems[i];

		if (item.offerId || item.offerId == 0) {
			if (offerMap.containsKey(item.offerId)) {
				groupMap = offerMap.get(item.offerId);
				if (groupMap.containsKey(item.groupId)) {
					value = groupMap.get(item.groupId);
					value.push(item);
					groupMap.put(item.groupId, value);
				} else {
					value = new Array();
					value.push(item);
					groupMap.put(item.groupId, value);
				}

				offerMap.put(item.offerId, groupMap);
			} else {
				groupMap = new WMCMap();
				value = new Array();
				value.push(item);
				groupMap.put(item.groupId, value);
				offerMap.put(item.offerId, groupMap);
			}
		}

	}

	return offerMap;
}

var RECOMMEND_AMT = 1;
var RECOMMEND_PCT = 20;

function contains(array, obj) {
	var i = array.length;

	while (i--) {
		if (array[i].productId === obj.productId
				&& array[i].offerId === obj.offerId) {
			return true;
		}
	}
	return false;
}

// 入口
function calculateInItemLevel(cartItems, desc, CAL_STRING) {

	// 去掉client端传过来的qty为0的记录，防止分摊
	var cartItemsArray = new Array();
	for (var i = 0; i < cartItems.length; i++) {

		var cart = cartItems[i];
		if (cart.qty > 0) {
			cartItemsArray.push(cart);

		}

	}

	var returnItems = new Array();

	if (cartItemsArray != null && cartItemsArray.length > 0) {

		var offerMaps = getMapCartItem(cartItemsArray);

		if (offerMaps.size() > 0) {
			var offer;
			var groupMap;
			var elements = offerMaps.elements;

			for (var i = 0; i < elements.length; i++) {
				offer = getOfferById(elements[i].key);
				var offerReturnItems;
				if (offer) {
					groupMap = elements[i].value;

					switch (offer.gpCaclTypeCode) {
					case PROMOTION_TYPE_AMT:
						offerReturnItems = calculateInItemLevelTypeAMT(offer,
								groupMap, desc, CAL_STRING);
						break;
					case PROMOTION_TYPE_PCT:
						offerReturnItems = calculateInItemLevelTypePCT(offer,
								groupMap, desc, CAL_STRING);
						break;
					case PROMOTION_TYPE_FIXED:
						offerReturnItems = calculateInItemLevelTypeFixed(offer,
								groupMap, desc, CAL_STRING);
						break;
					case PROMOTION_TYPE_AMT_TIERED:
						offerReturnItems = calculateInItemLevelTypeAMTTiered(
								offer, groupMap, desc, CAL_STRING);
						break;
					case PROMOTION_TYPE_PCT_TIERED:
						offerReturnItems = calculateInItemLevelTypePCTTiered(
								offer, groupMap, desc, CAL_STRING);
						break;
					case PROMOTION_TYPE_AMT_ONLINE:
						offerReturnItems = calculateInItemLevelTypeAMTOnline(
								offer, groupMap, desc, CAL_STRING);
						break;

					default:
						break;
					}

					// set recommended quantity
					if (offerReturnItems != null) {
						for (var k = 0; k < offerReturnItems.length; k++) {
							var returnItem = offerReturnItems[k];
							returnItems.push(returnItem);
						}
					}
				}
			}
		}
	}

	return returnItems;
}

// 阶梯式现金返还
function calculateInItemLevelTypeAMTTiered(offer, itemMap, desc, CAL_STRING) {
	var returnItems = new Array();

	var items = new Array();
	var discount = 0;
	if (offer != null && itemMap.size() > 0) {

		var totalAmt = 0;
		var groups = offer.groups;
		var group;
		var groupSeq;
		var items;
		var item;

		for (var i = 0; i < groups.length; i++) {
			group = groups[i];
			groupSeq = group.groupSeq;
			items = itemMap.get(groupSeq);

			var qty = 0;

			if (items) {
				for (var k = 0; k < items.length; k++) {
					item = items[k];
					qty += item.qty;
					totalAmt = totalAmt.add(item.qty.mul(item.taxPrice));
					returnItems.push(item);
				}
			}

			var tieredDiscounts = group.tieredDiscount;

			tieredDiscounts.sort(function(a, b) {
				return b.thresholdQty - a.thresholdQty;
			});

			for (var j = 0; j < tieredDiscounts.length; j++) {
				if (qty >= tieredDiscounts[j].thresholdQty) {
					discount = discount.add(tieredDiscounts[j].discountFactor);
					break;
				}
			}
		}

		if (discount >= totalAmt) {
			discount = 0;
		}

		for (var i = 0; i < returnItems.length; i++) {
			var item = returnItems[i];

			if (discount == 0 && desc == CAL_STRING) {
				item.exceptionFlag = "\"error\"";
			}

			// item.taxPrice =
			// item.qty.mul(item.taxPrice).mul(discount).div(totalAmt).toFixed(2);

			item.gpDiscount = item.qty.mul(item.taxPrice).mul(discount).div(
					totalAmt).toFixed(2);
			if (!item.gpDiscount) {
				item.gpDiscount = 0;
			}

			// item.qty= 0 ;
			returnItems[i] = item;
		}

		items = balancePriceForItems(discount, returnItems)

	}

	return items;
}

// 买立减
function calculateInItemLevelTypeAMT(offer, itemMap, desc, CAL_STRING) {

	var returnItems = new Array();
	var discount = 0;
	var totalAmount = 0;
	var offerGroupViews = offer.groups;
	var times = 0;
	var minTimes = 99999999;
	var key;
	var group;
	var items;
	var item;

	for (var i = 0; i < offerGroupViews.length; i++) {
		group = offerGroupViews[i];
		if (group) {
			key = group.groupSeq;
			items = itemMap.get(key);

			var qty = 0;

			if (items) {
				for (var k = 0; k < items.length; k++) {
					item = items[k];
					qty += item.qty;
					totalAmount = totalAmount.add(item.qty.mul(item.taxPrice));
					returnItems.push(item);
				}
			}

			times = parseInt(qty.div(group.thresholdQty), 10);
			if (times < minTimes) {
				minTimes = times;
			}
		}
	}

	discount = minTimes.mul(offer.discountFactor);

	if (discount >= totalAmount) {
		discount = 0;
	}

	for (var i = 0; i < returnItems.length; i++) {
		var item = returnItems[i];
		if (discount == 0 && desc == CAL_STRING) {
			item.exceptionFlag = "\"error\"";
		}

		item.gpDiscount = item.qty.mul(item.taxPrice).mul(discount).div(
				totalAmount).toFixed(2);
		// item.taxPrice =
		// item.qty.mul(item.taxPrice).mul(discount).div(totalAmount).toFixed(2);
		if (!item.gpDiscount) {
			item.gpDiscount = 0;
		}

		// item.qty= 0 ;
		returnItems[i] = item;
	}

	var items = balancePriceForItems(discount, returnItems)

	return items;
}

// 满立减
function calculateInItemLevelTypeAMTOnline(offer, itemMap, desc, CAL_STRING) {

	var returnItems = new Array();
	var discount = 0;
	var totalAmount = 0;
	var offerGroupViews = offer.groups;
	var times = 0;
	var minTimes = 99999999;
	var key;
	var group;
	var items;
	var item;
	var maxTimes = offer.discountTimes;

	for (var i = 0; i < offerGroupViews.length; i++) {
		group = offerGroupViews[i];
		if (group) {
			key = group.groupSeq;
			items = itemMap.get(key);

			if (items) {
				for (var k = 0; k < items.length; k++) {
					item = items[k];
					totalAmount = totalAmount.add(item.qty.mul(item.taxPrice));
					returnItems.push(item);
				}
			}

			times = parseInt(totalAmount.div(group.thresholdAmt), 10);

			if (maxTimes == 0) {
				minTimes = times;
			} else {
				if (maxTimes > times) {
					minTimes = times;
				} else {
					minTimes = maxTimes;
				}

			}

			// if(times < minTimes){
			// minTimes = times;
			// }
		}
	}

	discount = minTimes.mul(offer.discountFactor);

	if (discount >= totalAmount) {
		discount = 0;
	}

	for (var i = 0; i < returnItems.length; i++) {
		var item = returnItems[i];

		if (discount == 0 && desc == CAL_STRING) {
			item.exceptionFlag = "\"error\"";
		}

		item.gpDiscount = item.qty.mul(item.taxPrice).mul(discount).div(
				totalAmount).toFixed(2);
		// item.taxPrice =
		// item.qty.mul(item.taxPrice).mul(discount).div(totalAmount).toFixed(2);
		if (!item.gpDiscount) {
			item.gpDiscount = 0;
		}

		// item.qty= 0 ;
		returnItems[i] = item;
	}

	var items = balancePriceForItems(discount, returnItems)

	return items;

	// return returnItems;
}

// 阶梯式折扣
function calculateInItemLevelTypePCTTiered(offer, itemMap, desc, CAL_STRING) {

	var returnItems = new Array();
	var items = new Array();
	var discount = 0;

	if (offer && itemMap.size() > 0) {
		var groups = offer.groups;
		var group;
		var groupSeq;
		var items;
		var item;
		var totalAmt = 0;

		for (var i = 0; i < groups.length; i++) {
			group = groups[i];
			if (group) {
				groupSeq = group.groupSeq;
				items = itemMap.get(groupSeq);

				var qty = 0;
				var totalGroupAmt = 0;

				if (items) {
					for (var k = 0; k < items.length; k++) {
						item = items[k];
						qty += item.qty;
						totalGroupAmt = totalGroupAmt.add(item.qty
								.mul(item.taxPrice));
						returnItems.push(item);
					}
				}

				totalAmt = totalAmt.add(totalGroupAmt);

				var tieredDiscounts = group && group.tieredDiscount;

				tieredDiscounts.sort(function(a, b) {
					return b.thresholdQty - a.thresholdQty;
				});

				var maxDiscount = 0;
				for (var j = 0; j < tieredDiscounts.length; j++) {
					if (qty >= tieredDiscounts[j].thresholdQty) {
						maxDiscount = tieredDiscounts[j].discountFactor;
						break;
					}
				}

				discount = discount.add(totalGroupAmt).mul(maxDiscount)
						.div(100).toFixed(2);
			}
		}

		if (discount >= totalAmt) {
			discount = 0;
		}

		for (var i = 0; i < returnItems.length; i++) {
			var item = returnItems[i];

			if (discount == 0 && desc == CAL_STRING) {
				item.exceptionFlag = "\"error\"";
			}

			// item.taxPrice =
			// item.qty.mul(item.taxPrice).mul(discount).div(totalAmt).toFixed(2);
			item.gpDiscount = item.qty.mul(item.taxPrice).mul(discount).div(
					totalAmt).toFixed(2);

			if (!item.gpDiscount) {
				item.gpDiscount = 0;
			}

			// item.qty= 0 ;
			returnItems[i] = item;
		}

		items = balancePriceForItems(discount, returnItems)

	}

	return items;
}

// 折扣
function calculateInItemLevelTypePCT(offer, itemMap, desc, CAL_STRING) {

	var discount = 0;
	var returnItems = new Array();
	var items = new Array();

	if (offer != null && itemMap.size() > 0) {
		if (offer.groups.length > 1) {
			return;
		}

		var fulfilled = false;
		var totalAmount = 0;
		var groupSeq = itemMap.keys()[0];
		var items = itemMap.get(groupSeq);
		var qty = 0;
		var item;

		for (var i = 0; i < items.length; i++) {
			item = items[i];
			qty += item.qty;
			totalAmount = totalAmount.add(item.qty.mul(item.taxPrice));
			returnItems.push(item);
		}

		if (groupSeq == offer.groups[0].groupSeq) {
			var offerGroup = offer.groups[0];
			fulfilled = qty >= offerGroup.thresholdQty;
		}

		if (fulfilled) {
			discount = totalAmount.mul(offer.discountFactor).div(100)
					.toFixed(2);
		}

		if (discount >= totalAmount) {
			discount = 0;
		}

		for (var i = 0; i < returnItems.length; i++) {

			var item = returnItems[i];

			if (discount == 0 && desc == CAL_STRING) {
				item.exceptionFlag = "\"error\"";
			}

			item.gpDiscount = item.qty.mul(item.taxPrice).mul(discount).div(
					totalAmount).toFixed(2);
			// item.taxPrice =
			// item.qty.mul(item.taxPrice).mul(discount).div(totalAmount).toFixed(2);

			if (!item.gpDiscount) {
				item.gpDiscount = 0;
			}

			// item.qty= 0 ;
			returnItems[i] = item;
		}

		items = balancePriceForItems(discount, returnItems)

		// return returnItems;
	}
	return items;
}

// 固定现金返还
function calculateInItemLevelTypeFixed(offer, itemMap, desc, CAL_STRING) {

	var discount = 0;
	var returnItems = new Array();

	var items = new Array();

	if (offer != null && itemMap.size() > 0) {
		if (offer.groups.length > 1) {
			return;
		}

		var groupSeq = itemMap.keys()[0];
		var items = itemMap.get(groupSeq);

		items.sort(function(a, b) {
			return b.taxPrice - a.taxPrice;
		});

		var itemsList = new Array();

		var totalAmount = 0;

		for (var i = 0; i < items.length; i++) {
			var qty = items[i].qty;

			for (var j = 0; j < qty; j++) {

				var gpCartItemQty = new Object();

				gpCartItemQty.qty = 1;
				gpCartItemQty.cartItemId = items[i].cartItemId;
				gpCartItemQty.taxPrice = items[i].taxPrice;
				gpCartItemQty.productId = items[i].productId;

				itemsList.push(gpCartItemQty);
			}

			totalAmount = totalAmount.add(items[i].qty.mul(items[i].taxPrice));
			returnItems.push(items[i]);
		}

		var groups = offer.groups;
		var group;

		for (var i = 0; i < groups.length; i++) {
			var temp = groups[i];

			if (temp.groupSeq == groupSeq) {
				group = temp;
			}
		}

		var times = 0;
		// var discountQty = 0;

		if (group != null) {

			var groupItemsList = groupListByQuantity(itemsList,
					group.thresholdQty);
			var list;
			for (var k = 0; k < groupItemsList.length; k++) {

				list = groupItemsList[k].mydata.value;

				var groupTotalAmount = 0;
				for (var m = 0; m < list.length; m++) {
					groupTotalAmount = groupTotalAmount.add(list[m].taxPrice);
				}

				var discountFactor = offer.discountFactor;
				if (groupTotalAmount > discountFactor) {
					discount = discount.add(groupTotalAmount
							.sub(discountFactor));
				} else {
					break;
				}
			}

		}

		for (var i = 0; i < returnItems.length; i++) {
			var item = returnItems[i];

			if (discount == 0 && desc == CAL_STRING) {
				item.exceptionFlag = "\"error\"";
			}

			// item.taxPrice =
			// item.qty.mul(item.taxPrice).mul(discount).div(totalAmount).toFixed(2);
			item.gpDiscount = item.qty.mul(item.taxPrice).mul(discount).div(
					totalAmount).toFixed(2);

			if (!item.gpDiscount) {
				item.gpDiscount = 0;
			}

			// item.qty= 0 ;
			returnItems[i] = item;
		}

		items = balancePriceForItems(discount, returnItems)

	}
	return items;
}

function groupListByQuantity(itemsList, quantity) {
	if (itemsList == null) {
		return new Array();
	}
	if (quantity <= 0) {
		return;
	}

	var wrapList = new Array();
	var subList = new Array();

	var count = Math.floor(itemsList.length / quantity);

	var itemMap = new WMCMap();
	var subList = new Array();
	for (var i = 0; i < itemsList.length; i++) {

		if (i != 0 && i % quantity == 0) {
			count = count - 1;
			subList = [];
		}

		subList.push(itemsList[i]);
		itemMap.put(count, subList);
	}

	for ( var keys in itemMap.elements) {
		wrapList.push(new sersis(keys, itemMap.elements[keys]));
	}

	return wrapList;

}

function sersis(mykey, mydata) {
	this.mykey = mykey;
	this.mydata = mydata;
}

function objToJSON(obj) {
	var json = '{';
	var value;

	for ( var p in obj) {

		value = obj[p];

		if (value != 'undefined' && (typeof value != 'function')) {
			if (typeof value == 'object') {
				if (value.length && (value.length > 0)) {
					json += "\"" + p + "\"" + ":" + "[";

					for (var i = 0; i < value.length; i++) {
						json += objToJSON(value[i]) + ",";
					}

					json = json.substring(0, json.length - 1);
					json += "],";

				} else if (value.length == 0) {
					json += "\"" + p + "\"" + ":" + "[],";
				} else {
					json += objToJSON(value);
				}
			} else {
				json += "\"" + p + "\"" + ":" + value + ",";
			}
		}
	}

	json = json.substring(0, json.length - 1);
	json += "}";

	return json;
}

function JSONToString(obj) {
	var json;

	if (obj.length && (obj.length > 0)) {

		json = "[";

		for (var i = 0; i < obj.length; i++) {
			json += objToJSON(obj[i]) + ",";
		}

		json = json.substring(0, json.length - 1);
		json += "]";
	} else if (obj.length == 0) {
		return "[]";
	} else {
		json = objToJSON(obj);
	}
	return json;
}

/**
 * 获取优惠信息 params: cartItems 购物车商品项JSON,传入的字符串格式为[[{},{}],...] return:
 * 各项商品优惠的提示信息
 */
function getPromotionInfo(cartItems) {

	CAL_STRING = "cal";
	cartItems = eval("(" + cartItems + ")");

	var resultArray = new Array();
	var itemsArray = new Array();
	var obj;
	var cartItem;

	for (var i = 0; i < cartItems.length; i++) {

		cartItem = cartItems[i];

		if (cartItem.length > 0) {

			obj = new Object();

			obj.offerId = cartItem[0].offerId;
			var offerTypeCode = cartItem[0].offerTypeCode;
			var offer = getOfferById(obj.offerId);

			var cartMaps = getMapCartItem(cartItem); // 得到 一个类似
			// Map<offerId,Map<groupId,
			// cartItem> 的Map集合
			var groupMaps = cartMaps.values()[0];
			var desc = isRemind(offer, groupMaps); // 计算优惠顾提示信息,如果有则返回一个提示字符串,当达到优惠顾条件时，返回值为cal

			if (!desc) { // 该项商品没有优惠
				obj.tips = "\"\"";
				obj.totalDiscount = 0;
				obj.items = [];
			} else { // 该项商品有优惠

				// obj.totalDiscount = totalDiscount;
				// var items = cartListMap.get("listGpCartItem");
				var items = calculateInItemLevel(cartItem, desc, CAL_STRING);

				if (desc != CAL_STRING) { // 购买量没达到优惠条件
					obj.tips = "\"" + desc + "\"";
				} else { // 购买量达到优惠条件
					var itemDiscount = 0;

					for (var j = 0; j < items.length; j++) {
						itemDiscount = itemDiscount.add(items[j].gpDiscount)
								.toFixed(2);
						// items[j].exceptionFlag="\"error\"";
					}
					// 组合满立减多组不提示
					var offerGroups = offer && offer.groups;
					if (itemDiscount == 0) {
						if (offerTypeCode > 0) {
							obj.tips = "\"促销不可用\"";
							obj.errorCode = "-1";

						} else {
							if (offerGroups.length == 1) {
								obj.tips = "\"促销不可用\"";
								obj.errorCode = "-1";

							}
						}
					} else {

						obj.tips = "\"\"";
					}
				}

				itemsArray.push(items);
				obj.items = items;
			}

			obj.offerDesc = "\"\"";
			obj.offerDescCn = "\"\"";

			if (offer && offer.promotionDescCn) {
				obj.offerDesc = '"' + offer.promotionDescCn + '"';
			}
			if (offer && offer.promotionDesc) {
				obj.offerDescCn = '"' + offer.promotionDesc + '"';
			}

			resultArray.push(obj);
		}

	}

	resultArray.sort(function(a, b) {
		return a.offerId - b.offerId;
	});

	var itemsDiscountMap = new WMCMap();
	for (var j = 0; j < resultArray.length; j++) {

		var gpCartItems = resultArray[j];
		var exceptionFlag = validateGpOffer(gpCartItems, itemsDiscountMap);
		sumItemDiscount(gpCartItems, itemsDiscountMap, exceptionFlag);
	}

	return JSONToString(resultArray);
}

function sumItemDiscount(gpCartItems, itemsDiscountMap, exceptionFlag) {
	var totalDiscount = 0;
	if (exceptionFlag) {
		gpCartItems.tips = "\"促销不可用\"";
		gpCartItems.errorCode = "-1";
		gpCartItems.totalDiscount = 0;

		for (var j = 0; j < gpCartItems.items.length; j++) {
			gpCartItems.items[j].gpDiscount = 0;
		}
	} else {
		for (var k = 0; k < gpCartItems.items.length; k++) {
			var gpCartItem = gpCartItems.items[k];
			var itemDiscount = itemsDiscountMap.get(gpCartItem.productId).add(
					gpCartItem.gpDiscount).toFixed(2);
			itemsDiscountMap.put(gpCartItem.productId, itemDiscount);
			totalDiscount = totalDiscount.add(gpCartItem.gpDiscount).toFixed(2);
		}

		gpCartItems.totalDiscount = totalDiscount;

	}
}

function validateGpOffer(gpCartItems, itemsDiscountMap) {

	var exceptionFlag = false;

	for (var j = 0; j < gpCartItems.items.length; j++) {
		var gpCartItem = gpCartItems.items[j];

		if (!itemsDiscountMap.containsKey(gpCartItem.productId)) {
			itemsDiscountMap.put(gpCartItem.productId, 0);
		}
		// var aa = itemsDiscountMap.get(gpCartItem.productId);
		var itemDiscount = itemsDiscountMap.get(gpCartItem.productId).add(
				gpCartItem.gpDiscount).toFixed(2);
		var itemAmount = gpCartItem.qty.mul(gpCartItem.taxPrice).toFixed(2);
		if (itemDiscount.sub(itemAmount) >= 0) {
			exceptionFlag = true;
			gpCartItem.exceptionFlag = "\"error\"";
		}

	}
	return exceptionFlag;

}

function balancePriceForItems(totalDiscount, items) {

	if (items.length > 0) {

		if (items[0].productId != null && items[0].items != ""
				&& items[0].productId != undefined) {
			items.sort(function(a, b) {
				return a.productId - b.productId;
			});
		} else {
			items.sort(function(a, b) {
				return a.upc - b.upc;
			});
		}

		var tempTotal = 0;

		for (var i = 0; i < items.length; i++) {
			tempTotal = tempTotal.add(items[i].gpDiscount);
		}

		if (totalDiscount != tempTotal) {
			var spreads = totalDiscount.sub(tempTotal);
			var count = parseInt(Math.abs(spreads) * 100 / items.length, 10);
			var calCount = Math.abs(spreads) * 100 % items.length;
			var flag = spreads / Math.abs(spreads);

			for (var i = 0; i < items.length; i++) {
				items[i].gpDiscount = items[i].gpDiscount.add(count.mul(0.01)
						.mul(flag));

				if (calCount > i) {
					items[i].gpDiscount = items[i].gpDiscount.add(0.01
							.mul(flag));
				}
			}
		}
	}
	return items;
}
function balancePriceForItemsV2(totalDiscount, items) {

	items.sort(function(a, b) {
		return a.productId - b.productId;
	});

	var tempTotal = 0;

	for (var i = 0; i < items.length; i++) {
		tempTotal = tempTotal.add(items[i].taxPrice);
	}

	if (totalDiscount != tempTotal) {
		/*
		 * if(totalDiscount == 9.6){ alert(totalDiscount + "=" + tempTotal); }
		 */

		var spreads = totalDiscount.sub(tempTotal);
		var count = parseInt(Math.abs(spreads) * 100 / items.length, 10);
		var calCount = Math.abs(spreads) * 100 % items.length;
		var flag = spreads / Math.abs(spreads);

		for (var i = 0; i < items.length; i++) {
			items[i].taxPrice = items[i].taxPrice
					.add(count.mul(0.01).mul(flag));

			if (calCount > i) {
				items[i].taxPrice = items[i].taxPrice.add(0.01.mul(flag));
			}
		}
	}

	return items;
}

/**
 * 计算优惠顾提示信息,如果有则返回一个提示字符串,当达到优惠顾条件时，返回值为cal params: offer ,groupMaps
 * (groupMaps结构为 Map<groupId, cartItem>) return
 */

function isRemind(offer, groupMaps) {

	var desc;
	var groupSize = 0;
	var minQty = 0;
	var offerGroups = offer && offer.groups;
	var group;
	var groupId;
	var carts;
	var tieredDiscount;
	var thresholdAmt;
	var subQty = new Array();

	if (!offerGroups) {
		return false;
	}

	// 遍历该 offer(优惠) 的所有group
	for (var p = 0; p < offerGroups.length; p++) {
		group = offerGroups[p];
		minQty = group.thresholdQty;
		groupId = group.groupSeq;

		thresholdAmt = group.thresholdAmt;
		tieredDiscount = group.tieredDiscount;
		carts = groupMaps.get(groupId);

		if (!carts)
			break; // 该组没有carts, 退出循环 ?

		var relQty = 0;
		var relCartQty = 0;
		var relTaxPrice = 0;

		for (var i = 0; i < carts.length; i++) {
			relCartQty = carts[i].qty;
			// relTaxPrice += carts[i].taxPrice*relCartQty;
			relTaxPrice = (relTaxPrice + carts[i].taxPrice * relCartQty)
					.toFixed(2);
			relQty += carts[i].qty;
		}

		var obj = new Object();

		obj.relQty = relQty;
		obj.minQty = minQty;
		obj.thresholdAmt = thresholdAmt;
		obj.tieredDiscount = tieredDiscount;
		obj.relTaxPrice = relTaxPrice;
		subQty.push(obj);
		groupSize++;
	}
	var obj = subQty[0];

	if (offer.gpCaclTypeCode == PROMOTION_TYPE_AMT
			|| offer.gpCaclTypeCode == PROMOTION_TYPE_AMT_ONLINE) { // 0
		// 买立减
		// || 6
		// 满立减
		// 多组不提示,故当groupSize为1且只有一组时才有提示信息，其余情况可以直接算折扣（不符合条件算出来为0)
		desc = CAL_STRING;
		if (offerGroups.length == 1) {
			if (groupSize == 1) {
				if (offer.gpCaclTypeCode == PROMOTION_TYPE_AMT) {
					if (minQty > obj.relQty) {
						desc = "再购买" + (minQty - obj.relQty) + "件就可以享受"
								+ (offer.discountFactor).toFixed(2) + "元的优惠";
					}
				} else {
					if (thresholdAmt > obj.relTaxPrice) {
						desc = "再购买"
								+ (thresholdAmt - obj.relTaxPrice).toFixed(2)
								+ "元就可以享受" + (offer.discountFactor).toFixed(2)
								+ "元的优惠";
					}
				}
			}
		}
	} else {

		if (offer.gpCaclTypeCode == PROMOTION_TYPE_PCT) { // 1 折扣
			if (obj.relQty < minQty) {
				desc = "再购买" + (obj.minQty - obj.relQty) + "件就可以享受"
						+ (100 - offer.discountFactor).div(10) + "折的优惠";
			} else {
				desc = CAL_STRING;
			}
		} else if (offer.gpCaclTypeCode == PROMOTION_TYPE_AMT_TIERED
				|| offer.gpCaclTypeCode == PROMOTION_TYPE_PCT_TIERED) { // 2
			// 阶梯式现金返还/3
			// 阶梯式折扣

			var tieredDiscount = obj.tieredDiscount;

			tieredDiscount.sort(function(a, b) {
				return a.thresholdQty - b.thresholdQty; // thresholdQty 由小到大排序
			});

			var minQty = 0;
			var relQty = obj.relQty;
			var relTaxPrice = obj.relTaxPrice;
			var discount;

			// 找到符合条件的最优惠的组
			var currentLevel = -1; // 记录当前优惠梯级
			for (var i = 0; i < tieredDiscount.length; i++) {
				currentLevel = i; // 赋值当前优惠梯级
				if (relQty <= tieredDiscount[i].thresholdQty) {
					minQty = tieredDiscount[i].thresholdQty;
					discount = tieredDiscount[i].discountFactor;
					break;
				}
			}

			if (offer.gpCaclTypeCode == PROMOTION_TYPE_AMT_ONLINE_TIERED) {
				if (minQty > obj.relTaxPrice && currentLevel == 0) { // 当实际购买的数量小于一级阶梯设定数值时，提示
					desc = "再购买" + (minQty - obj.relTaxPrice).toFixed(2)
							+ "元就可以享受" + discount.toFixed(2) + "元的优惠";
				} else {
					desc = CAL_STRING;
				}
			} else {
				// 处于一级阶梯(currentLevel==0) 范围时需要提示，二级及以上说明需要按当前优惠梯级计算优惠了,不用再提示
				if (minQty > obj.relQty && currentLevel == 0) { // 当实际购买的数量小于一级阶梯设定数值时，提示
					if (offer.gpCaclTypeCode == PROMOTION_TYPE_AMT_TIERED) {
						desc = "再购买" + (minQty - obj.relQty) + "件就可以享受"
								+ discount.toFixed(2) + "元的优惠";
					} else {
						desc = "再购买" + (minQty - obj.relQty) + "件就可以享受"
								+ (100 - discount).div(10) + "折的优惠";
					}
				} else {
					desc = CAL_STRING;
				}
			}
		} else if (offer.gpCaclTypeCode == PROMOTION_TYPE_FIXED) { // 固定价格优惠
			if (obj.minQty > obj.relQty) {
				desc = "再购买" + (obj.minQty - obj.relQty) + "件就可以享受总价格"
						+ (offer.discountFactor).toFixed(2) + "元";
			} else {
				desc = CAL_STRING;
			}
		}

	}

	return desc;
}

function getPromotionInfoForAndroid(cartItems) {
	window.javaKey.onDiscountBack(getPromotionInfo(cartItems));
}