package com.walmart.mobile.checkout.enumcode.promotion;

import com.walmart.mobile.checkout.exception.handler.ErrorInfoInterface;

/**
 * 系统及业务级别的错误码
 * @author lliao2
 */
public enum PromotionErrorInfoEnum implements ErrorInfoInterface {
	SUCCESS("0", "success"), 
	GP_DATA_NOT_EXIST("-301","no promotion info"), 
	PRODUCT_DATA_NOT_EXIST("-303", "No product info"),
//	USER_UNAUTHORIZED("-304","unAuthorized"), 
	AMOUNT_NOT_MATCH("-305", "order amount not match"), 
	DISCOUNT_NOT_MATCH("-306","discount not match"), 
	DISCOUNT_NOT_COMPARE("-307","clientDiscount not equals serverGpDiscount"),
	GP_GROUP_NOT_ONLYONE("-308","There can be only one group, but find more than one"), 
	GP_VERSION_NOT_FOUND("-309","promotion version not found"), 
	PARAMETER_IS_EMPTY("-310","parameter can not empty");

	private String code;

	private String message;

	PromotionErrorInfoEnum(String code, String message) {
		this.code = code;
		this.message = message;
	}

	@Override
	public String getCode() {
		return this.code;
	}

	@Override
	public String getMessage() {
		return this.message;
	}
}
