package com.walmart.mobile.checkout.service.promotion;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.walmart.mobile.checkout.entity.promotion.GpOffer;
import com.walmart.mobile.checkout.repo.GpOfferRepository;

@Service
public class GpOfferService {

	@Autowired
	GpOfferRepository gpOfferRepository;

	public void gpOfferListsave(List<GpOffer> gpOfferList) {
		gpOfferRepository.save(gpOfferList);
	}

	public void delete(List<GpOffer> gpOfferList) {
		gpOfferRepository.delete(gpOfferList);
	}

	public GpOffer findByGpOfferId(int gpOfferId) {
		return gpOfferRepository.findByGpOfferId(gpOfferId);
	}

	public List<GpOffer> findByGpOfferIdIn(List<Integer> offerIdList) {
		return gpOfferRepository.findByGpOfferIdIn(offerIdList);
	}

	public List<GpOffer> findByStatus(int status) {
		return gpOfferRepository.findByStatus(status);
	}

	public List<GpOffer> findByGpOfferIdInAndStatus(List<Integer> offerIdList, Integer status) {
		return gpOfferRepository.findByGpOfferIdInAndStatus(offerIdList, status);
	}
	
	
	//add by leo begin
	
	
	public GpOffer findByGpOfferIdAndStatus(int gpOfferId, Integer status){
		return gpOfferRepository.findByGpOfferIdAndStatus(gpOfferId, status);
	}
	public void gpOfferSave(GpOffer gpOffer){
		gpOfferRepository.save(gpOffer);
	}
	
	//add by leo end
	
}