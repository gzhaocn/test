package com.walmart.mobile.checkout.bo.promotion;


import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
/**
 * 多gp计算
 * @author lliao2
 *
 */
public class CalcDiscountResult {

	private Map<Integer, List<GpCartItem>> gpOfferDiscounts;
	private BigDecimal totalDiscount;
	private boolean itemLevelDisocuntCompareFlag;
	private Map<Integer, Integer>  gpOfferIdMinTimesMap;

	public CalcDiscountResult() {
		gpOfferDiscounts = new HashMap<>();
		totalDiscount = BigDecimal.ZERO;
		itemLevelDisocuntCompareFlag = true;
		gpOfferIdMinTimesMap= new HashMap<>();
	}

	public boolean isItemLevelDisocuntCompareFlag() {
		return itemLevelDisocuntCompareFlag;
	}

	public void setItemLevelDisocuntCompareFlag(boolean itemLevelDisocuntCompareFlag) {
		this.itemLevelDisocuntCompareFlag = itemLevelDisocuntCompareFlag;
	}

	public Map<Integer, List<GpCartItem>> getGpOfferDiscounts() {
		return gpOfferDiscounts;
	}

	public void setGpOfferDiscounts(Map<Integer, List<GpCartItem>> gpOfferDiscounts) {
		this.gpOfferDiscounts = gpOfferDiscounts;
	}

	public BigDecimal getTotalDiscount() {
		return totalDiscount;
	}

	public void setTotalDiscount(BigDecimal totalDiscount) {
		this.totalDiscount = totalDiscount;
	}

	public Map<Integer, Integer> getGpOfferIdMinTimesMap() {
		return gpOfferIdMinTimesMap;
	}

	public void setGpOfferIdMinTimesMap(Map<Integer, Integer> gpOfferIdMinTimesMap) {
		this.gpOfferIdMinTimesMap = gpOfferIdMinTimesMap;
	}

}
