package com.walmart.mobile.checkout.entity.promotion;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Field;
/**
 * 分组信息
 * @author lliao2
 *
 */
public class Group implements Serializable {

	private static final long serialVersionUID = -3584768907523087679L;
	@Field("group_seq")
	private Integer groupSeq;

	@Field("threshold_qty")
	private Integer thresholdQty;

	@Field("threshold_amt")
	private BigDecimal thresholdAmt;

	@Field("tiered_discount")
	private List<TieredDiscount> tieredDiscount;

	public Integer getGroupSeq() {
		return groupSeq;
	}

	public Integer getThresholdQty() {
		return thresholdQty;
	}

	public List<TieredDiscount> getTieredDiscount() {
		return tieredDiscount;
	}

	public void setGroupSeq(Integer groupSeq) {
		this.groupSeq = groupSeq;
	}

	public void setThresholdQty(Integer thresholdQty) {
		this.thresholdQty = thresholdQty;
	}

	public void setTieredDiscount(List<TieredDiscount> tieredDiscount) {
		this.tieredDiscount = tieredDiscount;
	}

	public BigDecimal getThresholdAmt() {
		return thresholdAmt;
	}

	public void setThresholdAmt(BigDecimal thresholdAmt) {
		this.thresholdAmt = thresholdAmt;
	}

}
