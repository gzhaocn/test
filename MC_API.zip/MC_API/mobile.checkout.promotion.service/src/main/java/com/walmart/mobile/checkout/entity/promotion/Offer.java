package com.walmart.mobile.checkout.entity.promotion;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.math.BigDecimal;

import org.springframework.data.mongodb.core.mapping.Field;

/**
 * gp描述信息
 * 
 * @author lliao2
 *
 */
@ApiModel(description = "gp描述信息")
public class Offer implements Comparable<Offer>, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1115170743730270022L;
	@ApiModelProperty(value = "gp标识")
	@Field("gp_offer_id")
	private Integer gpOfferId;

	@ApiModelProperty(value = "gp 类型  ")
	@Field("gp_type_code")
	private Integer gpTypeCode;

	@ApiModelProperty(value = "gp分组")
	@Field("gp_group_seq")
	private Integer gpGroupSeq;

	@ApiModelProperty(value = "gp描述想信息")
	@Field("promotion_desc_cn")
	private String promotionDescCn;
	@ApiModelProperty(value = "gp金额")
	private BigDecimal gpDiscount;

	public Integer getGpOfferId() {
		return gpOfferId;
	}

	public void setGpOfferId(Integer gpOfferId) {
		this.gpOfferId = gpOfferId;
	}

	public Integer getGpTypeCode() {
		return gpTypeCode;
	}

	public void setGpTypeCode(Integer gpTypeCode) {
		this.gpTypeCode = gpTypeCode;
	}

	public Integer getGpGroupSeq() {
		return gpGroupSeq;
	}

	public void setGpGroupSeq(Integer gpGroupSeq) {
		this.gpGroupSeq = gpGroupSeq;
	}

	public String getPromotionDescCn() {
		return promotionDescCn;
	}

	public void setPromotionDescCn(String promotionDescCn) {
		this.promotionDescCn = promotionDescCn;
	}

	public BigDecimal getGpDiscount() {
		return gpDiscount == null ? BigDecimal.ZERO : gpDiscount;
	}

	public void setGpDiscount(BigDecimal gpDiscount) {
		this.gpDiscount = gpDiscount;
	}

	@Override
	public int compareTo(Offer o) {
		if (this.getGpOfferId() < o.getGpOfferId()) {
			return -1;
		} else if (this.getGpOfferId().intValue() == o.getGpOfferId().intValue()) {
			return 0;
		} else {
			return 1;
		}
	}

	@Override
	public int hashCode() {
		return this.getGpOfferId() == null ? 0 : this.getGpOfferId().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (!(obj instanceof Offer)) {
			return false;
		}
		Offer other = (Offer) obj;
		return this.getGpOfferId().equals(other.getGpOfferId());
	}
}
