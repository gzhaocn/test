package com.walmart.mobile.checkout.bo.promotion;

import java.util.List;

public class CalcItemsDiscountTimes {
	
	
	private Integer minTimes;
	
	private List<GpCartItem> returnItems;
	
	private Integer gpOfferId;

	public Integer getMinTimes() {
		return minTimes;
	}

	public void setMinTimes(Integer minTimes) {
		this.minTimes = minTimes;
	}

	public List<GpCartItem> getReturnItems() {
		return returnItems;
	}

	public void setReturnItems(List<GpCartItem> returnItems) {
		this.returnItems = returnItems;
	}

	public Integer getGpOfferId() {
		return gpOfferId;
	}

	public void setGpOfferId(Integer gpOfferId) {
		this.gpOfferId = gpOfferId;
	}
	

}
