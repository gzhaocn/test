package com.walmart.mobile.checkout.bo.promotion;


import java.math.BigDecimal;
/**
 * 购物车对象
 * @author lliao2
 *
 */
public class GpCartItem {

	private Integer gpOfferId;

	private Integer groupSeq;

	private Integer qty;

	private BigDecimal taxPrice; // 用成了2个含义 gp 金额

	private Long upc;

	private Long productId;

	private BigDecimal gpDiscount;

	private BigDecimal clientDiscount;
	private Long cartItemId;
	
	public GpCartItem() {
		//构造函数
	}

	public GpCartItem(Long productId, Long upc, int qty, BigDecimal taxPrice) {
		this.productId = productId;
		this.upc = upc;
		this.qty = qty;
		this.taxPrice = taxPrice;
	}

	public GpCartItem(Long productId, Long upc, int qty, BigDecimal taxPrice, int gpOfferId, int groupSeq, BigDecimal clientDiscount,Long cartItemId) {
		this.cartItemId = cartItemId;
		this.productId = productId;
		this.upc = upc;
		this.qty = qty;
		this.taxPrice = taxPrice;
		this.gpOfferId = gpOfferId;
		this.groupSeq = groupSeq;
		this.clientDiscount = clientDiscount;
	}

	public GpCartItem(Long productId, Long upc, int qty, BigDecimal taxPrice, int gpOfferId, int groupSeq) {
		this.productId = productId;
		this.upc = upc;
		this.qty = qty;
		this.taxPrice = taxPrice;
		this.gpOfferId = gpOfferId;
		this.groupSeq = groupSeq;
	}

	public BigDecimal getClientDiscount() {
		return clientDiscount;
	}

	public void setClientDiscount(BigDecimal clientDiscount) {
		this.clientDiscount = clientDiscount;
	}

	public BigDecimal getGpDiscount() {
		return gpDiscount;
	}

	public void setGpDiscount(BigDecimal gpDiscount) {
		this.gpDiscount = gpDiscount;
	}



	public Long getUpc() {
		return upc;
	}

	public void setUpc(Long upc) {
		this.upc = upc;
	}

	public Integer getGpOfferId() {
		return gpOfferId;
	}

	public void setGpOfferId(Integer gpOfferId) {
		this.gpOfferId = gpOfferId;
	}

	public Integer getGroupSeq() {
		return groupSeq;
	}

	public void setGroupSeq(Integer groupSeq) {
		this.groupSeq = groupSeq;
	}

	public Integer getQty() {
		return qty;
	}

	public void setQty(Integer qty) {
		this.qty = qty;
	}

	public BigDecimal getTaxPrice() {
		return taxPrice;
	}

	public void setTaxPrice(BigDecimal taxPrice) {
		this.taxPrice = taxPrice;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public Long getCartItemId() {
		return cartItemId;
	}

	public void setCartItemId(Long cartItemId) {
		this.cartItemId = cartItemId;
	}
}
