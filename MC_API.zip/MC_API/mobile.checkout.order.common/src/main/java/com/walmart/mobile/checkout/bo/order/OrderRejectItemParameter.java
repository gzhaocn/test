package com.walmart.mobile.checkout.bo.order;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "订单退货商品参数模型")
public class OrderRejectItemParameter {

	@ApiModelProperty(value = "productId", required = true)
	private Long productId;
	
	@ApiModelProperty(value = "购物车商品ID", required = true)
	private Long cartItemId;
	
	@ApiModelProperty(value = "退货数量", required = true)
	private Integer requestQuantity;
	
	@ApiModelProperty(value = "延保商品标识", required = true)
    private Integer ewsFlag;
	
	@ApiModelProperty(value = "延保商品id")
	private Long itemNumber;
	
	@ApiModelProperty(value = "退货原因", required = true)
    private Integer returnReason;

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public Long getCartItemId() {
		return cartItemId;
	}

	public void setCartItemId(Long cartItemId) {
		this.cartItemId = cartItemId;
	}

	public Integer getReturnReason() {
		return returnReason;
	}

	public void setReturnReason(Integer returnReason) {
		this.returnReason = returnReason;
	}

	public Integer getRequestQuantity() {
		return requestQuantity;
	}

	public void setRequestQuantity(Integer requestQuantity) {
		this.requestQuantity = requestQuantity;
	}

	public Integer getEwsFlag() {
		return ewsFlag;
	}

	public void setEwsFlag(Integer ewsFlag) {
		this.ewsFlag = ewsFlag;
	}

	public Long getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(Long itemNumber) {
		this.itemNumber = itemNumber;
	}

}
