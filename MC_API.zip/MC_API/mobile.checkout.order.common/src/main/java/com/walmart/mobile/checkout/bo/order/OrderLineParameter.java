package com.walmart.mobile.checkout.bo.order;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.walmart.mobile.checkout.rest.vo.EwsPriceVo;
import com.walmart.mobile.checkout.rest.vo.InventoryPriceVo;
import com.walmart.mobile.checkout.rest.vo.OfferVo;

@ApiModel(description = "商品参数模型")
public class OrderLineParameter {
	@ApiModelProperty(value = "商品唯一编码", hidden = true)
	private long upc;
	@ApiModelProperty(value = "商品标识", required = true)
	private Long productId;
	@ApiModelProperty(value = "商品名称")
	private String descOnline;
	@ApiModelProperty(value = "含税价格", required = true)
	private BigDecimal priceWithTax;
	@ApiModelProperty(value = "订购数量", required = true)
	private int orderQuantity;
	@ApiModelProperty(value = "分摊到的GP优惠金额", required = true)
	private BigDecimal gpDiscount;
	@ApiModelProperty(value = "小图标URL", hidden = true)
	private String thumbnailUrl;
	@ApiModelProperty(value = "商品gp信息")
	private List<OfferVo> gpOffers;
	@ApiModelProperty(value = "购物车商品序号", required = true)
	private Long cartItemId;

	@ApiModelProperty(value = "商品重量", hidden = true)
	private BigDecimal orderWeight;

	@ApiModelProperty(value = "称重商品条码")
	private Long barCode;
	@ApiModelProperty(value = "称重商品金额")
	private BigDecimal itemAmount;

	@ApiModelProperty(value = "商品类型(0非称重、1称重)", required = true)
	private int itemType; // 0非称重，1称重

	@ApiModelProperty(value = "是否计数的称重商品", required = true)
	private int unitPriceItemFlag;

	@ApiModelProperty(value = "商品延保信息")
	private EwsPriceVo ewsPrice;
	/**
	 * 0、未选择 1、选择
	 */
	@ApiModelProperty(value = "是否选了延保")
	private Integer ewsOptFlag;

	@ApiModelProperty(value = "配送数量")
	private Integer deliveryRequestQuantity;

	@ApiModelProperty(value = "是否配送(0、不配送  1、配送)")
	private Integer deliveryFlag;

	@ApiModelProperty(hidden = true)
	@JsonIgnore
	public OrderLineParameter setOrderLineParameter(InventoryPriceVo invenPrice) {

		if (this.getPriceWithTax() == null) {
			this.setPriceWithTax(new BigDecimal(invenPrice.getPriceWithTax().toString()));
		}
		if (StringUtils.isEmpty(this.getThumbnailUrl())) {
			this.setThumbnailUrl(StringUtils.EMPTY);
		}

		return this;
	}

	public long getUpc() {
		return upc;
	}

	public void setUpc(long upc) {
		this.upc = upc;
	}

	public String getDescOnline() {
		return descOnline != null ? descOnline : "";
	}

	public void setDescOnline(String descOnline) {
		this.descOnline = descOnline;
	}

	public BigDecimal getPriceWithTax() {
		return priceWithTax;
	}

	public void setPriceWithTax(BigDecimal priceWithTax) {
		this.priceWithTax = priceWithTax;
	}

	public int getOrderQuantity() {
		return orderQuantity;
	}

	public void setOrderQuantity(int orderQuantity) {
		this.orderQuantity = orderQuantity;
	}

	public BigDecimal getGpDiscount() {
		if (gpDiscount != null) {
			// 解决iOS传递过来的gpDiscount
			// double类型产生的误差问题（如84.600000000000001，和iOS保持一样的逻辑（先加0.000001后再保留2位小数，之后的全部舍去）
			return gpDiscount.add(new BigDecimal("0.000001")).setScale(2, RoundingMode.DOWN);
		} else {
			return BigDecimal.ZERO;
		}
	}

	public void setGpDiscount(BigDecimal gpDiscount) {
		this.gpDiscount = gpDiscount;
	}

	public String getThumbnailUrl() {
		return this.thumbnailUrl != null ? this.thumbnailUrl : "";
	}

	public void setThumbnailUrl(String thumbnailUrl) {
		this.thumbnailUrl = thumbnailUrl;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public List<OfferVo> getGpOffers() {
		return gpOffers;
	}

	public void setGpOffers(List<OfferVo> gpOffers) {
		this.gpOffers = gpOffers;
	}

	public int getItemType() {
		return itemType;
	}

	public void setItemType(int itemType) {
		this.itemType = itemType;
	}

	public Long getCartItemId() {
		return cartItemId;
	}

	public void setCartItemId(Long cartItemId) {
		this.cartItemId = cartItemId;
	}

	public BigDecimal getOrderWeight() {
		return orderWeight != null ? orderWeight : BigDecimal.ZERO;
	}

	public void setOrderWeight(BigDecimal orderWeight) {
		this.orderWeight = orderWeight;
	}

	public Long getBarCode() {
		return barCode;
	}

	public void setBarCode(Long barCode) {
		this.barCode = barCode;
	}

	public BigDecimal getItemAmount() {
		return itemAmount == null ? BigDecimal.ZERO : itemAmount;
	}

	public void setItemAmount(BigDecimal itemAmount) {
		this.itemAmount = itemAmount;
	}

	public int getUnitPriceItemFlag() {
		return unitPriceItemFlag;
	}

	public void setUnitPriceItemFlag(int unitPriceItemFlag) {
		this.unitPriceItemFlag = unitPriceItemFlag;
	}

	public EwsPriceVo getEwsPrice() {
		return ewsPrice;
	}

	public void setEwsPrice(EwsPriceVo ewsPrice) {
		this.ewsPrice = ewsPrice;
	}

	public Integer getEwsOptFlag() {
		return ewsOptFlag;
	}

	public void setEwsOptFlag(Integer ewsOptFlag) {
		this.ewsOptFlag = ewsOptFlag;
	}

	public Integer getDeliveryRequestQuantity() {
		return deliveryRequestQuantity;
	}

	public void setDeliveryRequestQuantity(Integer deliveryRequestQuantity) {
		this.deliveryRequestQuantity = deliveryRequestQuantity;
	}

	public Integer getDeliveryFlag() {
		return deliveryFlag;
	}

	public void setDeliveryFlag(Integer deliveryFlag) {
		this.deliveryFlag = deliveryFlag;
	}
}
