package com.walmart.mobile.checkout.domain.order;

import java.math.BigDecimal;

public class OrderDiscount extends OrderDiscountKey {
	private Long productId;

	private Integer storeId;

	private Integer gpTypeCode;

	private String promotionDescCn;

	private Long gpGroupSeq;

	private BigDecimal gpDiscount;
    
    private Integer gpDiscountTimes;
    
    private Integer linkSaveId;

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public Integer getGpTypeCode() {
		return gpTypeCode;
	}

	public void setGpTypeCode(Integer gpTypeCode) {
		this.gpTypeCode = gpTypeCode;
	}

	public String getPromotionDescCn() {
		return promotionDescCn;
	}

	public void setPromotionDescCn(String promotionDescCn) {
		this.promotionDescCn = promotionDescCn == null ? null : promotionDescCn.trim();
	}

	public Long getGpGroupSeq() {
		return gpGroupSeq;
	}

	public void setGpGroupSeq(Long gpGroupSeq) {
		this.gpGroupSeq = gpGroupSeq;
	}

	public BigDecimal getGpDiscount() {
		return gpDiscount != null ? gpDiscount : BigDecimal.ZERO;
	}

	public void setGpDiscount(BigDecimal gpDiscount) {
		this.gpDiscount = gpDiscount;
	}



	public Integer getGpDiscountTimes() {
		return gpDiscountTimes;
	}

	public void setGpDiscountTimes(Integer gpDiscountTimes) {
		this.gpDiscountTimes = gpDiscountTimes;
	}

	public Integer getLinkSaveId() {
		return linkSaveId;
	}

	public void setLinkSaveId(Integer linkSaveId) {
		this.linkSaveId = linkSaveId;
	}
}