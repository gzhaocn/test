package com.walmart.mobile.checkout.constant.order;

public class MessageTypeCons {
	/**
	 * orderList存在推送
	 */
	public static final int ORDERLIST_EXIST_PUSH = 1;
	/**
	 * orderList不存在推送
	 */
	public static final int ORDERLIST_NOT_EXIST_PUSH = 2;
	/**
	 * 快捷方式通过推送
	 */
	public static final int SHORT_CUT_COMFIREM_PUSH = 3;
	/**
	 * 快捷方式拒绝推送
	 */
	public static final int SHORT_CUT_REJECT_PUSH = 4;
	/**
	 * 常规方式通过推送
	 */
	public static final int COMMON_COMFIREM_PUSH = 5;
	/**
	 * 常规方式拒绝推送
	 */
	public static final int COMMON_REJECT_PUSH = 6;
	/**
	 * 常规方式全部通过推送
	 */
	public static final int COMMON_COMFIREM_ALL_PUSH = 7;

	private MessageTypeCons() {
	}

}
