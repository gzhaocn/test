package com.walmart.mobile.checkout.domain.order;


import java.math.BigDecimal;

public class OrderEws extends OrderEwsKey {
    private String ewsCategory;

    private BigDecimal ewsStartPrice;

    private BigDecimal ewsEndPrice;

    private Integer ewsTimeSlot;

    private BigDecimal ewsPrice;

    private Long ewsBarcode;

    private String ewsDesc;
    
    private Integer ewsQuantity;
   
    private BigDecimal ewsAmount;
    

    public String getEwsCategory() {
        return ewsCategory;
    }

    public void setEwsCategory(String ewsCategory) {
        this.ewsCategory = ewsCategory == null ? null : ewsCategory.trim();
    }

    public BigDecimal getEwsStartPrice() {
        return ewsStartPrice;
    }

    public void setEwsStartPrice(BigDecimal ewsStartPrice) {
        this.ewsStartPrice = ewsStartPrice;
    }

    public BigDecimal getEwsEndPrice() {
        return ewsEndPrice;
    }

    public void setEwsEndPrice(BigDecimal ewsEndPrice) {
        this.ewsEndPrice = ewsEndPrice;
    }

    public Integer getEwsTimeSlot() {
        return ewsTimeSlot;
    }

    public void setEwsTimeSlot(Integer ewsTimeSlot) {
        this.ewsTimeSlot = ewsTimeSlot;
    }

    public BigDecimal getEwsPrice() {
        return ewsPrice;
    }

    public void setEwsPrice(BigDecimal ewsPrice) {
        this.ewsPrice = ewsPrice;
    }

    public Long getEwsBarcode() {
        return ewsBarcode;
    }

    public void setEwsBarcode(Long ewsBarcode) {
        this.ewsBarcode = ewsBarcode;
    }

    public String getEwsDesc() {
        return ewsDesc;
    }

    public void setEwsDesc(String ewsDesc) {
        this.ewsDesc = ewsDesc == null ? null : ewsDesc.trim();
    }

	public Integer getEwsQuantity() {
		return ewsQuantity;
	}

	public void setEwsQuantity(Integer ewsQuantity) {
		this.ewsQuantity = ewsQuantity;
	}

	public BigDecimal getEwsAmount() {
		return ewsAmount;
	}

	public void setEwsAmount(BigDecimal ewsAmount) {
		this.ewsAmount = ewsAmount;
	}
}