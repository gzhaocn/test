package com.walmart.mobile.checkout.bo.order;

import java.util.Date;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "recordSales 查询订单信息参数")
public class QueryOrderRecordSalesParamter {
	@ApiModelProperty(value = "订单号码", required = true)
	private String orderId;

	@ApiModelProperty(value = "调用程序key", required = true)
	private String appKey;

	@ApiModelProperty(value = "调用时间", required = true)
	private Date timeStamp;

	@ApiModelProperty(value = "签名", required = true)
	private String sign;

	@ApiModelProperty(value = "参数格式（如：json）", required = true)
	private String format;

	@ApiModelProperty(value = "版本", required = true)
	private String version;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getAppKey() {
		return appKey;
	}

	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}

	public Date getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

}
