package com.walmart.mobile.checkout.constant.order;


public class OrderStatus {
	/**
	 * 未支付
	 */
	public static final int UNPAID = 1;

	/**
	 * 超时
	 */
	public static final int TIMEOUT = 10;

	/**
	 * 未支付订单取消处理中
	 */
	public static final int CANCELLING = 15;
	
	/**
	 * 已支付订单取消处理中
	 */
	public static final int PAID_CANCELLING = 18;


	/**
	 * 未支付情况之下，取消后的状态
	 */
	public static final int UNPAID_CANCELLED = 20;
	
	
	/**
	 * 支付完成，取消后，退款完成后的状态
	 */
	public static final int PAID_CANCELLED = 25;

	/**
	 * 支付
	 */
	public static final int PAID = 30;
	/**
	 * 完成
	 */
	public static final int COMPLETE = 80;

	/**
	 * 支付中
	 */
	public static final int PAYING = 28;
	
	private OrderStatus(){}

}
