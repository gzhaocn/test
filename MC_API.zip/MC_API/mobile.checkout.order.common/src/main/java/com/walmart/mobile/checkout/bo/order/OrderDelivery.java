package com.walmart.mobile.checkout.bo.order;

import java.util.List;

import com.walmart.mobile.checkout.domain.order.OrderLine;

public class OrderDelivery {
	
	private DeliveryParameter delivery ;
	private List<OrderLine> orderLineList ;
	
	public OrderDelivery(DeliveryParameter delivery,List<OrderLine> orderLineList){
		this.delivery = delivery;
		this.orderLineList = orderLineList;
	}
	
	public DeliveryParameter getDelivery() {
		return delivery;
	}
	public void setDelivery(DeliveryParameter delivery) {
		this.delivery = delivery;
	}
	public List<OrderLine> getOrderLineList() {
		return orderLineList;
	}
	public void setOrderLineList(List<OrderLine> orderLineList) {
		this.orderLineList = orderLineList;
	}

}
