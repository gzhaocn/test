package com.walmart.mobile.checkout.domain.order;

import java.math.BigDecimal;

public class OrderRefund {
	private String orderId;

	private Long upc;

	private Long cartItemId;

	private BigDecimal returnAmount;

	private Integer requestQuantity;

	private Integer returnQuantity;

	private Byte returnReason;

	private Byte refundStatus;

	private String batchNo;

	public Integer getReturnQuantity() {
		return returnQuantity;
	}

	public void setReturnQuantity(Integer returnQuantity) {
		this.returnQuantity = returnQuantity;
	}

	public BigDecimal getReturnAmount() {
		return returnAmount;
	}

	public void setReturnAmount(BigDecimal returnAmount) {
		this.returnAmount = returnAmount;
	}

	public Integer getRequestQuantity() {
		return requestQuantity;
	}

	public void setRequestQuantity(Integer requestQuantity) {
		this.requestQuantity = requestQuantity;
	}

	public Long getCartItemId() {
		return cartItemId;
	}

	public void setCartItemId(Long cartItemId) {
		this.cartItemId = cartItemId;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public Long getUpc() {
		return upc;
	}

	public void setUpc(Long upc) {
		this.upc = upc;
	}

	public Byte getReturnReason() {
		return returnReason;
	}

	public void setReturnReason(Byte returnReason) {
		this.returnReason = returnReason;
	}

	public Byte getRefundStatus() {
		return refundStatus;
	}

	public void setRefundStatus(Byte refundStatus) {
		this.refundStatus = refundStatus;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}
}