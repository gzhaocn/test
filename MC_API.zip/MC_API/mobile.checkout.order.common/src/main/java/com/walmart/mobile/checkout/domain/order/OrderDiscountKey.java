package com.walmart.mobile.checkout.domain.order;

public class OrderDiscountKey {
    private String orderId;

    private Long cartItemId;

    private Integer gpOfferId;

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId == null ? null : orderId.trim();
    }

    public Long getCartItemId() {
        return cartItemId;
    }

    public void setCartItemId(Long cartItemId) {
        this.cartItemId = cartItemId;
    }

    public Integer getGpOfferId() {
        return gpOfferId;
    }

    public void setGpOfferId(Integer gpOfferId) {
        this.gpOfferId = gpOfferId;
    }
}