package com.walmart.mobile.checkout.bo.order;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 扫描订单二维码获取客户申请退货订单
 * 
 * @author lliao2
 *
 */
@ApiModel(description = "扫描订单二维码获取客户申请退货订单")
public class OrderRefundParameter {
	@ApiModelProperty(value = "订单ID", required = true)
	private String orderId;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
}
