package com.walmart.mobile.checkout.bo.order;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * 出场二维码扫码参数
 * @author lliao2
 *
 */
@ApiModel(description = "出场二维码扫码参数模型")
public class OrderScanListParameter {
	@ApiModelProperty(value = "订单ID", required = true)
	private List<String> orderIds;
	@ApiModelProperty(value = "用户ID", required = true)
	private String userId;
	@ApiModelProperty(value = "门店ID", required = true)
	private String storeId;
	@ApiModelProperty(value = "通道号", required = true)
	private String sequenceNumber;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getStoreId() {
		return storeId;
	}
	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}
	public String getSequenceNumber() {
		return sequenceNumber;
	}
	public void setSequenceNumber(String sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}
	public List<String> getOrderIds() {
		return orderIds;
	}
	public void setOrderIds(List<String> orderIds) {
		this.orderIds = orderIds;
	}
}
