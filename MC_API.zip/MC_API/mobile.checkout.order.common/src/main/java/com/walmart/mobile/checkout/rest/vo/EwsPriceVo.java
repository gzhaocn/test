package com.walmart.mobile.checkout.rest.vo;

import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;

public class EwsPriceVo { 
	@ApiModelProperty(value = "维保商品种类")
    private String category;
	@ApiModelProperty(value = "维保商品itemNumber")
    private Long itemNumber;
	@ApiModelProperty(value = "起始价格")
    private BigDecimal startPrice;
	@ApiModelProperty(value = "终止价格")
    private BigDecimal endPrice;
	@ApiModelProperty(value = "年限")
    private Integer timeSlot;
	@ApiModelProperty(value = "保额")
    private BigDecimal extendedWarrantyPrice;
	@ApiModelProperty(value = "维保商品barCode")
    private Long ewsBarcode;
	@ApiModelProperty(value = "描述信息")
    private String desc;
	@ApiModelProperty(value = "维保商品数量")
    private Integer ewsQuantity;
	@ApiModelProperty(value = "维保金额")
    private BigDecimal ewsAmount;
	
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public Long getItemNumber() {
		return itemNumber;
	}
	public void setItemNumber(Long itemNumber) {
		this.itemNumber = itemNumber;
	}
	public BigDecimal getStartPrice() {
		return startPrice;
	}
	public void setStartPrice(BigDecimal startPrice) {
		this.startPrice = startPrice;
	}
	public BigDecimal getEndPrice() {
		return endPrice;
	}
	public void setEndPrice(BigDecimal endPrice) {
		this.endPrice = endPrice;
	}
	public Integer getTimeSlot() {
		return timeSlot;
	}
	public void setTimeSlot(Integer timeSlot) {
		this.timeSlot = timeSlot;
	}
	public Long getEwsBarcode() {
		return ewsBarcode;
	}
	public void setEwsBarcode(Long ewsBarcode) {
		this.ewsBarcode = ewsBarcode;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public BigDecimal getExtendedWarrantyPrice() {
		return extendedWarrantyPrice;
	}
	public void setExtendedWarrantyPrice(BigDecimal extendedWarrantyPrice) {
		this.extendedWarrantyPrice = extendedWarrantyPrice;
	}
	public Integer getEwsQuantity() {
		return ewsQuantity;
	}
	public void setEwsQuantity(Integer ewsQuantity) {
		this.ewsQuantity = ewsQuantity;
	}
	public BigDecimal getEwsAmount() {
		return ewsAmount;
	}
	public void setEwsAmount(BigDecimal ewsAmount) {
		this.ewsAmount = ewsAmount;
	}

    

}
