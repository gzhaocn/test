package com.walmart.mobile.checkout.domain.order;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.walmart.mobile.checkout.bo.order.OrderLineParameter;
import com.walmart.mobile.checkout.bo.order.OrderParameter;
import com.walmart.mobile.checkout.constant.order.ItemType;
import com.walmart.mobile.checkout.rest.vo.InventoryPriceVo;
import com.walmart.mobile.checkout.rest.vo.ProductDetailVo;

public class OrderLine extends OrderLineKey {
	private Long upc;

	private Integer itemType;

	private BigDecimal priceWithTax;

	private Integer orderQuantity;

	private BigDecimal orderWeight;

	private BigDecimal itemAmount;

	private String thumbnailUrl;

	private String descOnline;

	private BigDecimal wasPrice;

	private BigDecimal priceWithoutTax;

	private BigDecimal taxRate;

	private BigDecimal unitCost;

	private Date returnBy;

	private BigDecimal gpDiscount;

	private Integer storeId;

	private Integer reportCode;

	private Integer department;

	private String posDescOnline;

	private Long itemNumber;

	private Integer magneticFlag;

	private Integer unitPriceItemFlag;

	private Integer ewsOptFlag;

	private Integer specialItemFlag;

	private Integer deliveryFlag;

	private Integer deliveryRequestQuantity;
	/**
	 * CPK商品
	 */
	private Integer unitFlag;

	public OrderLine() {
		// 构造函数
	}

	public OrderLine(OrderLineParameter orderLineParam, Order order, ProductDetailVo productDetail, InventoryPriceVo dbInvenPrice, OrderParameter orderParam, Date orderLineReturnBy) {
		this.descOnline = orderLineParam.getDescOnline();
		this.gpDiscount = orderLineParam.getGpDiscount();
		this.setOrderId(order.getOrderId());
		this.setCartItemId(orderLineParam.getCartItemId());
		this.orderQuantity = orderLineParam.getOrderQuantity();
		this.priceWithTax = orderLineParam.getPriceWithTax();
		this.priceWithoutTax = dbInvenPrice.getPriceWithoutTax();
		this.itemType = orderLineParam.getItemType();
		this.itemAmount = orderLineParam.getItemAmount();
		this.returnBy = orderLineReturnBy;
		if (orderLineParam.getItemType() == ItemType.WEGITH_ITEM) {
			// CPV商品priceWithTax为0，orderweight设置为1,priceWithoutTax 自己计算
			this.orderWeight = BigDecimal.valueOf(dbInvenPrice.getPriceWithTax()).compareTo(BigDecimal.ZERO) == 0 ? new BigDecimal(1) : orderLineParam.getItemAmount().divide(
					new BigDecimal(String.valueOf(dbInvenPrice.getPriceWithTax())), 5, BigDecimal.ROUND_HALF_UP);
			this.priceWithTax = BigDecimal.valueOf(dbInvenPrice.getPriceWithTax()).compareTo(BigDecimal.ZERO) == 0 ? orderLineParam.getItemAmount() : orderLineParam.getPriceWithTax();
			this.priceWithoutTax = BigDecimal.valueOf(dbInvenPrice.getPriceWithTax()).compareTo(BigDecimal.ZERO) == 0 ? orderLineParam.getItemAmount().divide(
					BigDecimal.ONE.add(dbInvenPrice.getTaxRate()), 2, BigDecimal.ROUND_HALF_UP) : dbInvenPrice.getPriceWithoutTax();
		}
		this.itemAmount = orderLineParam.getItemAmount();
		this.thumbnailUrl = orderLineParam.getThumbnailUrl();
		this.upc = productDetail.getUpc();
		this.setProductId(dbInvenPrice.getProductId());
		this.wasPrice = getWasPrice(dbInvenPrice);

		this.taxRate = dbInvenPrice.getTaxRate();
		this.unitCost = dbInvenPrice.getUnitCost();
		this.storeId = orderParam.getStoreId();
		this.reportCode = dbInvenPrice.getReportCode();

		this.department = dbInvenPrice.getDepartmentWmInternal() != null ? dbInvenPrice.getDepartmentWmInternal() : productDetail.getDepartmentWmInternal();
		this.posDescOnline = dbInvenPrice.getPosDescOnline();
		this.itemNumber = dbInvenPrice.getItemNumber();
		this.magneticFlag = dbInvenPrice.getMagneticFlag();
		this.unitPriceItemFlag = orderLineParam.getUnitPriceItemFlag();
		this.ewsOptFlag = orderLineParam.getEwsOptFlag();
		this.deliveryFlag = orderLineParam.getDeliveryFlag();
		this.deliveryRequestQuantity = orderLineParam.getDeliveryRequestQuantity();
		this.unitFlag = dbInvenPrice.getUnitFlag();
	}

	public String getDescOnline() {
		return descOnline;
	}

	public void setDescOnline(String descOnline) {
		this.descOnline = descOnline;
	}

	public BigDecimal getPriceWithTax() {
		return priceWithTax != null ? priceWithTax : BigDecimal.ZERO;
	}

	public void setPriceWithTax(BigDecimal priceWithTax) {
		this.priceWithTax = priceWithTax;
	}

	public BigDecimal getWasPrice() {
		return wasPrice != null ? wasPrice : BigDecimal.ZERO;
	}

	public void setWasPrice(BigDecimal wasPrice) {
		this.wasPrice = wasPrice;
	}

	public Integer getOrderQuantity() {
		return orderQuantity;
	}

	public void setOrderQuantity(Integer orderQuantity) {
		this.orderQuantity = orderQuantity;
	}

	public BigDecimal getGpDiscount() {
		return gpDiscount != null ? gpDiscount : BigDecimal.ZERO;
	}

	public void setGpDiscount(BigDecimal gpDiscount) {
		this.gpDiscount = gpDiscount;
	}

	public String getThumbnailUrl() {
		return thumbnailUrl;
	}

	public void setThumbnailUrl(String thumbnailUrl) {
		this.thumbnailUrl = thumbnailUrl;
	}

	public Date getReturnBy() {
		return returnBy;
	}

	public void setReturnBy(Date returnBy) {
		this.returnBy = returnBy;
	}

	public BigDecimal getPriceWithoutTax() {
		return priceWithoutTax != null ? priceWithoutTax : BigDecimal.ZERO;
	}

	public void setPriceWithoutTax(BigDecimal priceWithoutTax) {
		this.priceWithoutTax = priceWithoutTax;
	}

	public BigDecimal getTaxRate() {
		return taxRate != null ? taxRate : BigDecimal.ZERO;
	}

	public void setTaxRate(BigDecimal taxRate) {
		this.taxRate = taxRate;
	}

	public BigDecimal getUnitCost() {
		return unitCost != null ? unitCost : BigDecimal.ZERO;
	}

	public void setUnitCost(BigDecimal unitCost) {
		this.unitCost = unitCost;
	}

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public Long getUpc() {
		return upc;
	}

	public void setUpc(Long upc) {
		this.upc = upc;
	}

	private BigDecimal getWasPrice(InventoryPriceVo invenPrice) {
		Float fWasPrice = invenPrice.getWasPrice();
		BigDecimal price = null;
		if (fWasPrice != null) {
			price = new BigDecimal(fWasPrice.toString());
		}

		return price;
	}

	public int getItemType() {
		return itemType;
	}

	public void setItemType(int itemType) {
		this.itemType = itemType;
	}

	public BigDecimal getOrderWeight() {
		return orderWeight != null ? orderWeight : BigDecimal.ZERO;
	}

	public void setOrderWeight(BigDecimal orderWeight) {
		this.orderWeight = orderWeight;
	}

	public BigDecimal getItemAmount() {
		return itemAmount != null ? itemAmount : BigDecimal.ZERO;
	}

	public void setItemAmount(BigDecimal itemAmount) {
		this.itemAmount = itemAmount;
	}

	public void setItemType(Integer itemType) {
		this.itemType = itemType;
	}

	/**
	 * @return the reportCode
	 */
	public Integer getReportCode() {
		return reportCode;
	}

	/**
	 * @param reportCode
	 *            the reportCode to set
	 */
	public void setReportCode(Integer reportCode) {
		this.reportCode = reportCode;
	}

	/**
	 * @return the department
	 */
	public Integer getDepartment() {
		return department;
	}

	/**
	 * @param department
	 *            the department to set
	 */
	public void setDepartment(Integer department) {
		this.department = department;
	}

	public String getPosDescOnline() {
		return posDescOnline;
	}

	public void setPosDescOnline(String posDescOnline) {
		this.posDescOnline = posDescOnline;
	}

	public Long getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(Long itemNumber) {
		this.itemNumber = itemNumber;
	}

	public Integer getMagneticFlag() {
		return magneticFlag == null ? 0 : magneticFlag;
	}

	public void setMagneticFlag(Integer magneticFlag) {
		this.magneticFlag = magneticFlag;
	}

	public Integer getUnitPriceItemFlag() {
		return unitPriceItemFlag;
	}

	public void setUnitPriceItemFlag(Integer unitPriceItemFlag) {
		this.unitPriceItemFlag = unitPriceItemFlag;
	}

	public Integer getEwsOptFlag() {
		return ewsOptFlag;
	}

	public void setEwsOptFlag(Integer ewsOptFlag) {
		this.ewsOptFlag = ewsOptFlag;
	}

	public Integer getSpecialItemFlag() {
		return specialItemFlag;
	}

	public void setSpecialItemFlag(Integer specialItemFlag) {
		this.specialItemFlag = specialItemFlag;
	}

	@JsonIgnore
	public BigDecimal calcProductAmount(BigDecimal productQty, int itemType) {
		BigDecimal productAmount = this.getPriceWithTax().multiply(productQty);
		if (itemType == ItemType.WEGITH_ITEM) {
			productAmount = this.getItemAmount().multiply(productQty);
		}
		if (this.getGpDiscount() != null) {
			productAmount = productAmount.subtract(this.getGpDiscount());
		}
		return productAmount;
	}

	public Integer getDeliveryFlag() {
		return deliveryFlag;
	}

	public void setDeliveryFlag(Integer deliveryFlag) {
		this.deliveryFlag = deliveryFlag;
	}

	public Integer getDeliveryRequestQuantity() {
		return deliveryRequestQuantity == null ? 0 : deliveryRequestQuantity;
	}

	public void setDeliveryRequestQuantity(Integer deliveryRequestQuantity) {
		this.deliveryRequestQuantity = deliveryRequestQuantity;
	}

	public Integer getUnitFlag() {
		return unitFlag == null ? 0 : unitFlag;
	}

	public void setUnitFlag(Integer unitFlag) {
		this.unitFlag = unitFlag;
	}

}
