package com.walmart.mobile.checkout.bo.order;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 未支付取消订单参数
 * @author lliao2
 *
 */
@ApiModel(description = "取消未支付订单参数模型")
public class OrderCancelParameter {
	@ApiModelProperty(value = "订单ID", required = true)
	private String orderId;
	@ApiModelProperty(value = "取消原因", required = true)
	private int cancelReason;
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public int getCancelReason() {
		return cancelReason;
	}
	public void setCancelReason(int cancelReason) {
		this.cancelReason = cancelReason;
	}

}
