package com.walmart.mobile.checkout.bo.order;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;

@ApiModel(description = "运费商品参数模型")
public class ShippingFeeItemParameter {
	@ApiModelProperty(value = "商品唯一编码")
	private long upc;
	@ApiModelProperty(value = "商品标识", required = true)
	private Long productId;
	@ApiModelProperty(value = "商品名称")
	private String descOnline;
	@ApiModelProperty(value = "含税价格", required = true)
	private BigDecimal priceWithTax;
	@ApiModelProperty(value = "订购数量", required = true)
	private int orderQuantity;
	@ApiModelProperty(value = "购物车商品序号", required = true)
	private Long cartItemId;

	public long getUpc() {
		return upc;
	}

	public void setUpc(long upc) {
		this.upc = upc;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public String getDescOnline() {
		return descOnline;
	}

	public void setDescOnline(String descOnline) {
		this.descOnline = descOnline;
	}

	public BigDecimal getPriceWithTax() {
		return priceWithTax;
	}

	public void setPriceWithTax(BigDecimal priceWithTax) {
		this.priceWithTax = priceWithTax;
	}

	public int getOrderQuantity() {
		return orderQuantity;
	}

	public void setOrderQuantity(int orderQuantity) {
		this.orderQuantity = orderQuantity;
	}

	public Long getCartItemId() {
		return cartItemId;
	}

	public void setCartItemId(Long cartItemId) {
		this.cartItemId = cartItemId;
	}

}
