package com.walmart.mobile.checkout.bo.order;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 订单提交发票信息
 * @author lliao2
 *
 */
@ApiModel(description = "订单提交发票信息参数与模型")
public class OrderInvoiceInfoParamter {
	@ApiModelProperty(value = "订单ID", required = true)
	private String orderId;
	@ApiModelProperty(value = "发票抬头", required = true)
	private String invoiceTitle;
	@ApiModelProperty(value = "发票类型", required = true)
	private int invoiceType;
	@ApiModelProperty(value = "企业纳税代码", required = true)
	private String taxCode;
	@ApiModelProperty(value = "发票邮箱", required = true)
	private String invoiceEmail;
	
	
	public String getInvoiceTitle() {
		return invoiceTitle;
	}
	public void setInvoiceTitle(String invoiceTitle) {
		this.invoiceTitle = invoiceTitle;
	}
	public int getInvoiceType() {
		return invoiceType;
	}
	public void setInvoiceType(int invoiceType) {
		this.invoiceType = invoiceType;
	}
	public String getTaxCode() {
		return taxCode;
	}
	public void setTaxCode(String taxCode) {
		this.taxCode = taxCode;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getInvoiceEmail() {
		return invoiceEmail;
	}
	public void setInvoiceEmail(String invoiceEmail) {
		this.invoiceEmail = invoiceEmail;
	}

}
