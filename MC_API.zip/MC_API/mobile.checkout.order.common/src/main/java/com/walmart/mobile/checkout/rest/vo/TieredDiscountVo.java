package com.walmart.mobile.checkout.rest.vo;

import java.io.Serializable;
import java.math.BigDecimal;

import org.springframework.data.mongodb.core.mapping.Field;
/**
 * 阶梯gp参数
 * @author lliao2
 *
 */
public class TieredDiscountVo implements Serializable {

	private static final long serialVersionUID = 2745696401756239193L;

	@Field("threshold_qty")
	private Integer thresholdQty;

	@Field("discount_factor")
	private BigDecimal discountFactor;

	@Field("threshold_amt")
	private BigDecimal thresholdAmt;

	public BigDecimal getThresholdAmt() {
		return thresholdAmt;
	}

	public void setThresholdAmt(BigDecimal thresholdAmt) {
		this.thresholdAmt = thresholdAmt;
	}

	public BigDecimal getDiscountFactor() {
		return discountFactor;
	}

	public void setDiscountFactor(BigDecimal discountFactor) {
		this.discountFactor = discountFactor;
	}

	public Integer getThresholdQty() {
		return thresholdQty;
	}

	public void setThresholdQty(Integer thresholdQty) {
		this.thresholdQty = thresholdQty;
	}

}
