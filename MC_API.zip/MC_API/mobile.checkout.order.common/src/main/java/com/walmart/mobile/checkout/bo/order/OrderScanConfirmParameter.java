package com.walmart.mobile.checkout.bo.order;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 出场二维码扫码参数
 * 
 * @author lliao2
 *
 */
@ApiModel(description = "出场二维码扫码参数模型")
public class OrderScanConfirmParameter {
	@ApiModelProperty(value = "订单ID", required = true)
	private String orderId;
	@ApiModelProperty(value = "用户ID", required = true)
	private String userId;
	@ApiModelProperty(value = "门店ID", required = true)
	private String storeId;
	@ApiModelProperty(value = "通道号", required = true)
	private String sequenceNumber;
	@ApiModelProperty(value = "通过原因", required = false)
	private Integer cancelReason;
	@ApiModelProperty(value = "通过文字描述", required = false)
	private String cancelRemark;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getStoreId() {
		return storeId;
	}

	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}

	public String getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(String sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public Integer getCancelReason() {
		return cancelReason;
	}

	public void setCancelReason(Integer cancelReason) {
		this.cancelReason = cancelReason;
	}

	public String getCancelRemark() {
		return cancelRemark;
	}

	public void setCancelRemark(String cancelRemark) {
		this.cancelRemark = cancelRemark;
	}
}
