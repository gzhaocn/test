package com.walmart.mobile.checkout.bo.order;

public class OrderInformation {
	
	private Integer status;
	private String tcNumber;
	
	public OrderInformation(Integer status,String tcNumber){
		this.status = status;
		this.tcNumber = tcNumber;
	}
	
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public String getTcNumber() {
		return tcNumber;
	}
	public void setTcNumber(String tcNumber) {
		this.tcNumber = tcNumber;
	}

}
