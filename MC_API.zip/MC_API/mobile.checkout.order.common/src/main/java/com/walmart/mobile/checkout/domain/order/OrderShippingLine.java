package com.walmart.mobile.checkout.domain.order;

import java.math.BigDecimal;
import java.util.Date;

public class OrderShippingLine extends OrderShippingLineKey {
	private Long upc;

	private Integer itemType;

	private BigDecimal priceWithTax;

	private Integer orderQuantity;

	private String thumbnailUrl;

	private String descOnline;

	private BigDecimal wasPrice;

	private BigDecimal priceWithoutTax;

	private BigDecimal taxRate;

	private BigDecimal unitCost;

	private Date returnBy;

	private BigDecimal gpDiscount;

	private Integer storeId;

	private Integer reportCode;

	private Integer department;

	private String posDescOnline;

	private Long itemNumber;

	private Long cartItemId;

	public Long getUpc() {
		return upc;
	}

	public void setUpc(Long upc) {
		this.upc = upc;
	}

	public Integer getItemType() {
		return itemType;
	}

	public void setItemType(Integer itemType) {
		this.itemType = itemType;
	}

	public BigDecimal getPriceWithTax() {
		return priceWithTax == null ? BigDecimal.ZERO : priceWithTax;
	}

	public void setPriceWithTax(BigDecimal priceWithTax) {
		this.priceWithTax = priceWithTax;
	}

	public Integer getOrderQuantity() {
		return orderQuantity;
	}

	public void setOrderQuantity(Integer orderQuantity) {
		this.orderQuantity = orderQuantity;
	}

	public String getThumbnailUrl() {
		return thumbnailUrl;
	}

	public void setThumbnailUrl(String thumbnailUrl) {
		this.thumbnailUrl = thumbnailUrl == null ? null : thumbnailUrl.trim();
	}

	public String getDescOnline() {
		return descOnline;
	}

	public void setDescOnline(String descOnline) {
		this.descOnline = descOnline == null ? null : descOnline.trim();
	}

	public BigDecimal getWasPrice() {
		return wasPrice == null ? BigDecimal.ZERO : wasPrice;
	}

	public void setWasPrice(BigDecimal wasPrice) {
		this.wasPrice = wasPrice;
	}

	public BigDecimal getPriceWithoutTax() {
		return priceWithoutTax == null ? BigDecimal.ZERO : priceWithoutTax;
	}

	public void setPriceWithoutTax(BigDecimal priceWithoutTax) {
		this.priceWithoutTax = priceWithoutTax;
	}

	public BigDecimal getTaxRate() {
		return taxRate == null ? BigDecimal.ZERO : taxRate;
	}

	public void setTaxRate(BigDecimal taxRate) {
		this.taxRate = taxRate;
	}

	public BigDecimal getUnitCost() {
		return unitCost == null ? BigDecimal.ZERO : unitCost;
	}

	public void setUnitCost(BigDecimal unitCost) {
		this.unitCost = unitCost;
	}

	public Date getReturnBy() {
		return returnBy;
	}

	public void setReturnBy(Date returnBy) {
		this.returnBy = returnBy;
	}

	public BigDecimal getGpDiscount() {
		return gpDiscount == null ? BigDecimal.ZERO : gpDiscount;
	}

	public void setGpDiscount(BigDecimal gpDiscount) {
		this.gpDiscount = gpDiscount;
	}

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public Integer getReportCode() {
		return reportCode;
	}

	public void setReportCode(Integer reportCode) {
		this.reportCode = reportCode;
	}

	public Integer getDepartment() {
		return department;
	}

	public void setDepartment(Integer department) {
		this.department = department;
	}

	public String getPosDescOnline() {
		return posDescOnline;
	}

	public void setPosDescOnline(String posDescOnline) {
		this.posDescOnline = posDescOnline == null ? null : posDescOnline.trim();
	}

	public Long getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(Long itemNumber) {
		this.itemNumber = itemNumber;
	}

	public Long getCartItemId() {
		return cartItemId;
	}

	public void setCartItemId(Long cartItemId) {
		this.cartItemId = cartItemId;
	}
}