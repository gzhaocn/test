package com.walmart.mobile.checkout.rest.vo;

import io.swagger.annotations.ApiModel;

import java.io.Serializable;
import java.math.BigDecimal;

import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * gp描述信息
 * 
 * @author lliao2
 *
 */
@ApiModel(description = "gp描述信息")
public class OfferVo implements Comparable<OfferVo>, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1115170743730270022L;
	@Field("gp_offer_id")
	private Integer gpOfferId;

	@Field("gp_type_code")
	private Integer gpTypeCode;

	@Field("gp_group_seq")
	private Integer gpGroupSeq;

	@Field("promotion_desc_cn")
	private String promotionDescCn;

	@Field("promotion_title_cn")
	private String promotionTitleCn;

	private BigDecimal gpDiscount;

	@Field("link_save_id")
	private Integer linkSaveId;

	public Integer getGpOfferId() {
		return gpOfferId;
	}

	public void setGpOfferId(Integer gpOfferId) {
		this.gpOfferId = gpOfferId;
	}

	public Integer getGpTypeCode() {
		return gpTypeCode;
	}

	public void setGpTypeCode(Integer gpTypeCode) {
		this.gpTypeCode = gpTypeCode;
	}

	public Integer getGpGroupSeq() {
		return gpGroupSeq;
	}

	public void setGpGroupSeq(Integer gpGroupSeq) {
		this.gpGroupSeq = gpGroupSeq;
	}

	public String getPromotionDescCn() {
		return promotionDescCn;
	}

	public void setPromotionDescCn(String promotionDescCn) {
		this.promotionDescCn = promotionDescCn;
	}

	public BigDecimal getGpDiscount() {
		return gpDiscount == null ? BigDecimal.ZERO : gpDiscount;
	}

	public void setGpDiscount(BigDecimal gpDiscount) {
		this.gpDiscount = gpDiscount;
	}

	@Override
	@JsonIgnore
	public int compareTo(OfferVo o) {
		if (this.getGpOfferId() < o.getGpOfferId()) {
			return -1;
		} else if (this.getGpOfferId().intValue() == o.getGpOfferId().intValue()) {
			return 0;
		} else {
			return 1;
		}
	}

	@Override
	@JsonIgnore
	public int hashCode() {
		return this.getGpOfferId() == null ? 0 : this.getGpOfferId().hashCode();
	}

	@Override
	@JsonIgnore
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (!(obj instanceof OfferVo)) {
			return false;
		}
		OfferVo other = (OfferVo) obj;
		return this.getGpOfferId().equals(other.getGpOfferId());
	}

	public Integer getLinkSaveId() {
		return linkSaveId;
	}

	public void setLinkSaveId(Integer linkSaveId) {
		this.linkSaveId = linkSaveId;
	}

	public String getPromotionTitleCn() {
		return promotionTitleCn;
	}

	public void setPromotionTitleCn(String promotionTitleCn) {
		this.promotionTitleCn = promotionTitleCn;
	}

}
