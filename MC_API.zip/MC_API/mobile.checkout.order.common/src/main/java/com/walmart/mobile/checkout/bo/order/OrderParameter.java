package com.walmart.mobile.checkout.bo.order;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.walmart.mobile.checkout.domain.order.OrderEwsLine;
import com.walmart.mobile.checkout.domain.order.OrderShippingLine;
import com.walmart.mobile.checkout.rest.vo.EwsPriceVo;
import com.walmart.mobile.checkout.rest.vo.GpOfferVo;
import com.walmart.mobile.checkout.rest.vo.InventoryPriceVo;
import com.walmart.mobile.checkout.rest.vo.NoDeliverItemVo;
import com.walmart.mobile.checkout.rest.vo.ProductDetailVo;
import com.walmart.mobile.checkout.rest.vo.SpecialItemVo;
import com.walmart.mobile.checkout.utils.AmountUtil;

@ApiModel(description = "订单参数模型")
public class OrderParameter {
	/* 客户端参数开始 */
	@ApiModelProperty(value = "送货信息")
	private DeliveryParameter delivery;
	@ApiModelProperty(value = "运费")
	private BigDecimal shippingFee;
	@ApiModelProperty(value = "包装费", hidden = true)
	private BigDecimal packagingFee;
	@ApiModelProperty(value = "门店短名称", required = true)
	private String shortNameCn;
	@ApiModelProperty(value = "发票抬头")
	private String invoiceTitle;
	@ApiModelProperty(value = "发票类型(0 不需要1纸质发票  3电子个人发票 4电子单位发票)")
	private int invoiceType;
	@ApiModelProperty(value = "订单总额", required = true)
	private BigDecimal amount;
	@ApiModelProperty(value = "GP优惠金额")
	private BigDecimal totalGpDiscount;
	@ApiModelProperty(value = "商品详情")
	private List<OrderLineParameter> orderLines;
	@ApiModelProperty(value = "运费商品详情")
	private ShippingFeeItemParameter shippingFeeItemLine;
	@ApiModelProperty(value = "门店号", required = true)
	private int storeId;
	@ApiModelProperty(value = "订单类型(1:mobileCK,2:H5,3:GHS)", required = true)
	private Integer orderType;
	@ApiModelProperty(value = "企业税务编码", required = false)
	private String taxCode;
	@ApiModelProperty(value = "发票邮箱", required = false)
	private String invoiceEmail;

	/* 客户端参数结束 */

	/* 服务器端临时参数开始 */
	@ApiModelProperty(value = "是否配送(0、不配送  1、配送)", hidden = true)
	private Integer deliveryFlag;

	@ApiModelProperty(hidden = true)
	private String userId;

	@ApiModelProperty(hidden = true)
	private String dagId;
	@ApiModelProperty(hidden = true)
	private String orderId;
	@ApiModelProperty(hidden = true)
	@JsonIgnore
	Map<Long, ProductDetailVo> productDetails;
	@ApiModelProperty(hidden = true)
	@JsonIgnore
	Map<Long, InventoryPriceVo> inventoryPrices;
	@ApiModelProperty(hidden = true)
	@JsonIgnore
	Map<Integer, GpOfferVo> gpOffers;
	@ApiModelProperty(hidden = true)
	@JsonIgnore
	List<Long> productIds;
	@ApiModelProperty(hidden = true)
	@JsonIgnore
	Map<Integer, Integer> gpOfferIdMinTimesMap;

	@ApiModelProperty(hidden = true)
	@JsonIgnore
	Map<Integer, Integer> gpOfferIdAndLinkSaveIdMap;

	@ApiModelProperty(hidden = true)
	@JsonIgnore
	Map<Long, Long> productIdAndItemNumberMap;

	private String mobilePhone;
	@ApiModelProperty(hidden = true)
	@JsonIgnore
	private List<EwsPriceVo> ewsPriceList;

	@ApiModelProperty(hidden = true)
	@JsonIgnore
	private List<OrderEwsLine> orderEwsLineList;

	@ApiModelProperty(hidden = true)
	@JsonIgnore
	private Map<Long, SpecialItemVo> upcAndSpecialItemMap;

	/**
	 * 消磁标记（软硬标）
	 */
	@JsonIgnore
	private Integer magneticFlag;

	@JsonIgnore
	@ApiModelProperty(hidden = true)
	private Map<Long, NoDeliverItemVo> noDeliverItemMap;
	@JsonIgnore
	@ApiModelProperty(hidden = true)
	private BigDecimal deliveryThreshold;
	@JsonIgnore
	@ApiModelProperty(hidden = true)
	private BigDecimal dbShippingFee;

	@ApiModelProperty(hidden = true)
	@JsonIgnore
	private OrderShippingLine orderShippingLine;

	/* 服务器端临时参数结束 */

	public String getShortNameCn() {
		return shortNameCn;
	}

	public void setShortNameCn(String shortNameCn) {
		this.shortNameCn = shortNameCn;
	}

	public int getInvoiceType() {
		return invoiceType;
	}

	public void setInvoiceType(int invoiceType) {
		this.invoiceType = invoiceType;
	}

	public String getInvoiceTitle() {
		return invoiceTitle != null ? invoiceTitle : "";
	}

	public void setInvoiceTitle(String invoiceTitle) {
		this.invoiceTitle = invoiceTitle;
	}

	public BigDecimal getShippingFee() {
		return shippingFee != null ? shippingFee : BigDecimal.ZERO;
	}

	public void setShippingFee(BigDecimal shippingFee) {
		this.shippingFee = shippingFee;
	}

	public BigDecimal getPackagingFee() {
		return packagingFee != null ? packagingFee : BigDecimal.ZERO;
	}

	public void setPackagingFee(BigDecimal packagingFee) {
		this.packagingFee = packagingFee;
	}

	public BigDecimal getAmount() {
		return amount != null ? amount : BigDecimal.ZERO;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public BigDecimal getTotalGpDiscount() {
		return totalGpDiscount != null ? totalGpDiscount : BigDecimal.ZERO;
	}

	public void setTotalGpDiscount(BigDecimal totalGpDiscount) {
		this.totalGpDiscount = totalGpDiscount;
	}

	public List<OrderLineParameter> getOrderLines() {
		return orderLines;
	}

	public void setOrderLines(List<OrderLineParameter> orderLines) {
		this.orderLines = orderLines;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public int getStoreId() {
		return storeId;
	}

	public void setStoreId(int storeId) {
		this.storeId = storeId;
	}

	public String getDagId() {
		return dagId;
	}

	public void setDagId(String dagId) {
		this.dagId = dagId;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public Map<Long, ProductDetailVo> getProductDetails() {
		return productDetails;
	}

	public void setProductDetails(Map<Long, ProductDetailVo> productDetails) {
		this.productDetails = productDetails;
	}

	public Map<Long, InventoryPriceVo> getInventoryPrices() {
		return inventoryPrices;
	}

	public void setInventoryPrices(Map<Long, InventoryPriceVo> inventoryPrices) {
		this.inventoryPrices = inventoryPrices;
	}

	public Map<Integer, GpOfferVo> getGpOffers() {
		return gpOffers;
	}

	public void setGpOffers(Map<Integer, GpOfferVo> gpOffers) {
		this.gpOffers = gpOffers;
	}

	public List<Long> getProductIds() {
		return productIds;
	}

	public void setProductIds(List<Long> productIds) {
		this.productIds = productIds;
	}

	/**
	 * 获取UPC 列表.
	 * 
	 * @param orderParam
	 * @return
	 */
	@JsonIgnore
	public List<Long> buildProductIdList() {
		productIds = new ArrayList<>();
		for (OrderLineParameter olr : getOrderLines()) {
			productIds.add(olr.getProductId());
		}

		return productIds;
	}

	@JsonIgnore
	public boolean checkOrderAmount(BigDecimal itemAmount, List<OrderLineParameter> orderLines) {

		BigDecimal clientItemAmount = getAmount();

		BigDecimal clientGpDiscount = getTotalGpDiscount();

		BigDecimal clientPackageFee = getPackagingFee();
		BigDecimal clientShipingFee = getShippingFee();
		BigDecimal ewsAmount = getOrderEwsAmount(orderLines);
		return clientItemAmount.compareTo(AmountUtil.calcOrderPaymentAmount(itemAmount, clientGpDiscount, clientShipingFee, clientPackageFee, ewsAmount)) == 0;
	}

	public Map<Integer, Integer> getGpOfferIdMinTimesMap() {
		return gpOfferIdMinTimesMap;
	}

	public void setGpOfferIdMinTimesMap(Map<Integer, Integer> gpOfferIdMinTimesMap) {
		this.gpOfferIdMinTimesMap = gpOfferIdMinTimesMap;
	}

	public Map<Long, Long> getProductIdAndItemNumberMap() {
		return productIdAndItemNumberMap;
	}

	public void setProductIdAndItemNumberMap(Map<Long, Long> productIdAndItemNumberMap) {
		this.productIdAndItemNumberMap = productIdAndItemNumberMap;
	}

	public Integer getOrderType() {
		return orderType;
	}

	public void setOrderType(Integer orderType) {
		this.orderType = orderType;
	}

	public String getMobilePhone() {
		return mobilePhone;
	}

	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}

	public Map<Integer, Integer> getGpOfferIdAndLinkSaveIdMap() {
		return gpOfferIdAndLinkSaveIdMap;
	}

	public void setGpOfferIdAndLinkSaveIdMap(Map<Integer, Integer> gpOfferIdAndLinkSaveIdMap) {
		this.gpOfferIdAndLinkSaveIdMap = gpOfferIdAndLinkSaveIdMap;
	}

	public String getTaxCode() {
		return taxCode;
	}

	public void setTaxCode(String taxCode) {
		this.taxCode = taxCode;
	}

	public List<EwsPriceVo> getEwsPriceList() {
		return ewsPriceList;
	}

	public void setEwsPriceList(List<EwsPriceVo> ewsPriceList) {
		this.ewsPriceList = ewsPriceList;
	}

	@JsonIgnore
	public BigDecimal getOrderEwsAmount(List<OrderLineParameter> orderLines) {
		BigDecimal orderEwsAmount = BigDecimal.ZERO;
		for (OrderLineParameter orderLineParameter : orderLines) {
			EwsPriceVo ewsPrice = orderLineParameter.getEwsPrice();
			if (ewsPrice != null) {
				orderEwsAmount = orderEwsAmount.add(ewsPrice.getEwsAmount());
			}
		}

		return orderEwsAmount;
	}

	public List<OrderEwsLine> getOrderEwsLineList() {
		return orderEwsLineList;
	}

	public void setOrderEwsLineList(List<OrderEwsLine> orderEwsLineList) {
		this.orderEwsLineList = orderEwsLineList;
	}

	public Map<Long, SpecialItemVo> getUpcAndSpecialItemMap() {
		return upcAndSpecialItemMap;
	}

	public void setUpcAndSpecialItemMap(Map<Long, SpecialItemVo> upcAndSpecialItemMap) {
		this.upcAndSpecialItemMap = upcAndSpecialItemMap;
	}

	public Integer getMagneticFlag() {
		return magneticFlag == null ? 0 : magneticFlag;
	}

	public void setMagneticFlag(Integer magneticFlag) {
		this.magneticFlag = magneticFlag;
	}

	public String getInvoiceEmail() {
		return invoiceEmail;
	}

	public void setInvoiceEmail(String invoiceEmail) {
		this.invoiceEmail = invoiceEmail;
	}

	public DeliveryParameter getDelivery() {
		return delivery;
	}

	public void setDelivery(DeliveryParameter delivery) {
		this.delivery = delivery;
	}

	public Integer getDeliveryFlag() {
		return deliveryFlag;
	}

	public void setDeliveryFlag(Integer deliveryFlag) {
		this.deliveryFlag = deliveryFlag;
	}

	public Map<Long, NoDeliverItemVo> getNoDeliverItemMap() {
		return noDeliverItemMap;
	}

	public void setNoDeliverItemMap(Map<Long, NoDeliverItemVo> noDeliverItemMap) {
		this.noDeliverItemMap = noDeliverItemMap;
	}

	public BigDecimal getDeliveryThreshold() {
		return deliveryThreshold;
	}

	public void setDeliveryThreshold(BigDecimal deliveryThreshold) {
		this.deliveryThreshold = deliveryThreshold;
	}

	public BigDecimal getDbShippingFee() {
		return dbShippingFee;
	}

	public void setDbShippingFee(BigDecimal dbShippingFee) {
		this.dbShippingFee = dbShippingFee;
	}

	public ShippingFeeItemParameter getShippingFeeItemLine() {
		return shippingFeeItemLine;
	}

	public void setShippingFeeItemLine(ShippingFeeItemParameter shippingFeeItemLine) {
		this.shippingFeeItemLine = shippingFeeItemLine;
	}

	public OrderShippingLine getOrderShippingLine() {
		return orderShippingLine;
	}

	public void setOrderShippingLine(OrderShippingLine orderShippingLine) {
		this.orderShippingLine = orderShippingLine;
	}

}
