package com.walmart.mobile.checkout.bo.order;

/**
 * @author lliao2
 */
public class ExitRuleParameter {
	private String orderId;
	private Long productId;
	private String userId;

	// 人规则属性
	/**
	 * 黑名单
	 */
	private Integer blackFlag;
	/**
	 * 月均交易数量
	 */
	private Integer monthlyAverageTransactionNumber;

	/**
	 * 月均交易价格
	 */
	private double monthlyAverageTransactionAmount;

	/**
	 * 本次交易金额
	 */
	private double orderAmount;

	// 交易规则属性
	/**
	 * 空扫码、定位错误、重复扫码
	 */
	private Integer emptyOrRepeatScanFlag;
	/**
	 * 扫码和支付时间间隔
	 */
	private Integer timeBetweenScanAndPaid;
	/**
	 * 本次交易商品数
	 */
	private Integer orderQuantity;
	/**
	 * 平均单价
	 */
	private double averageAmount;
	/**
	 * 本次交易塑料袋数量
	 */
	private Integer packageBagNumber;
	/**
	 * 本次交易其他商品数量
	 */
	private Integer otherItemNumber;

	// 物规则属性
	/**
	 * 随机抽查
	 */
	private Integer randomNumber;
	/**
	 * 复合条码
	 */
	private Integer unitFlag;

	/**
	 * 商品部门 93 、05、15
	 */
	private String department;
	/**
	 * 商品金额
	 */
	private double itemAmount;

	/**
	 * 消磁商品
	 */
	private Integer magneticFlag;

	public Integer getMagneticFlag() {
		return magneticFlag == null ? 0 : magneticFlag;
	}

	public void setMagneticFlag(Integer magneticFlag) {
		this.magneticFlag = magneticFlag;
	}

	public Integer getMonthlyAverageTransactionNumber() {
		return monthlyAverageTransactionNumber == null ? 0 : monthlyAverageTransactionNumber;
	}

	public void setMonthlyAverageTransactionNumber(Integer monthlyAverageTransactionNumber) {
		this.monthlyAverageTransactionNumber = monthlyAverageTransactionNumber;
	}

	public Integer getEmptyOrRepeatScanFlag() {
		return emptyOrRepeatScanFlag == null ? 0 : emptyOrRepeatScanFlag;
	}

	public void setEmptyOrRepeatScanFlag(Integer emptyOrRepeatScanFlag) {
		this.emptyOrRepeatScanFlag = emptyOrRepeatScanFlag;
	}

	public Integer getTimeBetweenScanAndPaid() {
		return timeBetweenScanAndPaid == null ? 0 : timeBetweenScanAndPaid;
	}

	public void setTimeBetweenScanAndPaid(Integer timeBetweenScanAndPaid) {
		this.timeBetweenScanAndPaid = timeBetweenScanAndPaid;
	}

	public Integer getOrderQuantity() {
		return orderQuantity == null ? 0 : orderQuantity;
	}

	public void setOrderQuantity(Integer orderQuantity) {
		this.orderQuantity = orderQuantity;
	}

	public Integer getPackageBagNumber() {
		return packageBagNumber == null ? 0 : packageBagNumber;
	}

	public void setPackageBagNumber(Integer packageBagNumber) {
		this.packageBagNumber = packageBagNumber;
	}

	public Integer getOtherItemNumber() {
		return otherItemNumber;
	}

	public void setOtherItemNumber(Integer otherItemNumber) {
		this.otherItemNumber = otherItemNumber;
	}

	public Integer getRandomNumber() {
		return randomNumber;
	}

	public void setRandomNumber(Integer randomNumber) {
		this.randomNumber = randomNumber;
	}

	public Integer getBlackFlag() {
		return blackFlag == null ? 0 : blackFlag;
	}

	public void setBlackFlag(Integer blackFlag) {
		this.blackFlag = blackFlag;
	}

	public double getMonthlyAverageTransactionAmount() {
		return monthlyAverageTransactionAmount;
	}

	public void setMonthlyAverageTransactionAmount(double monthlyAverageTransactionAmount) {
		this.monthlyAverageTransactionAmount = monthlyAverageTransactionAmount;
	}

	public double getOrderAmount() {
		return orderAmount;
	}

	public void setOrderAmount(double orderAmount) {
		this.orderAmount = orderAmount;
	}

	public double getAverageAmount() {
		return averageAmount;
	}

	public void setAverageAmount(double averageAmount) {
		this.averageAmount = averageAmount;
	}

	public Integer getUnitFlag() {
		return unitFlag == null ? 0 : unitFlag;
	}

	public void setUnitFlag(Integer unitFlag) {
		this.unitFlag = unitFlag;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public double getItemAmount() {
		return itemAmount;
	}

	public void setItemAmount(double itemAmount) {
		this.itemAmount = itemAmount;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}
