package com.walmart.mobile.checkout.rest.vo;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * 多gp计算
 * 
 * @author lliao2
 *
 */
public class CalcDiscountResultVo {

	private BigDecimal totalDiscount;
	private boolean itemLevelDisocuntCompareFlag;
	private Map<Integer, Integer> gpOfferIdMinTimesMap;

	public CalcDiscountResultVo() {
		totalDiscount = BigDecimal.ZERO;
		itemLevelDisocuntCompareFlag = true;
		gpOfferIdMinTimesMap = new HashMap<>();
	}

	public boolean isItemLevelDisocuntCompareFlag() {
		return itemLevelDisocuntCompareFlag;
	}

	public void setItemLevelDisocuntCompareFlag(boolean itemLevelDisocuntCompareFlag) {
		this.itemLevelDisocuntCompareFlag = itemLevelDisocuntCompareFlag;
	}

	public BigDecimal getTotalDiscount() {
		return totalDiscount;
	}

	public void setTotalDiscount(BigDecimal totalDiscount) {
		this.totalDiscount = totalDiscount;
	}

	public Map<Integer, Integer> getGpOfferIdMinTimesMap() {
		return gpOfferIdMinTimesMap;
	}

	public void setGpOfferIdMinTimesMap(Map<Integer, Integer> gpOfferIdMinTimesMap) {
		this.gpOfferIdMinTimesMap = gpOfferIdMinTimesMap;
	}

}
