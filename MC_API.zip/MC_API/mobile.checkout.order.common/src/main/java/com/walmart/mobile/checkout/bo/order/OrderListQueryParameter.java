package com.walmart.mobile.checkout.bo.order;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "查询订单列表参数模型")
public class OrderListQueryParameter {
	/* 客户端参数开始 */
	@ApiModelProperty(value = "开始数", required = true)
	private int start;
	@ApiModelProperty(value = "行数", required = true)
	private int row;
	public int getStart() {
		return start;
	}
	public void setStart(int start) {
		this.start = start;
	}
	public int getRow() {
		return row;
	}
	public void setRow(int row) {
		this.row = row;
	}



}
