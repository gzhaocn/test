package com.walmart.mobile.checkout.constant.order;

public class InvoiceCons {
	
	
	public static final String NEED_REPLACE_APPLYKEY = "#####@@@#####";

	public static final int EGIFTCARD = 4;

	// 电子个人发票 Electronic personal invoice
	public static final int ELECTRONIC_PERSONAL_INVOICE = 3;

	// 电子单位发票
	public static final int ELECTRONIC_UNIT_INVOICE = 4;

	// 线下已开纸质发票
	public static final String INVOICE_OPENED = "-1";
	
	
	public static final String TC_NUMBER_NULL = "#TC_NUMBER#";
	
	
	private InvoiceCons(){}

}
