package com.walmart.mobile.checkout.bo.order;

import java.math.BigDecimal;
import java.util.Date;

public class ScanRefundBo {

	private String requestNumber;

	private String orderId;

	private Long upc;

	private Integer requestQuantity;

	private String descOnline;

	private String thumbnailUrl;

	private BigDecimal returnAmount;

	private BigDecimal priceWithTax;

	private Integer itemType;

	private BigDecimal itemAmount;

	private Byte returnReason;

	private Date requestTime;

	private Byte refundStatus;

	private String batchNo;

	private Long cartItemId;
	/**
	 * 是否延保商品
	 */
	private Integer ewsFlag;

	private String ewsRequestNumber;
	private BigDecimal wasPrice;

	public String getEwsRequestNumber() {
		return ewsRequestNumber;
	}

	public void setEwsRequestNumber(String ewsRequestNumber) {
		this.ewsRequestNumber = ewsRequestNumber;
	}

	public Integer getItemType() {
		return itemType;
	}

	public void setItemType(Integer itemType) {
		this.itemType = itemType;
	}

	public BigDecimal getItemAmount() {
		return itemAmount;
	}

	public void setItemAmount(BigDecimal itemAmount) {
		this.itemAmount = itemAmount;
	}

	public BigDecimal getPriceWithTax() {
		return priceWithTax;
	}

	public void setPriceWithTax(BigDecimal priceWithTax) {
		this.priceWithTax = priceWithTax;
	}

	public Long getCartItemId() {
		return cartItemId;
	}

	public void setCartItemId(Long cartItemId) {
		this.cartItemId = cartItemId;
	}

	public Integer getEwsFlag() {
		return ewsFlag;
	}

	public void setEwsFlag(Integer ewsFlag) {
		this.ewsFlag = ewsFlag;
	}

	public String getDescOnline() {
		return descOnline;
	}

	public void setDescOnline(String descOnline) {
		this.descOnline = descOnline;
	}

	public String getThumbnailUrl() {
		return thumbnailUrl;
	}

	public void setThumbnailUrl(String thumbnailUrl) {
		this.thumbnailUrl = thumbnailUrl;
	}

	public String getRequestNumber() {

		return requestNumber;
	}

	public void setRequestNumber(String requestNumber) {
		this.requestNumber = requestNumber;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public Long getUpc() {
		return upc;
	}

	public void setUpc(Long upc) {
		this.upc = upc;
	}

	public Integer getRequestQuantity() {
		return requestQuantity;
	}

	public void setRequestQuantity(Integer requestQuantity) {
		this.requestQuantity = requestQuantity;
	}

	public BigDecimal getReturnAmount() {
		return returnAmount;
	}

	public void setReturnAmount(BigDecimal returnAmount) {
		this.returnAmount = returnAmount;
	}

	public Byte getReturnReason() {
		return returnReason;
	}

	public void setReturnReason(Byte returnReason) {
		this.returnReason = returnReason;
	}

	public Date getRequestTime() {
		return requestTime;
	}

	public void setRequestTime(Date requestTime) {
		this.requestTime = requestTime;
	}

	public Byte getRefundStatus() {
		return refundStatus;
	}

	public void setRefundStatus(Byte refundStatus) {
		this.refundStatus = refundStatus;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public BigDecimal getWasPrice() {
		return wasPrice;
	}

	public void setWasPrice(BigDecimal wasPrice) {
		this.wasPrice = wasPrice;
	}

}
