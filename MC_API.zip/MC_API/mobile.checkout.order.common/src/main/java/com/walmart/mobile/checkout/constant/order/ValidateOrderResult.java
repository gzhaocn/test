package com.walmart.mobile.checkout.constant.order;


public class ValidateOrderResult {
	/**
	 * Not Sold
	 */
	public static final int NOTSOLD = 1;
	/**
	 * inventory shortage
	 */
	public static final int INVENTORY_SHORTAGE = 2;
	/**
	 * price change
	 */
	public static final int PRICE_CHANGE = 3;
	/**
	 * /offer change
	 */
	public static final int OFFER_CHANGE = 4;

	/**
	 * purchasing limit
	 */
	public static final int PURCHASING_LIMIT = 5;
	/**
	 * 称重商品价格与条码不一致
	 */
	public static final int BARCODE_AMOUNT_CHANGE = 6;
	/**
	 * 数量限制
	 */
	public static final int OVER_RESTRICTIONQTY = 7;
	private ValidateOrderResult(){}

}
