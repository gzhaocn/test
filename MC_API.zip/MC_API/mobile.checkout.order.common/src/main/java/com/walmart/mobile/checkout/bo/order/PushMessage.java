package com.walmart.mobile.checkout.bo.order;

import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.annotation.JSONField;

public class PushMessage {
	private List<String> userIds;
	
	@JSONField(name="hello")
	private Map<String,Object> content;
	
	private String broadcast;
	private String condition;
	
	public String getBroadcast() {
		return broadcast;
	}
	public void setBroadcast(String broadcast) {
		this.broadcast = broadcast;
	}
	public String getCondition() {
		return condition;
	}
	public void setCondition(String condition) {
		this.condition = condition;
	}
	public List<String> getUserIds() {
		return userIds;
	}
	public void setUserIds(List<String> userIds) {
		this.userIds = userIds;
	}
	public Map<String, Object> getContent() {
		return content;
	}
	public void setContent(Map<String, Object> content) {
		this.content = content;
	}

}
