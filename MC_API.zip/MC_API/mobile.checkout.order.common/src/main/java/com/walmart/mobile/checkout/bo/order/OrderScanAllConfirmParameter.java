package com.walmart.mobile.checkout.bo.order;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * 出场二维码扫码参数
 * 
 * @author lliao2
 *
 */
@ApiModel(description = "出场二维码全部通过扫码参数模型")
public class OrderScanAllConfirmParameter {
	@ApiModelProperty(value = "订单ID列表", required = true)
	private List<String> orderIds;
	@ApiModelProperty(value = "用户ID", required = true)
	private String userId;
	@ApiModelProperty(value = "通过原因", required = false)
	private Integer cancelReason;
	@ApiModelProperty(value = "通过文字描述", required = false)
	private String cancelRemark;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public List<String> getOrderIds() {
		return orderIds;
	}

	public void setOrderIds(List<String> orderIds) {
		this.orderIds = orderIds;
	}

	public Integer getCancelReason() {
		return cancelReason;
	}

	public void setCancelReason(Integer cancelReason) {
		this.cancelReason = cancelReason;
	}

	public String getCancelRemark() {
		return cancelRemark;
	}

	public void setCancelRemark(String cancelRemark) {
		this.cancelRemark = cancelRemark;
	}
}
