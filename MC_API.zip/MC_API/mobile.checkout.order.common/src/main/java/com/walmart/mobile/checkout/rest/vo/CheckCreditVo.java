package com.walmart.mobile.checkout.rest.vo;

import java.math.BigDecimal;

import com.walmart.mobile.checkout.bo.order.DeliveryOrder;

public class CheckCreditVo {

	private Integer checkFlag;
	private String userName;
	private Integer magneticFlag;
	private Integer specialItemFlag;
	private Integer blackFlag;
	/**
	 * 交易次数
	 */
	private Integer transCount;
	/**
	 * 平均金额
	 */
	private BigDecimal avgAmount;

	private DeliveryOrder deliveryOrder;
	/**
	 * 空订单 标志 ，1为没有已支付订单
	 */
	private Integer nullOrderFlag;

	public CheckCreditVo() {
		// 构造函数
	}

	public CheckCreditVo(Integer checkFlag, String userName) {
		this.checkFlag = checkFlag;
		this.userName = userName;
	}

	public Integer getCheckFlag() {
		return checkFlag;
	}

	public void setCheckFlag(Integer checkFlag) {
		this.checkFlag = checkFlag;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Integer getMagneticFlag() {
		return magneticFlag == null ? 0 : magneticFlag;
	}

	public void setMagneticFlag(Integer magneticFlag) {
		this.magneticFlag = magneticFlag;
	}

	public Integer getSpecialItemFlag() {
		return specialItemFlag;
	}

	public void setSpecialItemFlag(Integer specialItemFlag) {
		this.specialItemFlag = specialItemFlag;
	}

	public DeliveryOrder getDeliveryOrder() {
		return deliveryOrder;
	}

	public void setDeliveryOrder(DeliveryOrder deliveryOrder) {
		this.deliveryOrder = deliveryOrder;
	}

	public Integer getNullOrderFlag() {
		return nullOrderFlag == null ? 0 : 1;
	}

	public void setNullOrderFlag(Integer nullOrderFlag) {
		this.nullOrderFlag = nullOrderFlag;
	}

	public Integer getTransCount() {
		return transCount;
	}

	public void setTransCount(Integer transCount) {
		this.transCount = transCount;
	}

	public BigDecimal getAvgAmount() {
		return avgAmount;
	}

	public void setAvgAmount(BigDecimal avgAmount) {
		this.avgAmount = avgAmount;
	}

	public Integer getBlackFlag() {
		return blackFlag;
	}

	public void setBlackFlag(Integer blackFlag) {
		this.blackFlag = blackFlag;
	}

}
