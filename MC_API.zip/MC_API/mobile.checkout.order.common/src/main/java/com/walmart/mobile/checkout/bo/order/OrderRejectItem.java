package com.walmart.mobile.checkout.bo.order;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;
@ApiModel(description = "订单退货参数模型")
	
public class OrderRejectItem {
	@ApiModelProperty(value = "订单ID", required = true)
	private String orderId;
	
	
	@ApiModelProperty(value = "退货商品详情", required = true)
	private List<OrderRejectItemParameter> orderRejectItemParameterList;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public List<OrderRejectItemParameter> getOrderRejectItemParameterList() {
		return orderRejectItemParameterList;
	}

	public void setOrderRejectItemParameterList(List<OrderRejectItemParameter> orderRejectItemParameterList) {
		this.orderRejectItemParameterList = orderRejectItemParameterList;
	}

}
