package com.walmart.mobile.checkout.constant.order;

public class ItemType {
	/**
	 * 称重商品
	 */
	public static final int WEGITH_ITEM = 1; 
	/**
	 * 非称重商品
	 */
	public static final int NO_WEGITH_ITEM = 0; 
	
	private ItemType(){}

}
