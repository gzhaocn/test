package com.walmart.mobile.checkout.rest.vo;

import java.math.BigInteger;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.walmart.mobile.checkout.entity.document.BaseDocument;

@Document(collection = "product_detail")
public class ProductDetailVo extends BaseDocument<BigInteger> implements Comparable<ProductDetailVo> {
	private static final long serialVersionUID = 1L;

	public static final int PRODUCT_STATUS_ACTIVE = 0;

	private Long upc;
	@Field("desc_online")
	private String descOnline;

	@Field("thumbnail_url")
	private String thumbnailUrl;

	@Field("sales_qty")
	private Integer salesQty;
	@Field("sales_amt")
	private Integer salesAmt;
	@Field("product_flag")
	private List<Integer> productFlag;

	@Field("status")
	private Integer status;
	@Field("brand_name")
	private String brandName;
	@Field("item_type")
	private Integer itemType;
	@Field("department_wm_internal")
	private Integer departmentWmInternal;

	@Field("item_number")
	private Long itemNumber;

	public ProductDetailVo() {
		// 构造函数
	}

	public ProductDetailVo(BigInteger id) {
		setId(id);
	}

	public String getDescOnline() {
		return descOnline;
	}

	public Integer getSalesQty() {
		return salesQty;
	}

	public List<Integer> getProductFlag() {
		return productFlag;
	}

	public void setDescOnline(String descOnline) {
		this.descOnline = descOnline;
	}

	public void setThumbnailUrl(String thumbnailUrl) {
		this.thumbnailUrl = thumbnailUrl;
	}

	public String getThumbnailUrl() {
		return thumbnailUrl;
	}

	public void setSalesQty(Integer salesQty) {
		this.salesQty = salesQty;
	}

	public void setProductFlag(List<Integer> productFlag) {
		this.productFlag = productFlag;
	}

	public Long getUpc() {
		return upc;
	}

	public void setUpc(Long upc) {
		this.upc = upc;
	}

	public Integer getStatus() {
		return status == null ? 0 : status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public Integer getSalesAmt() {
		return salesAmt;
	}

	public void setSalesAmt(Integer salesAmt) {
		this.salesAmt = salesAmt;
	}

	@Override
	public int compareTo(ProductDetailVo o) {
		if (o == null) {
			return -1;
		}
		return this.upc.compareTo(o.upc);
	}

	public Integer getItemType() {
		return itemType;
	}

	public void setItemType(Integer itemType) {
		this.itemType = itemType;
	}

	@Override
	public int hashCode() {
		return this.getItemNumber() == null ? 0 : this.getItemNumber().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (!(obj instanceof ProductDetailVo)) {
			return false;
		}
		ProductDetailVo other = (ProductDetailVo) obj;
		return this.getItemNumber().equals(other.getItemNumber());
	}

	/**
	 * @return the departmentWmInternal
	 */
	public Integer getDepartmentWmInternal() {
		return departmentWmInternal;
	}

	/**
	 * @param departmentWmInternal
	 *            the departmentWmInternal to set
	 */
	public void setDepartmentWmInternal(Integer departmentWmInternal) {
		this.departmentWmInternal = departmentWmInternal;
	}

	public Long getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(Long itemNumber) {
		this.itemNumber = itemNumber;
	}

}