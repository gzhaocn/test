package com.walmart.mobile.checkout.bo.order;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.util.Date;

@ApiModel(description = "配送参数模型")
public class DeliveryParameter {

	@ApiModelProperty(value = "收货人")
	private String deliveryName;
	@ApiModelProperty(value = "省份")
	private String province;
	@ApiModelProperty(value = "城市")
	private String city;
	@ApiModelProperty(value = "区域")
	private String district;
	@ApiModelProperty(value = "地址")
	private String address;
	@ApiModelProperty(value = "送货时段描述", required = false)
	private String deliveryPeriodDesc;
	@ApiModelProperty(value = "收货人电话")
	private String deliveryPhone;
	@ApiModelProperty(value = "配送方式(1到店自提2送货上门)")
	private int deliveryMethod;
	@ApiModelProperty(value = "送货时段", required = false)
	private int deliveryPeriod;
	@ApiModelProperty(value = "送货时间", required = false)
	private Date deliveryDate;
	@ApiModelProperty(value = "经度")
	private Double longitude;
	@ApiModelProperty(value = "纬度")
	private Double latitude;
	@ApiModelProperty(value = "邮政编码", required = false)
	private String zipcode;
	@ApiModelProperty(value = "备注", required = false)
	private String deliveryInstruction;

	@ApiModelProperty(value = "运费", hidden = true)
	private BigDecimal shippingFee;
	@ApiModelProperty(value = "门店号", hidden = true)
	private Integer storeId;

	@ApiModelProperty(value = "订单号", hidden = true)
	private String orderId;
	@ApiModelProperty(value = "用户Id", hidden = true)
	private String userId;

	public String getDeliveryName() {
		return deliveryName;
	}

	public void setDeliveryName(String deliveryName) {
		this.deliveryName = deliveryName;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDeliveryPeriodDesc() {
		return deliveryPeriodDesc;
	}

	public void setDeliveryPeriodDesc(String deliveryPeriodDesc) {
		this.deliveryPeriodDesc = deliveryPeriodDesc;
	}

	public String getDeliveryPhone() {
		return deliveryPhone;
	}

	public void setDeliveryPhone(String deliveryPhone) {
		this.deliveryPhone = deliveryPhone;
	}

	public int getDeliveryMethod() {
		return deliveryMethod;
	}

	public void setDeliveryMethod(int deliveryMethod) {
		this.deliveryMethod = deliveryMethod;
	}

	public int getDeliveryPeriod() {
		return deliveryPeriod;
	}

	public void setDeliveryPeriod(int deliveryPeriod) {
		this.deliveryPeriod = deliveryPeriod;
	}

	public Date getDeliveryDate() {
		return deliveryDate;
	}

	public void setDeliveryDate(Date deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getDeliveryInstruction() {
		return deliveryInstruction;
	}

	public void setDeliveryInstruction(String deliveryInstruction) {
		this.deliveryInstruction = deliveryInstruction;
	}

	public BigDecimal getShippingFee() {
		return shippingFee;
	}

	public void setShippingFee(BigDecimal shippingFee) {
		this.shippingFee = shippingFee;
	}

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}
