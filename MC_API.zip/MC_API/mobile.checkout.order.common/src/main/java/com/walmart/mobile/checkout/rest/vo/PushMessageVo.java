package com.walmart.mobile.checkout.rest.vo;

import java.util.Map;

import com.alibaba.fastjson.annotation.JSONField;

public class PushMessageVo {
	
	private String userId;
	
	@JSONField(name="hello")
	private Map<String,Object> content;
	
	private String broadcast;
	private String condition;
	
	public String getBroadcast() {
		return broadcast;
	}
	public void setBroadcast(String broadcast) {
		this.broadcast = broadcast;
	}
	public String getCondition() {
		return condition;
	}
	public void setCondition(String condition) {
		this.condition = condition;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Map<String, Object> getContent() {
		return content;
	}
	public void setContent(Map<String, Object> content) {
		this.content = content;
	}

}
