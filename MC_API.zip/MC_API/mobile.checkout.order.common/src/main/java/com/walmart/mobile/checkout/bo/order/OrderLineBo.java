package com.walmart.mobile.checkout.bo.order;

import java.util.Collections;
import java.util.List;

import com.walmart.mobile.checkout.domain.order.OrderDiscount;
import com.walmart.mobile.checkout.domain.order.OrderEws;
import com.walmart.mobile.checkout.domain.order.OrderLine;
import com.walmart.mobile.checkout.domain.order.OrderRefund;

/**
 * 查询订单详情BO
 * 
 * @author lliao2
 *
 */
public class OrderLineBo extends OrderLine {

	private List<OrderDiscount> orderDiscountList;

	private List<OrderRefund> orderRefundList;

	private OrderEws orderEws;

	public OrderLineBo() {
		// 构造函数
	}

	public List<OrderDiscount> getOrderDiscountList() {
		return orderDiscountList == null ? Collections.emptyList() : orderDiscountList;
	}

	public void setOrderDiscountList(List<OrderDiscount> orderDiscountList) {
		this.orderDiscountList = orderDiscountList;
	}

	public OrderEws getOrderEws() {
		return orderEws;
	}

	public void setOrderEws(OrderEws orderEws) {
		this.orderEws = orderEws;
	}

	public List<OrderRefund> getOrderRefundList() {
		return orderRefundList;
	}

	public void setOrderRefundList(List<OrderRefund> orderRefundList) {
		this.orderRefundList = orderRefundList;
	}
}
