package com.walmart.mobile.checkout.constant.order;

public class OrderCons {
	public static final int EGIFTCARD = 4;
	public static final String NEED_REPLACE_APPLYKEY = "#####@@@#####";
	/**
	 * 门店是否支持电子发票（1、支持）
	 */
	public static final int SUPPORT_EINVOICE_FLAG = 1;
	/**
	 * 加密用append字符
	 */
	public static final String APPSECUERT = "mobileCK";
	
	/**
	 * 是否选择了延保商品(1、已选择 0、未选择)
	 */
	public static final int EWS_ITEM_SELECTED = 1;
	public static final int EWS_ITEM_NOT_SELECTED = 0;
	
	/**
	 * 扫描推送成功次数
	 */
	public static final String COUNT ="1";
	/**
	 * 订单类型 1、mobileCK 2、H5
	 */
	public static final int MCK_ORDER_TYPE = 1;
	public static final int H5_ORDER_TYPE = 2;
	/**
	 * 支付类型
	 */
	public static final int WECHAT_PAY_TYPE = 2;
	
	public static final int EGIFTCARD_PAY_TYPE = 4;
	
	
	private OrderCons(){}

}
