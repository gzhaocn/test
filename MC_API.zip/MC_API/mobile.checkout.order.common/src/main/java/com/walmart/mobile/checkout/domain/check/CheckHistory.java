package com.walmart.mobile.checkout.domain.check;

import java.util.Date;

import org.apache.commons.lang3.StringUtils;

public class CheckHistory {
	private String checkId;

	private String userId;

	private String screenFlag;

	private String subScreenFlag;

	private String orderId;

	private Long productId;

	private String batchNo;
	private Date createTime;

	public String getCheckId() {
		return checkId;
	}

	public void setCheckId(String checkId) {
		this.checkId = checkId == null ? null : checkId.trim();
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId == null ? null : userId.trim();
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId == null ? null : orderId.trim();
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getScreenFlag() {
		return StringUtils.isNotEmpty(screenFlag) ? screenFlag.trim() : screenFlag;
	}

	public void setScreenFlag(String screenFlag) {
		this.screenFlag = screenFlag;
	}

	public String getSubScreenFlag() {
		return subScreenFlag;
	}

	public void setSubScreenFlag(String subScreenFlag) {
		this.subScreenFlag = subScreenFlag;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}
}