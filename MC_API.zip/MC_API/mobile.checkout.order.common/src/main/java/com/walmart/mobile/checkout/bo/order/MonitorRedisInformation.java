package com.walmart.mobile.checkout.bo.order;

import java.util.List;

public class MonitorRedisInformation {
	private Integer storeId;
	private String userId;
	private String orderId;
	private String dagId;
	/**
	 * 通道号
	 */
	private String sequenceNumber;
	private List<MonitorOrderAmount> monitorOrderAmountList;
	/**
	 * monitor给出的扫码序列号
	 */
	private String seqId;

	private String screenFlag;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getDagId() {
		return dagId;
	}

	public void setDagId(String dagId) {
		this.dagId = dagId;
	}

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public String getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(String sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public List<MonitorOrderAmount> getMonitorOrderAmountList() {
		return monitorOrderAmountList;
	}

	public void setMonitorOrderAmountList(List<MonitorOrderAmount> monitorOrderAmountList) {
		this.monitorOrderAmountList = monitorOrderAmountList;
	}

	public String getSeqId() {
		return seqId;
	}

	public void setSeqId(String seqId) {
		this.seqId = seqId;
	}

	public String getScreenFlag() {
		return screenFlag;
	}

	public void setScreenFlag(String screenFlag) {
		this.screenFlag = screenFlag;
	}

}
