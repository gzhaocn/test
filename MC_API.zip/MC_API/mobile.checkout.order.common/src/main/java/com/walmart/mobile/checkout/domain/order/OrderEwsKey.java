package com.walmart.mobile.checkout.domain.order;


public class OrderEwsKey {
    private String orderId;

    private Long productId;

    private Long cartItemId;

    private Long ewsItemNumber;

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId == null ? null : orderId.trim();
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public Long getCartItemId() {
        return cartItemId;
    }

    public void setCartItemId(Long cartItemId) {
        this.cartItemId = cartItemId;
    }

    public Long getEwsItemNumber() {
        return ewsItemNumber;
    }

    public void setEwsItemNumber(Long ewsItemNumber) {
        this.ewsItemNumber = ewsItemNumber;
    }
}