package com.walmart.mobile.checkout.bo.order;

public class DeliveryOrder {

	private Integer storeId;
	private String orderId;
	private Integer deliveryFlag;

	public DeliveryOrder(Integer storeId, String orderId, Integer deliveryFlag) {
		this.storeId = storeId;
		this.orderId = orderId;
		this.deliveryFlag = deliveryFlag;
	}

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public Integer getDeliveryFlag() {
		return deliveryFlag;
	}

	public void setDeliveryFlag(Integer deliveryFlag) {
		this.deliveryFlag = deliveryFlag;
	}

}
