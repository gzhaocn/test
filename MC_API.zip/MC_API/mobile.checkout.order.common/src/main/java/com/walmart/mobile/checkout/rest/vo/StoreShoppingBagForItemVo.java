package com.walmart.mobile.checkout.rest.vo;

public class StoreShoppingBagForItemVo{

	/**
	 * 
	 */

	private Long upc;
	private Integer storeId;
	private String descOnline;
	private Long itemNumber;

	public Integer getStoreId() {
		return storeId;
	}
	
	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}
	
	public String getDescOnline() {
		return this.descOnline;
	}
	
	public void setDescOnline(String descOnline) {
		this.descOnline = descOnline;
	}

	public Long getUpc() {
		return upc;
	}

	public void setUpc(Long upc) {
		this.upc = upc;
	}

	public Long getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(Long itemNumber) {
		this.itemNumber = itemNumber;
	}
	
}
