package com.walmart.mobile.checkout.bo.order;

import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.walmart.mobile.checkout.domain.check.CheckHistory;
import com.walmart.mobile.checkout.rest.vo.CheckCreditVo;

public class OrderExit {

	private List<OrderBo> orderBoList;
	@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
	private Integer checkFlag;
	@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
	private String userName;
	private CheckCreditVo checkCreditVo;
	private List<CheckHistory> checkHistoryList;

	public OrderExit(List<OrderBo> orderBoList, Integer checkFlag, String userName, CheckCreditVo checkCreditVo) {
		this.orderBoList = orderBoList;
		this.checkFlag = checkFlag;
		this.userName = userName;
		this.checkCreditVo = checkCreditVo;
	}

	public OrderExit(List<OrderBo> orderBoList, CheckCreditVo checkCreditVo) {
		this.orderBoList = orderBoList;
		this.checkCreditVo = checkCreditVo;
	}

	public List<OrderBo> getOrderBoList() {
		return orderBoList;
	}

	public void setOrderBoList(List<OrderBo> orderBoList) {
		this.orderBoList = orderBoList;
	}

	public Integer getCheckFlag() {
		return checkFlag;
	}

	public void setCheckFlag(Integer checkFlag) {
		this.checkFlag = checkFlag;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public CheckCreditVo getCheckCreditVo() {
		return checkCreditVo;
	}

	public void setCheckCreditVo(CheckCreditVo checkCreditVo) {
		this.checkCreditVo = checkCreditVo;
	}

	public List<CheckHistory> getCheckHistoryList() {
		return checkHistoryList;
	}

	public void setCheckHistoryList(List<CheckHistory> checkHistoryList) {
		this.checkHistoryList = checkHistoryList;
	}

}
