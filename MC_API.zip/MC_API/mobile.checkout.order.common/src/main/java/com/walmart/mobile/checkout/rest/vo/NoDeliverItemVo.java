package com.walmart.mobile.checkout.rest.vo;


public class NoDeliverItemVo {
	private Long upc;

	public Long getUpc() {
		return upc;
	}

	public void setUpc(Long upc) {
		this.upc = upc;
	}

}
