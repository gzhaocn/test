package com.walmart.mobile.checkout.bo.order;

/**
 * @author lliao2
 */
public class ExitCheckResult {

	private boolean postCodeResult = false; // true:通过校验；false：未通过校验
	private String ruleName;
	private String screenFlag;
	private String orderId;
	private Long productId;
	private String userId;

	public String getScreenFlag() {
		return screenFlag;
	}

	public void setScreenFlag(String screenFlag) {
		this.screenFlag = screenFlag;
	}

	public boolean isPostCodeResult() {
		return postCodeResult;
	}

	public void setPostCodeResult(boolean postCodeResult) {
		this.postCodeResult = postCodeResult;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}
}
