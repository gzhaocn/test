package com.walmart.mobile.checkout.bo.order;

import java.util.List;

import com.walmart.mobile.checkout.domain.order.Order;

public class OrderBo extends Order {

	private List<OrderLineBo> orderLineBoList;

	public List<OrderLineBo> getOrderLineBoList() {
		return orderLineBoList;
	}

	public void setOrderLineBoList(List<OrderLineBo> orderLineBoList) {
		this.orderLineBoList = orderLineBoList;
	}
}
