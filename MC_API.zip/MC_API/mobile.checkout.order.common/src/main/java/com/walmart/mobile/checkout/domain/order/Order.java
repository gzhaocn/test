package com.walmart.mobile.checkout.domain.order;

import java.math.BigDecimal;
import java.util.Date;

import com.walmart.mobile.checkout.bo.order.OrderParameter;
import com.walmart.mobile.checkout.constant.order.OrderStatus;

public class Order {

	private String orderId;
	private String userId;
	private Integer storeId;
	private String shortNameCn;
	private int status;
	private BigDecimal amount;
	private BigDecimal totalGpDiscount;
	private BigDecimal voucherDiscount;

	private BigDecimal shippingFee;
	private BigDecimal packagingFee;
	private String invoiceTitle;
	private int invoiceType;
	private String invoicePdfUrl;
	private String tcNumber;
	private Integer tcSequenceNumber;
	private Integer tcRegisterNumber;
	private Date tcTransTime;
	private Integer cancelReason;
	private String cancelRemark;
	private Date createdTime;
	private int payType;
	private Date paidTime;
	private Date completedTime;
	private Integer version;
	private Integer itemSize;
	private Integer orderType; // 1:mobileCK,2:h5
	private String mobilePhone;// 发票需要
	private String taxCode;
	private String invoiceNo;
	private String invoiceCode;
	private String reverseInvoiceUrl;
	private BigDecimal paymentCouponFee;

	private Date scanTime;
	/**
	 * 订单是否有消磁商品
	 */
	private Integer magneticFlag;
	private String invoiceEmail;
	private Integer deliveryFlag;
	private String sequenceNumber;

	public Order() {
		this.version = 0;
	}

	public Order(OrderParameter orderParam, String orderId) {

		this.orderId = orderId;
		this.status = OrderStatus.UNPAID;
		this.userId = orderParam.getUserId();
		// fee
		this.amount = orderParam.getAmount();

		this.packagingFee = orderParam.getPackagingFee();
		this.shippingFee = orderParam.getShippingFee();
		// invoice
		this.invoiceTitle = orderParam.getInvoiceTitle();
		this.invoiceType = orderParam.getInvoiceType();
		// sale
		this.shortNameCn = orderParam.getShortNameCn();
		this.storeId = orderParam.getStoreId();
		this.totalGpDiscount = orderParam.getTotalGpDiscount();
		this.createdTime = new Date();

		this.version = 0;
		this.orderType = orderParam.getOrderType();
		this.mobilePhone = orderParam.getMobilePhone();
		this.taxCode = orderParam.getTaxCode();
		this.magneticFlag = orderParam.getMagneticFlag();
		this.invoiceEmail = orderParam.getInvoiceEmail();
		this.deliveryFlag = orderParam.getDeliveryFlag();

	}

	public BigDecimal calcGoodsAmount() {
		BigDecimal goodsAmount = this.getAmount();
		BigDecimal goodsShippingFee = this.getShippingFee() == null ? BigDecimal.ZERO : this.getShippingFee();
		BigDecimal goodsPackagingFee = this.getPackagingFee() == null ? BigDecimal.ZERO : this.getPackagingFee();
		goodsAmount = goodsAmount.subtract(goodsShippingFee).subtract(goodsPackagingFee);
		return goodsAmount;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getUserId() {
		return userId;
	}

	public Integer getItemSize() {
		return itemSize;
	}

	public void setItemSize(Integer itemSize) {
		if (this.itemSize != null) {
			this.itemSize += itemSize;
		} else {
			this.itemSize = itemSize;
		}
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public String getShortNameCn() {
		return shortNameCn;
	}

	public void setShortNameCn(String shortNameCn) {
		this.shortNameCn = shortNameCn;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public BigDecimal getTotalGpDiscount() {
		if (totalGpDiscount == null) {
			return BigDecimal.ZERO;
		}
		return totalGpDiscount;
	}

	public void setTotalGpDiscount(BigDecimal totalGpDiscount) {
		this.totalGpDiscount = totalGpDiscount;
	}

	public BigDecimal getVoucherDiscount() {
		if (voucherDiscount == null) {
			return BigDecimal.ZERO;
		}
		return voucherDiscount;
	}

	public void setVoucherDiscount(BigDecimal voucherDiscount) {
		this.voucherDiscount = voucherDiscount;
	}

	public BigDecimal getShippingFee() {
		return (shippingFee == null ? BigDecimal.ZERO : shippingFee).compareTo(BigDecimal.ZERO) <= 0 ? BigDecimal.ZERO : shippingFee;
	}

	public void setShippingFee(BigDecimal shippingFee) {
		this.shippingFee = shippingFee;
	}

	public BigDecimal getPackagingFee() {
		return BigDecimal.ZERO;
	}

	public void setPackagingFee(BigDecimal packagingFee) {
		this.packagingFee = packagingFee;
	}

	public String getInvoiceTitle() {
		return invoiceTitle;
	}

	public void setInvoiceTitle(String invoiceTitle) {
		this.invoiceTitle = invoiceTitle;
	}

	public int getInvoiceType() {
		return invoiceType;
	}

	public void setInvoiceType(int invoiceType) {
		this.invoiceType = invoiceType;
	}

	public String getInvoicePdfUrl() {
		return invoicePdfUrl;
	}

	public void setInvoicePdfUrl(String invoicePdfUrl) {
		this.invoicePdfUrl = invoicePdfUrl;
	}

	public String getTcNumber() {
		return tcNumber;
	}

	public void setTcNumber(String tcNumber) {
		this.tcNumber = tcNumber;
	}

	public Integer getTcSequenceNumber() {
		return tcSequenceNumber;
	}

	public void setTcSequenceNumber(Integer tcSequenceNumber) {
		this.tcSequenceNumber = tcSequenceNumber;
	}

	public Integer getTcRegisterNumber() {
		return tcRegisterNumber;
	}

	public void setTcRegisterNumber(Integer tcRegisterNumber) {
		this.tcRegisterNumber = tcRegisterNumber;
	}

	public Date getTcTransTime() {
		return tcTransTime;
	}

	public void setTcTransTime(Date tcTransTime) {
		this.tcTransTime = tcTransTime;
	}

	public Integer getCancelReason() {
		return cancelReason;
	}

	public void setCancelReason(Integer cancelReason) {
		this.cancelReason = cancelReason;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public int getPayType() {
		return payType;
	}

	public void setPayType(int payType) {
		this.payType = payType;
	}

	public Date getPaidTime() {
		return paidTime;
	}

	public void setPaidTime(Date paidTime) {
		this.paidTime = paidTime;
	}

	public Date getCompletedTime() {
		return completedTime;
	}

	public void setCompletedTime(Date completedTime) {
		this.completedTime = completedTime;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public boolean isTimeout() {
		return this.status == OrderStatus.TIMEOUT;
	}

	public Integer getOrderType() {
		return orderType;
	}

	public void setOrderType(Integer orderType) {
		this.orderType = orderType;
	}

	public String getMobilePhone() {
		return mobilePhone;
	}

	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}

	public String getTaxCode() {
		return taxCode;
	}

	public void setTaxCode(String taxCode) {
		this.taxCode = taxCode;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public String getInvoiceCode() {
		return invoiceCode;
	}

	public void setInvoiceCode(String invoiceCode) {
		this.invoiceCode = invoiceCode;
	}

	public String getReverseInvoiceUrl() {
		return reverseInvoiceUrl;
	}

	public void setReverseInvoiceUrl(String reverseInvoiceUrl) {
		this.reverseInvoiceUrl = reverseInvoiceUrl;
	}

	public BigDecimal getPaymentCouponFee() {
		return paymentCouponFee;
	}

	public void setPaymentCouponFee(BigDecimal paymentCouponFee) {
		this.paymentCouponFee = paymentCouponFee;
	}

	public Date getScanTime() {
		return scanTime;
	}

	public void setScanTime(Date scanTime) {
		this.scanTime = scanTime;
	}

	public String getCancelRemark() {
		return cancelRemark;
	}

	public void setCancelRemark(String cancelRemark) {
		this.cancelRemark = cancelRemark;
	}

	public Integer getMagneticFlag() {
		return magneticFlag == null ? 0 : magneticFlag;
	}

	public void setMagneticFlag(Integer magneticFlag) {
		this.magneticFlag = magneticFlag;
	}

	public String getInvoiceEmail() {
		return invoiceEmail;
	}

	public void setInvoiceEmail(String invoiceEmail) {
		this.invoiceEmail = invoiceEmail;
	}

	public Integer getDeliveryFlag() {
		return deliveryFlag;
	}

	public void setDeliveryFlag(Integer deliveryFlag) {
		this.deliveryFlag = deliveryFlag;
	}

	public String getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(String sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}
}
