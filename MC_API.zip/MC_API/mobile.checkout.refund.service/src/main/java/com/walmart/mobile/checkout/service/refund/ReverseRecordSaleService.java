package com.walmart.mobile.checkout.service.refund;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.walmart.mobile.checkout.bo.order.OrderBo;
import com.walmart.mobile.checkout.bo.order.OrderLineBo;
import com.walmart.mobile.checkout.bo.recordsale.RecordSaleOrder;
import com.walmart.mobile.checkout.bo.recordsale.RecordSaleOrderInfo;
import com.walmart.mobile.checkout.bo.recordsale.RecordSaleOrderLine;
import com.walmart.mobile.checkout.bo.recordsale.Tax;
import com.walmart.mobile.checkout.bo.recordsale.Weight;
import com.walmart.mobile.checkout.bo.refund.RefundBo;
import com.walmart.mobile.checkout.constant.recordsale.RecordSaleConstants;
import com.walmart.mobile.checkout.domain.refund.Refund;
import com.walmart.mobile.checkout.handler.send.RecordsaleSendHandler;

@Service
public class ReverseRecordSaleService {

	private static final Logger LOG = LoggerFactory.getLogger(ReverseRecordSaleService.class);
	
	private static final String TC_NUMBER_NULL = "#TC_NUMBER#";

	@Value("${recordsale.test}")
	String recordSaleStatus;
	
	@Value("${recordsale.test.store}")
	String recordSaleStore;
	
	
	@Autowired
	private RecordsaleSendHandler recordsaleSendHandler;

	public String sendReverseRecordSale(List<Refund> refundList, String orderSoruceType, OrderBo orderBo,Integer recordEvent) {

		List<OrderLineBo> orderLineBoList = orderBo.getOrderLineBoList();

		//KEY ="upc_cartItemId"
		Map<String, OrderLineBo> upcOrderLineMap =  getOrderLineMapByRateType(orderLineBoList);
		
		
		
	
		RecordSaleOrder rsOrder = new RecordSaleOrder();
		String batchNo = refundList.get(0).getBatchNo();
		String realOrderId = refundList.get(0).getOrderId();
		rsOrder.setOrderId(batchNo);
		rsOrder.setRealOrderId(realOrderId);
		rsOrder.setRecordEvent(recordEvent);
		RecordSaleOrderInfo orderInfo = getOrderInfo(orderSoruceType, batchNo, orderBo);
		Map<Integer, Tax> map = new HashMap<>(16);
		
		// 判断是否全退，还是部分退
		if (refundList.size() == 1 && (0L == refundList.get(0).getUpc())) {
			// 退款总金额
			BigDecimal	tempCount = refundList.get(0).getReturnAmount();
			LOG.info("total machine , batchNo:{} , orderStatus :{} , OrderId :{}",batchNo , recordEvent, realOrderId);
			orderInfo.setSaleAmount(tempCount);
			orderInfo.setTenderAmount(tempCount);
			setTotalMachine(map,rsOrder, orderLineBoList);

		} else {
			LOG.info("part machine, batchNo:{} , orderStatus :{} , OrderId :{}",batchNo , recordEvent, realOrderId);
			List<RefundBo> listRefund = getRefundMapByUpc(refundList, upcOrderLineMap,   orderInfo);
			setPartMachine(map ,rsOrder,  listRefund);

		}
		orderInfo.getTotalTax().addAll(map.values());
		rsOrder.setOrderInfo(orderInfo);
		
		String reverseData = JSON.toJSONString(rsOrder);
		if (reverseData != null && StringUtils.isNotBlank(orderBo.getTcNumber())) {
			recordsaleSendHandler.recordsaleSendMessage(reverseData);
		} else if (reverseData != null && StringUtils.isBlank(orderBo.getTcNumber())) {
			recordsaleSendHandler.recordsaleSendDelayMessage(reverseData);
		}

		return reverseData;
	}

	/**
	 * 设置orderInfo的信息
	 * 
	 * @param orderSoruceType
	 * @param batchNo
	 * @param orderBo
	 * @return
	 */
	private RecordSaleOrderInfo getOrderInfo(String orderSoruceType, String batchNo, OrderBo orderBo) {
		RecordSaleOrderInfo orderInfo = new RecordSaleOrderInfo();
		orderInfo.setOrderSource(orderSoruceType);
		orderInfo.setRsOrderType(RecordSaleConstants.MOBILE_CHECKOUT_REVERSE_ORDER);
		if ("1".equals(recordSaleStatus)) {
			orderInfo.setStoreNbr(Integer.parseInt(recordSaleStore));
		} else {
			orderInfo.setStoreNbr(orderBo.getStoreId());
		}
		orderInfo.setOrderId(batchNo);
		
		if(StringUtils.isEmpty(orderBo.getTcNumber())){
			orderInfo.setOriginalTransactionCode(TC_NUMBER_NULL);
		}else{
			orderInfo.setOriginalTransactionCode(orderBo.getTcNumber());	
		}
		
		
		return orderInfo;
	}

	/**
	 * 
	 * @param rsOrder
	 * @param taxRefundMap
	 * @param listRefund
	 * @param tempItemCountMap
	 * @param tempTaxMap
	 * @param tempCount
	 * @return
	 */
	private BigDecimal setPartMachine(Map<Integer, Tax> map, RecordSaleOrder rsOrder,
			List<RefundBo> listRefund) {

		 BigDecimal tempCount = BigDecimal.ZERO;
		
		for (RefundBo refundBo : listRefund) {
			RecordSaleOrderLine orderItem = new RecordSaleOrderLine();
			orderItem.setLineItemType(refundBo.getLineItemType());
			orderItem.setItemNbr(refundBo.getItemNbr());
			orderItem.setItemDesc(refundBo.getPosDescOnline());
			orderItem.setUpcNbr(refundBo.getRefund().getUpc() + "");
			orderItem.setReportCode(refundBo.getReportCode());
			orderItem.setDeptNbr(refundBo.getDeptNbr());
			orderItem.setQuantity(refundBo.getRefund().getReturnQuantity());
			orderItem.setBasePrice(refundBo.getPriceWithoutTax());
			Tax tax = new Tax();
			tax.setTaxType(RecordSaleConstants.getTaxType(refundBo.getTaxRate()));
            setRefundTaxAmount(tax, refundBo, map);
			

			if (RecordSaleConstants.PRODUCT_TYPE_WEIGHT == refundBo.getLineItemType()) {
				Weight weight = new Weight();
				weight.setUom(RecordSaleConstants.MOBILE_CHECKOUT_WEIGHT_UOM);
				weight.setAmount(refundBo.getOrderWeight());
				orderItem.setTotalWeight(weight);

			}

			orderItem.setTax(tax);
			rsOrder.getOrderItems().add(orderItem);

		}

		return tempCount ;

	}

	private void setTotalMachine(Map<Integer, Tax> map,RecordSaleOrder rsOrder, List<OrderLineBo> orderLineBoList) {

		
		
		for (OrderLineBo orderLineBo : orderLineBoList) {
			RecordSaleOrderLine orderItem = new RecordSaleOrderLine();
			orderItem.setLineItemType(orderLineBo.getItemType());
			orderItem.setItemNbr(orderLineBo.getItemNumber()+"");
			orderItem.setItemDesc(orderLineBo.getPosDescOnline());
			orderItem.setUpcNbr(orderLineBo.getUpc() + "");
			orderItem.setReportCode(orderLineBo.getReportCode());
			orderItem.setDeptNbr(orderLineBo.getDepartment());
			orderItem.setQuantity(orderLineBo.getOrderQuantity());

			Tax tax = new Tax();
			int key = orderLineBo.getTaxRate().multiply(BigDecimal.valueOf(100)).intValue();
			tax.setTaxType(RecordSaleConstants.getTaxType(key));
           
			int mode = BigDecimal.ROUND_DOWN;
		

			if (RecordSaleConstants.PRODUCT_TYPE_WEIGHT == orderLineBo.getItemType()) {
				Weight weight = new Weight();
				weight.setUom(RecordSaleConstants.MOBILE_CHECKOUT_WEIGHT_UOM);
				weight.setAmount(orderLineBo.getOrderWeight());
				orderItem.setTotalWeight(weight);
				
				BigDecimal realTotalMoney = orderLineBo.getItemAmount().subtract(orderLineBo.getGpDiscount()) ;
				BigDecimal divideTemp = orderLineBo.getOrderWeight().multiply(BigDecimal.valueOf(1).add(orderLineBo.getTaxRate())) ;
				orderItem.setBasePrice( realTotalMoney.divide( divideTemp , 2 , mode ) );
				
				BigDecimal temp = orderItem.getBasePrice().multiply(orderLineBo.getOrderWeight()).setScale(2, mode) ;
				BigDecimal taxAmount = realTotalMoney.subtract(temp).setScale(2, mode) ;
				
				LOG.info("total machine , realTotalMoney:{} , divideTemp :{}, totalBasePricetemp {}, taxAmount{} ",realTotalMoney , divideTemp,temp , taxAmount);
				
				tax.setTaxAmount(taxAmount);
				
			} else {
				
				BigDecimal tempTotal = orderLineBo.getPriceWithTax().multiply(new BigDecimal(orderLineBo.getOrderQuantity())) ;
				
				BigDecimal realTotalMoney = tempTotal.subtract(orderLineBo.getGpDiscount()) ;
				BigDecimal divideTemp = new BigDecimal(orderLineBo.getOrderQuantity()).multiply(BigDecimal.valueOf(1).add(orderLineBo.getTaxRate())) ;
				orderItem.setBasePrice(realTotalMoney.divide( divideTemp , 2 , mode ));
				
				BigDecimal temp = orderItem.getBasePrice().multiply(new BigDecimal(orderLineBo.getOrderQuantity())) ;
				BigDecimal taxAmount = realTotalMoney.subtract( temp.setScale(2, mode) ) ;
				LOG.info("total machine , realTotalMoney:{} , divideTemp :{}, totalBasePricetemp {}, taxAmount{} ",realTotalMoney , divideTemp,temp , taxAmount);
				tax.setTaxAmount(taxAmount);
			}

			setTaxAmount(tax, orderLineBo,map );
			
			orderItem.setTax(tax);

			
			rsOrder.getOrderItems().add(orderItem);

		}

		

	}

	/**
	 * 根据taxRate 分成多组的orderLineBo
	 * 
	 * @param orderLineBoList
	 * @return
	 */
	private Map<String, OrderLineBo> getOrderLineMapByRateType(List<OrderLineBo> orderLineBoList) {
		Map<String, OrderLineBo> upcOrderLineMap = new HashMap<>(16);
		for (OrderLineBo orderLineBo : orderLineBoList) {
			upcOrderLineMap.put(orderLineBo.getUpc() + "_"+orderLineBo.getCartItemId(), orderLineBo);
		}
		return upcOrderLineMap;
	}

	
	
	/**
	 * 
	 * @param refundList 退款详情列表
	 * @param upcOrderLineMap  upc订单列表
	 * @param taxTempCount 各种退款的总额 按照税率划分
	 * @param taxRefundMap  各种税率的列表
	 * @param tempCount 退款总额减去当前商品退款金额
	 * @param listRefund 退款详情列表的封装信息
	 * @return
	 */
	private List<RefundBo> getRefundMapByUpc(List<Refund> refundList, Map<String, OrderLineBo> upcOrderLineMap,RecordSaleOrderInfo orderInfo) {
		BigDecimal tempCount = BigDecimal.ZERO;
	    List<RefundBo> list = new ArrayList<>();
		for (Refund refund : refundList) {

			tempCount = tempCount.add(refund.getReturnAmount());
			OrderLineBo orderLineBo = upcOrderLineMap.get(refund.getUpc() + "_"+refund.getCartItemId());
			RefundBo refundBo = new RefundBo(refund, orderLineBo);
			list.add(refundBo);
		}
		orderInfo.setSaleAmount(tempCount);
		orderInfo.setTenderAmount(tempCount);
		return list;
	}




	private void setTaxAmount(Tax tax, OrderLineBo orderLineBo,Map<Integer, Tax> map) {
			getTempTaxMap(map, tax.getTaxAmount(), orderLineBo.getTaxRate().multiply(BigDecimal.valueOf(100)).intValue());
	}

	private void setRefundTaxAmount(Tax tax, RefundBo refundBo, Map<Integer, Tax> map) {

		if (RecordSaleConstants.PRODUCT_TYPE_NOMOAL == refundBo.getLineItemType()) {
			// 非称重商品
			BigDecimal taxAmount = refundBo.getRefund().getReturnAmount().subtract(refundBo.getPriceWithoutTax()
					.multiply(BigDecimal.valueOf(refundBo.getRefund().getReturnQuantity())));
			getTempTaxMap(map, taxAmount, refundBo.getTaxRate());
			tax.setTaxAmount(taxAmount);
		} else {
			// 称重商品
			BigDecimal taxAmount = getSubTaxAmount(refundBo.getRefund().getReturnAmount(),
					(refundBo.getPriceWithoutTax().multiply(refundBo.getOrderWeight())).setScale(2, BigDecimal.ROUND_DOWN));
			getTempTaxMap(map, taxAmount, refundBo.getTaxRate());
			tax.setTaxAmount(taxAmount);

		}

	}


	private BigDecimal getSubTaxAmount(BigDecimal priceWithTax, BigDecimal priceWithoutTax) {
		LOG.info("priceWithTax:{} ,priceWithoutTax:{}", priceWithTax, priceWithoutTax);
		return priceWithTax.subtract(priceWithoutTax).setScale(2, BigDecimal.ROUND_DOWN);
	}

	
	private void getTempTaxMap(Map<Integer, Tax> map, BigDecimal taxAmount, Integer taxRate) {

		if (map.containsKey(taxRate)) {
			Tax tax = map.get(taxRate);
			tax.setTaxAmount(tax.getTaxAmount().add(taxAmount));
			map.put(taxRate, tax);
		} else {
			Tax tax = new Tax();
			tax.setTaxType(RecordSaleConstants.getTaxType(taxRate));
			tax.setTaxAmount(taxAmount);
			map.put(taxRate, tax);
		}
	}

	

}
