package com.walmart.mobile.checkout.constant.refund;

import com.walmart.mobile.checkout.exception.handler.ErrorInfoInterface;

/**
 * 系统及业务级别的错误码
 */
public enum RefundErrorInfoEnum implements ErrorInfoInterface{
    UPDATE_REFUND_STATUS_FAILED("-900","update refund status failed")
    ;


    private String code;

    private String message;

    RefundErrorInfoEnum(String code, String message) {
        this.code = code;
        this.message = message;
    }
    @Override
    public String getCode(){
        return this.code;
    }
    @Override
    public String getMessage(){
        return this.message;
    }
}
