package com.walmart.mobile.checkout.constant.refund;


public class PayType {
	
	
	/**
	 * mobileck 微信支付
	 */
	public static final String MOBILECK_WECHATPAY ="1";
	/**
	 * h5微信支付
	 */
	public static final String H5_WECHATPAY ="2";
	private PayType(){}


}
