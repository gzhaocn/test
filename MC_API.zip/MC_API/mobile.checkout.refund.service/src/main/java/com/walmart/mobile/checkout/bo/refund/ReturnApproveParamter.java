package com.walmart.mobile.checkout.bo.refund;

public class ReturnApproveParamter {
	
	private String requestNumber;
	private Integer returnQuantity;

	public String getRequestNumber() {
		return requestNumber;
	}

	public void setRequestNumber(String requestNumber) {
		this.requestNumber = requestNumber;
	}

	public Integer getReturnQuantity() {
		return returnQuantity;
	}

	public void setReturnQuantity(Integer returnQuantity) {
		this.returnQuantity = returnQuantity;
	}

}
