package com.walmart.mobile.checkout.domain.refund;

import java.math.BigDecimal;
import java.util.Date;

public class Refund {
	private String requestNumber;

	private String orderId;

	private Long upc;

	private Integer returnQuantity;

	private Integer requestQuantity;

	private BigDecimal returnAmount;

	private Byte returnReason;

	private Date requestTime;

	private Byte refundStatus;

	private Date refundTime;

	private Byte payType;

	private Byte requestType;

	private String batchNo;

	private Long productId;

	private Long cartItemId;
	/**
	 * 是否延保商品
	 */
	private Integer ewsFlag;
	/**
	 * 延保商品itemNumber
	 */
	private Long itemNumber;
	/**
	 * 逆向过机tcNumber
	 */
	private String reverseTcNumber;
	/**
	 * 延保商品requestNumber
	 */
	private String ewsRequestNumber;

	private Date reverseTcNumberTime;

	public String getRequestNumber() {
		return requestNumber;
	}

	public void setRequestNumber(String requestNumber) {
		this.requestNumber = requestNumber == null ? null : requestNumber.trim();
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId == null ? null : orderId.trim();
	}

	public Long getUpc() {
		return upc;
	}

	public void setUpc(Long upc) {
		this.upc = upc;
	}

	public Integer getReturnQuantity() {
		return returnQuantity;
	}

	public void setReturnQuantity(Integer returnQuantity) {
		this.returnQuantity = returnQuantity;
	}

	public Integer getRequestQuantity() {
		return requestQuantity;
	}

	public void setRequestQuantity(Integer requestQuantity) {
		this.requestQuantity = requestQuantity;
	}

	public BigDecimal getReturnAmount() {
		return returnAmount;
	}

	public void setReturnAmount(BigDecimal returnAmount) {
		this.returnAmount = returnAmount;
	}

	public Byte getReturnReason() {
		return returnReason;
	}

	public void setReturnReason(Byte returnReason) {
		this.returnReason = returnReason;
	}

	public Date getRequestTime() {
		return requestTime;
	}

	public void setRequestTime(Date requestTime) {
		this.requestTime = requestTime;
	}

	public Byte getRefundStatus() {
		return refundStatus;
	}

	public void setRefundStatus(Byte refundStatus) {
		this.refundStatus = refundStatus;
	}

	public Date getRefundTime() {
		return refundTime;
	}

	public void setRefundTime(Date refundTime) {
		this.refundTime = refundTime;
	}

	public Byte getPayType() {
		return payType;
	}

	public void setPayType(Byte payType) {
		this.payType = payType;
	}

	public Byte getRequestType() {
		return requestType;
	}

	public void setRequestType(Byte requestType) {
		this.requestType = requestType;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo == null ? null : batchNo.trim();
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public Long getCartItemId() {
		return cartItemId;
	}

	public void setCartItemId(Long cartItemId) {
		this.cartItemId = cartItemId;
	}

	public Integer getEwsFlag() {
		return ewsFlag;
	}

	public void setEwsFlag(Integer ewsFlag) {
		this.ewsFlag = ewsFlag;
	}

	public Long getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(Long itemNumber) {
		this.itemNumber = itemNumber;
	}

	public String getReverseTcNumber() {
		return reverseTcNumber;
	}

	public void setReverseTcNumber(String reverseTcNumber) {
		this.reverseTcNumber = reverseTcNumber;
	}

	public String getEwsRequestNumber() {
		return ewsRequestNumber;
	}

	public void setEwsRequestNumber(String ewsRequestNumber) {
		this.ewsRequestNumber = ewsRequestNumber;
	}

	public Date getReverseTcNumberTime() {
		return reverseTcNumberTime;
	}

	public void setReverseTcNumberTime(Date reverseTcNumberTime) {
		this.reverseTcNumberTime = reverseTcNumberTime;
	}
}