package com.walmart.mobile.checkout.bo.refund;

import java.math.BigDecimal;

import com.walmart.mobile.checkout.bo.order.OrderLineBo;
import com.walmart.mobile.checkout.domain.refund.Refund;

public class RefundBo {

	private Refund refund;

	private Integer lineItemType;

	private String itemNbr;

	private String itemDesc;

	private Integer reportCode;

	private Integer deptNbr;

	private Integer taxRate;

	private String posDescOnline;

	private BigDecimal priceWithTax;

	private BigDecimal priceWithoutTax;

	private BigDecimal orderWeight;

	public RefundBo(Refund refund, OrderLineBo orderLineBo) {
		this.refund = refund;
		this.lineItemType = orderLineBo.getItemType();
		this.itemNbr = orderLineBo.getItemNumber() + "";
		this.itemDesc = orderLineBo.getPosDescOnline();
		this.reportCode = orderLineBo.getReportCode();
		this.deptNbr = orderLineBo.getDepartment();
		this.taxRate = orderLineBo.getTaxRate().multiply(BigDecimal.valueOf(100)).intValue();
		
		if(1 == orderLineBo.getItemType()){
			this.priceWithTax = refund.getReturnAmount().divide(orderLineBo.getOrderWeight(),2, BigDecimal.ROUND_DOWN); 
		}else{
			this.priceWithTax = refund.getReturnQuantity() == 0 ? BigDecimal.ZERO : refund.getReturnAmount().divide(new BigDecimal(refund.getReturnQuantity()), 2, BigDecimal.ROUND_DOWN);
		}
		
		//base_price 保留小数点2位，后面的数据舍去
		this.priceWithoutTax = this.priceWithTax.divide(BigDecimal.valueOf(1).add(orderLineBo.getTaxRate()), 2,BigDecimal.ROUND_DOWN);
		this.posDescOnline = orderLineBo.getPosDescOnline();
		this.orderWeight = orderLineBo.getOrderWeight();
	}

	public Refund getRefund() {
		return refund;
	}

	public void setRefund(Refund refund) {
		this.refund = refund;
	}

	public Integer getLineItemType() {
		return lineItemType;
	}

	public void setLineItemType(Integer lineItemType) {
		this.lineItemType = lineItemType;
	}

	public String getItemNbr() {
		return itemNbr;
	}

	public void setItemNbr(String itemNbr) {
		this.itemNbr = itemNbr;
	}

	public String getItemDesc() {
		return itemDesc;
	}

	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}

	public Integer getReportCode() {
		return reportCode;
	}

	public void setReportCode(Integer reportCode) {
		this.reportCode = reportCode;
	}

	public Integer getDeptNbr() {
		return deptNbr;
	}

	public void setDeptNbr(Integer deptNbr) {
		this.deptNbr = deptNbr;
	}

	public Integer getTaxRate() {
		return taxRate;
	}

	public void setTaxType(Integer taxRate) {
		this.taxRate = taxRate;
	}

	public String getPosDescOnline() {
		return posDescOnline;
	}

	public void setPosDescOnline(String posDescOnline) {
		this.posDescOnline = posDescOnline;
	}

	public BigDecimal getPriceWithTax() {
		return priceWithTax;
	}

	public void setPriceWithTax(BigDecimal priceWithTax) {
		this.priceWithTax = priceWithTax;
	}

	public BigDecimal getPriceWithoutTax() {
		return priceWithoutTax;
	}

	public void setPriceWithoutTax(BigDecimal priceWithoutTax) {
		this.priceWithoutTax = priceWithoutTax;
	}

	public void setTaxRate(Integer taxRate) {
		this.taxRate = taxRate;
	}

	public BigDecimal getOrderWeight() {
		return orderWeight;
	}

	public void setOrderWeight(BigDecimal orderWeight) {
		this.orderWeight = orderWeight;
	}

}
