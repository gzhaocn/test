package com.walmart.mobile.checkout.bo.refund;

import io.swagger.annotations.ApiModelProperty;

import java.util.Date;

public class RefundModifyParamter {
	@ApiModelProperty(value = "批次号", required = true)
	private String batchNo;
	@ApiModelProperty(value = "return状态", required = true)
	private Byte returnStatus;
	@ApiModelProperty(value = "订单号", required = true)
	private String orderId;

	@ApiModelProperty(value = "调用程序key", required = true)
	private String appKey;

	@ApiModelProperty(value = "调用时间", required = true)
	private Date timeStamp;

	@ApiModelProperty(value = "签名", required = true)
	private String sign;

	@ApiModelProperty(value = "参数格式（如：json）", required = true)
	private String format;

	@ApiModelProperty(value = "版本", required = true)
	private String version;

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public Byte getReturnStatus() {
		return returnStatus;
	}

	public void setReturnStatus(Byte returnStatus) {
		this.returnStatus = returnStatus;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getAppKey() {
		return appKey;
	}

	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}

	public Date getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

}
