package com.walmart.mobile.checkout.mapper;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.walmart.mobile.checkout.domain.refund.Refund;

public interface RefundMapper {
	int deleteByPrimaryKey(String requestNumber);

	int insert(Refund record);

	int insertByBatch(List<Refund> record);

	int insertSelective(Refund record);

	Refund selectByPrimaryKey(String requestNumber);

	List<Refund> selectByOrderId(String orderId);

	int updateByPrimaryKeySelective(Refund record);

	int updateByPrimaryKey(Refund record);

	int updateByBatchRefund(@Param("refundList") List<Refund> refundList);

	int updateRefundStatus(@Param("batchNo") String batchNo, @Param("refundStatus") Byte refundStatus, @Param("refundTime") Date refundTime);

	int updateRefundReverseTcNumber(@Param("batchNo") String batchNo, @Param("reverseTcNumber") String reverseTcNumber, @Param("reverseTcNumberTime") Date reverseTcNumberTime);

	int selectRequestQuantity(@Param("orderId") String orderId, @Param("productId") Long productId, @Param("cartItemId") Long cartItemId);

	int selectRequestRefundStatusSumbitQuantity(@Param("orderId") String orderId, @Param("productId") Long productId, @Param("cartItemId") Long cartItemId);

	int selectRequestQuantityByOrderId(@Param("orderId") String orderId, @Param("ewsFlag") Integer ewsFlag);

	BigDecimal selectRequestAmount(@Param("orderId") String orderId);

	BigDecimal selectRequestAmountByProductIdAndCartItemId(@Param("orderId") String orderId, @Param("productId") Long productId, @Param("cartItemId") Long cartItemId);

	int selectReturnQuantity(@Param("orderId") String orderId, @Param("productId") Long productId, @Param("cartItemId") Long cartItemId);
}
