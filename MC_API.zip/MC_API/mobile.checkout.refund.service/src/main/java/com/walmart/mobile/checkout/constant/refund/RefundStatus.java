package com.walmart.mobile.checkout.constant.refund;

import java.util.ArrayList;
import java.util.List;

public class RefundStatus {
	
	/**
	 * 提交退货审批，亦即退货中
	 */
	public static final int RETURN_STATUS_SUBMIT = 0;
	/**
	 * 退货申请已过期：亦即超出退货期限
	 */
	public static final int RETURN_STATUS_TIMEOUT = 1;
	/**
	 * 已退货，待退款：亦即退货审批已被批准，等待退款
	 */
	public static final int RETURN_STATUS_REFUND_PENDING = 2;
	/**
	 * 退款成功
	 */
	public static final int RETURN_STATUS_REFUND_SUCCESS = 3;
	/**
	 * 退款失败
	 */
	public static final int RETURN_STATUS_REFUND_FAILED = 4;
	

	public static final int REQUEST_TYPE_ORDER_CANCEL = 0; // 取消

	public static final int REQUEST_TYPE_ORDER_LINE_RETURN = 2; // 退货

	private RefundStatus() {
	}
	
	public static final List<Integer> RETURNED_STATUS_LIST = new ArrayList<>();
	static {
		RETURNED_STATUS_LIST.add(RefundStatus.RETURN_STATUS_REFUND_PENDING);
		RETURNED_STATUS_LIST.add(RefundStatus.RETURN_STATUS_REFUND_SUCCESS);
		RETURNED_STATUS_LIST.add(RefundStatus.RETURN_STATUS_REFUND_FAILED);
	}
}
