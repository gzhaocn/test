package com.walmart.mobile.checkout.service.refund;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.walmart.mobile.checkout.bo.order.OrderRejectItem;
import com.walmart.mobile.checkout.bo.order.OrderRejectItemParameter;
import com.walmart.mobile.checkout.bo.refund.RefundModifyParamter;
import com.walmart.mobile.checkout.constant.order.OrderCons;
import com.walmart.mobile.checkout.constant.order.OrderErrorInfoEnum;
import com.walmart.mobile.checkout.constant.order.OrderStatus;
import com.walmart.mobile.checkout.constant.refund.RefundStatus;
import com.walmart.mobile.checkout.domain.order.Order;
import com.walmart.mobile.checkout.domain.order.OrderLine;
import com.walmart.mobile.checkout.domain.refund.Refund;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.mapper.OrderEwsLineMapper;
import com.walmart.mobile.checkout.mapper.OrderLineMapper;
import com.walmart.mobile.checkout.mapper.OrderMapper;
import com.walmart.mobile.checkout.mapper.RefundMapper;
import com.walmart.mobile.checkout.service.IdService;
import com.walmart.mobile.checkout.service.OrderStatusService;
import com.walmart.mobile.checkout.statemachine.OrderEventTypeEnum;
import com.walmart.mobile.checkout.utils.DateUtil;
import com.walmart.mobile.checkout.utils.crypto.SHA512;
import com.walmart.mobile.checkout.utils.order.OrderUtils;

@Service
public class RefundService {

	@Autowired
	RefundMapper refundMapper;
	@Autowired
	OrderMapper orderMapper;
	@Autowired
	OrderLineMapper orderLineMapper;
	@Autowired
	OrderEwsLineMapper orderEwsLineMapper;
	@Autowired
	OrderStatusService orderStatusService;
	@Autowired
	private IdService orderSerialNumberService;

	private static final Logger LOG = LoggerFactory.getLogger(RefundService.class);

	/**
	 * 插入refund
	 * 
	 * @param refund
	 * @return
	 */
	public int insertRefund(Refund refund) {
		return refundMapper.insert(refund);
	}

	public int updateByPrimaryKeySelective(Refund record) {
		return refundMapper.updateByPrimaryKeySelective(record);
	}

	public int updateByBatchRefund(List<Refund> refundList) {
		return refundMapper.updateByBatchRefund(refundList);
	}

	/**
	 * 批量插入
	 * 
	 * @param refundList
	 * @return
	 */
	public int insertBatchRefund(List<Refund> refundList) {
		return refundMapper.insertByBatch(refundList);
	}

	public Refund selectByPrimaryKey(String requestNumber) {
		return refundMapper.selectByPrimaryKey(requestNumber);
	}

	public List<Refund> getApplyOrderRefundList(String orderId) {
		List<Refund> refundList = refundMapper.selectByOrderId(orderId);
		if (refundList != null) {
			refundList.removeIf(refund -> refund.getRefundStatus() != RefundStatus.RETURN_STATUS_SUBMIT);
		}
		return refundList;
	}

	public List<Refund> getOrderRefundList(String orderId) {
		return refundMapper.selectByOrderId(orderId);
	}

	public int selectReturnQuantity(String orderId, Long productId, Long cartItemId) {
		return refundMapper.selectReturnQuantity(orderId, productId, cartItemId);
	}

	public int updateRefundReverseTcNumber(String batchNo, String reverseTcNumber, Date reverseTcNumberTime) {
		return refundMapper.updateRefundReverseTcNumber(batchNo, reverseTcNumber, reverseTcNumberTime);
	}

	/**
	 * 不通过构建refund对象
	 * 
	 * @param requestNumber
	 * @param orderId
	 * @param cancelReason
	 * @param payType
	 * @param amount
	 * @return
	 */
	public Refund buildRefund(String requestNumber, String orderId, int cancelReason, int payType, BigDecimal amount) {

		Refund refund = new Refund();

		String batchNo = requestNumber + DateUtil.dateToString(new Date(), DateUtil.PATTERN_YYYYMMDD);
		refund.setRequestNumber(requestNumber);
		refund.setBatchNo(batchNo);
		refund.setOrderId(orderId);

		refund.setRefundStatus(Byte.parseByte(String.valueOf(RefundStatus.RETURN_STATUS_REFUND_PENDING)));
		refund.setReturnReason(Byte.parseByte(String.valueOf(cancelReason)));

		Date now = Calendar.getInstance().getTime();
		refund.setRequestTime(now);
		refund.setRefundTime(now);

		refund.setReturnAmount(amount);
		/** 取消逻辑，下面值设置为0,代表全部 */
		refund.setUpc(0L);
		refund.setProductId(0L);
		refund.setReturnQuantity(0);
		refund.setRequestQuantity(0);
		refund.setCartItemId(0L);

		refund.setPayType(Byte.parseByte(String.valueOf(payType)));
		refund.setRequestType(Byte.parseByte(String.valueOf(RefundStatus.REQUEST_TYPE_ORDER_CANCEL)));
		return refund;
	}

	/**
	 * 查询已经申请退货中和已经退货的数量
	 * 
	 * @param orderId
	 * @param productId
	 * @param cartItemId
	 * @return
	 */
	public int selectRequestQuantity(String orderId, Long productId, Long cartItemId) {
		return refundMapper.selectRequestRefundStatusSumbitQuantity(orderId, productId, cartItemId) + refundMapper.selectReturnQuantity(orderId, productId, cartItemId);
		/**
		 * return refundMapper.selectRequestQuantity(orderId, productId,
		 * cartItemId);
		 */
	}

	/**
	 * 已退数量 alreadyReturnedQty（如果已退数量为0，则为已申请退货数量）
	 * 
	 * @param order
	 * @param orderLine
	 * @param currentReturnQuantity
	 * @param totalHistoryReturnedQuantity
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	public BigDecimal getRefundAmount(Order order, OrderLine orderLine, int currentReturnQuantity, int totalHistoryReturnedQuantity) throws GlobalErrorInfoException {
		BigDecimal shippingFee = order.getShippingFee() == null ? BigDecimal.ZERO : order.getShippingFee();
		BigDecimal packagingFee = order.getPackagingFee() == null ? BigDecimal.ZERO : order.getPackagingFee();
		BigDecimal productQty = new BigDecimal(orderLine.getOrderQuantity());
		// 商品单价 * 购买数量 - orderLine GP = 该商品实际总价
		BigDecimal productAmount = orderLine.calcProductAmount(productQty, orderLine.getItemType());
		// 本次申请退货数量+已退数量=此商品的购买数量，表明此商品已全部退完
		if (currentReturnQuantity + totalHistoryReturnedQuantity == productQty.intValue()) {
			return calcAllReturnedAmount(orderLine, productAmount);
		} else {
			return calcParitalReturnAmount(order, currentReturnQuantity, shippingFee, packagingFee, productQty, productAmount);
		}
	}

	/**
	 * 该商品没有全部退完（部分退），该商品实际总价*(本次退货数量/该商品购买数量)=要退的商品金额
	 * 
	 * @param order
	 * @param currentReturnQuantity
	 * @param shippingFee
	 * @param packagingFee
	 * @param productQty
	 * @param productAmount
	 * @return
	 */
	private BigDecimal calcParitalReturnAmount(Order order, int currentReturnQuantity, BigDecimal shippingFee, BigDecimal packagingFee, BigDecimal productQty, BigDecimal productAmount) {
		BigDecimal needToReturnAmount = productAmount.multiply(new BigDecimal(currentReturnQuantity)).divide(productQty, 4, BigDecimal.ROUND_HALF_UP).setScale(2, RoundingMode.HALF_UP);
		BigDecimal alreadyReturnedAmount = refundMapper.selectRequestAmount(order.getOrderId());
		// 订单金额（用户实付金额）-运费-包装费
		BigDecimal orderAmount = order.getAmount().subtract(shippingFee).subtract(packagingFee);
		// 订单金额还剩下的未退金额
		BigDecimal remainedAmount = orderAmount.subtract(alreadyReturnedAmount);
		remainedAmount = remainedAmount.compareTo(BigDecimal.ZERO) > 0 ? remainedAmount : BigDecimal.ZERO;
		needToReturnAmount = needToReturnAmount.compareTo(BigDecimal.ZERO) > 0 ? needToReturnAmount : BigDecimal.ZERO;
		// 取两者较小值
		return remainedAmount.compareTo(needToReturnAmount) > 0 ? needToReturnAmount : remainedAmount;
	}

	/**
	 * 整单退货（加上本次申请退货数量，订单里所有商品都已经退货或已申请退货）
	 * 
	 * @param orderLine
	 * @param productAmount
	 * @return
	 */
	private BigDecimal calcAllReturnedAmount(OrderLine orderLine, BigDecimal productAmount) {

		// 该商品已退金额
		BigDecimal alreadyReturnedAmount = refundMapper.selectRequestAmountByProductIdAndCartItemId(orderLine.getOrderId(), orderLine.getProductId(), orderLine.getCartItemId());
		// 本次申请退货要退款的金额=商品单价*购买数量-orderLine GP -按比例平摊的优惠金额 - 该商品已退金额
		BigDecimal needToReturnAmount = productAmount.subtract(alreadyReturnedAmount);
		// 退款不可为负
		return needToReturnAmount.compareTo(BigDecimal.ZERO) > 0 ? needToReturnAmount : BigDecimal.ZERO;
	}

	/**
	 * 退款成功后回写状态
	 * 
	 * @param refundModifyParamter
	 * @throws GlobalErrorInfoException
	 */
	@Transactional(rollbackFor = Exception.class)
	public void updateRefundAndOrderStatus(RefundModifyParamter refundModifyParamter) throws GlobalErrorInfoException {
		LOG.info("the orderId is {},dagId is {}", refundModifyParamter.getOrderId(), OrderUtils.getDagId(refundModifyParamter.getOrderId()));
		refundMapper.updateRefundStatus(refundModifyParamter.getBatchNo(), refundModifyParamter.getReturnStatus(), new Date());
		String returnStatus = String.valueOf(refundModifyParamter.getReturnStatus());
		LOG.info("the orderId is {},refundStatus is {}", refundModifyParamter.getOrderId(), returnStatus);
		if (refundModifyParamter.getReturnStatus() == RefundStatus.RETURN_STATUS_REFUND_SUCCESS) {
			Order order = orderMapper.selectByPrimaryKey(refundModifyParamter.getOrderId());
			if (order.getStatus() != OrderStatus.COMPLETE) {
				orderStatusService.updateOrderStatus(order, OrderEventTypeEnum.PAID_CANCELL_ROLLBACK.getCode());
			}
		}
	}

	/**
	 * checkSum检查
	 * 
	 * @param refundModifyParamter
	 * @throws GlobalErrorInfoException
	 */
	public void refundCheckSum(RefundModifyParamter refundModifyParamter) throws GlobalErrorInfoException {
		StringBuilder sb = new StringBuilder();
		String signString = sb.append(refundModifyParamter.getAppKey()).append(refundModifyParamter.getVersion()).append(refundModifyParamter.getFormat()).append(refundModifyParamter.getTimeStamp())
				.append(refundModifyParamter.getOrderId()).append(OrderCons.APPSECUERT).toString();
		LOG.info("signString:{}", signString);
		String checkSign = StringUtils.EMPTY;
		try {
			checkSign = SHA512.hashValue(signString);
		} catch (NoSuchAlgorithmException e) {
			LOG.error("can't build checkSum", e);
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.CHECKSUM_CRYPTO_FAILED);
		}
		LOG.info("checkSign:{}", checkSign);
		if (!StringUtils.equals(checkSign, refundModifyParamter.getSign())) {
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.CHECKSUM_NOT_COMPARE);
		}
	}

	/**
	 * 计算requestAmount
	 * 
	 * @param orderId
	 * @return
	 */
	public BigDecimal selectRequestAmount(String orderId) {
		return refundMapper.selectRequestAmount(orderId);
	}

	/**
	 * 部分退货-全退
	 * 
	 * @param orderRejectItem
	 * @param rejectItemList
	 * @param order
	 * @param refundedAmount
	 * @param orderAmount
	 * @return
	 * @throws GlobalErrorInfoException
	 */
	public List<Refund> rejectItemApply(OrderRejectItem orderRejectItem, List<OrderRejectItemParameter> rejectItemList, Order order, BigDecimal refundedAmount, BigDecimal orderAmount)
			throws GlobalErrorInfoException {

		List<Refund> refundList = new ArrayList<>();
		Map<Long, String> map = new HashMap<>(10);
		for (int i = 0; i < rejectItemList.size(); i++) {
			String requestNumber = this.orderSerialNumberService.buildRefundId(order.getStoreId(), OrderUtils.getDagId(order.getOrderId()));
			OrderRejectItemParameter orderRejectItemParameter = rejectItemList.get(i);
			compareRequestQuantityLessZero(orderRejectItemParameter);
			Refund refund = this.buildRefund(orderRejectItem, order, requestNumber, orderRejectItemParameter);
			OrderLine orderLine = this.queryOrderLine(order.getOrderId(), orderRejectItemParameter.getProductId(), orderRejectItemParameter.getCartItemId(), orderRejectItemParameter.getItemNumber(),
					orderRejectItemParameter.getEwsFlag());
			refund.setUpc(orderLine.getUpc());
			refund.setProductId(orderLine.getProductId());
			if (refund.getEwsFlag() == 1) {
				map.put(refund.getCartItemId(), refund.getRequestNumber());
			}
			int totalHistoryReturnedQuantity = this.selectRequestQuantity(order.getOrderId(), orderLine.getProductId(), orderRejectItemParameter.getCartItemId());
			if (refund.getRequestQuantity().intValue() + totalHistoryReturnedQuantity > orderLine.getOrderQuantity().intValue()) {
				LOG.info("the refund quantity > order quantity, requestquantity is {},totalHistoryReturnedQuantity is {},orderquantity is{}", refund.getRequestQuantity(),
						totalHistoryReturnedQuantity, orderLine.getOrderQuantity());
				throw new GlobalErrorInfoException(OrderErrorInfoEnum.REJECT_ITEM_REQYEST_QUANTITY_OVER_ORDER_QUANTITY);
			}
			BigDecimal orderlineRefundAmount = this.getRefundAmount(order, orderLine, refund.getRequestQuantity().intValue(), totalHistoryReturnedQuantity);
			LOG.info("orderlineRefundAmount is {}", orderlineRefundAmount);
			Integer returnQuantity = orderLine.getOrderQuantity() - totalHistoryReturnedQuantity;
			LOG.info("returnQuantity is {},totalHistoryReturnedQuantity is {},orderlineRefundAmount is {}", returnQuantity, totalHistoryReturnedQuantity, orderlineRefundAmount);
			if (refundedAmount.add(orderlineRefundAmount).compareTo(orderAmount) >= 0) {
				orderlineRefundAmount = orderAmount.subtract(refundedAmount);
				refund.setReturnAmount(orderlineRefundAmount);
				refundList.add(refund);
				break;
			}
			refund.setReturnAmount(orderlineRefundAmount);
			refundList.add(refund);

		}
		if (CollectionUtils.isNotEmpty(refundList)) {
			for (Refund refund : refundList) {
				if (refund.getEwsFlag() == 0 && map.containsKey(refund.getCartItemId())) {
					refund.setEwsRequestNumber(map.get(refund.getCartItemId()));
				}
			}
		}

		return refundList;
	}

	/**
	 * 判断requestQuantity的值是否合理
	 * 
	 * @param orderRejectItemParameter
	 * @throws GlobalErrorInfoException
	 */
	private void compareRequestQuantityLessZero(OrderRejectItemParameter orderRejectItemParameter) throws GlobalErrorInfoException {
		if (0 >= Integer.valueOf(orderRejectItemParameter.getRequestQuantity())) {
			LOG.info(" RequestQuantity is less than zero, RequestQuantity {}", orderRejectItemParameter.getRequestQuantity());
			throw new GlobalErrorInfoException(OrderErrorInfoEnum.REJECT_ITEM_REQYEST_QUANTITY_IS_ZERO);
		}
	}

	/**
	 * 查询退货对应的orderLine信息
	 * 
	 * @param order
	 * @param orderRejectItemParameter
	 * @return
	 */
	public OrderLine queryOrderLine(String orderId, Long productId, Long cartItemId, Long itemNumber, Integer ewsFlag) {
		OrderLine orderLine;
		if (ewsFlag == 0) {
			orderLine = this.orderLineMapper.selectOrderLineByOrderIdAndProductIdAndCartItemId(orderId, productId, cartItemId);
		} else {
			orderLine = this.orderEwsLineMapper.selectOrderLineByOrderIdAndCartItemIdAndItemNumber(orderId, cartItemId, itemNumber);
			if (orderLine == null) {
				// 兼容历史数据
				orderLine = this.orderEwsLineMapper.selectOrderLineByOrderIdAndItemNumber(orderId, itemNumber);
			}
		}
		return orderLine;
	}

	/**
	 * 退货构建refund
	 * 
	 * @param orderRejectItem
	 * @param order
	 * @param requestNumber
	 * @param orderRejectItemParameter
	 * @return
	 */
	private Refund buildRefund(OrderRejectItem orderRejectItem, Order order, String requestNumber, OrderRejectItemParameter orderRejectItemParameter) {
		Refund refund = new Refund();
		refund.setRequestNumber(requestNumber);
		refund.setProductId(orderRejectItemParameter.getProductId());
		refund.setOrderId(orderRejectItem.getOrderId());
		refund.setCartItemId(orderRejectItemParameter.getCartItemId());

		refund.setReturnReason(Byte.parseByte(String.valueOf(orderRejectItemParameter.getReturnReason())));
		refund.setRequestQuantity(orderRejectItemParameter.getRequestQuantity());
		refund.setReturnQuantity(0);
		refund.setRequestTime(Calendar.getInstance().getTime());
		refund.setRefundStatus(Byte.parseByte(String.valueOf(RefundStatus.RETURN_STATUS_SUBMIT)));
		refund.setPayType(Byte.parseByte(String.valueOf(order.getPayType())));
		refund.setRequestType(Byte.parseByte(String.valueOf(RefundStatus.REQUEST_TYPE_ORDER_LINE_RETURN)));
		refund.setItemNumber(orderRejectItemParameter.getItemNumber());
		refund.setEwsFlag(orderRejectItemParameter.getEwsFlag());
		return refund;
	}

}
