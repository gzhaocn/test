package com.mpush.mpns.biz.domain;

import java.util.List;

public class PushOrderMsg {
	
	private List<Order> orderList;
	private String sequenceNumber;
	public List<Order> getOrderList() {
		return orderList;
	}
	public void setOrderList(List<Order> orderList) {
		this.orderList = orderList;
	}
	public String getSequenceNumber() {
		return sequenceNumber;
	}
	public void setSequenceNumber(String sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

}
