/*
 * (C) Copyright 2015-2016 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Contributors:
 *     ohun@live.cn (夜色)
 */

package com.mpush.mpns.biz.service.impl;

import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.mpush.api.Constants;
import com.mpush.api.push.AckModel;
import com.mpush.api.push.MsgType;
import com.mpush.api.push.PushCallback;
import com.mpush.api.push.PushContext;
import com.mpush.api.push.PushMsg;
import com.mpush.api.push.PushSender;
import com.mpush.api.router.ClientLocation;
import com.mpush.api.spi.common.CacheManager;
import com.mpush.api.spi.common.CacheManagerFactory;
import com.mpush.mpns.biz.domain.NotifyDO;
import com.mpush.mpns.biz.domain.OfflineMsg;
import com.mpush.mpns.biz.domain.PushOrderMsg;
import com.mpush.mpns.biz.service.PushService;
import com.mpush.tools.Jsons;
import com.mpush.tools.config.CC;

/**
 * Created by ohun on 16/9/15.
 *
 * @author ohun@live.cn (夜色)
 */
@Service
public class PushServiceImpl implements PushService {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Resource
	private PushSender mpusher;

	private final AtomicLong msgIdSeq = new AtomicLong(1);// TODO业务自己处理

	private static CacheManager cacheManager = CacheManagerFactory.create();

	@Override
	public boolean notify(String userId) {
		List<String> message = cacheManager.lrange(userId, 0, -1, String.class);

		boolean result = true;

		for (String msg : message) {
			logger.info("offline message. msg:{}", msg);
			result = notify(userId, new NotifyDO(msg));
			if (!result) {
				logger.info("offline notify failed. content:{}", msg);
				break;
			}
		}
		if (result) {
			cacheManager.del(userId);
		}
		return result;
	}

	@Override
	public boolean notify(String userId, NotifyDO notifyDO) {
		String contents = notifyDO.content;
		logger.info("push content:{} to userId:{}", contents, userId);
		PushOrderMsg order = JSON.parseObject(contents, PushOrderMsg.class);

		PushMsg pushMsg = PushMsg.build(MsgType.NOTIFICATION_AND_MESSAGE, order);
		pushMsg.setMsgId(Long.toString(msgIdSeq.incrementAndGet()));
		byte[] content = Jsons.toJson(pushMsg).getBytes(Constants.UTF_8);

		saveOfflineMsg(new OfflineMsg(userId, content, contents));

		doSend(userId, content, new PushCallback() {
			int retryCount = 0;

			@Override
			public void onSuccess(String userId, ClientLocation location) {
				logger.info("send msg success");
				clearOfflineMsg(userId);
			}

			@Override
			public void onFailure(String userId, ClientLocation clientLocation) {
				logger.info("send msg onFailure");
			}

			@Override
			public void onOffline(String userId, ClientLocation clientLocation) {
				logger.info("send msg onOffline");
			}

			@Override
			public void onTimeout(String userId, ClientLocation clientLocation) {
				logger.info("send msg onTimeout");
				if (retryCount++ > 2) {
					logger.info("retry complete.");
				} else {
					doSend(userId, content, this);
				}
			}
		});

		return true;
	}

	private void doSend(String userId, byte[] content, PushCallback callback) {
		mpusher.send(new PushContext(content).setUserId(userId).setCallback(callback).setAckModel(AckModel.AUTO_ACK));
	}

	/**
	 * private void send2ANPs(String userId, NotifyDO notifyDO, String
	 * deviceToken) { logger.info("send to ANPs"); }
	 * 
	 * private void send2MiPush(String userId, NotifyDO notifyDO) { logger.info(
	 * "send to xiaomi push"); }
	 * 
	 * private void send2HuaweiPush(String userId, NotifyDO notifyDO) {
	 * logger.info("send to huawei push"); }
	 * 
	 * private void send2JPush(String userId, NotifyDO notifyDO) { logger.info(
	 * "send to jpush"); }
	 */

	private void saveOfflineMsg(OfflineMsg offlineMsg) {
		String userId = offlineMsg.getUserId();
		logger.info("save offline msg to db.userId:{}", userId);
		cacheManager.lpush(userId, offlineMsg.getBody());
		cacheManager.expire(userId, CC.mp.redis.redis_expire);
	}

	private void clearOfflineMsg(String userId) {
		logger.info("clear offline msg in db.userId:{}", userId);
		cacheManager.del(userId);
	}
}
