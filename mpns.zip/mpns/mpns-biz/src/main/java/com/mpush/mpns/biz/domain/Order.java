package com.mpush.mpns.biz.domain;


import java.math.BigDecimal;
import java.util.Date;


public class Order {

	private String orderId;

	private String userId;

	private Integer storeId;

	private String shortNameCn;

	private int status;

	private BigDecimal amount;

	private BigDecimal totalGpDiscount;

	private BigDecimal voucherDiscount;

	private String province;

	private String city;

	private String district;

	private String address;

	private String zipcode;

	private Double longitude;

	private Double latitude;

	private BigDecimal shippingFee;

	private BigDecimal packagingFee;

	private String deliveryName;

	private String deliveryPhone;

	private Integer deliveryMethod;

	private Date deliveryDate;

	private Integer deliveryPeriod;

	private String deliveryPeriodDesc;

	private String deliveryInstruction;

	private String invoiceTitle;

	private int invoiceType;

	private String invoicePdfUrl;

	private String tcNumber;

	private Integer tcSequenceNumber;

	private Integer tcRegisterNumber;

	private Date tcTransTime;

	private int cancelReason;

	private Date createdTime;

	private int payType;

	private Date paidTime;

	private Date completedTime;

	private Integer version;

	private Integer itemSize;
	
	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public String getShortNameCn() {
		return shortNameCn;
	}

	public void setShortNameCn(String shortNameCn) {
		this.shortNameCn = shortNameCn;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public BigDecimal getTotalGpDiscount() {
		return totalGpDiscount;
	}

	public void setTotalGpDiscount(BigDecimal totalGpDiscount) {
		this.totalGpDiscount = totalGpDiscount;
	}

	public BigDecimal getVoucherDiscount() {
		return voucherDiscount;
	}

	public void setVoucherDiscount(BigDecimal voucherDiscount) {
		this.voucherDiscount = voucherDiscount;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public BigDecimal getShippingFee() {
		return shippingFee;
	}

	public void setShippingFee(BigDecimal shippingFee) {
		this.shippingFee = shippingFee;
	}

	public BigDecimal getPackagingFee() {
		return packagingFee;
	}

	public void setPackagingFee(BigDecimal packagingFee) {
		this.packagingFee = packagingFee;
	}

	public String getDeliveryName() {
		return deliveryName;
	}

	public void setDeliveryName(String deliveryName) {
		this.deliveryName = deliveryName;
	}

	public String getDeliveryPhone() {
		return deliveryPhone;
	}

	public void setDeliveryPhone(String deliveryPhone) {
		this.deliveryPhone = deliveryPhone;
	}

	public Integer getDeliveryMethod() {
		return deliveryMethod;
	}

	public void setDeliveryMethod(Integer deliveryMethod) {
		this.deliveryMethod = deliveryMethod;
	}

	public Date getDeliveryDate() {
		return deliveryDate;
	}

	public void setDeliveryDate(Date deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	public Integer getDeliveryPeriod() {
		return deliveryPeriod;
	}

	public void setDeliveryPeriod(Integer deliveryPeriod) {
		this.deliveryPeriod = deliveryPeriod;
	}

	public String getDeliveryPeriodDesc() {
		return deliveryPeriodDesc;
	}

	public void setDeliveryPeriodDesc(String deliveryPeriodDesc) {
		this.deliveryPeriodDesc = deliveryPeriodDesc;
	}

	public String getDeliveryInstruction() {
		return deliveryInstruction;
	}

	public void setDeliveryInstruction(String deliveryInstruction) {
		this.deliveryInstruction = deliveryInstruction;
	}

	public String getInvoiceTitle() {
		return invoiceTitle;
	}

	public void setInvoiceTitle(String invoiceTitle) {
		this.invoiceTitle = invoiceTitle;
	}

	public int getInvoiceType() {
		return invoiceType;
	}

	public void setInvoiceType(int invoiceType) {
		this.invoiceType = invoiceType;
	}

	public String getInvoicePdfUrl() {
		return invoicePdfUrl;
	}

	public void setInvoicePdfUrl(String invoicePdfUrl) {
		this.invoicePdfUrl = invoicePdfUrl;
	}

	public String getTcNumber() {
		return tcNumber;
	}

	public void setTcNumber(String tcNumber) {
		this.tcNumber = tcNumber;
	}

	public Integer getTcSequenceNumber() {
		return tcSequenceNumber;
	}

	public void setTcSequenceNumber(Integer tcSequenceNumber) {
		this.tcSequenceNumber = tcSequenceNumber;
	}

	public Integer getTcRegisterNumber() {
		return tcRegisterNumber;
	}

	public void setTcRegisterNumber(Integer tcRegisterNumber) {
		this.tcRegisterNumber = tcRegisterNumber;
	}

	public Date getTcTransTime() {
		return tcTransTime;
	}

	public void setTcTransTime(Date tcTransTime) {
		this.tcTransTime = tcTransTime;
	}

	public int getCancelReason() {
		return cancelReason;
	}

	public void setCancelReason(int cancelReason) {
		this.cancelReason = cancelReason;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public int getPayType() {
		return payType;
	}

	public void setPayType(int payType) {
		this.payType = payType;
	}

	public Date getPaidTime() {
		return paidTime;
	}

	public void setPaidTime(Date paidTime) {
		this.paidTime = paidTime;
	}

	public Date getCompletedTime() {
		return completedTime;
	}

	public void setCompletedTime(Date completedTime) {
		this.completedTime = completedTime;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public Integer getItemSize() {
		return itemSize;
	}

	public void setItemSize(Integer itemSize) {
		this.itemSize = itemSize;
	}


}
