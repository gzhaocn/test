package com.mpush.mpns.web.config;

import javax.sql.DataSource;

import org.h2.Driver;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScan.Filter;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;
import org.springframework.stereotype.Controller;

import com.mpush.api.push.PushSender;
import com.mpush.api.spi.common.ServiceDiscoveryFactory;
import com.mpush.api.srd.ServiceDiscovery;
import com.mpush.mpns.web.boot.AppServer;

import io.vertx.core.Vertx;

@Configuration
// @ImportResource("classpath:spring-core.xml")
@ComponentScan(value = "com.mpush.mpns", excludeFilters = { @Filter(Controller.class) })
public class SpringConfig {
	private static AppServer SERVER;
	private static Vertx VERTX;
	private static AnnotationConfigApplicationContext CTX;

	public static void init(io.vertx.core.Vertx vertx, AppServer server) {
		// VERTX = Vertx.newInstance(vertx);
		VERTX = vertx;
		SERVER = server;
		CTX = new AnnotationConfigApplicationContext(SpringConfig.class);
	}

	public static void scanHandler() {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.setParent(CTX);
		context.scan("com.mpush.mpns.web.handler");
		context.refresh();
	}

	@Bean
	public DataSource dataSource() {
		SimpleDriverDataSource dataSource = new SimpleDriverDataSource();
		dataSource.setDriverClass(Driver.class);
		dataSource.setUrl("jdbc:h2:file:/tmp/.h2/mpush;MODE=MySQL;AUTO_SERVER=TRUE;DB_CLOSE_DELAY=-1");
		dataSource.setUsername("mpush");
		dataSource.setPassword("mpush");
		return dataSource;
	}
	

	@Bean(initMethod = "start", destroyMethod = "stop")
	public ServiceDiscovery serviceDiscovery() {
		return ServiceDiscoveryFactory.create();
	}

	@Bean(initMethod = "start", destroyMethod = "stop")
	public PushSender pushSender() {
		return com.mpush.api.push.PushSender.create();
	}

	@Bean(name = "VERTX", destroyMethod = "close")
	public Vertx vertx() {
		return VERTX;
	}

	@Bean(name = "SERVER", destroyMethod = "stop")
	public AppServer server() {
		return SERVER;
	}

}