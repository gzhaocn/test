package com.mpush.custom.server;

import com.alibaba.fastjson.JSONObject;
import com.mpush.api.connection.Connection;
import com.mpush.api.protocol.Packet;
import com.mpush.common.handler.BaseMessageHandler;
import com.mpush.common.message.AckMessage;
import com.mpush.common.message.PushMessage;
import com.mpush.common.message.gateway.GatewayPushMessage;
import com.mpush.core.push.PushCenter;
import com.mpush.tools.log.Logs;

public class WebSocketPushHandler extends BaseMessageHandler<PushMessage> {

	@Override
	public PushMessage decode(Packet packet, Connection connection) {
		return new PushMessage(packet, connection);
	}

	@Override
	public void handle(PushMessage message) {
		Logs.PUSH.info("receive client push message={}", message);

		if (message.autoAck()) {
			AckMessage.from(message).sendRaw();
			Logs.PUSH.info("send ack for push message={}", message);
		}

		GatewayPushMessage msg = new GatewayPushMessage(message.getPacket(), message.getConnection());
		JSONObject json = message.getPacket().getBody();
		msg.setUserId(json.remove("userId").toString());
		msg.setClientType(2);
		msg.setContent(json.toJSONString().getBytes());
		PushCenter.I.push(msg);
	}

}
