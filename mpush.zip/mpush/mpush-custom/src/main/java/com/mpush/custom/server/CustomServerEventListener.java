package com.mpush.custom.server;

import static io.netty.handler.codec.http.HttpVersion.HTTP_1_1;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.eventbus.Subscribe;
import com.mpush.api.ServerEventListener;
import com.mpush.api.event.KickUserEvent;
import com.mpush.api.event.RouterChangeEvent;
import com.mpush.api.event.ServerShutdownEvent;
import com.mpush.api.event.ServerStartupEvent;
import com.mpush.api.event.UserOfflineEvent;
import com.mpush.api.event.UserOnlineEvent;
import com.mpush.api.spi.Spi;
import com.mpush.api.spi.core.ServerEventListenerFactory;
import com.mpush.netty.http.HttpCallback;
import com.mpush.netty.http.HttpClient;
import com.mpush.netty.http.NettyHttpClient;
import com.mpush.netty.http.RequestContext;
import com.mpush.tools.config.CC;
import com.mpush.tools.event.EventBus;
import com.typesafe.config.ConfigFactory;

import io.netty.buffer.ByteBuf;
import io.netty.handler.codec.http.DefaultFullHttpRequest;
import io.netty.handler.codec.http.FullHttpRequest;
import io.netty.handler.codec.http.FullHttpResponse;
import io.netty.handler.codec.http.HttpMethod;
import io.netty.handler.codec.http.HttpResponse;
import io.netty.util.CharsetUtil;

@Spi(order = 0)
public class CustomServerEventListener implements ServerEventListener, ServerEventListenerFactory {
	private final static Logger LOGGER = LoggerFactory.getLogger(CustomServerEventListener.class);

	private final HttpClient httpClient = NettyHttpClient.I();

	@Override
	public ServerEventListener get() {
		EventBus.I.register(this);
		ConfigFactory.load();
		return this;
	}

	@Override
	@Subscribe
	public void on(ServerStartupEvent event) {
		LOGGER.info("服务开启");
	}

	@Override
	@Subscribe
	public void on(ServerShutdownEvent server) {
		LOGGER.info("服务关闭");
	}

	@Override
	@Subscribe
	public void on(RouterChangeEvent event) {
		LOGGER.info("路由更改");
	}

	@Override
	@Subscribe
	public void on(KickUserEvent event) {
		LOGGER.info("踢掉用户：" + event.userId);
	}

	@Override
	@Subscribe
	public void on(UserOfflineEvent event) {

		LOGGER.info("用户下线:" + event.getUserId());
	}

	@Override
	@Subscribe
	public void on(UserOnlineEvent event) {
		LOGGER.info("用户上线:" + event.getUserId());
		String url = CC.mp.http.offile_user_push_host + event.getUserId();
		FullHttpRequest request = new DefaultFullHttpRequest(HTTP_1_1, HttpMethod.valueOf("GET"), url);
		RequestContext rc = new RequestContext(request, new HttpCallback() {

			@Override
			public void onTimeout() {
			}

			@Override
			public void onResponse(HttpResponse response) {
				ByteBuf content = ((FullHttpResponse) response).content();
				if (content != null && content.readableBytes() > 0) {
					byte[] body = new byte[content.readableBytes()];
					content.readBytes(body);
					LOGGER.info(new String(body, CharsetUtil.UTF_8));
				}
			}

			@Override
			public boolean onRedirect(HttpResponse response) {
				return false;
			}

			@Override
			public void onFailure(int statusCode, String reasonPhrase) {
			}

			@Override
			public void onException(Throwable throwable) {
			}
		});
		try {
			httpClient.request(rc);
		} catch (Exception e) {
			LOGGER.info("http request error.", e);
		}
	}
}
