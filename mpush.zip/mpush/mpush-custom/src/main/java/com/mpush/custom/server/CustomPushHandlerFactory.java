package com.mpush.custom.server;

import com.mpush.api.MessageHandler;
import com.mpush.api.spi.Spi;
import com.mpush.api.spi.handler.PushHandlerFactory;

@Spi(order = 0)
public class CustomPushHandlerFactory implements PushHandlerFactory {
	private volatile WebSocketPushHandler webSocketPushHandler;

	@Override
	public MessageHandler get() {
		if (webSocketPushHandler == null) {
			synchronized (this) {
				if (webSocketPushHandler == null) {
					webSocketPushHandler = new WebSocketPushHandler();
				}
			}
		}
		return webSocketPushHandler;
	}
}
