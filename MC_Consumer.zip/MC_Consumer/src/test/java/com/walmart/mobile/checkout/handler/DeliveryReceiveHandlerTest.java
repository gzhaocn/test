package com.walmart.mobile.checkout.handler;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;

import com.walmart.mobile.checkout.BaseTest;
import com.walmart.mobile.checkout.deliveryMapper.DeliveryLineMapper;
import com.walmart.mobile.checkout.deliveryMapper.DeliveryMapper;
import com.walmart.mobile.checkout.handler.receive.DeliveryReceiveHandler;
import com.walmart.mobile.checkout.service.DeliveryService;
import com.walmart.mobile.checkout.utils.PropertyUtils;

public class DeliveryReceiveHandlerTest extends BaseTest {

	@Autowired
	@InjectMocks
	private DeliveryService deliveryService;

	@Mock
	private DeliveryMapper deliveryMapper;

	@Mock
	private DeliveryLineMapper deliveryLineMapper;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Autowired
	@InjectMocks
	private DeliveryReceiveHandler deliveryReceiveHandler;

	@Test
	public void processDeliveryTest() throws Exception {
		deliveryReceiveHandler.processDelivery(PropertyUtils.getConfigValue("test.delivery.create"), null);
	}
}
