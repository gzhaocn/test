package credit;

import java.util.UUID;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.config.MainConfig;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.service.CreditInfoService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MainConfig.class })
@WebAppConfiguration
public class CreditInfoTest {

	@Autowired
	CreditInfoService creditInfoService;

	@Test
	public void refreshBlackState() throws GlobalErrorInfoException {
		// 如果一个 dag 的 user_credit_info 有10万条记录，每次查询更新 100 个 blacklist 用时约 50ms
		JSONObject data = new JSONObject();
		JSONArray add = new JSONArray();
		// for (int i = 0; i < 1000; i++) {
		// add.add(getRandomIdNumber());
		// }
		// add.add("8Oncw+5/YXEZ2arhoNTGJDK/3GV+5S2MNAPQcWGqr/g=");
		JSONArray delete = new JSONArray();
		delete.add("8Oncw+5/YXEZ2arhoNTGJDK/3GV+5S2MNAPQcWGqr/g=");
		data.put("add", add);
		data.put("delete", delete);
		creditInfoService.refreshBlackState(data.toString());
	}

	private String getRandomIdNumber() {
		UUID uuid = UUID.randomUUID();
		return uuid.toString();
	}

}
