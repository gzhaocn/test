package com.walmart.mobile.checkout.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSON;
import com.walmart.mobile.checkout.bean.PushMessage;
import com.walmart.mobile.checkout.bean.PushMessageVo;

@Service("pushService")
public class PushService {

	private static final Logger LOG = LoggerFactory.getLogger(PushService.class);

	@Autowired
	RestTemplate restTemplate;

	@Value("${push.url}")
	private String pushUrl;

	public void push(String pushMessage) throws Exception {

		LOG.info("push receive message {}", pushMessage);

		PushMessage pushMessage2 = JSON.parseObject(pushMessage, PushMessage.class);
		List<String> userIds = pushMessage2.getUserIds();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		/**
		 * "{\"userId\":\"user-0\",\"hello\":\"中文\",\"broadcast\":\"false\",\"condition\":\"ewrtewr\"}"
		 * ;
		 */
		try {
			for (String userId : userIds) {
				PushMessageVo pushMessageVo = new PushMessageVo();
				pushMessageVo.setUserId(userId);
				pushMessageVo.setContent(pushMessage2.getContent());
				pushMessageVo.setBroadcast(pushMessage2.getBroadcast());
				String json = JSON.toJSON(pushMessageVo).toString();
				HttpEntity<String> entity = new HttpEntity<>(json, headers);
				restTemplate.postForObject(pushUrl, entity, String.class);
				
				LOG.info("process push success ,push url is {}, send push message : {}", pushUrl, json);
			}
		} catch (Exception e) {
			LOG.error("process push error : ", e);
			throw new Exception(e);
		}

	}

}
