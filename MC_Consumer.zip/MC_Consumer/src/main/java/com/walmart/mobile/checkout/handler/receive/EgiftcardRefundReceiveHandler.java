package com.walmart.mobile.checkout.handler.receive;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.handler.annotation.Headers;

import com.walmart.mobile.checkout.annotation.JmsHandler;
import com.walmart.mobile.checkout.annotation.JmsRetry;
import com.walmart.mobile.checkout.service.EgiftcardRefundService;

@JmsHandler
public class EgiftcardRefundReceiveHandler {

	@Autowired
	private EgiftcardRefundService egiftcardRefundService;

	@JmsListener(destination = "${egiftcard.refund.queue.name}")
	@JmsRetry(3)
	public void processEgiftcardRefund(String egiftcardRefundMessage, @Headers Map<String, Object> headers) throws Exception {
		egiftcardRefundService.processEgiftcardRefund(egiftcardRefundMessage);
	}

}
