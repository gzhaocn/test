package com.walmart.mobile.checkout.constant;

import com.walmart.mobile.checkout.utils.PropertyUtils;

public class WechatConstants {

	private WechatConstants() {
	}
	
	public static String REFUND_API = "https://api.mch.weixin.qq.com/secapi/pay/refund";

	public static String REFUND_QUERY_API = "https://api.mch.weixin.qq.com/pay/refundquery";

	public static String HttpsRequestClassName = "com.walmart.mobile.checkout.utils.wechat.HttpsRequest";
	
	public static String H5HttpsRequestClassName = "com.walmart.mobile.checkout.utils.wechat.WechatH5HttpsRequest";
	
	private static  String key;

	// 微信分配的公众号ID（开通公众号之后可以获取到）
	private static  String appID;



	// 微信支付分配的商户号ID（开通公众号的微信支付功能之后可以获取到）
	private static  String mchID;

	// 受理模式下给子商户分配的子商户号
	private static String subMchID = "";
	
	// HTTPS证书的本地路径
	private static  String certLocalPath;

	// HTTPS证书密码，默认密码等于商户号MCHID
	private static  String certPassword;

	// 支付Key
	private static  String payKey;

	// 支付api
	private static  String payApi;




	private static  String h5AppID;
	private static  String h5AppKey;
	private static  String h5MchID;
	private static  String h5CertLocalPath;
	private static  String h5CertPassword;

	static {

		key = PropertyUtils.getConfigValue("weixin.key");
		payKey = PropertyUtils.getConfigValue("weixin.paykey");
		appID = PropertyUtils.getConfigValue("weixin.appid");
		mchID = PropertyUtils.getConfigValue("weixin.mch_id");
		certLocalPath = PropertyUtils.getConfigValue("weixin.certLocalPath");
		certPassword = PropertyUtils.getConfigValue("weixin.certPassword");

		h5AppID = PropertyUtils.getConfigValue("weixin.h5.appid");
		h5AppKey = PropertyUtils.getConfigValue("weixin.h5.key");
		h5MchID = PropertyUtils.getConfigValue("weixin.h5.mch_id");
		h5CertLocalPath = PropertyUtils.getConfigValue("weixin.h5.certLocalPath");
		h5CertPassword = PropertyUtils.getConfigValue("weixin.h5.certPassword");
	}

	public static String getKey() {
		return key;
	}

	public static String getPayKey() {
		return payKey;
	}

	public static String getAppid() {
		return appID;
	}

	public static String getMchid() {
		return mchID;
	}

	public static String getCertLocalPath() {
		return certLocalPath;
	}

	public static String getCertPassword() {
		return certPassword;
	}

	public static String getPayApi() {
		return payApi;
	}


	

	public static String getH5AppID() {
		return h5AppID;
	}

	public static String getH5AppKey() {
		return h5AppKey;
	}

	public static String getH5MchID() {
		return h5MchID;
	}

	public static String getH5CertLocalPath() {
		return h5CertLocalPath;
	}

	public static String getH5CertPassword() {
		return h5CertPassword;
	}


	public static String getAppID() {
		return appID;
	}

	public static void setAppID(String appID) {
		WechatConstants.appID = appID;
	}

	public static String getMchID() {
		return mchID;
	}

	public static void setMchID(String mchID) {
		WechatConstants.mchID = mchID;
	}

	public static String getSubMchID() {
		return subMchID;
	}

	public static void setSubMchID(String subMchID) {
		WechatConstants.subMchID = subMchID;
	}

	
	public static void setKey(String key) {
		WechatConstants.key = key;
	}

	public static void setCertLocalPath(String certLocalPath) {
		WechatConstants.certLocalPath = certLocalPath;
	}

	public static void setCertPassword(String certPassword) {
		WechatConstants.certPassword = certPassword;
	}

	public static void setPayKey(String payKey) {
		WechatConstants.payKey = payKey;
	}

	public static void setPayApi(String payApi) {
		WechatConstants.payApi = payApi;
	}


	public static void setH5AppID(String h5AppID) {
		WechatConstants.h5AppID = h5AppID;
	}

	public static void setH5AppKey(String h5AppKey) {
		WechatConstants.h5AppKey = h5AppKey;
	}

	public static void setH5MchID(String h5MchID) {
		WechatConstants.h5MchID = h5MchID;
	}

	public static void setH5CertLocalPath(String h5CertLocalPath) {
		WechatConstants.h5CertLocalPath = h5CertLocalPath;
	}

	public static void setH5CertPassword(String h5CertPassword) {
		WechatConstants.h5CertPassword = h5CertPassword;
	}
	
}
