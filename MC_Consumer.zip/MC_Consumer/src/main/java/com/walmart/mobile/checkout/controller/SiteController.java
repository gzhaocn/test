package com.walmart.mobile.checkout.controller;

import io.swagger.annotations.ApiOperation;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@Controller

public class SiteController {
	 String svnVersion = null;
	 private static final Logger LOG = LoggerFactory.getLogger(SiteController.class);
	 
	 
	@ApiOperation(value = "/", notes = "首页" ,hidden=true)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public Object index() {
		return "{msg:hi}";
	}
	@ApiOperation(value = "/version", notes = "查看版本号",hidden=true)
	@RequestMapping(value = "/version", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public Object getFileRevision() {
		if (svnVersion == null) {
			InputStream stream = null;
			try {
				stream = this.getClass().getResourceAsStream("/misc.properties");
				Properties props = new Properties();
				props.load(stream);
				svnVersion = props.getProperty("svn.file.revision");
			} catch (IOException e) {
				LOG.error("the properties is not found",e);
				svnVersion = "(null)";
			} finally {
				IOUtils.closeQuietly(stream);

			}
		}
		return "SVN Revision is: " + svnVersion;
	}

}
