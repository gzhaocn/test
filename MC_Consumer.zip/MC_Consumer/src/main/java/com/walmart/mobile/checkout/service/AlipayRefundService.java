package com.walmart.mobile.checkout.service;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.walmart.mobile.checkout.constant.RefundStatus;
import com.walmart.mobile.checkout.utils.DateUtil;
import com.walmart.mobile.checkout.utils.alipay.RSA;
import com.walmart.mobile.checkout.utils.alipay.config.AlipayConfig;
import com.walmart.mobile.checkout.utils.alipay.config.AlipayCore;

@Service("alipayRefundService")
public class AlipayRefundService {

	private static final Logger LOG = LoggerFactory.getLogger(AlipayRefundService.class);

	private static final String REFUND_SUCCESS_FLAG = "T";
	
	// 请求URL必须使用UTF-8编码，否则Alipay SIGN时会存在获取平台编码进行字符串解析，导致签名错误。
	private static final String REQUEST_PARAMETER_ENCODING = "UTF-8";
	
	@Value("${alipay.refund.notify_url}")
	String alipayRefundNotificationUrl;
	
	
	public void processAlipayRefund(String alipayRefundMessage) throws Exception {
		
	
	}

	
	public int alipayRefundRequest(String tradeId,  String returnAmount, String batchNo, Integer orderType) throws ClientProtocolException, IOException, DocumentException {
		String url = spellAlipayRefundUrl(tradeId, returnAmount, batchNo, orderType);
		return sendRefundRequest(url);
	}
	
	private String spellAlipayRefundUrl(String tradeId, String returnAmount, String batchNo, Integer orderType) throws UnsupportedEncodingException {
		StringBuilder sb = new StringBuilder();
		sb.append(AlipayConfig.httpsURL + "?");

		Map<String, String> urlParams = getAlipayRefundParams(tradeId, returnAmount, batchNo, orderType);
		for (String key : urlParams.keySet()) {
			sb.append(key).append("=").append(URLEncoder.encode(urlParams.get(key), REQUEST_PARAMETER_ENCODING)).append("&");
		}
		return sb.substring(0, sb.length() - 1);
	}
	
	
	private int sendRefundRequest(String url) throws ClientProtocolException, IOException, DocumentException {
		HttpGet httpGet = new HttpGet(url);
		CloseableHttpClient httpclient = HttpClients.createDefault();
		CloseableHttpResponse response = null;

		try {
			response = httpclient.execute(httpGet);
			if (response.getStatusLine().getStatusCode() == HttpStatus.OK.value()) {
				String result = EntityUtils.toString(response.getEntity());
				LOG.info("Refund URL:{}, alipay refund result:{}", url, result);
				String success = parseAlipayRequestResult(result);
				if (REFUND_SUCCESS_FLAG.equals(success)) {
					return RefundStatus.RETURN_STATUS_REFUND_PENDING;
				}
			}
		} finally {
			IOUtils.closeQuietly(response);
			IOUtils.closeQuietly(httpclient);
		}
		return RefundStatus.RETURN_STATUS_REFUND_FAILED;
	}
	
	private String parseAlipayRequestResult(String result) throws DocumentException {
		Document document = DocumentHelper.parseText(result);
		Element root = document.getRootElement();
		@SuppressWarnings("unchecked")
		List<Element> list = root.elements("is_success");
		return list.get(0).getText();
	}
	
	
	/**
	 * 组装alipayRefund参数
	 * 
	 * @param tradeId
	 * @param returnAmount
	 * @param orderId
	 * @param batchNo
	 * @param orderType
	 * @return
	 */
	private Map<String, String> getAlipayRefundParams(String tradeId, String returnAmount, String batchNo, Integer orderType) {
		Map<String, String> resultMap = new HashMap<>();
		resultMap.put("_input_charset", AlipayConfig.inputCharset);

		// 国内支付
		resultMap.put("service", "refund_fastpay_by_platform_nopwd");
		resultMap.put("partner", AlipayConfig.partner);
		resultMap.put("seller_email", AlipayConfig.seller);
		resultMap.put("refund_date", DateUtil.getDateTimeStr(new Date(), DateUtil.PATTERN_YYYY_MM_DD_HH_MM_SS));
		resultMap.put("batch_no", batchNo);
		resultMap.put("batch_num", String.valueOf(1));
		resultMap.put("notify_url", alipayRefundNotificationUrl);
		resultMap.put("detail_data", buildDetailData(tradeId, returnAmount));
		String sign = RSA.sign(AlipayCore.createLinkString(resultMap), AlipayConfig.privateKey, AlipayConfig.inputCharset);
		resultMap.put("sign", sign);
		resultMap.put("sign_type", AlipayConfig.signType);

		return resultMap;
	}
	
	private String buildDetailData(String tradeId, String returnAmount) {
		StringBuilder sb = new StringBuilder();
		sb.append(tradeId).append("^").append(returnAmount).append("^协商退款");
		return sb.toString();
	}
}
