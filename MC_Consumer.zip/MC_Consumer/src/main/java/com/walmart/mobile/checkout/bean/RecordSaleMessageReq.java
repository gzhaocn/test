package com.walmart.mobile.checkout.bean;

import java.io.Serializable;

public class RecordSaleMessageReq implements Serializable {

	private static final long serialVersionUID = 7422448539711116709L;

	private String orderId;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

}
