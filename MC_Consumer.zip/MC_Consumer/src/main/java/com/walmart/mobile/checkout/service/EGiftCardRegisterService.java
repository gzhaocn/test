package com.walmart.mobile.checkout.service;

import java.io.IOException;

import net.sf.json.JSONObject;
import net.sf.json.JSONSerializer;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.walmart.mobile.checkout.constant.giftcard.Const;
import com.walmart.mobile.checkout.utils.SHA512;

@Service
public class EGiftCardRegisterService {

	/** ********* Egifcard base config info ********** **/
	@Value("${card66.privateKey}")
	String privateKey;

	@Value("${card66.issuerId}")
	String issuerId;

	@Value("${card66.channel}")
	String channel;

	@Value("${card66.company}")
	String company;

	@Value("${card66.defaultCardType}")
	String defaultCardType;

	/** ********* register interface config ********** **/
	@Value("${card66.register.host}")
	String registerHost;

	@Value("${card66.register.protocol}")
	String registerProtocol;

	@Value("${card66.register.path}")
	String registerPath;

	@Value("${card66.register.type}")
	String registerType;

	/** ********* modify interface config ********** **/
	@Value("${card66.modify.host}")
	String modifyHost;

	@Value("${card66.modify.protocol}")
	String modifyProtocol;

	@Value("${card66.modify.path}")
	String modifyPath;

	@Value("${card66.modify.type}")
	String modifyType;

	private static final Logger LOG = LoggerFactory.getLogger(EGiftCardRegisterService.class);

	public int register(String mobliePhone) throws Exception {
		LOG.info("str register EGiftCard . mobliePhone={}", mobliePhone);
		String[] values = new String[] { issuerId, mobliePhone, privateKey };

		String mac = SHA512.hashValue(StringUtils.join(values)).toUpperCase();

		java.net.URI uri = new URIBuilder().setScheme(registerProtocol).setHost(registerHost).setPath(registerPath)
				.setParameter("issuerId", issuerId).setParameter("mobliePhone", mobliePhone).setParameter("mac", mac)
				.setParameter("type", registerType).setParameter("signType", "SHA512").setParameter("channel", channel)
				.setParameter("defaultCardType", defaultCardType).build();

		return sendGetHttpRequest(uri);
	}

	public int modifyMobilePhone(String oldMoblie, String newMoblie) throws Exception {
		LOG.info("str modifyMobilePhone EGiftCard . oldMoblie={},newMoblie={}", oldMoblie, newMoblie);
		String[] values = new String[] { issuerId, oldMoblie, newMoblie, privateKey };

		String mac = SHA512.hashValue(StringUtils.join(values)).toUpperCase();

		java.net.URI uri = new URIBuilder().setScheme(modifyProtocol).setHost(modifyHost).setPath(modifyPath)
				.setParameter("issuerId", issuerId).setParameter("oldMoblie", oldMoblie).setParameter("mac", mac)
				.setParameter("signType", "SHA512").setParameter("newMoblie", newMoblie)
				.setParameter("type", modifyType).setParameter("channel", channel).build();

		return sendGetHttpRequest(uri);
	}

	private int sendGetHttpRequest(java.net.URI uri) {
		LOG.info("str sendGetHttpRequest EGiftCard .");
		String msg = null;
		int code = -1;
		CloseableHttpResponse response = null;
		CloseableHttpClient closeableHttpClient = HttpClients.createDefault();
		try {
			response = closeableHttpClient.execute(new HttpGet(uri));
			if (response.getStatusLine().getStatusCode() == 200) {
				String result = EntityUtils.toString(response.getEntity());

				JSONObject obj = (JSONObject) JSONSerializer.toJSON(result);

				if (obj.containsKey(Const.RESULT_KEY_CODE)) {
					code = obj.getInt(Const.RESULT_KEY_CODE);
				}

				if (obj.containsKey(Const.RESULT_KEY_MSG)) {
					msg = obj.getString(Const.RESULT_KEY_MSG);
				}

				LOG.info("code:{}, msg:{}, result:{}", code, msg, result);
			}

		} catch (IOException ex) {
			LOG.error("sendGetHttpRequest", ex);
		} finally {
			IOUtils.closeQuietly(response);
			IOUtils.closeQuietly(closeableHttpClient);
		}
		LOG.info("end sendGetHttpRequest EGiftCard . code={}", code);
		return code;
	}
}
