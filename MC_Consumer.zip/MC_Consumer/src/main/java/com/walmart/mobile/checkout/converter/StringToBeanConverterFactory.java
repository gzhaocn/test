package com.walmart.mobile.checkout.converter;

import org.springframework.core.convert.TypeDescriptor;
import org.springframework.core.convert.converter.ConditionalConverter;
import org.springframework.core.convert.converter.Converter;
import org.springframework.core.convert.converter.ConverterFactory;

public class StringToBeanConverterFactory implements ConverterFactory<String, Object>, ConditionalConverter {

	@Override
	public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType) {
		if (targetType.equals(TypeDescriptor.valueOf(String.class))) {
			return false;
		}
		return sourceType.equals(TypeDescriptor.valueOf(String.class)) && targetType.getSource() instanceof Object;
	}

	@Override
	public <T> Converter<String, T> getConverter(Class<T> targetType) {
		return new StringToBeanConverter<>(targetType);
	}
}
