package com.walmart.mobile.checkout.handler.receive;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import com.walmart.mobile.checkout.annotation.JmsHandler;
import com.walmart.mobile.checkout.annotation.JmsRetry;
import com.walmart.mobile.checkout.service.CreditInfoService;

@JmsHandler
public class CreditInfoRefreshReceiveHandler {
	private static final Logger LOGGER = LoggerFactory.getLogger(CreditInfoRefreshReceiveHandler.class);

	@Autowired
	private CreditInfoService creditInfoService;

	@JmsListener(destination = "${blacklist.queue.name}")
	@JmsRetry(1)
	public void refreshBlackState(String blacklistMessage) throws Exception {
		LOGGER.info("start to refresh blackState in userCreditInfo");
		creditInfoService.refreshBlackState(blacklistMessage);
	}

}
