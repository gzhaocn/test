
package com.walmart.mobile.checkout.utils.ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for anonymous complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="RECSMSEx_UTF8Result" type="{http://tempuri.org/}ArrayOfMOBody" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "recsmsExUTF8Result" })
@XmlRootElement(name = "RECSMSEx_UTF8Response")
public class RECSMSExUTF8Response {

	@XmlElement(name = "RECSMSEx_UTF8Result")
	protected ArrayOfMOBody recsmsExUTF8Result;

	/**
	 * Gets the value of the recsmsExUTF8Result property.
	 * 
	 * @return possible object is {@link ArrayOfMOBody }
	 * 
	 */
	public ArrayOfMOBody getRECSMSExUTF8Result() {
		return recsmsExUTF8Result;
	}

	/**
	 * Sets the value of the recsmsExUTF8Result property.
	 * 
	 * @param value
	 *            allowed object is {@link ArrayOfMOBody }
	 * 
	 */
	public void setRECSMSExUTF8Result(ArrayOfMOBody value) {
		this.recsmsExUTF8Result = value;
	}

}
