package com.walmart.mobile.checkout.utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateUtil {
	
	

	public static final String PATTERN_YYYYMMDDHHMMS6 = "yyyyMMddHHmmssSSS";
	public static final String PATTERN_YYYYMMDDHHMMSS = "yyyyMMddHHmmss";
	public static final String PATTERN_YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
	public static final String PATTERN_YYYYMMDD = "yyyyMMdd";
	public static final String PATTERN_YYYY_MM_DD_HH_MM_SS_CN = "yyyy/MM/dd HH:mm:ss";

	public static final String DATE_FORMAT_PATTERN_YYYYMMDDHHMMSS = "yyyyMMddHHmmss";
	public static final String DATE_FORMAT_PATTERN_DATE = "yyyy-MM-dd";
	public static final String DATE_FORMAT_PATTERN_DATE_1 = "yyyy/MM/dd HH:mm:ss.SSS";
	public static final String DATE_FORMAT_PATTERN = "yyyy-MM-dd HH:mm:ss";
	public static final String DATE_TIME_PART_MIN_STR = " 00:00:00";
	public static final String DATE_TIME_PART_MAX_STR = " 23:59:59";

	public static final String DATE_TIME_HISTORY_MIN_STR = "2000-01-01";

	private static final long DELTA;

	public static final long DAY_MILLI_SECS = 24 * 60 * 60 * 1000;

	
	private DateUtil(){}
	
	static {

		Calendar instance = Calendar.getInstance();

		DELTA = -(instance.get(Calendar.ZONE_OFFSET) + instance.get(Calendar.DST_OFFSET));
	}

	public static Date getZeroTime(Date date) {
		if (date == null) {
			date = new Date();
		}

		long milliSecs = date.getTime();

		return new Date(milliSecs - ((milliSecs - DELTA) % DAY_MILLI_SECS));
	}

	public static Date getDateZeroTime(final Date date) {
		if (date == null) {
			return null;
		}

		long milliSecs = date.getTime();

		return new Date(milliSecs - ((milliSecs - DELTA) % DAY_MILLI_SECS));
	}

	public static long getIntevalOfZeroTime(Date date) {
		if (date == null) {
			date = new Date();
		}
		return date.getTime() - getZeroTime(date).getTime();
	}

	/**
	 * 以指定的格式来格式化日期
	 * 
	 * @param date
	 * @param format
	 * @return
	 */
	public static String formatDateByFormat(java.util.Date date, String format) {
		String result = "";
		if (date != null) {
			try {
				SimpleDateFormat sdf = new SimpleDateFormat(format);
				result = sdf.format(date);
			} catch (Exception ex) {
				// do nothing
			}
		}
		return result;
	}

	public static String getDateTimeStr(Date date, String pattern) {
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		return sdf.format(date);
	}

	public static String getDateTimeStr(String pattern) {
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		return sdf.format(Calendar.getInstance().getTime());
	}

	public static Long getDateTime(String pattern) {
		return Long.parseLong(getDateTimeStr(pattern));
	}

}
