package com.walmart.mobile.checkout.service;

import java.security.NoSuchAlgorithmException;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.bean.QueryOrderParamter;
import com.walmart.mobile.checkout.constant.AppConstants;
import com.walmart.mobile.checkout.exception.ApplicationException;
import com.walmart.mobile.checkout.utils.SHA512;

@Service("orderStatusService")
public class OrderStatusService {

	private static final Logger LOG = LoggerFactory.getLogger(OrderStatusService.class);


	@Autowired
	RestTemplate restTemplate;

	@Value("${order.complete.url}")
	private String orderCompleteUrl;

	@Value("${order.status.url}")
	private String orderStatusUrl;

	public static final int PAID = 30;


	public void updateOrderStatus(String orderId) throws ApplicationException {
		
		String queryOrderResult = getOrderInfo(orderId);
		LOG.info("order queryOrderResult {}  ", queryOrderResult);
		JSONObject orderStatusResult = JSON.parseObject(queryOrderResult);
		String code = orderStatusResult.getString("code");
			
		if ("0".endsWith(code)) {
				String orderInformation = orderStatusResult.getString("result");
				JSONObject orderInformationObject = JSON.parseObject(orderInformation);
				Integer status = orderInformationObject.getInteger("status");
				LOG.info("order query result code:{} , order status :{}", code, status);
				if(status == PAID){
					compeleteOrderMessage(orderId);
				}
			} else {
				throw new ApplicationException("query order data  fail");
			}
			
		}
	

	private void compeleteOrderMessage( String orderId) throws ApplicationException {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		QueryOrderParamter queryOrderParamter =getQueryOrderParamter(orderId);
		HttpEntity<String> queryOrderParamterEntity = new HttpEntity<>(JSON.toJSONString(queryOrderParamter), headers);
		String result = restTemplate.postForObject(orderCompleteUrl, queryOrderParamterEntity, String.class);
		LOG.info("consumer recordsale result : {}", result);
		JSONObject orderStatusResult = JSON.parseObject(result);
		String code = orderStatusResult.getString("code");
		if (!"0".equals(code)) {
			throw new ApplicationException("orderId: " + orderId + ", order update fail ,result msg: " + result,
					-1);
		}
	}

	private String getOrderInfo(String orderId  ) throws ApplicationException {

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		QueryOrderParamter queryOrderParamter =getQueryOrderParamter(orderId);
		HttpEntity<String> queryOrderParamterEntity = new HttpEntity<>(JSON.toJSONString(queryOrderParamter), headers);
		return restTemplate.postForObject(orderStatusUrl, queryOrderParamterEntity, String.class);

	}

	
	private QueryOrderParamter getQueryOrderParamter(String orderId ) throws ApplicationException{
		QueryOrderParamter queryOrderParamter = new QueryOrderParamter();
		Date date = new Date();
		queryOrderParamter.setOrderId(orderId);
		queryOrderParamter.setAppKey(AppConstants.SYS_APP_KEY);
		queryOrderParamter.setFormat(AppConstants.RECORD_SALE_FORMAT);
		queryOrderParamter.setVersion(AppConstants.RECORD_SALE_VERSION);
		queryOrderParamter.setTimeStamp(date);

		StringBuilder sb = new StringBuilder();
		String signString = sb.append(AppConstants.SYS_APP_KEY).append(AppConstants.RECORD_SALE_VERSION)
				.append(AppConstants.RECORD_SALE_FORMAT).append(date).append(orderId)
				.append(AppConstants.RECORD_SALE_APPSECUERT).toString();

		String checkSign = StringUtils.EMPTY;

		try {
			checkSign = SHA512.hashValue(signString);
		} catch (NoSuchAlgorithmException e) {
			LOG.error("can't build checkSum", e);
			throw new ApplicationException("build checkSum  fail");
		}

		LOG.info("orderId : {} ,  checkSign :{} ", orderId, checkSign);

		queryOrderParamter.setSign(checkSign);
		
		return queryOrderParamter ;
	}
	

}
