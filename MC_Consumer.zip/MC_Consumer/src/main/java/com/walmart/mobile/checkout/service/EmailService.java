package com.walmart.mobile.checkout.service;

import java.util.Arrays;

import org.apache.commons.mail.Email;
import org.apache.commons.mail.SimpleEmail;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.walmart.mobile.checkout.bean.EmailBean;

@Service
public class EmailService {
	private static final Logger LOGGER = LoggerFactory.getLogger(EmailService.class);

	@Value("${mail_from_eamil}")
	private String mailFromEmail;
	@Value("${mail_from_name}")
	private String mailFromName;
	@Value("${mail_smtp_host}")
	private String mailSmtpHost;
	@Value("${mail_smtp_port}")
	private int mailSmtpPort;
	@Value("${mail_smtp_auth}")
	private Boolean mailSmtpAuth;
	@Value("${mail_smtp_username}")
	private String mailSmtpUsername;
	@Value("${mail_smtp_password}")
	private String mailSmtpPassword;
	@Value("${mail_encoding}")
	private String mailEncoding;
	@Value("${mail_smtp_ssl}")
	private Boolean mailSmtpSsl;
	@Value("${mail_summary_subject}")
	private String mailSuject;
	@Value("${mail_body_template}")
	private String mailBodyTemplate;

	private String[] administrators;

	@Value("${mail_summary_receivers}")
	public void setAdministrators(String administrators) {
		this.administrators = administrators.split(",");
	}

	public void sendEmailMsg(String body) {
		sendEmailMsg(mailSuject, body);
	}

	public void sendEmailMsg(String title, String body) {
		EmailBean message = new EmailBean();
		message.setBody(body);
		message.setTitle(title);
		message.setToMailList(administrators);
		sendEmail(message);
	}

	public void sendEmail(final EmailBean message) {
		try {
			Email email = new SimpleEmail();
			email.setHostName(mailSmtpHost);
			email.setSmtpPort(mailSmtpPort);
			email.setCharset(mailEncoding);
			if (mailSmtpAuth) {
				email.setAuthentication(mailSmtpUsername, mailSmtpPassword);
			}
			email.setSSLOnConnect(mailSmtpSsl);
			email.setFrom(mailFromEmail, mailFromName);
			email.addTo(message.getToMailList() == null ? administrators : message.getToMailList());
			email.setSubject(message.getTitle() == null ? mailSuject : message.getTitle());
			email.setMsg(String.format(mailBodyTemplate, message.getBody()));
			email.send();
		} catch (Exception e) {
			LOGGER.error(String.format(
					"Can't send alert email: Host:%s, Port:%d, User:%s, From:%s, To:%s, Subject:%s, Message:%s",
					mailSmtpHost, mailSmtpPort, mailSmtpUsername, mailFromEmail, Arrays.toString(administrators),
					mailSuject, message), e);
		}
	}
}
