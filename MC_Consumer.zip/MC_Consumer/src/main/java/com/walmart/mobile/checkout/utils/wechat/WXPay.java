package com.walmart.mobile.checkout.utils.wechat;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;

import javax.xml.parsers.ParserConfigurationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestTemplate;
import org.xml.sax.SAXException;

import com.walmart.mobile.checkout.constant.WechatConstants;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.utils.wechat.business.RefundBusiness;
import com.walmart.mobile.checkout.utils.wechat.business.RefundQueryBusiness;
import com.walmart.mobile.checkout.utils.wechat.refund.protocol.RefundReqData;
import com.walmart.mobile.checkout.utils.wechat.refund.query.protocol.RefundQueryReqData;
import com.walmart.mobile.checkout.utils.wechat.service.RefundQueryService;
import com.walmart.mobile.checkout.utils.wechat.service.RefundService;



/**
 * SDK总入口
 */
public class WXPay {

	private static final Logger LOGGER = LoggerFactory.getLogger(WXPay.class);
	/**
	 * 初始化SDK依赖的几个关键配置
	 * 
	 * @param key
	 *            签名算法需要用到的秘钥
	 * @param appID
	 *            公众账号ID
	 * @param mchID
	 *            商户ID
	 * @param sdbMchID
	 *            子商户ID，受理模式必填
	 * @param certLocalPath
	 *            HTTP证书在服务器中的路径，用来加载证书用
	 * @param certPassword
	 *            HTTP证书的密码，默认等于MCHID
	 */
	public static void initSDKConfiguration(String key, String appID, String mchID, String sdbMchID,
			String certLocalPath, String certPassword) {
		WechatConstants.setKey(key);
		WechatConstants.setAppID(appID);
		WechatConstants.setMchID(mchID);
		WechatConstants.setSubMchID(sdbMchID);
		WechatConstants.setCertLocalPath(certLocalPath);
		WechatConstants.setCertPassword(certPassword);
	}

	/**
	 * 请求退款服务
	 * 
	 * @param refundReqData
	 *            这个数据对象里面包含了API要求提交的各种数据字段
	 * @return API返回的XML数据
	 * @throws Exception
	 */
	public static String requestRefundService(RefundReqData refundReqData) throws Exception {
		return new RefundService().request(refundReqData , true);
	}

	/**
	 * 请求退款查询服务
	 * 
	 * @param refundQueryReqData
	 *            这个数据对象里面包含了API要求提交的各种数据字段
	 * @return API返回的XML数据
	 * @throws Exception
	 */
	public static String requestRefundQueryService(RefundQueryReqData refundQueryReqData) throws Exception {
		return new RefundQueryService().request(refundQueryReqData,true);
	}

	/**
	 * 调用退款业务逻辑
	 * 
	 * @param refundReqData
	 *            这个数据对象里面包含了API要求提交的各种数据字段
	 * @param resultListener
	 *            业务逻辑可能走到的结果分支，需要商户处理
	 * @throws SAXException
	 * @throws ParserConfigurationException
	 * @throws IOException
	 * @throws InstantiationException
	 * @throws ClassNotFoundException
	 * @throws IllegalAccessException
	 * @throws KeyStoreException
	 * @throws NoSuchAlgorithmException
	 * @throws KeyManagementException
	 * @throws UnrecoverableKeyException
	 * @throws GlobalErrorInfoException 
	 * @throws Exception
	 */
	public static void doRefundBusiness(RefundReqData refundReqData, RefundBusiness.ResultListener resultListener)throws Exception  {
		try {
			
			new RefundBusiness().run(refundReqData, resultListener,true);
			LOGGER.info("doRefundBusiness  refundReqData: {} " ,refundReqData.getOut_refund_no());
		} catch (Exception e) {
			LOGGER.error("出错了 {}" ,e);
			throw e;
		}
	}

	/**
	 * 运行退款查询的业务逻辑
	 * 
	 * @param refundQueryReqData
	 *            这个数据对象里面包含了API要求提交的各种数据字段
	 * @param resultListener
	 *            商户需要自己监听被扫支付业务逻辑可能触发的各种分支事件，并做好合理的响应处理
	 * @throws Exception
	 */
	public static void doRefundQueryBusiness(RefundQueryReqData refundQueryReqData,
			RefundQueryBusiness.ResultListener resultListener, RestTemplate restTemplate , String refundUrl) throws Exception {
		new RefundQueryBusiness().run(refundQueryReqData, resultListener,restTemplate ,refundUrl, true);
	}

}
