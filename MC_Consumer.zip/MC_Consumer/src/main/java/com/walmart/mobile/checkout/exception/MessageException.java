package com.walmart.mobile.checkout.exception;

public class MessageException extends ApplicationException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MessageException(Throwable cause) {
		super(cause);
	}

	public MessageException(String message) {
		super(message);
	}

	public MessageException(String message, Integer code) {
		super(message, code);
	}
}
