package com.walmart.mobile.checkout.deliveryMapper;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

public interface DeliverySequenceMapper {
	@Select("select next value for ${key}")
	long getSeq(@Param("key") String key);
}
