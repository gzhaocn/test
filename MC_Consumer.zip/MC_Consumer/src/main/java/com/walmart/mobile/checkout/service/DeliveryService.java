package com.walmart.mobile.checkout.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.deliveryMapper.DeliveryLineMapper;
import com.walmart.mobile.checkout.deliveryMapper.DeliveryMapper;
import com.walmart.mobile.checkout.deliveryMapper.DeliverySequenceMapper;
import com.walmart.mobile.checkout.domain.delivery.Delivery;
import com.walmart.mobile.checkout.domain.delivery.DeliveryLine;

@Service
public class DeliveryService {

	@Value("${delivery.app.id}")
	private String appId;

	@Autowired
	private DeliveryMapper deliveryMapper;

	@Autowired
	private DeliveryLineMapper deliveryLineMapper;

	@Autowired
	private DeliverySequenceMapper deliverySequenceMapper;

	public Delivery getDelivery(String data) {
		JSONObject json = JSONObject.parseObject(data);
		Delivery delivery = JSONObject.parseObject(json.getString("delivery"), Delivery.class);
		Integer storeId = delivery.getStoreId();
		String deliveryId = getDeliveryId(storeId);
		delivery.setDeliveryId(deliveryId);
		delivery.setCreatedTime(new Date());
		delivery.setCreatedBy(delivery.getUserId());
		delivery.setStatus(5);
		return delivery;
	}

	public List<DeliveryLine> getDeliveryLine(String data, Delivery delivery) {
		JSONObject json = JSONObject.parseObject(data);
		List<DeliveryLine> deliveryLineList = JSONObject.parseArray(json.getString("orderLineList"), DeliveryLine.class);
		for (Iterator<DeliveryLine> iterator = deliveryLineList.iterator(); iterator.hasNext();) {
			DeliveryLine deliveryLine = iterator.next();
			if (!deliveryLine.isDelivery()) {
				iterator.remove();
				continue;
			}
			deliveryLine.setDeliveryId(delivery.getDeliveryId());
			deliveryLine.setOrderId(delivery.getOrderId());
			deliveryLine.setDeliveryLineId(getDeliveryLineId(delivery.getStoreId()));
		}
		return deliveryLineList;
	}

	@Transactional(rollbackFor = Exception.class, transactionManager = "deliverySqlServerTransactionManager")
	public void createDelivery(Delivery delivery, List<DeliveryLine> deliveryLineList) {
		deliveryMapper.insertDelivery(delivery);
		deliveryLineMapper.insertDeliveryLine(deliveryLineList);
	}

	private String getDeliveryId(Integer storeId) {
		return new StringBuilder().append(appId).append(String.format("%05d", storeId)).append(new SimpleDateFormat("yymmdd").format(new Date()))
				.append(String.format("%09d", deliverySequenceMapper.getSeq("delivery_seq"))).toString();
	}

	private String getDeliveryLineId(Integer storeId) {
		return new StringBuilder().append(appId).append(String.format("%05d", storeId)).append(new SimpleDateFormat("yymmdd").format(new Date()))
				.append(String.format("%09d", deliverySequenceMapper.getSeq("delivery_line_seq"))).toString();
	}
}
