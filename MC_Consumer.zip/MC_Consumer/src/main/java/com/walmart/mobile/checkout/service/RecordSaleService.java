package com.walmart.mobile.checkout.service;

import java.security.NoSuchAlgorithmException;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.bean.QueryOrderParamter;
import com.walmart.mobile.checkout.constant.AppConstants;
import com.walmart.mobile.checkout.exception.ApplicationException;
import com.walmart.mobile.checkout.utils.SHA512;

@Service("recordSaleService")
public class RecordSaleService {

	private static final Logger LOG = LoggerFactory.getLogger(RecordSaleService.class);

	private static final String TC_NUMBER_NULL = "#TC_NUMBER#";

	@Autowired
	RestTemplate restTemplate;

	@Value("${recordsale.url}")
	private String recordSaleUrl;

	@Value("${order.status.url}")
	private String orderStatusUrl;

	public static final int PAID = 30;
	public static final int COMPLETE = 80;

	public static final int PAID_CANCELLING = 18;

	public void processRecordSale(String recordsaleMessage) throws ApplicationException {

		JSONObject recordsaleObject = JSON.parseObject(recordsaleMessage);
		String orderId = recordsaleObject.getString("orderId");// 订单号 或者是batchNo
		String realOrderId = recordsaleObject.getString("realOrderId");
		Integer recordEvent = recordsaleObject.getInteger("recordEvent");// 订单状态

		// 正向过机，状态是30，
		// 逆向过机，状态可能是18（取消中），25（取消） ， 80 （完成）
		if (PAID == recordEvent) {
			LOG.info("recordsale, orderId:{} , batchNo(orderId) :{}", realOrderId, orderId);
			sendRcsMessage(recordsaleMessage, realOrderId);
		} else {

			LOG.info("逆向过机, orderId:{} , orderstatus : {} ", realOrderId, recordEvent);

			if (recordsaleMessage.contains(TC_NUMBER_NULL)) {

				LOG.info("reverse recordsale, orderId:{} , batchNo(orderId) :{} ,tcnumber is null ", realOrderId,
						orderId);

				String queryOrderResult = getOrderInfo(realOrderId, recordEvent);
				LOG.info("order queryOrderResult {}  ", queryOrderResult);
				JSONObject orderStatusResult = JSON.parseObject(queryOrderResult);
				String code = orderStatusResult.getString("code");

				if ("0".endsWith(code)) {
					String orderInformation = orderStatusResult.getString("result");
					JSONObject orderInformationObject = JSON.parseObject(orderInformation);
					Integer status = orderInformationObject.getInteger("status");
					String tcNumber = orderInformationObject.getString("tcNumber");
					LOG.info("order query result code:{} , order status :{} , tcNumber : {} ", code, status, tcNumber);
					String recordsaleMessageJson = setRecordSaleString(tcNumber, recordsaleMessage);
					LOG.info("send reverse recordsale string: {} ", recordsaleMessageJson);
					sendRcsMessage(recordsaleMessageJson, realOrderId);	
				} else {
					throw new ApplicationException("query order data  fail");
				}
			} else {
				LOG.info("reverse recordsale, orderId:{} , batchNo(orderId) :{} ,tcnumber is not null ", realOrderId,
						orderId);
				sendRcsMessage(recordsaleMessage, realOrderId);
			}
		}
	}

	private void sendRcsMessage(String recordsaleMessage, String orderId) throws ApplicationException {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		HttpEntity<String> entity = new HttpEntity<>(recordsaleMessage, headers);
		String result = restTemplate.postForObject(recordSaleUrl, entity, String.class);
		LOG.info("consumer recordsale result : {}", result);
		JSONObject jsonObject = JSON.parseObject(result);
		String recordsaleCode = jsonObject.getString("status");
		String description = jsonObject.getString("description");
		if (!"0".equals(recordsaleCode)) {
			throw new ApplicationException("orderId: " + orderId + ",record consumer fail ,result msg: " + description,
					-1);
		}
	}

	private String getOrderInfo(String orderId, Integer recordEvent) throws ApplicationException {

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		QueryOrderParamter queryOrderParamter = new QueryOrderParamter();
		Date date = new Date();
		queryOrderParamter.setOrderId(orderId);
		queryOrderParamter.setAppKey(AppConstants.SYS_APP_KEY);
		queryOrderParamter.setFormat(AppConstants.RECORD_SALE_FORMAT);
		queryOrderParamter.setVersion(AppConstants.RECORD_SALE_VERSION);
		queryOrderParamter.setTimeStamp(date);

		StringBuilder sb = new StringBuilder();
		String signString = sb.append(AppConstants.SYS_APP_KEY).append(AppConstants.RECORD_SALE_VERSION)
				.append(AppConstants.RECORD_SALE_FORMAT).append(date).append(orderId)
				.append(AppConstants.RECORD_SALE_APPSECUERT).toString();

		String checkSign = StringUtils.EMPTY;

		try {
			checkSign = SHA512.hashValue(signString);
		} catch (NoSuchAlgorithmException e) {
			LOG.error("can't build checkSum", e);
			throw new ApplicationException("build checkSum  fail");
		}

		LOG.info("orderId : {} ,  checkSign :{},  recordEvent:{}", orderId, checkSign, recordEvent);

		queryOrderParamter.setSign(checkSign);

		HttpEntity<String> queryOrderParamterEntity = new HttpEntity<>(JSON.toJSONString(queryOrderParamter), headers);
		return restTemplate.postForObject(orderStatusUrl, queryOrderParamterEntity, String.class);

	}

	private String setRecordSaleString(String tcNumber, String recordsaleMessage) {
		if (StringUtils.isNotBlank(tcNumber)) {
			return recordsaleMessage.replaceAll(TC_NUMBER_NULL, tcNumber);
		} else {
			return recordsaleMessage.replaceAll(TC_NUMBER_NULL, "");

		}
	}

}
