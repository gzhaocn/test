package com.walmart.mobile.checkout.config;

import java.io.IOException;

import org.apache.commons.lang.ArrayUtils;
import org.mybatis.spring.mapper.MapperScannerConfigurer;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import com.walmart.mobile.checkout.exception.ApplicationRuntimeException;
import com.walmart.mobile.checkout.utils.PropertyUtils;

@Configuration
public class ScanConfig {

	@Bean
	public PropertyPlaceholderConfigurer getPropertyPlaceholderConfigurer() {
		PropertyUtils prop = new PropertyUtils();
		prop.setSystemPropertiesModeName("SYSTEM_PROPERTIES_MODE_OVERRIDE");
		prop.setIgnoreResourceNotFound(false);
		prop.setLocations(getPorpResource());
		return prop;
	}

	public Resource[] getPorpResource() {
		String packageSearchPath = "classpath*:config/*.properties";
		Resource[] resources = null;
		try {
			resources = new PathMatchingResourcePatternResolver().getResources(packageSearchPath);
			Resource[] configs = new PathMatchingResourcePatternResolver().getResources("classpath*:activemq_config/*.properties");
			resources = (Resource[]) ArrayUtils.addAll(resources, configs);
		} catch (IOException e) {
			throw new ApplicationRuntimeException(e);
		}
		return resources;
	}

	@Bean
	public MapperScannerConfigurer userDynamicMssqlMapperScannerConfigurer() {
		MapperScannerConfigurer scanConfig = new MapperScannerConfigurer();
		scanConfig.setBasePackage("com.walmart.mobile.checkout.userMapper");
		scanConfig.setSqlSessionFactoryBeanName("userDynamicSqlServerSessionFactory");
		return scanConfig;
	}

	@Bean
	public MapperScannerConfigurer deliveryMssqlMapperScannerConfigurer() {
		MapperScannerConfigurer scanConfig = new MapperScannerConfigurer();
		scanConfig.setBasePackage("com.walmart.mobile.checkout.deliveryMapper");
		scanConfig.setSqlSessionFactoryBeanName("deliverySqlServerSessionFactory");
		return scanConfig;
	}
}
