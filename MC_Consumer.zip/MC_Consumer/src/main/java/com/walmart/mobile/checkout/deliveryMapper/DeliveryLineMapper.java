package com.walmart.mobile.checkout.deliveryMapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.InsertProvider;

import com.walmart.mobile.checkout.domain.delivery.DeliveryLine;

public interface DeliveryLineMapper {

	@InsertProvider(type = DeliveryLineProvider.class, method = "insertDeliveryLine")
	Integer insertDeliveryLine(List<DeliveryLine> deliveryLine);

	class DeliveryLineProvider {
		public String insertDeliveryLine(Map<String, List<DeliveryLine>> deliveryLineMap) {
			StringBuilder sql = new StringBuilder();
			sql.append("INSERT INTO delivery_line (delivery_line_id , delivery_id , order_id , product_id , cart_item_id , "
					+ "request_quantity , sign_quantity , upc , desc_online , pos_desc_online , department , was_price ,"
					+ " price_with_tax , price_without_tax , item_number , item_amount , item_type , store_id ) VALUES ");
			for (DeliveryLine deliveryLine : deliveryLineMap.get("list")) {
				sql.append("('" + deliveryLine.getDeliveryLineId() + "' , '").append(deliveryLine.getDeliveryId() + "' , '")
						.append(deliveryLine.getOrderId() + "' , ").append(deliveryLine.getProductId() + " , ").append(deliveryLine.getCartItemId() + " , ")
						.append(deliveryLine.getRequestQuantity() + " , ").append(deliveryLine.getSignQuantity() + " , ").append(deliveryLine.getUpc() + " , '")
						.append(deliveryLine.getDescOnline() + "' , '").append(deliveryLine.getPosDescOnline() + "' , ")
						.append(deliveryLine.getDepartment() + " , ").append(deliveryLine.getWasPrice() + " , ").append(deliveryLine.getPriceWithTax() + " , ")
						.append(deliveryLine.getPriceWithoutTax() + " , ").append(deliveryLine.getItemNumber() + " , ")
						.append(deliveryLine.getItemAmount() + " , ").append(deliveryLine.getItemType() + " , ").append(deliveryLine.getStoreId() + " ),");
			}
			return sql.substring(0, sql.length() - 1);
		}
	}
}