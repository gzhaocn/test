package com.walmart.mobile.checkout.handler.receive;

import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.handler.annotation.Headers;

import com.walmart.mobile.checkout.annotation.JmsHandler;
import com.walmart.mobile.checkout.annotation.JmsRetry;
import com.walmart.mobile.checkout.bean.PhoneMsg;
import com.walmart.mobile.checkout.service.push.GeneralPushService;

@JmsHandler
public class SmsReceiveHandler {
	private static final Logger LOGGER = LoggerFactory.getLogger(SmsReceiveHandler.class);

	@Autowired
	private GeneralPushService generalPushService;

	@JmsListener(destination = "${sms.queue.name}")
	@JmsRetry(3)
	public void processSms(PhoneMsg phoneMsg, @Headers Map<String, Object> headers) {
		LOGGER.info("send msg: {}", phoneMsg);
		if (StringUtils.isNotBlank(phoneMsg.getMobilePhone()) && StringUtils.isNotBlank(phoneMsg.getMsg())) {
			generalPushService.pushSMS(phoneMsg.getMobilePhone(), phoneMsg.getMsg());
		}else{
			LOGGER.info("phone or msg is not allow empty: {}", phoneMsg);
		}
	}

}
