package com.walmart.mobile.checkout.service;

import java.net.URISyntaxException;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.walmart.mobile.checkout.utils.SHA512;
import com.walmart.mobile.checkout.utils.egiftcard.Const;

import net.sf.json.JSONObject;
import net.sf.json.JSONSerializer;

@Service("egiftcardRefundService")
public class EgiftcardRefundService {

	private static final Logger LOG = LoggerFactory.getLogger(EgiftcardRefundService.class);

	
	@Value("${card66.refund.type}")
	String refundType;

	@Value("${card66.privateKey}")
	String privateKey;
	
	@Value("${card66.refund.protocol}")
	String refundProtocol;
	
	@Value("${card66.refund.host}")
	String refundHost;
	
	@Value("${card66.refund.path}")
	String refundPath;
	
	@Value("${card66.issuerId}")
	String issuerId;
	
	public void processEgiftcardRefund(String egiftcardRefundMessage) throws Exception {
		
	
	}
	
	
	private boolean requestEGiftRefund(String orderId,String merId, String amounts, String requestNumber) throws NoSuchAlgorithmException, URISyntaxException {

		String pType = refundType;
		String pRequestNo = requestNumber;

		String pTotalAmount = amounts;


		String pMerchantNo = merId;
		String pUserId = merId;

		String pPrivateKey = privateKey;

		String[] values = new String[] { pPrivateKey, orderId, pMerchantNo, pUserId, pTotalAmount, pRequestNo };

		String pMac = SHA512.hashValue(StringUtils.join(values)).toUpperCase();

		LOG.info("EGift refund params: privateKey={},p_orderId={},p_merchantNo={},p_userId={},p_totalAmount={},p_requestNo={},p_mac={}", pPrivateKey, orderId, pMerchantNo, pUserId, pTotalAmount,
				pRequestNo, pMac);

		java.net.URI uri = new URIBuilder().setScheme(refundProtocol).setHost(refundHost).setPath(refundPath).setParameter("mac", pMac).setParameter("type", pType)
				.setParameter("requestNo", pRequestNo).setParameter("orderId", orderId).setParameter("totalAmount", pTotalAmount).setParameter("merchantNo", pMerchantNo)
				.setParameter("issuerId", issuerId).setParameter("signType", "SHA512").setParameter("userId", pUserId).build();

		return sendGetHttpRequest(uri);
	}

	private boolean sendGetHttpRequest(java.net.URI uri) {
		if (LOG.isDebugEnabled())
			LOG.debug("uri={}", uri);
		int code = -1;

		HttpGet httpGet = new HttpGet(uri);
		CloseableHttpResponse response = null;
		CloseableHttpClient httpclient = null;
		try {
			httpclient = HttpClients.createDefault();
			response = httpclient.execute(httpGet);
			if (response.getStatusLine().getStatusCode() == HttpStatus.OK.value()) {
				String result = EntityUtils.toString(response.getEntity());
				LOG.info("result={}", result);
				JSONObject obj = (JSONObject) JSONSerializer.toJSON(result);

				if (obj.containsKey(Const.RESULT_KEY_CODE)) {
					code = obj.getInt(Const.RESULT_KEY_CODE);
				}
			} else {
				LOG.error("response.StatusLine.StatusCode={}", response.getStatusLine().getStatusCode());
			}
		} catch (Exception e) {
			LOG.error("Failed to setup http connection", e);
		} finally {
			IOUtils.closeQuietly(response);
			IOUtils.closeQuietly(httpclient);
		}
		return (code == 0) ? true : false;
	}

}
