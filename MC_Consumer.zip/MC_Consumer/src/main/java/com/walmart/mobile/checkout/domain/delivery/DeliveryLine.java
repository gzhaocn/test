package com.walmart.mobile.checkout.domain.delivery;

import java.math.BigDecimal;

import com.alibaba.fastjson.annotation.JSONField;

public class DeliveryLine {

	private String deliveryLineId;

	private String deliveryId;

	private String orderId;

	private Long productId;

	private Long cartItemId;

	@JSONField(name = "deliveryRequestQuantity")
	private Integer requestQuantity;

	private Integer signQuantity;

	private Long upc;

	private String descOnline;

	private String posDescOnline;

	private BigDecimal priceWithTax;

	private BigDecimal wasPrice;

	private BigDecimal priceWithoutTax;

	private Integer department;

	private Long itemNumber;

	private Integer itemType;

	private BigDecimal itemAmount;

	private Integer storeId;

	private Integer deliveryFlag;

	public boolean isDelivery() {
		return this.deliveryFlag == 1;
	}

	public Integer getDeliveryFlag() {
		return deliveryFlag;
	}

	public void setDeliveryFlag(Integer deliveryFlag) {
		this.deliveryFlag = deliveryFlag;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getDeliveryLineId() {
		return deliveryLineId;
	}

	public void setDeliveryLineId(String deliveryLineId) {
		this.deliveryLineId = deliveryLineId;
	}

	public String getDeliveryId() {
		return deliveryId;
	}

	public void setDeliveryId(String deliveryId) {
		this.deliveryId = deliveryId;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public Long getCartItemId() {
		return cartItemId;
	}

	public void setCartItemId(Long cartItemId) {
		this.cartItemId = cartItemId;
	}

	public Integer getRequestQuantity() {
		return requestQuantity;
	}

	public void setRequestQuantity(Integer requestQuantity) {
		this.requestQuantity = requestQuantity;
	}

	public Integer getSignQuantity() {
		return signQuantity;
	}

	public void setSignQuantity(Integer signQuantity) {
		this.signQuantity = signQuantity;
	}

	public Long getUpc() {
		return upc;
	}

	public void setUpc(Long upc) {
		this.upc = upc;
	}

	public String getDescOnline() {
		return descOnline;
	}

	public void setDescOnline(String descOnline) {
		this.descOnline = descOnline;
	}

	public String getPosDescOnline() {
		return posDescOnline;
	}

	public void setPosDescOnline(String posDescOnline) {
		this.posDescOnline = posDescOnline;
	}

	public BigDecimal getPriceWithTax() {
		return priceWithTax;
	}

	public void setPriceWithTax(BigDecimal priceWithTax) {
		this.priceWithTax = priceWithTax;
	}

	public BigDecimal getWasPrice() {
		return wasPrice;
	}

	public void setWasPrice(BigDecimal wasPrice) {
		this.wasPrice = wasPrice;
	}

	public BigDecimal getPriceWithoutTax() {
		return priceWithoutTax;
	}

	public void setPriceWithoutTax(BigDecimal priceWithoutTax) {
		this.priceWithoutTax = priceWithoutTax;
	}

	public Integer getDepartment() {
		return department;
	}

	public void setDepartment(Integer department) {
		this.department = department;
	}

	public Long getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(Long itemNumber) {
		this.itemNumber = itemNumber;
	}

	public Integer getItemType() {
		return itemType;
	}

	public void setItemType(Integer itemType) {
		this.itemType = itemType;
	}

	public BigDecimal getItemAmount() {
		return itemAmount;
	}

	public void setItemAmount(BigDecimal itemAmount) {
		this.itemAmount = itemAmount;
	}

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}
}
