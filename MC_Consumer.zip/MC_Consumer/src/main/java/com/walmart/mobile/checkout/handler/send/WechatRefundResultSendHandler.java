package com.walmart.mobile.checkout.handler.send;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.apache.activemq.ScheduledMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import com.walmart.mobile.checkout.annotation.JmsHandler;

@JmsHandler
public class WechatRefundResultSendHandler {

	@Autowired
	private JmsTemplate jmsTemplate;

	@Value("${wechat.refund.query.queue.name}")
	private String wechatQueryQueueName;

	public void sendMessage(final String msg) {
		jmsTemplate.send(wechatQueryQueueName, new MessageCreator() {
			@Override
			public Message createMessage(Session session) throws JMSException {
				Message message = session.createTextMessage(msg);
			    message.setLongProperty(ScheduledMessage.AMQ_SCHEDULED_DELAY, 1200000L);
				return message;
			}
		});
	}
	

	
}
