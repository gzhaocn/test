package com.walmart.mobile.checkout.utils.wechat.service;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;

import com.walmart.mobile.checkout.constant.WechatConstants;


public class BaseService {

	// API的地址
	private String apiURL;

	// 发请求的HTTPS请求器
	private IServiceRequest serviceRequest;
	
	// 发请求的HTTPS请求器
	private IServiceRequest serviceH5Request;


	public BaseService(String api) throws ClassNotFoundException, IllegalAccessException, InstantiationException {
		apiURL = api;
		Class c = Class.forName(WechatConstants.HttpsRequestClassName);
		serviceRequest = (IServiceRequest) c.newInstance();
		
		Class cc = Class.forName(WechatConstants.H5HttpsRequestClassName);
		serviceH5Request = (IServiceRequest) cc.newInstance();
	}

	protected String sendPost(Object xmlObj) throws UnrecoverableKeyException, IOException, NoSuchAlgorithmException,
			KeyStoreException, KeyManagementException {
		return serviceRequest.sendPost(apiURL, xmlObj);
	}

	
	protected String sendH5Post(Object xmlObj) throws UnrecoverableKeyException, IOException, NoSuchAlgorithmException,
	KeyStoreException, KeyManagementException {
          return serviceH5Request.sendPost(apiURL, xmlObj);
}
	
	/**
	 * 供商户想自定义自己的HTTP请求器用
	 * 
	 * @param request
	 *            实现了IserviceRequest接口的HttpsRequest
	 */
	public void setServiceRequest(IServiceRequest request , IServiceRequest serviceH5Request) {
		serviceRequest = request;
		serviceH5Request = serviceH5Request;
	}
}
