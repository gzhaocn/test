package com.walmart.mobile.checkout.handler.receive;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.handler.annotation.Headers;

import com.walmart.mobile.checkout.annotation.JmsHandler;
import com.walmart.mobile.checkout.annotation.JmsRetry;
import com.walmart.mobile.checkout.domain.delivery.Delivery;
import com.walmart.mobile.checkout.domain.delivery.DeliveryLine;
import com.walmart.mobile.checkout.service.DeliveryService;

@JmsHandler
public class DeliveryReceiveHandler {

	private static final Logger LOGGER = LoggerFactory.getLogger(DeliveryReceiveHandler.class);

	@Autowired
	private DeliveryService deliveryService;

	@JmsListener(destination = "${deliveryOrder.queue.name}")
	@JmsRetry
	public void processDelivery(String data, @Headers Map<String, Object> headers) throws Exception {
		LOGGER.info("create delivery data:{}", data);
		Delivery delivery = deliveryService.getDelivery(data);
		List<DeliveryLine> deliveryLineList = deliveryService.getDeliveryLine(data, delivery);
		deliveryService.createDelivery(delivery, deliveryLineList);
	}

}
