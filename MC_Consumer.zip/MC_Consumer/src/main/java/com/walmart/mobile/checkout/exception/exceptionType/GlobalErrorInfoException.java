package com.walmart.mobile.checkout.exception.exceptionType;

import com.walmart.mobile.checkout.exception.ErrorInfoInterface;
import com.walmart.mobile.checkout.utils.AppUtils;

/**
 * 统一错误码异常
 * 
 * @author lliao2
 */
public class GlobalErrorInfoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final transient ErrorInfoInterface errorInfo;

	private final boolean isPrint;

	public GlobalErrorInfoException(ErrorInfoInterface errorInfo, Throwable cause) {
		super(AppUtils.messageFormat("error code:{0},msg:{1}", errorInfo.getCode(), errorInfo.getMessage()), cause);
		this.isPrint = false;
		this.errorInfo = errorInfo;
	}

	public GlobalErrorInfoException(ErrorInfoInterface errorInfo) {
		super(AppUtils.messageFormat("error code:{0},msg:{1}", errorInfo.getCode(), errorInfo.getMessage()));
		this.isPrint = true;
		this.errorInfo = errorInfo;
	}

	public ErrorInfoInterface getErrorInfo() {
		return errorInfo;
	}

	public boolean isPrint() {
		return isPrint;
	}
}
