package com.walmart.mobile.checkout.handler.receive;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.handler.annotation.Headers;

import com.walmart.mobile.checkout.annotation.JmsHandler;
import com.walmart.mobile.checkout.annotation.JmsRetry;
import com.walmart.mobile.checkout.service.PushService;

@JmsHandler
public class PushMessageReceiveHandler {
	private static final Logger LOGGER = LoggerFactory.getLogger(PushMessageReceiveHandler.class);

	@Autowired
	private PushService pushService;

	@JmsListener(destination = "${pushMessage.queue.name}")
	@JmsRetry(3)
	public void processPushMessage(String message, @Headers Map<String, Object> headers) throws Exception {
		LOGGER.info("the push message is:{}",message);
		pushService.push(message);
	}
}
