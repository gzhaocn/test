package com.walmart.mobile.checkout.service;

import java.security.Security;

import javax.annotation.PostConstruct;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

import com.walmart.mobile.checkout.bean.SmsBean;
import com.walmart.mobile.checkout.utils.MD5Util;
import com.walmart.mobile.checkout.utils.sms.ws.WebService;
import com.walmart.mobile.checkout.utils.ws.WebServiceSoap;

@Service
public class SmsService {
	private static final Logger LOGGER = LoggerFactory.getLogger(EmailService.class);

	private WebServiceSoap wss;

	@Value("${sms.username}")
	private String sn;
	@Value("${sms.password}")
	private String password;
	private String pwd;

	@Value("${sms.ssl:}")
	private String smsSsl;
	@Value("${client.need.proxy}")
	private String cnProxy;
	@Value("${http.client.proxy.host}")
	private String httpProxyHost;
	@Value("${http.client.proxy.port}")
	private String httpProxyPort;
	@Value("${https.client.proxy.host}")
	private String httpsProxyHost;
	@Value("${https.client.proxy.port}")
	private String httpsProxyPort;

	@PostConstruct
	private void init() {
		if (StringUtils.isNotEmpty(smsSsl)) {
			System.setProperty("javax.net.ssl.trustStore", ApplicationContext.class.getResource(smsSsl).getPath());
		}
		System.setProperty("java.protocol.handler.pkgs", "com.sun.net.ssl.internal.www.protocol");
		Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
		System.setProperty("java.protocol.handler.pkgs", "javax.net.ssl");

		LOGGER.info("init config porxy. http.proxyHost={},http.proxyPort={},https.proxyHost={},https.proxyPort={}",
				cnProxy, httpProxyHost, httpProxyPort, httpsProxyHost, httpsProxyPort);

		Boolean needProxy = Boolean.parseBoolean(cnProxy);
		if (needProxy) {
			System.setProperty("http.proxyHost", httpProxyHost);
			System.setProperty("http.proxyPort", httpProxyPort);
			System.setProperty("https.proxyHost", httpsProxyHost);
			System.setProperty("https.proxyPort", httpsProxyPort);
		}

		HostnameVerifier hv = new HostnameVerifier() {
			public boolean verify(String urlHostName, SSLSession session) {
				return urlHostName.equals(session.getPeerHost());
			}
		};
		HttpsURLConnection.setDefaultHostnameVerifier(hv);
		wss = new WebService().getWebServiceSoap();
		pwd = MD5Util.md5(sn + password);
		LOGGER.info("init config end . WebServiceSoap={}", wss);
	}

	public void sendMsgToPhone(SmsBean smsBean) {
		LOGGER.info("-------------->>>> msg:{}",smsBean.getBody());
		wss.mt(sn, pwd, smsBean.getMobile(), smsBean.getBody(), smsBean.getExt(), smsBean.getStime(),
				smsBean.getRrid());
	}
}
