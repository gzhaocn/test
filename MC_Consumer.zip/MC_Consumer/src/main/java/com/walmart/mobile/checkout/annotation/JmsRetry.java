package com.walmart.mobile.checkout.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.walmart.mobile.checkout.constant.AppConstants;

@Target({ ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface JmsRetry {
	/**
	 * min is 1 and max is 10
	 * 
	 * @return
	 */
	int value() default AppConstants.EXP_RETRY;

	boolean email() default true;
}
