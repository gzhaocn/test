package com.walmart.mobile.checkout.utils.wechat.business;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.bean.RefundModifyParamter;
import com.walmart.mobile.checkout.constant.RefundStatus;
import com.walmart.mobile.checkout.exception.ApplicationException;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.utils.wechat.common.Signature;
import com.walmart.mobile.checkout.utils.wechat.common.Util;
import com.walmart.mobile.checkout.utils.wechat.refund.query.protocol.RefundQueryReqData;
import com.walmart.mobile.checkout.utils.wechat.refund.query.protocol.RefundQueryResData;
import com.walmart.mobile.checkout.utils.wechat.service.RefundQueryService;


/**
 * User: rizenguo Date: 2014/12/2 Time: 18:51
 */
public class RefundQueryBusiness {

	public RefundQueryBusiness() throws IllegalAccessException, ClassNotFoundException, InstantiationException {
		refundQueryService = new RefundQueryService();
	}

	public interface ResultListener {
		// API返回ReturnCode不合法，支付请求逻辑错误，请仔细检测传过去的每一个参数是否合法，或是看API能否被正常访问
		void onFailByReturnCodeError(RefundQueryResData refundQueryResData);

		// API返回ReturnCode为FAIL，支付API系统返回失败，请检测Post给API的数据是否规范合法
		void onFailByReturnCodeFail(RefundQueryResData refundQueryResData);

		// 支付请求API返回的数据签名验证失败，有可能数据被篡改了
		void onFailBySignInvalid(RefundQueryResData refundQueryResData);

		// 退款查询失败
		void onRefundQueryFail(RefundQueryResData refundQueryResData);

		// 退款查询成功
		void onRefundQuerySuccess(RefundQueryResData refundQueryResData);

		// 错误信息
		void setResult(String message);
	}

	private static final Logger LOG = LoggerFactory.getLogger(RefundQueryBusiness.class);
	private RefundQueryService refundQueryService;

	/**
	 * 运行退款查询的业务逻辑
	 * 
	 * @param refundQueryReqData
	 *            这个数据对象里面包含了API要求提交的各种数据字段
	 * @param resultListener
	 *            商户需要自己监听被扫支付业务逻辑可能触发的各种分支事件，并做好合理的响应处理
	 * @throws GlobalErrorInfoException 
	 * @throws Exception
	 */
	public void run(RefundQueryReqData refundQueryReqData, RefundQueryBusiness.ResultListener resultListener,RestTemplate restTemplate , String refundUrl,boolean type)
			throws Exception {

		// --------------------------------------------------------------------
		// 构造请求“退款查询API”所需要提交的数据
		// --------------------------------------------------------------------
		String message;
		// 接受API返回
		String refundQueryServiceResponseString;

		long costTimeStart = System.currentTimeMillis();

		// 表示是本地测试数据
		LOG.info("退款查询API返回的数据如下：");
		refundQueryServiceResponseString = refundQueryService.request(refundQueryReqData,type);

		long costTimeEnd = System.currentTimeMillis();
		long totalTimeCost = costTimeEnd - costTimeStart;
		LOG.info("api请求总耗时：{}ms",totalTimeCost);

		LOG.info(refundQueryServiceResponseString);
		
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		RefundModifyParamter refundModifyParamter = new RefundModifyParamter();
		refundModifyParamter.setBatchNo(refundQueryReqData.getOut_refund_no());
		refundModifyParamter.setOrderId(refundQueryReqData.getOut_trade_no());

		// 将从API返回的XML数据映射到Java对象
		RefundQueryResData refundQueryResData = (RefundQueryResData) Util
				.getObjectFromXML(refundQueryServiceResponseString, RefundQueryResData.class);

		if (refundQueryResData == null || refundQueryResData.getReturn_code() == null) {
			message = "Case1:退款查询API请求逻辑错误，请仔细检测传过去的每一个参数是否合法，或是看API能否被正常访问";
			LOG.error(message);
			resultListener.setResult(message);
			resultListener.onFailByReturnCodeError(refundQueryResData);
			return;
		}

		// Debug:查看数据是否正常被填充到scanPayResponseData这个对象中
		// Util.reflect(refundQueryResData);

		if (refundQueryResData.getReturn_code().equals("FAIL")) {
			/// 注意：一般这里返回FAIL是出现系统级参数错误，请检测Post给API的数据是否规范合法
			message = "Case2:退款查询API系统返回失败，请检测Post给API的数据是否规范合法";
			resultListener.setResult(message);
			resultListener.onFailByReturnCodeFail(refundQueryResData);
			throw new ApplicationException("查询结果出错 ， messge:" + message );
		} else {
			LOG.info("查询退款查询API系统成功返回数据");
			// --------------------------------------------------------------------
			// 收到API的返回数据的时候得先验证一下数据有没有被第三方篡改，确保安全
			// --------------------------------------------------------------------

			if (!Signature.checkIsSignValidFromResponseString(refundQueryServiceResponseString,type)) {
				message = "Case3:退款查询API返回的数据签名验证失败，有可能数据被篡改了";
				LOG.error(message);
				resultListener.setResult(message);
				resultListener.onFailBySignInvalid(refundQueryResData);
				return;
			}

			if (refundQueryResData.getResult_code().equals("FAIL")) {
				message = "查询退款出错，错误码：" + refundQueryResData.getErr_code() + "     错误信息："
						+ refundQueryResData.getErr_code_des();
				
				resultListener.setResult(message);
				resultListener.onRefundQueryFail(refundQueryResData);
				refundModifyParamter.setReturnStatus(Byte.valueOf(String.valueOf(RefundStatus.RETURN_STATUS_REFUND_FAILED)));
				// 退款失败时再怎么延时查询退款状态都没有意义，这个时间建议要么再手动重试一次，依然失败的话请走投诉渠道进行投诉
				throw new ApplicationException("查询结果出错 ， messge:" + message );
			} else {
				// 退款成功
				message = "Case5:【退款查询成功】";
				LOG.info(message);
				resultListener.onRefundQuerySuccess(refundQueryResData);
				refundModifyParamter.setReturnStatus(Byte.valueOf(String.valueOf(RefundStatus.RETURN_STATUS_REFUND_SUCCESS)));	
			}
		}
		String refundParamter  = JSON.toJSONString(refundModifyParamter);
		LOG.info("orderId is {},refundModifyParamter is {}",refundQueryReqData.getOut_trade_no(),refundParamter);	
		HttpEntity<String> entity = new HttpEntity<>(refundParamter, headers);
		String result = restTemplate.postForObject(refundUrl, entity, String.class);
		JSONObject refundUpdateResult = JSON.parseObject(result);
		String code = refundUpdateResult.getString("code");
		if("0".endsWith(code)){
			LOG.info("update refund status success");	
		}else{
			throw new ApplicationException("update refund fail");
		}
		
	}

	public void setRefundQueryService(RefundQueryService service) {
		refundQueryService = service;
	}

}
