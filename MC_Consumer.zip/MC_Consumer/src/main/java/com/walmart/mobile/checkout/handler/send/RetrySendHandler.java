package com.walmart.mobile.checkout.handler.send;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.apache.activemq.ScheduledMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import com.walmart.mobile.checkout.annotation.JmsHandler;
import com.walmart.mobile.checkout.bean.RetryBean;
import com.walmart.mobile.checkout.exception.ApplicationException;
import com.walmart.mobile.checkout.utils.AppUtils;

@JmsHandler
public class RetrySendHandler {
	private static final Logger LOGGER = LoggerFactory.getLogger(RetrySendHandler.class);

	@Autowired
	private JmsTemplate jmsTemplate;

	public void sendMessage(final RetryBean retryBean) throws ApplicationException {
		LOGGER.info(AppUtils.messageFormat("retry size:{0},count:{1},delay time:{2}", retryBean.getSize(),
				retryBean.getCount(), retryBean.getDelayTime()));
		jmsTemplate.send(retryBean.getQueueName(), new MessageCreator() {
			@Override
			public Message createMessage(Session session) throws JMSException {
				LOGGER.info("retry session:" + session.toString());
				Message sendMsg = session.createTextMessage(retryBean.getMessage());

				sendMsg.setJMSCorrelationID(retryBean.getCorrelationID());
				if (retryBean.isRetry()) {
					sendMsg.setIntProperty("size", retryBean.getSize());
					sendMsg.setIntProperty("count", retryBean.getCount());
					sendMsg.setLongProperty(ScheduledMessage.AMQ_SCHEDULED_DELAY, retryBean.getDelayTime());
				}
				return sendMsg;
			}
		});
	}
}
