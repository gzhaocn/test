package com.walmart.mobile.checkout.utils.wechat.common;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.walmart.mobile.checkout.constant.GlobalErrorInfoEnum;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;

public class XMLParser {

	private XMLParser() {
	}

	public static Map<String, Object> getMapFromXML(String xmlString) throws GlobalErrorInfoException {
		Map<String, Object> map = new HashMap<>();
		InputStream is = null;
		try {
			// 这里用Dom的方式解析回包的最主要目的是防止API新增回包字段
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			// 使用开发语言提供的禁用外部实体的方法
			factory.setExpandEntityReferences(false);
			DocumentBuilder builder = factory.newDocumentBuilder();
			is = Util.getStringStream(xmlString);
			Document document = builder.parse(is);

			// 获取到document里面的全部结点
			NodeList allNodes = document.getFirstChild().getChildNodes();
			Node node;

			int i = 0;
			while (i < allNodes.getLength()) {
				node = allNodes.item(i);
				if (node instanceof Element) {
					map.put(node.getNodeName(), node.getTextContent());
				}
				i++;
			}
		} catch (ParserConfigurationException | IOException | SAXException e) {
			throw new GlobalErrorInfoException(GlobalErrorInfoEnum.WECHAT_SIGNATURE_ERROR, e);
		} finally {
			IOUtils.closeQuietly(is);
		}
		return map;

	}

}
