package com.walmart.mobile.checkout.utils;

import java.text.MessageFormat;

import javax.jms.Message;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.constant.AppConstants;

public final class AppUtils {

	private static final Logger LOGGER = LoggerFactory.getLogger(AppUtils.class);

	private AppUtils() {
	}

	public static String messageFormat(String pattern, Object... arguments) {
		return MessageFormat.format(pattern, arguments);
	}

	public static Long stringToLong(String value) {
		return Long.parseLong(value);
	}

	public static Integer stringToInteger(String value) {
		return Integer.parseInt(value);
	}

	public static boolean isJsonObject(String text) {

		try {
			JSONObject.parseObject(text);
			return true;
		} catch (Exception e) {
			LOGGER.error("JsonObject format error : " + e.getMessage());
			return false;
		}
	}

	public static Long getProductId(Long upc, Integer supplierId) {
		return supplierId * 1000000000000L + upc;
	}

	public static String getJsonByPath(JSONArray json, String path) {
		return getJsonByPath(json.toJSONString(), path, 0);
	}

	public static String getJsonByPath(JSONObject json, String path) {
		return getJsonByPath(json.toJSONString(), path, 0);
	}

	public static String getJsonByPath(String text, String path) {
		return getJsonByPath(text, path, 0);
	}

	public static String getJsonByPath(String text, String path, Integer index) {
		String[] paths = path.split("[.]");
		String result;
		if (isJsonObject(text)) {
			JSONObject json = JSONObject.parseObject(text);
			result = json.getString(paths[index]);
		} else {
			JSONArray jsonArr = JSONObject.parseArray(text);
			result = jsonArr.getString(stringToInteger(paths[index]));
		}
		if (index == paths.length - 1 || result == null) {
			return result;
		}
		return getJsonByPath(result, path, ++index);
	}

	public static Long buildProductId(Long upc, Integer supplierId) {
		return buildProductId(upc, supplierId.toString());
	}

	public static Long buildProductId(Long upc, String supplierId) {
		return Long.parseLong(supplierId + String.format(AppConstants.UPC_ID_FORMAT, upc));
	}

	public static Integer getJmsIntegerValue(String name, Message message) {
		try {
			return message.getIntProperty(name);
		} catch (Exception e) {
			return null;
		}
	}

	public static String getJmsStringValue(String name, Message message) {
		try {
			return message.getStringProperty(name);
		} catch (Exception e) {
			return null;
		}
	}

	public static <T> T getJavaBean(String source, Class<T> clazz) {
		return JSON.parseObject(source, clazz);
	}
}
