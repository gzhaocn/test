package com.walmart.mobile.checkout.handler.receive;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.handler.annotation.Headers;

import com.walmart.mobile.checkout.annotation.JmsHandler;
import com.walmart.mobile.checkout.annotation.JmsRetry;
import com.walmart.mobile.checkout.service.EmailService;

@JmsHandler
public class EmailReceiveHandler {

	@Autowired
	private EmailService emailService;

	@JmsListener(destination = "${email.queue.name}")
	@JmsRetry
	public void processEmail(String body, @Headers Map<String, Object> headers) {
		emailService.sendEmailMsg(body);
	}
}
