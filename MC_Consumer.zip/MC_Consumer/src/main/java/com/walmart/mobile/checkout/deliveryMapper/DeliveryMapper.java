package com.walmart.mobile.checkout.deliveryMapper;

import org.apache.ibatis.annotations.Insert;

import com.walmart.mobile.checkout.domain.delivery.Delivery;

public interface DeliveryMapper {

	@Insert("INSERT INTO delivery "
			+ "(delivery_id ,order_id ,user_id ,store_id ,status ,delivery_type ,shipping_fee ,province ,city ,district ,address ,zipcode ,longitude ,"
			+ "latitude ,delivery_name ,delivery_phone ,delivery_date ,delivery_period ,delivery_period_desc ,delivery_instruction ,"
			+ "delivery_by ,delivery_start_time ,delivery_end_time ,created_time ,created_by ,updated_time ,updated_by ,version) "
			+ "VALUES (#{deliveryId } ,#{orderId } ,#{userId } ,#{storeId } ,#{status } ,#{deliveryType } ,"
			+ "#{shippingFee } ,#{province } ,#{city } ,#{district } ,#{address } ,#{zipcode } ,"
			+ "#{longitude } ,#{latitude } ,#{deliveryName } ,#{deliveryPhone } ,#{deliveryDate,jdbcType=DATE } ,"
			+ "#{deliveryPeriod } ,#{deliveryPeriodDesc } ,#{deliveryInstruction },"
			+ "#{deliveryBy } ,#{deliveryStartTime,jdbcType=TIMESTAMP} ,#{deliveryEndTime,jdbcType=TIMESTAMP} ,#{createdTime,jdbcType=TIMESTAMP } ,"
			+ "#{createdBy } ,#{updatedTime,jdbcType=TIMESTAMP } ,#{updatedBy } ,#{version})")
	Integer insertDelivery(Delivery delivery);
}