package com.walmart.mobile.checkout.handler.receive;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.handler.annotation.Headers;

import com.walmart.mobile.checkout.annotation.JmsHandler;
import com.walmart.mobile.checkout.annotation.JmsRetry;
import com.walmart.mobile.checkout.service.WechatH5RefundService;

@JmsHandler
public class WechatH5RefundReceiveHandler {

	@Autowired
	private WechatH5RefundService wechatH5RefundService;

	@JmsListener(destination = "${wechat.H5.refund.queue.name}")
	@JmsRetry(3)
	public void processWechatH5Refund(String wechatH5RefundMessage, @Headers Map<String, Object> headers) throws Exception {
		wechatH5RefundService.processWechatH5Refund(wechatH5RefundMessage);
	}

}
