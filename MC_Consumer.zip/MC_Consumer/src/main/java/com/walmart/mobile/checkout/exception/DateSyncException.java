package com.walmart.mobile.checkout.exception;

public class DateSyncException extends ApplicationException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DateSyncException(Throwable cause) {
		super(cause);
	}

	public DateSyncException(String message) {
		super(message);
	}

	public DateSyncException(String message, Integer code) {
		super(message, code);
	}
}
