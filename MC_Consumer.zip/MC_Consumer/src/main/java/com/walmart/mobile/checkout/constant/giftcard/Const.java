package com.walmart.mobile.checkout.constant.giftcard;

/**
 * Shanghai UPCARD - access card & payment gateway merchant interface
 * 【Application level input parameters】
 * 
 * @author JiangZhihui
 *
 */
public class Const {
	private Const(){}
	public static final  String RESULT_KEY_CODE = "code";
	public static final  String RESULT_KEY_MSG = "msg";
	public static final  String RESULT_KEY_ORDER_NO = "orderNo";
}
