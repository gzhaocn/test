package com.walmart.mobile.checkout.userMapper;

import java.util.List;

public interface UserCreditInfoMapper {

	void addBlackFlag(List<String> idNumbers);

	void removeBlackFlag(List<String> idNumbers);

}