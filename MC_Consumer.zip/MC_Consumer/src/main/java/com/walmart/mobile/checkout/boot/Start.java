package com.walmart.mobile.checkout.boot;

import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;

import com.walmart.mobile.checkout.config.MainConfig;

import ch.qos.logback.core.joran.spi.JoranException;

public class Start extends SpringBootServletInitializer {
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(getClasses());
	}

	public static void main(String[] args) throws JoranException {
		new Start().configure(new SpringApplicationBuilder()).run(args);
	}

	private Class<?>[] getClasses() {
		Class<?>[] clazzs = { MainConfig.class };
		return clazzs;
	}
}
