package com.walmart.mobile.checkout.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.walmart.mobile.checkout.constant.RefundStatus;
import com.walmart.mobile.checkout.handler.send.WechatH5RefundResultSendHandler;
import com.walmart.mobile.checkout.utils.wechat.WXH5Pay;
import com.walmart.mobile.checkout.utils.wechat.business.WechatRefundResultListener;
import com.walmart.mobile.checkout.utils.wechat.refund.protocol.RefundReqData;
import com.walmart.mobile.checkout.utils.wechat.refund.query.protocol.RefundQueryReqData;
@Service("wechatH5RefundService")
public class WechatH5RefundService {

	
	@Autowired
	private WechatH5RefundResultSendHandler wechatH5RefundResultSendHandler;
	
	private static final Logger LOG = LoggerFactory.getLogger(WechatH5RefundService.class);
	
	public void processWechatH5Refund(String wechatRefundMessage) throws Exception {
		int result = RefundStatus.RETURN_STATUS_REFUND_FAILED;
		RefundReqData refundReqData = JSON.parseObject(wechatRefundMessage, RefundReqData.class);
		
		WechatRefundResultListener listener = new WechatRefundResultListener();
		WXH5Pay.doRefundBusiness(refundReqData, listener);
		// 系统超时重试
		if (listener.getErr_code().equals("SYSTEMERROR")) {
			WXH5Pay.doRefundBusiness(refundReqData, listener);
		}
		if (listener.getErr_code().equals("NOTENOUGH")) {
			refundReqData.setRefund_account("REFUND_SOURCE_RECHARGE_FUNDS",false);
			WXH5Pay.doRefundBusiness(refundReqData, listener);
		}

		result = listener.getReturn_status();
		String errorMessage = listener.getResult();
		LOG.info("wechat h5 refund result :{} , errorMessage :{}", result ,errorMessage);
		
		RefundQueryReqData refundQueryReqData = new RefundQueryReqData(refundReqData.getAppid(),refundReqData.getMch_id(),  refundReqData.getOut_refund_no(),refundReqData.getOut_trade_no(),false);
		wechatH5RefundResultSendHandler.sendMessage(JSON.toJSONString(refundQueryReqData));
	
	
	}

}
