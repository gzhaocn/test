package com.walmart.mobile.checkout.constant;

public class RefundStatus {
	
	private RefundStatus(){}

	/**
	 * 退款失败
	 */
	public static final int RETURN_STATUS_REFUND_FAILED = 4;
	/**
	 * 待退款
	 */
	public static final int RETURN_STATUS_REFUND_PENDING = 2;
	
	/**
	 * 退款成功
	 */
	public static final int RETURN_STATUS_REFUND_SUCCESS = 3;
	
	
}
