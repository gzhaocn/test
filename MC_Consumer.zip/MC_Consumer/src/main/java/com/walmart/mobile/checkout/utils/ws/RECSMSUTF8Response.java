
package com.walmart.mobile.checkout.utils.ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for anonymous complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="RECSMS_UTF8Result" type="{http://tempuri.org/}ArrayOfMOBody" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "recsmsutf8Result" })
@XmlRootElement(name = "RECSMS_UTF8Response")
public class RECSMSUTF8Response {

	@XmlElement(name = "RECSMS_UTF8Result")
	protected ArrayOfMOBody recsmsutf8Result;

	/**
	 * Gets the value of the recsmsutf8Result property.
	 * 
	 * @return possible object is {@link ArrayOfMOBody }
	 * 
	 */
	public ArrayOfMOBody getRECSMSUTF8Result() {
		return recsmsutf8Result;
	}

	/**
	 * Sets the value of the recsmsutf8Result property.
	 * 
	 * @param value
	 *            allowed object is {@link ArrayOfMOBody }
	 * 
	 */
	public void setRECSMSUTF8Result(ArrayOfMOBody value) {
		this.recsmsutf8Result = value;
	}

}
