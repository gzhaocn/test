package com.walmart.mobile.checkout.service.push;

/**
 * General push service interface
 * 
 * @author JiangZhihui
 *
 */
public interface GeneralPushService {

	public static final String APPKEY = "dd1066407b044738b6479275";
	public static final String MASTERSECRET = "2b38ce69b1de2a7fa95706ea";

	public static final String TITLE = "Test from API example";
	public static final String ALERT = "Test from API Example - alert";
	public static final String MSG_CONTENT = "Test from API Example - msgContent";
	public static final String REGISTRATION_ID = "0900e8d85ef";
	public static final String TAG = "tag_api";

	/**
	 * audio SMS push interface
	 * 
	 * @param mobileNumber
	 * @param content
	 * @return 0: Success ; -1:Failure
	 */
	public int pushSmsAudio(String mobile, String txt);

	/**
	 * SMS push interface
	 * 
	 * @param mobileNumber
	 * @param content
	 * @param params
	 * @return 0: Success ; -1:Failure
	 */
	public int pushSMS(String mobileNumber, String content, Object... params);

}
