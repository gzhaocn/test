package com.walmart.mobile.checkout.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSON;
import com.walmart.mobile.checkout.utils.wechat.WXH5Pay;
import com.walmart.mobile.checkout.utils.wechat.business.WechatRefundQueryResultListener;
import com.walmart.mobile.checkout.utils.wechat.refund.query.protocol.RefundQueryReqData;

@Service("wechatH5RefundQueryService")
public class WechatH5RefundQueryService {

	
	@Autowired
	RestTemplate restTemplate;

	@Value("${refund.url}")
	private String refundUrl;
	

	public void processWechatQueryRefund(String wechatRefundMessage) throws Exception {
		
		RefundQueryReqData	refundQueryReqData =	JSON.parseObject(wechatRefundMessage, RefundQueryReqData.class);
		WechatRefundQueryResultListener resultListener = new WechatRefundQueryResultListener();
		WXH5Pay.doRefundQueryBusiness(refundQueryReqData, resultListener,  restTemplate , refundUrl);
		
		
	}

}
