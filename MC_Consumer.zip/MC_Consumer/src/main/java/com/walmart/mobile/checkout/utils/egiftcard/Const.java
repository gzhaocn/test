package com.walmart.mobile.checkout.utils.egiftcard;


public class Const {
	public final static String RESULT_KEY_CODE = "code";
	public final static String RESULT_KEY_MSG = "msg";
	public final static String RESULT_KEY_ORDER_NO = "orderNo";
}
