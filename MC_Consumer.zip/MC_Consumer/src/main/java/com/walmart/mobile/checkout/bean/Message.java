package com.walmart.mobile.checkout.bean;

public class Message {
	private String code;
	private String msg;
	private Object data;

	public boolean isSuccess() {
		return "0".equals(this.code);
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public static Message createFail(String msg) {
		return createFail("-1", msg);
	}

	public static Message createFail(String code, String msg) {
		Message message = new Message();
		message.setCode(code);
		message.setMsg(msg);
		return message;
	}

	public static Message createSuccess() {
		return createSuccess("success");
	}

	public static Message createSuccess(String msg) {
		Message message = new Message();
		message.setCode("0");
		message.setMsg(msg);
		return message;
	}

	/**
	 * 含有data参数
	 * 
	 * @param msg
	 * @param data
	 * @return
	 */
	public static Message createSuccess(String msg, Object data) {
		Message message = new Message();
		message.setCode("0");
		message.setMsg(msg);
		message.setData(data);
		return message;
	}

	/**
	 * 含有data参数
	 * 
	 * @param code
	 * @param msg
	 * @param data
	 * @return
	 */
	public static Message createFail(String code, String msg, Object data) {
		Message message = new Message();
		message.setCode(code);
		message.setMsg(msg);
		message.setData(data);
		return message;
	}
}
