package com.walmart.mobile.checkout.bean;

public class RefundModifyParamter {
	private  String batchNo;
	private Byte returnStatus;
	private String orderId;
	public String getBatchNo() {
		return batchNo;
	}
	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}
	public Byte getReturnStatus() {
		return returnStatus;
	}
	public void setReturnStatus(Byte returnStatus) {
		this.returnStatus = returnStatus;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

}
