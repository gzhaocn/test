package com.walmart.mobile.checkout.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.dag.DagHost;
import com.walmart.mobile.checkout.dag.HostData;
import com.walmart.mobile.checkout.userMapper.UserCreditInfoMapper;
import com.walmart.mobile.checkout.utils.ThreadLocalContextHolder;

@Service
public class CreditInfoService {

	@Autowired
	private UserCreditInfoMapper userCreditInfoMapper;

	@Value("${ddr.request.param}")
	private String ddrParam;

	@Value("${ddr.request.url}")
	private String ddrUrl;

	@Autowired
	private RestTemplate restTemplate;

	private static final int MAX = 100;

	public void refreshBlackState(String blacklistMessage) {
		System.out.println("start to refresh blackState in userCreditInfo");
		JSONObject data = JSON.parseObject(blacklistMessage);
		JSONArray add = data.getJSONArray("add");
		JSONArray delete = data.getJSONArray("delete");
		List<DagHost> dagHosts = getDagHostList();
		for (DagHost dagHost : dagHosts) {
			refreshBlackState(add, delete, dagHost.getDagId());
		}
	}

	private List<DagHost> getDagHostList() {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<>(ddrParam, headers);
		String result = restTemplate.postForObject(ddrUrl, entity, String.class);
		DagHost.triggerUserDag(true);
		List<DagHost> dss = JSONObject.parseObject(result, HostData.class).getData();
		Map<Object, Object> dataSources = new HashMap<>(16);
		for (int i = 0; i < dss.size(); i++) {
			DagHost dh = dss.get(i);
			String key = dh.getDagId();
			dataSources.put(key, dh.getDataSource());
		}
		DagHost.triggerUserDag(false);
		return dss;
	}

	private void refreshBlackState(JSONArray add, JSONArray delete, String dagId) {
		ThreadLocalContextHolder.put("dagId", dagId);
		for (int i = 0, size = add.size(); i < size / MAX + 1; i++) {
			List<String> blacklistAdd = new ArrayList<>();
			for (int index = i * MAX; index < i * MAX + 100 && index < size; index++) {
				blacklistAdd.add(add.getString(index));
			}
			addBlackFlag(blacklistAdd);
		}
		for (int i = 0, size = delete.size(); i < size / MAX + 1; i++) {
			List<String> blacklistRemove = new ArrayList<>();
			for (int index = i * MAX; index < i * MAX + 100 && index < size; index++) {
				blacklistRemove.add(delete.getString(index));
			}
			removeBlackFlag(blacklistRemove);
		}
	}

	private void addBlackFlag(List<String> blackIds) {
		if (blackIds.size() > 0) {
			long startTime = System.currentTimeMillis();
			userCreditInfoMapper.addBlackFlag(blackIds);
			System.out.println("spend " + (System.currentTimeMillis() - startTime) + "ms.");
		}
	}

	private void removeBlackFlag(List<String> blackIds) {
		if (blackIds.size() > 0) {
			long startTime = System.currentTimeMillis();
			userCreditInfoMapper.removeBlackFlag(blackIds);
			System.out.println("spend " + (System.currentTimeMillis() - startTime) + "ms.");
		}
	}

}
