package com.walmart.mobile.checkout.utils.wechat.business;

import com.walmart.mobile.checkout.constant.RefundStatus;
import com.walmart.mobile.checkout.utils.wechat.business.RefundBusiness.ResultListener;
import com.walmart.mobile.checkout.utils.wechat.refund.protocol.RefundResData;

public class WechatRefundResultListener implements ResultListener {

	private int return_status;
	// 执行结果
	private String result = "";
	private String err_code = "";

	@Override
	public void onFailByReturnCodeError(RefundResData refundResData) {
		this.return_status = RefundStatus.RETURN_STATUS_REFUND_FAILED;
	}

	@Override
	public void onFailByReturnCodeFail(RefundResData refundResData) {
		this.return_status = RefundStatus.RETURN_STATUS_REFUND_FAILED;
	}

	@Override
	public void onFailBySignInvalid(RefundResData refundResData) {
		this.return_status = RefundStatus.RETURN_STATUS_REFUND_FAILED;
	}

	@Override
	public void onRefundFail(RefundResData refundResData) {
		this.err_code = refundResData.getErr_code();
		this.return_status = RefundStatus.RETURN_STATUS_REFUND_FAILED;
	}

	@Override
	public void onRefundSuccess(RefundResData refundResData) {
		this.return_status = RefundStatus.RETURN_STATUS_REFUND_PENDING;
	}

	public String getErr_code() {
		return err_code;
	}

	public int getReturn_status() {
		return return_status;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

}
