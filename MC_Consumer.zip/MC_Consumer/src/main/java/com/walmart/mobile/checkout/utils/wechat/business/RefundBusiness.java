package com.walmart.mobile.checkout.utils.wechat.business;


import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;

import javax.xml.parsers.ParserConfigurationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.SAXException;

import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.utils.wechat.common.Signature;
import com.walmart.mobile.checkout.utils.wechat.common.Util;
import com.walmart.mobile.checkout.utils.wechat.refund.protocol.RefundReqData;
import com.walmart.mobile.checkout.utils.wechat.refund.protocol.RefundResData;
import com.walmart.mobile.checkout.utils.wechat.service.RefundService;

/**
 * User: rizenguo Date: 2014/12/2 Time: 17:51
 */
public class RefundBusiness {

	public RefundBusiness() throws IllegalAccessException, ClassNotFoundException, InstantiationException {
		refundService = new RefundService();
	}

	public interface ResultListener {

		// API返回ReturnCode不合法，支付请求逻辑错误，请仔细检测传过去的每一个参数是否合法，或是看API能否被正常访问
		void onFailByReturnCodeError(RefundResData refundResData);

		// API返回ReturnCode为FAIL，支付API系统返回失败，请检测Post给API的数据是否规范合法
		void onFailByReturnCodeFail(RefundResData refundResData);

		// 支付请求API返回的数据签名验证失败，有可能数据被篡改了
		void onFailBySignInvalid(RefundResData refundResData);

		// 退款失败
		void onRefundFail(RefundResData refundResData);

		// 退款成功
		void onRefundSuccess(RefundResData refundResData);

		// 结果信息
		void setResult(String result);

	}

	// 打log用
	private static final Logger LOGGER = LoggerFactory.getLogger(RefundBusiness.class);
	private RefundService refundService;

	/**
	 * 调用退款业务逻辑
	 * 
	 * @param refundReqData
	 *            这个数据对象里面包含了API要求提交的各种数据字段
	 * @param resultListener
	 *            业务逻辑可能走到的结果分支，需要商户处理
	 * @throws IOException
	 * @throws KeyStoreException
	 * @throws NoSuchAlgorithmException
	 * @throws KeyManagementException
	 * @throws UnrecoverableKeyException
	 * @throws SAXException
	 * @throws ParserConfigurationException
	 * @throws GlobalErrorInfoException 
	 * @throws Exception
	 */
	public void run(RefundReqData refundReqData, ResultListener resultListener,boolean type )
			throws UnrecoverableKeyException, KeyManagementException, NoSuchAlgorithmException, KeyStoreException,
			IOException, ParserConfigurationException, SAXException, GlobalErrorInfoException {

		// --------------------------------------------------------------------
		// 构造请求“退款API”所需要提交的数据
		// --------------------------------------------------------------------
		// API返回的数据
		String refundServiceResponseString;
		String message;

		long costTimeStart = System.currentTimeMillis();

		LOGGER.info("wechatpay请求退款API返回的数据如下：");
		refundServiceResponseString = refundService.request(refundReqData, type);

		long costTimeEnd = System.currentTimeMillis();
		long totalTimeCost = costTimeEnd - costTimeStart;
		LOGGER.info("api请求总耗时：{} ms", totalTimeCost);
		LOGGER.info(refundServiceResponseString);

		// 将从API返回的XML数据映射到Java对象
		RefundResData refundResData = (RefundResData) Util.getObjectFromXML(refundServiceResponseString,
				RefundResData.class);

		if (refundResData == null || refundResData.getReturn_code() == null) {
			message = "Case1:退款API请求逻辑错误，请仔细检测传过去的每一个参数是否合法，或是看API能否被正常访问";
			LOGGER.info(message);
			resultListener.setResult(message);
			resultListener.onFailByReturnCodeError(refundResData);
			return;
		}

	

		if (refundResData.getReturn_code().equals("FAIL")) {
			/// 注意：一般这里返回FAIL是出现系统级参数错误，请检测Post给API的数据是否规范合法
			message = "Case2:退款API系统返回失败，请检测Post给API的数据是否规范合法";
			LOGGER.info(message);
			resultListener.setResult(message);
			resultListener.onFailByReturnCodeFail(refundResData);
		} else {
			LOGGER.info("退款API系统成功返回数据");
			// --------------------------------------------------------------------
			// 收到API的返回数据的时候得先验证一下数据有没有被第三方篡改，确保安全
			// --------------------------------------------------------------------

			if (!Signature.checkIsSignValidFromResponseString(refundServiceResponseString , type)) {
				message = "Case3:退款请求API返回的数据签名验证失败，有可能数据被篡改了";
				LOGGER.info(message);
				resultListener.setResult(message);
				resultListener.onFailBySignInvalid(refundResData);
				return;
			}

			if (refundResData.getResult_code().equals("FAIL")) {
				message = "出错，错误码：" + refundResData.getErr_code() + "     错误信息：" + refundResData.getErr_code_des();
				LOGGER.info(message);
				resultListener.setResult(message);
				// 退款失败时再怎么延时查询退款状态都没有意义，这个时间建议要么再手动重试一次，依然失败的话请走投诉渠道进行投诉
				resultListener.onRefundFail(refundResData);
			} else {
				// 退款成功
				message = "Case5:【退款成功】";
				LOGGER.info(message);
				resultListener.setResult(message);
				resultListener.onRefundSuccess(refundResData);
			}
		}
	}

	public void setRefundService(RefundService service) {
		refundService = service;
	}
}
