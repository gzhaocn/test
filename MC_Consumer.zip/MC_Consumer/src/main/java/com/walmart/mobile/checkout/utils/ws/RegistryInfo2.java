
package com.walmart.mobile.checkout.utils.ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for RegistryInfo2 complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name="RegistryInfo2">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="RESULT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="REGISTRYCODE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SERVICECODE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BALANCE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CREATEDATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="REGISTRYSTATEID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PRIORITY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FIRSTREGISTRYDATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="REGISTRYDATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AGENTID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PRODUCTNAME" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DESTMOBILE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FLAG" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="REPLYCONTENT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ISRETURN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="VERSION" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="GRADE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PARENT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SUBSIDIARY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ROLES" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BALSTATUS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DISCOUNT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SLIST" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="POPM" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UPDATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MMS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RegistryInfo2", propOrder = { "result", "registrycode", "servicecode", "balance", "createdate",
		"registrystateid", "priority", "firstregistrydate", "registrydate", "agentid", "productname", "destmobile",
		"flag", "replycontent", "isreturn", "version", "grade", "parent", "subsidiary", "roles", "balstatus",
		"discount", "slist", "popm", "update", "mms" })
public class RegistryInfo2 {

	@XmlElement(name = "RESULT")
	protected String result;
	@XmlElement(name = "REGISTRYCODE")
	protected String registrycode;
	@XmlElement(name = "SERVICECODE")
	protected String servicecode;
	@XmlElement(name = "BALANCE")
	protected String balance;
	@XmlElement(name = "CREATEDATE")
	protected String createdate;
	@XmlElement(name = "REGISTRYSTATEID")
	protected String registrystateid;
	@XmlElement(name = "PRIORITY")
	protected String priority;
	@XmlElement(name = "FIRSTREGISTRYDATE")
	protected String firstregistrydate;
	@XmlElement(name = "REGISTRYDATE")
	protected String registrydate;
	@XmlElement(name = "AGENTID")
	protected String agentid;
	@XmlElement(name = "PRODUCTNAME")
	protected String productname;
	@XmlElement(name = "DESTMOBILE")
	protected String destmobile;
	@XmlElement(name = "FLAG")
	protected String flag;
	@XmlElement(name = "REPLYCONTENT")
	protected String replycontent;
	@XmlElement(name = "ISRETURN")
	protected String isreturn;
	@XmlElement(name = "VERSION")
	protected String version;
	@XmlElement(name = "GRADE")
	protected String grade;
	@XmlElement(name = "PARENT")
	protected String parent;
	@XmlElement(name = "SUBSIDIARY")
	protected String subsidiary;
	@XmlElement(name = "ROLES")
	protected String roles;
	@XmlElement(name = "BALSTATUS")
	protected String balstatus;
	@XmlElement(name = "DISCOUNT")
	protected String discount;
	@XmlElement(name = "SLIST")
	protected String slist;
	@XmlElement(name = "POPM")
	protected String popm;
	@XmlElement(name = "UPDATE")
	protected String update;
	@XmlElement(name = "MMS")
	protected String mms;

	/**
	 * Gets the value of the result property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getRESULT() {
		return result;
	}

	/**
	 * Sets the value of the result property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setRESULT(String value) {
		this.result = value;
	}

	/**
	 * Gets the value of the registrycode property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getREGISTRYCODE() {
		return registrycode;
	}

	/**
	 * Sets the value of the registrycode property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setREGISTRYCODE(String value) {
		this.registrycode = value;
	}

	/**
	 * Gets the value of the servicecode property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getSERVICECODE() {
		return servicecode;
	}

	/**
	 * Sets the value of the servicecode property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setSERVICECODE(String value) {
		this.servicecode = value;
	}

	/**
	 * Gets the value of the balance property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getBALANCE() {
		return balance;
	}

	/**
	 * Sets the value of the balance property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setBALANCE(String value) {
		this.balance = value;
	}

	/**
	 * Gets the value of the createdate property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getCREATEDATE() {
		return createdate;
	}

	/**
	 * Sets the value of the createdate property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setCREATEDATE(String value) {
		this.createdate = value;
	}

	/**
	 * Gets the value of the registrystateid property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getREGISTRYSTATEID() {
		return registrystateid;
	}

	/**
	 * Sets the value of the registrystateid property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setREGISTRYSTATEID(String value) {
		this.registrystateid = value;
	}

	/**
	 * Gets the value of the priority property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getPRIORITY() {
		return priority;
	}

	/**
	 * Sets the value of the priority property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setPRIORITY(String value) {
		this.priority = value;
	}

	/**
	 * Gets the value of the firstregistrydate property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getFIRSTREGISTRYDATE() {
		return firstregistrydate;
	}

	/**
	 * Sets the value of the firstregistrydate property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setFIRSTREGISTRYDATE(String value) {
		this.firstregistrydate = value;
	}

	/**
	 * Gets the value of the registrydate property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getREGISTRYDATE() {
		return registrydate;
	}

	/**
	 * Sets the value of the registrydate property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setREGISTRYDATE(String value) {
		this.registrydate = value;
	}

	/**
	 * Gets the value of the agentid property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getAGENTID() {
		return agentid;
	}

	/**
	 * Sets the value of the agentid property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setAGENTID(String value) {
		this.agentid = value;
	}

	/**
	 * Gets the value of the productname property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getPRODUCTNAME() {
		return productname;
	}

	/**
	 * Sets the value of the productname property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setPRODUCTNAME(String value) {
		this.productname = value;
	}

	/**
	 * Gets the value of the destmobile property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getDESTMOBILE() {
		return destmobile;
	}

	/**
	 * Sets the value of the destmobile property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setDESTMOBILE(String value) {
		this.destmobile = value;
	}

	/**
	 * Gets the value of the flag property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getFLAG() {
		return flag;
	}

	/**
	 * Sets the value of the flag property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setFLAG(String value) {
		this.flag = value;
	}

	/**
	 * Gets the value of the replycontent property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getREPLYCONTENT() {
		return replycontent;
	}

	/**
	 * Sets the value of the replycontent property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setREPLYCONTENT(String value) {
		this.replycontent = value;
	}

	/**
	 * Gets the value of the isreturn property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getISRETURN() {
		return isreturn;
	}

	/**
	 * Sets the value of the isreturn property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setISRETURN(String value) {
		this.isreturn = value;
	}

	/**
	 * Gets the value of the version property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getVERSION() {
		return version;
	}

	/**
	 * Sets the value of the version property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setVERSION(String value) {
		this.version = value;
	}

	/**
	 * Gets the value of the grade property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getGRADE() {
		return grade;
	}

	/**
	 * Sets the value of the grade property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setGRADE(String value) {
		this.grade = value;
	}

	/**
	 * Gets the value of the parent property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getPARENT() {
		return parent;
	}

	/**
	 * Sets the value of the parent property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setPARENT(String value) {
		this.parent = value;
	}

	/**
	 * Gets the value of the subsidiary property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getSUBSIDIARY() {
		return subsidiary;
	}

	/**
	 * Sets the value of the subsidiary property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setSUBSIDIARY(String value) {
		this.subsidiary = value;
	}

	/**
	 * Gets the value of the roles property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getROLES() {
		return roles;
	}

	/**
	 * Sets the value of the roles property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setROLES(String value) {
		this.roles = value;
	}

	/**
	 * Gets the value of the balstatus property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getBALSTATUS() {
		return balstatus;
	}

	/**
	 * Sets the value of the balstatus property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setBALSTATUS(String value) {
		this.balstatus = value;
	}

	/**
	 * Gets the value of the discount property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getDISCOUNT() {
		return discount;
	}

	/**
	 * Sets the value of the discount property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setDISCOUNT(String value) {
		this.discount = value;
	}

	/**
	 * Gets the value of the slist property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getSLIST() {
		return slist;
	}

	/**
	 * Sets the value of the slist property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setSLIST(String value) {
		this.slist = value;
	}

	/**
	 * Gets the value of the popm property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getPOPM() {
		return popm;
	}

	/**
	 * Sets the value of the popm property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setPOPM(String value) {
		this.popm = value;
	}

	/**
	 * Gets the value of the update property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getUPDATE() {
		return update;
	}

	/**
	 * Sets the value of the update property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setUPDATE(String value) {
		this.update = value;
	}

	/**
	 * Gets the value of the mms property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getMMS() {
		return mms;
	}

	/**
	 * Sets the value of the mms property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setMMS(String value) {
		this.mms = value;
	}

}
