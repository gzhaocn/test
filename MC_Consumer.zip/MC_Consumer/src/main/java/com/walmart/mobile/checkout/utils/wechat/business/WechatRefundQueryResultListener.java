package com.walmart.mobile.checkout.utils.wechat.business;


import com.walmart.mobile.checkout.utils.wechat.business.RefundQueryBusiness.ResultListener;
import com.walmart.mobile.checkout.utils.wechat.refund.query.protocol.RefundQueryResData;

public class WechatRefundQueryResultListener implements ResultListener {

	// 执行结果
	private String result = "";
	private String refund_status = "";
	private String err_code = "";

	@Override
	public void onFailByReturnCodeError(RefundQueryResData refundQueryResData) {
	}

	@Override
	public void onFailByReturnCodeFail(RefundQueryResData refundQueryResData) {
	}

	@Override
	public void onFailBySignInvalid(RefundQueryResData refundQueryResData) {
	}

	@Override
	public void onRefundQueryFail(RefundQueryResData refundQueryResData) {
		if (!"SYSTEMERROR".equals(refundQueryResData.getErr_code())) {
			refund_status = "FAIL";
		}
	}

	@Override
	public void onRefundQuerySuccess(RefundQueryResData refundQueryResData) {
		refund_status = refundQueryResData.getRefund_status_0();
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getErr_code() {
		return err_code;
	}

	public void setErr_code(String err_code) {
		this.err_code = err_code;
	}

	public String getRefund_status() {
		return refund_status;
	}

	public void setRefund_status(String refund_status) {
		this.refund_status = refund_status;
	}

}
