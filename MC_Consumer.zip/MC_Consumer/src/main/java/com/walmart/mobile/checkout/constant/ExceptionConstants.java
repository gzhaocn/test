package com.walmart.mobile.checkout.constant;

/**
 * 应用需要的常量,除String的类型以外都尽量使用基本数据类型,而不要使用封装类. 这个类都是放异常使用到的错误代码,相对应的描述应该放到配置文件中
 * 
 * @author kchen15
 * 
 */
public interface ExceptionConstants {

	/** -------------------- 异常处理 -------------------- */
	/** 应用异常的默认错误代码 */
	int APP_EXP_DEFAULT_CODE = -1;
}
