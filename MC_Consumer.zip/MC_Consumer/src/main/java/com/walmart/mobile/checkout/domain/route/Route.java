package com.walmart.mobile.checkout.domain.route;

public class Route {
	private String userId;
	private String mobilePhone;
	private String dagId;
	/**
	 * third party id.
	 */
	private String openId;
	private Integer loginType;

	public Route() {
		/*
		 * default construtor
		 */
	}

	public Route(String userId) {
		this.userId = userId;
	}

	public Route(Integer loginType, String mobilePhone) {
		this.loginType = loginType;
		this.mobilePhone = mobilePhone;
	}

	public Route(Integer loginType, String openId, String mobilePhone) {
		this.loginType = loginType;
		this.openId = openId;
		this.mobilePhone = mobilePhone;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getMobilePhone() {
		return mobilePhone;
	}

	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}

	public String getDagId() {
		return dagId;
	}

	public void setDagId(String dagId) {
		this.dagId = dagId;
	}

	public String getOpenId() {
		return openId;
	}

	public void setOpenId(String openId) {
		this.openId = openId;
	}

	public Integer getLoginType() {
		return loginType;
	}

	public void setLoginType(Integer loginType) {
		this.loginType = loginType;
	}

	@Override
	public String toString() {
		return "Route [userId=" + userId + ", mobilePhone=" + mobilePhone + ", dagId=" + dagId + ", openId=" + openId
				+ ", loginType=" + loginType + "]";
	}
}
