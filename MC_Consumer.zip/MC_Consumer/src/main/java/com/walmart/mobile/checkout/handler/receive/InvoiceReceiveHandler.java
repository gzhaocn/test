package com.walmart.mobile.checkout.handler.receive;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.handler.annotation.Headers;

import com.walmart.mobile.checkout.annotation.JmsHandler;
import com.walmart.mobile.checkout.annotation.JmsRetry;
import com.walmart.mobile.checkout.service.InvoiceService;

@JmsHandler
public class InvoiceReceiveHandler {
	private static final Logger LOGGER = LoggerFactory.getLogger(InvoiceReceiveHandler.class);

	@Autowired
	private InvoiceService invoiceService;

	@JmsListener(destination = "${invoice.queue.name}")
	@JmsRetry(5)
	public void processInvoice(String invoiceMessage, @Headers Map<String, Object> headers) throws Exception {
		LOGGER.info("processInvoice info:{}", invoiceMessage);
		invoiceService.processInvoice(invoiceMessage);
	}

} 
