package com.walmart.mobile.checkout.handler.receive;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.handler.annotation.Headers;

import com.walmart.mobile.checkout.annotation.JmsHandler;
import com.walmart.mobile.checkout.annotation.JmsRetry;
import com.walmart.mobile.checkout.bean.PhoneMsg;
import com.walmart.mobile.checkout.service.EGiftCardRegisterService;

@JmsHandler
public class EgiftcardReceiveHandler {
	private static final Logger LOGGER = LoggerFactory.getLogger(EgiftcardReceiveHandler.class);

	@Autowired
	private EGiftCardRegisterService eGiftCardRegisterService;

	@JmsListener(destination = "${egiftcard.register.queue.name}")
	@JmsRetry(3)
	public void processRegisterEgiftcard(String mobilePhone, @Headers Map<String, Object> headers) throws Exception {
		LOGGER.info("egiftcard.register mobilePhone:{}",mobilePhone);
		eGiftCardRegisterService.register(mobilePhone);
	}
	
	
	@JmsListener(destination = "${egiftcard.change.queue.name}")
	@JmsRetry(3)
	public void processChangeEgiftcard(PhoneMsg phoneMsg, @Headers Map<String, Object> headers) throws Exception {
		LOGGER.info("egiftcard.change phone msg:{}",phoneMsg);
		eGiftCardRegisterService.modifyMobilePhone(phoneMsg.getMobilePhone(),phoneMsg.getNewMobilePhone());
	}
}
