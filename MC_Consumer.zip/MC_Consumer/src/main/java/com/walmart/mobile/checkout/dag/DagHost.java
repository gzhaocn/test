package com.walmart.mobile.checkout.dag;

import java.io.IOException;
import java.sql.SQLException;
import java.text.MessageFormat;

import javax.sql.DataSource;

import com.alibaba.druid.pool.DruidDataSource;
import com.walmart.mobile.checkout.constant.GlobalErrorInfoEnum;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.utils.PropertyUtils;

public class DagHost {
	private static boolean isUserDag = false;

	/** dag编号 */
	private String dagId;

	/** 主机地址 ip */
	private String host;

	/** 数据源 */
	private DataSource dataSource;

	public String getDagId() {
		return dagId;
	}

	public void setDagId(String dagId) {
		this.dagId = dagId;
	}

	public String getHost() {
		return host;
	}

	public static final  void triggerUserDag(boolean bool) {
		isUserDag = bool;
	}

	/**
	 * 
	 * @param host
	 * @throws GlobalErrorInfoException
	 * @throws IOException
	 * @throws SQLException
	 */
	public void setHost(String host) throws GlobalErrorInfoException {
		this.host = host;
		DruidDataSource ds = new DruidDataSource();
		ds.setDriverClassName(PropertyUtils.getConfigValue("dag.class"));
		if (isUserDag) {
			ds.setUrl(MessageFormat.format(PropertyUtils.getConfigValue("user.dag.url"), host));
			ds.setUsername(PropertyUtils.getConfigValue("user.dag.username"));
			ds.setPassword(PropertyUtils.getConfigValue("user.dag.password"));
		} else {
			ds.setUrl(MessageFormat.format(PropertyUtils.getConfigValue("dag.url"), host));
			ds.setUsername(PropertyUtils.getConfigValue("dag.username"));
			ds.setPassword(PropertyUtils.getConfigValue("dag.password"));
		}
		ds.setInitialSize(Integer.valueOf(PropertyUtils.getConfigValue("dag.initialSize")));
		ds.setMaxActive(Integer.valueOf(PropertyUtils.getConfigValue("dag.maxActive")));
		ds.setMaxWait(Integer.valueOf(PropertyUtils.getConfigValue("dag.maxWait")));
		ds.setRemoveAbandonedTimeout(Integer.valueOf(PropertyUtils.getConfigValue("dag.removeAbandonedTimeoutMillis")));
		ds.setRemoveAbandoned(Boolean.valueOf(PropertyUtils.getConfigValue("dag.removeAbandoned")));
		ds.setLogAbandoned(Boolean.valueOf(PropertyUtils.getConfigValue("dag.logAbandoned")));
		try {
			ds.setFilters(PropertyUtils.getConfigValue("dag.filter"));
		} catch (SQLException e) {
			throw new GlobalErrorInfoException(GlobalErrorInfoEnum.DRUID_LOAD_FILTER, e);
		}
		this.dataSource = ds;
	}

	public DataSource getDataSource() {
		return dataSource;
	}
}
