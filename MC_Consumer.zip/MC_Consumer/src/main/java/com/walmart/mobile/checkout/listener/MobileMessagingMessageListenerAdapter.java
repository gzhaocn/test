package com.walmart.mobile.checkout.listener;

import java.util.UUID;

import javax.jms.JMSException;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.command.ActiveMQQueue;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.listener.adapter.MessagingMessageListenerAdapter;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessagingException;
import org.springframework.messaging.handler.invocation.InvocableHandlerMethod;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.annotation.JmsRetry;
import com.walmart.mobile.checkout.bean.RetryBean;
import com.walmart.mobile.checkout.constant.AppConstants;
import com.walmart.mobile.checkout.exception.ApplicationException;
import com.walmart.mobile.checkout.exception.ApplicationRuntimeException;
import com.walmart.mobile.checkout.handler.exp.JmsExceptionHandler;
import com.walmart.mobile.checkout.handler.send.RetrySendHandler;
import com.walmart.mobile.checkout.service.EmailService;
import com.walmart.mobile.checkout.utils.AppUtils;
import com.walmart.mobile.checkout.utils.ThreadLocalContextHolder;

public class MobileMessagingMessageListenerAdapter extends MessagingMessageListenerAdapter {
	private static final Logger LOGGER = LoggerFactory.getLogger(MobileMessagingMessageListenerAdapter.class);

	private static final String THREADNAMEMSG = "threadName";

	private JmsExceptionHandler jmsExceptionHandler;

	private InvocableHandlerMethod handlerMethod;

	private RetrySendHandler retrySendHandler;

	private Integer retry = AppConstants.EXP_RETRY;

	private boolean isEmail = true;

	private EmailService emailService;

	@Override
	public void setHandlerMethod(InvocableHandlerMethod handlerMethod) {
		this.handlerMethod = handlerMethod;
		JmsRetry jsmRetry = this.handlerMethod.getMethodAnnotation(JmsRetry.class);
		if (jsmRetry != null) {
			retry = jsmRetry.value();
			isEmail = jsmRetry.email();
		}
	}

	private void retrySendMessage(javax.jms.Message jmsMessage) {
		String threadNames = ThreadLocalContextHolder.get(THREADNAMEMSG, String.class);
		try {
			RetryBean retryBean = new RetryBean();
			retryBean.setSize(retry);
			retryBean.setCount(AppUtils.getJmsIntegerValue("count", jmsMessage));
			retryBean.setMessage(((TextMessage) jmsMessage).getText());
			retryBean.setCorrelationID(jmsMessage.getJMSCorrelationID());
			retryBean.setQueueName(((ActiveMQQueue) jmsMessage.getJMSDestination()).getQueueName());
			if (retryBean.isComplete()) {
				LOGGER.warn("Retry the message to complete.");
				if (isEmail) {
					emailService.sendEmailMsg(
							AppUtils.messageFormat("retry send message to end.thread Name:{0},message:{1}", threadNames,
									retryBean.getMessage()));
				}
			} else {
				retrySendHandler.sendMessage(retryBean);
			}
		} catch (Exception e) {
			String expMsg = AppUtils.messageFormat("retry send message exp. {0} times,cause:{1}", retry,
					e.getMessage());
			// 重新发送消息失败的情况下不需要重试
			exceptionHandler(new ApplicationException(expMsg, e), jmsMessage, false);
			if (isEmail) {
				emailService.sendEmailMsg(AppUtils.messageFormat("thread name:{0},", threadNames) + expMsg);
			}
		}
	}

	private void exceptionHandler(Throwable ex, javax.jms.Message jmsMessage, boolean isRetry) {
		if (ex instanceof ApplicationException) {
			jmsExceptionHandler.handleThrowable((ApplicationException) ex);
		} else if (ex instanceof ApplicationRuntimeException) {
			jmsExceptionHandler.handleThrowable((ApplicationRuntimeException) ex);
		} else {
			jmsExceptionHandler.handleThrowable(ex);
		}
		if (isRetry) {
			retrySendMessage(jmsMessage);
		}
	}

	@Override
	public void onMessage(javax.jms.Message jmsMessage, Session session) throws JMSException {
		long startTime = System.currentTimeMillis();
		String threadNames = getThreadName();
		String request = JSON.toJSONString(jmsMessage);
		String response = null;
		try {
			setUuidToThread(jmsMessage, threadNames, false);
			Message<?> message = toMessagingMessage(jmsMessage);
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("Processing [{}]", message);
			}
			Object result = invokeHandler(jmsMessage, session, message);
			if (result != null) {
				handleResult(result, jmsMessage, session);
				response = JSONObject.toJSONString(result);
			} else {
				LOGGER.trace("No result object given - no result to handle");
			}
		} catch (Exception ex) {
			exceptionHandler(ex, jmsMessage, this.retry > 0);
		} finally {
			Long used = System.currentTimeMillis() - startTime;
			LOGGER.info("used time:{} ms,request:{},response:{}", used, request, response);
			setUuidToThread(jmsMessage, threadNames, true);
			ThreadLocalContextHolder.clear();
		}
	}

	private Object invokeHandler(javax.jms.Message jmsMessage, Session session, Message<?> message)
			throws ApplicationException {
		try {
			return this.handlerMethod.invoke(message, jmsMessage, session);
		} catch (ApplicationException | ApplicationRuntimeException ex) {
			throw ex;
		} catch (MessagingException ex) {
			throw new ApplicationException(
					createMessagingErrorMessage("Listener method could not be invoked with incoming message"), ex);
		} catch (Exception ex) {
			throw new ApplicationException(
					"Listener method '" + this.handlerMethod.getMethod().toGenericString() + "' threw exception", ex);
		}
	}

	private String createMessagingErrorMessage(String description) {
		StringBuilder sb = new StringBuilder(description).append(",thread name:")
				.append(ThreadLocalContextHolder.get(THREADNAMEMSG, String.class)).append("\n")
				.append("Endpoint handler details:\n").append("Method [").append(this.handlerMethod.getMethod())
				.append("]\n").append("Bean [").append(this.handlerMethod.getBean()).append("]\n");
		return sb.toString();
	}

	private String getThreadName() {
		String threadNames = Thread.currentThread().getName();
		Integer index = threadNames.indexOf('|');
		if (index != -1) {
			threadNames = threadNames.substring(0, index).trim();
		}
		return threadNames;
	}

	private void setUuidToThread(javax.jms.Message jmsMessage, String threadNames, boolean bool) throws JMSException {
		if (bool) {
			Thread.currentThread().setName(threadNames);
			return;
		}
		StringBuilder nameBuff = new StringBuilder(threadNames);
		Integer count = AppUtils.getJmsIntegerValue("count", jmsMessage);
		String correlationID = getCorrelationID(jmsMessage);
		ThreadLocalContextHolder.put(THREADNAMEMSG, correlationID);
		nameBuff.append(" | ").append(logId(correlationID, count));
		Thread.currentThread().setName(nameBuff.toString());
	}

	private String getCorrelationID(javax.jms.Message jmsMessage) throws JMSException {
		String correlationID = jmsMessage.getJMSCorrelationID();
		if (StringUtils.isEmpty(correlationID)) {
			correlationID = UUID.randomUUID().toString();
		}
		jmsMessage.setJMSCorrelationID(correlationID);
		return correlationID;
	}

	private String logId(String correlationID, Integer count) {
		Integer num = count == null ? 1 : count;
		String logId = correlationID + "-" + num;
		ThreadLocalContextHolder.put("logId", logId);
		return logId;
	}

	public MobileMessagingMessageListenerAdapter setJmsExceptionHandler(JmsExceptionHandler jmsExceptionHandler) {
		this.jmsExceptionHandler = jmsExceptionHandler;
		return this;
	}

	public MobileMessagingMessageListenerAdapter setRetrySendHandler(RetrySendHandler retrySendHandler) {
		this.retrySendHandler = retrySendHandler;
		return this;
	}

	public MobileMessagingMessageListenerAdapter setEmailService(EmailService emailService) {
		this.emailService = emailService;
		return this;
	}
}
