package com.walmart.mobile.checkout.utils.sms;

import java.security.Security;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.walmart.mobile.checkout.utils.MD5Util;
import com.walmart.mobile.checkout.utils.PropertyUtils;
import com.walmart.mobile.checkout.utils.sms.ws.WebService;
import com.walmart.mobile.checkout.utils.ws.WebServiceSoap;

public class Client {
	private static final Logger LOG = LoggerFactory.getLogger(Client.class);

	private static final String SMS_SIGN_LANG_CN = "【沃尔玛】";
	private static final String SMS_SIGN_LANG_EN = "【Walmart】";
	private static int defaultSignLang = 0;

	private static WebService ws;
	private static WebServiceSoap wss;

	private String sn;
	private String password;
	private String pwd;

	private static Client client = null;
	private final static byte[] LOCK = new byte[0];

	public Client(String sn, String password) {
		this.sn = sn;
		this.password = password;
		this.pwd = MD5Util.md5(sn + password);
	}

	static {
		init();
	}

	public static Client getInstance() {
		synchronized (LOCK) {
			if (client == null) {
				String sn = PropertyUtils.getConfigValue("sms.username");
				String password = PropertyUtils.getConfigValue("sms.password");
				defaultSignLang = Integer.parseInt(PropertyUtils.getConfigValue("sms.sign.lang"));
				client = new Client(sn, password);
			}
		}
		return client;
	}

	private static void init() {
		System.setProperty("java.protocol.handler.pkgs", "com.sun.net.ssl.internal.www.protocol");
		Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
		System.setProperty("java.protocol.handler.pkgs", "javax.net.ssl");

		LOG.info("init config porxy. http.proxyHost={},http.proxyPort={},https.proxyHost={},https.proxyPort={}",
				PropertyUtils.getConfigValue("client.need.proxy"),
				PropertyUtils.getConfigValue("http.client.proxy.host"),
				PropertyUtils.getConfigValue("http.client.proxy.port"),
				PropertyUtils.getConfigValue("https.client.proxy.host"),
				PropertyUtils.getConfigValue("https.client.proxy.port"));

		Boolean needProxy = Boolean.parseBoolean(PropertyUtils.getConfigValue("client.need.proxy"));
		if (needProxy) {
			System.setProperty("http.proxyHost", PropertyUtils.getConfigValue("http.client.proxy.host"));
			System.setProperty("http.proxyPort", PropertyUtils.getConfigValue("http.client.proxy.port"));
			System.setProperty("https.proxyHost", PropertyUtils.getConfigValue("https.client.proxy.host"));
			System.setProperty("https.proxyPort", PropertyUtils.getConfigValue("https.client.proxy.port"));
		}

		HostnameVerifier hv = new HostnameVerifier() {
			@Override
			public boolean verify(String urlHostName, SSLSession session) {
				return urlHostName.equals(session.getPeerHost());
			}
		};
		HttpsURLConnection.setDefaultHostnameVerifier(hv);

		ws = new WebService();
		wss = ws.getWebServiceSoap();
		LOG.info("init config end . WebServiceSoap={}", wss);
	}

	public int mt(String mobile, String content, String ext, String stime, String rrid) {
		String result = "-1";
		String updatedContent = contentProc(content);

		if (defaultSignLang == 0) {
			result = wss.mt(sn, pwd, mobile, updatedContent, "", stime, rrid);
		} else if (defaultSignLang == 1) {
			result = wss.mt(sn, pwd, mobile, updatedContent, "", stime, rrid);
		} else {
			result = wss.mt(sn, pwd, mobile, updatedContent, ext, stime, rrid);
		}

		Long num = Long.parseLong(result);
		if (num <= 1L) {
			LOG.error("mt result .result={}", result);
			return -1;
		}
		return 0;
	}

	private String contentProc(String content) {
		if (content.endsWith(SMS_SIGN_LANG_CN) || content.endsWith(SMS_SIGN_LANG_EN)) {
			return content;
		} else if (defaultSignLang == 0) {
			return content.concat(SMS_SIGN_LANG_CN);
		} else {
			return content.concat(SMS_SIGN_LANG_EN);
		}
	}

	public int mt(String mobile, String content) {
		return this.mt(mobile, content, "", "", "");
	}

	public int balance() {
		String result = wss.balance(sn, pwd);
		return Integer.parseInt(result);
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getPassword() {
		return password;
	}

	public String getSn() {
		return sn;
	}

	public WebService getWs() {
		return ws;
	}

	public WebServiceSoap getWss() {
		return wss;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	@SuppressWarnings("static-access")
	public void setWs(WebService ws) {
		this.ws = ws;
	}

	@SuppressWarnings("static-access")
	public void setWss(WebServiceSoap wss) {
		this.wss = wss;
	}

}
