package com.walmart.mobile.checkout.service.push;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.walmart.mobile.checkout.utils.sms.Client;


/**
 * General push service processing class
 *
 * @author JiangZhihui
 *
 */
@Service("generalPushService")
public class GeneralPushHandler implements GeneralPushService {

	private static final Logger LOG = LoggerFactory.getLogger(GeneralPushHandler.class);

	// @Autowired
	// private AudioServiceSoap soap;

	@Override
	public int pushSmsAudio(String mobile, String txt) {
		// String sn = PropertyUtils.getConfigValue("sms.username");
		// String password = PropertyUtils.getConfigValue("sms.password");
		// String result = soap.mdAudioSend(sn, MD5Util.md5(sn + password),
		// "title", mobile, txt, "", "", "");
		// return result.startsWith("-") ? -1 : 0;
		return 0;
	}

	@Override
	public int pushSMS(String mobileNumber, String content, Object... params) {
		return sendSMSFromDmdelivery(mobileNumber, content, params);
	}

	/**
	 * Dmdelivery Send a text message interface call
	 *
	 * @param mobileNumber
	 * @param content
	 * @param messageParams
	 * @return
	 */
	public int sendSMSFromDmdelivery(String mobileNumber, String content, Object... params) {
		try {
			if (LOG.isInfoEnabled()) {
				LOG.info("Call SMS vendor DMdelivery send SMS. mobileNumber={}", mobileNumber);
			}
			Client client = Client.getInstance();
			int result = client.mt(mobileNumber, content);
			if (LOG.isInfoEnabled()) {
				LOG.info("Call SMS vendor DMdelivery send SMS is successful, returns the result：" + result);
			}
			return result;
		} catch (Exception e) {
			LOG.error("Call SMS vendor DMdelivery failure send text messages", e);
			return -1;
		}

	}

}
