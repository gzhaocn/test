package com.walmart.mobile.checkout.exception;

import java.io.Serializable;

import com.walmart.mobile.checkout.constant.GlobalErrorInfoEnum;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 返回体
 * @author lliao2
 */
@ApiModel
public class ResultBody implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3455864552409084052L;

	/**
	 * 响应代码
	 */
	@ApiModelProperty(value = "响应代码")
	private String code;

	/**
	 * 响应消息
	 */
	@ApiModelProperty(value = "响应消息")
	private String message;

	/**
	 * 响应结果
	 */
	@ApiModelProperty(value = "返回结果")
	private transient Object result;

	public ResultBody() {
		this.code = GlobalErrorInfoEnum.SUCCESS.getCode();
		this.message = GlobalErrorInfoEnum.SUCCESS.getMessage();
	}

	public ResultBody(ErrorInfoInterface errorInfo) {
		this.code = errorInfo.getCode();
		this.message = errorInfo.getMessage();
	}

	public ResultBody(Object result) {
		this.code = GlobalErrorInfoEnum.SUCCESS.getCode();
		this.message = GlobalErrorInfoEnum.SUCCESS.getMessage();
		this.result = result;
	}

	public ResultBody(Object result, ErrorInfoInterface errorInfo) {
		this.code = errorInfo.getCode();
		this.message = errorInfo.getMessage();
		this.result = result;
	}

	public ResultBody(Object result, String code, String message) {
		this.code = code;
		this.message = message;
		this.result = result;
	}

	public void setErrorInfoInterface(ErrorInfoInterface errorInfo) {
		this.code = errorInfo.getCode();
		this.message = errorInfo.getMessage();
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Object getResult() {
		return result;
	}

	public void setResult(Object result) {
		this.result = result;
	}

}
