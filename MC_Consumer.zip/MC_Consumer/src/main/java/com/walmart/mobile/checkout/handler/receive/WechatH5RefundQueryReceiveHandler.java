package com.walmart.mobile.checkout.handler.receive;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.handler.annotation.Headers;

import com.walmart.mobile.checkout.annotation.JmsHandler;
import com.walmart.mobile.checkout.annotation.JmsRetry;
import com.walmart.mobile.checkout.service.WechatH5RefundQueryService;

@JmsHandler
public class WechatH5RefundQueryReceiveHandler {

	@Autowired
	private WechatH5RefundQueryService wechatH5RefundQueryService;
	
	@JmsListener(destination = "${wechat.H5.refund.query.queue.name}")
	@JmsRetry(3)
	public void processWechatRefund(String recordsaleMessage, @Headers Map<String, Object> headers) throws Exception {
		wechatH5RefundQueryService.processWechatQueryRefund(recordsaleMessage);
	}

}
