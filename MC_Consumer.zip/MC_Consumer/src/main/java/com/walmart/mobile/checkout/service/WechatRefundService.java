package com.walmart.mobile.checkout.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.walmart.mobile.checkout.constant.RefundStatus;
import com.walmart.mobile.checkout.handler.send.WechatRefundResultSendHandler;
import com.walmart.mobile.checkout.utils.wechat.WXPay;
import com.walmart.mobile.checkout.utils.wechat.business.WechatRefundResultListener;
import com.walmart.mobile.checkout.utils.wechat.refund.protocol.RefundReqData;
import com.walmart.mobile.checkout.utils.wechat.refund.query.protocol.RefundQueryReqData;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@Service("wechatRefundService")
public class WechatRefundService {

	private static final Logger LOG = LoggerFactory.getLogger(WechatRefundService.class);
	
	@Autowired
	private WechatRefundResultSendHandler wechatRefundResultSendHandler;
	
	
	public void processWechatRefund(String wechatRefundMessage) throws Exception {
		int result = RefundStatus.RETURN_STATUS_REFUND_FAILED;
		RefundReqData refundReqData = JSON.parseObject(wechatRefundMessage, RefundReqData.class);
		
		WechatRefundResultListener listener = new WechatRefundResultListener();
		WXPay.doRefundBusiness(refundReqData, listener);
		result = listener.getReturn_status();
		if(result == RefundStatus.RETURN_STATUS_REFUND_PENDING){
			String errorMessage = listener.getResult();
			LOG.info("wechat refund result :{} , Message :{}", result ,errorMessage);
			RefundQueryReqData refundQueryReqData = new RefundQueryReqData(refundReqData.getAppid(),refundReqData.getMch_id(),  refundReqData.getOut_refund_no(),refundReqData.getOut_trade_no(),  true);
			wechatRefundResultSendHandler.sendMessage(JSON.toJSONString(refundQueryReqData));
		}else{
			LOG.info("errorCode {} , wechatRefundMessage :{}", listener.getErr_code() ,wechatRefundMessage);
		    throw new Exception(listener.getErr_code());
		}

	}

}
