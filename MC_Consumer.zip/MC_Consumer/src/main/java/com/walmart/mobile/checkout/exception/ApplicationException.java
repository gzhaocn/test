package com.walmart.mobile.checkout.exception;

import com.walmart.mobile.checkout.constant.ExceptionConstants;

public class ApplicationException extends Exception {
	private static final long serialVersionUID = 1L;

	private Integer code = ExceptionConstants.APP_EXP_DEFAULT_CODE;

	public ApplicationException(Throwable cause) {
		super(cause);
	}

	public ApplicationException(String message, Throwable cause) {
		super(message + " cause:" + cause.getMessage(), cause);
	}

	public ApplicationException(String message, Integer code, Throwable cause) {
		super(message + " cause:" + cause.getMessage(), cause);
		this.code = code;
	}

	public ApplicationException(String message) {
		super(message);
	}

	public ApplicationException(String message, Integer code) {
		super(message);
		this.code = code;
	}

	public Integer getErrorCode() {
		return code;
	}
}
