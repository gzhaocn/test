package com.walmart.mobile.checkout.handler.receive;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.handler.annotation.Headers;

import com.walmart.mobile.checkout.annotation.JmsHandler;
import com.walmart.mobile.checkout.annotation.JmsRetry;
import com.walmart.mobile.checkout.service.OrderStatusService;

@JmsHandler
public class OrderStatusReceiveHandler {

	private static final Logger LOGGER = LoggerFactory.getLogger(InvoiceReceiveHandler.class);
	@Autowired
	private OrderStatusService orderStatusService;


	
	@JmsListener(destination = "${order.status.queue.name}")
	@JmsRetry(3)
	public void orderStatusReceive(String orderIdMessage, @Headers Map<String, Object> headers) throws Exception {
		LOGGER.info("OrderStatusReceive info:{}", orderIdMessage);
		orderStatusService.updateOrderStatus(orderIdMessage);
	}

}
