package com.walmart.mobile.checkout.config;

import java.io.File;
import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.data.mongo.MongoDataAutoConfiguration;
import org.springframework.boot.autoconfigure.data.mongo.MongoRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.security.SecurityAutoConfiguration;
import org.springframework.boot.context.embedded.tomcat.TomcatEmbeddedServletContainerFactory;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsProcessor;
import org.springframework.web.cors.CorsUtils;
import org.springframework.web.cors.DefaultCorsProcessor;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

@Configuration
@EnableAutoConfiguration(exclude = { DataSourceAutoConfiguration.class, SecurityAutoConfiguration.class, MongoRepositoriesAutoConfiguration.class,
		MongoDataAutoConfiguration.class })
@Import({ ScanConfig.class, JmsConfig.class, RestConfig.class, UserDynamicConfig.class, DruidConfig.class, MongoDbConfig.class, DeliveryDbConfig.class })
@ComponentScan("com.walmart.mobile.checkout.controller,com.walmart.mobile.checkout.handler,com.walmart.mobile.checkout.service")
public class MainConfig {
	private static final Logger LOG = LoggerFactory.getLogger(MainConfig.class);

	@Value("${server.tomcat.docBase:WebContent}")
	private String documentRoot;

	private String[] origins;

	@Value("${cross.domain.origin}")
	public void setOrigin(String origin) {
		if (StringUtils.isNotEmpty(origin)) {
			this.origins = origin.split(",");
		}
	}

	@Bean
	public TomcatEmbeddedServletContainerFactory getTomcatEmbeddedServletContainerFactory() {
		TomcatEmbeddedServletContainerFactory tescf = new TomcatEmbeddedServletContainerFactory();
		documentRoot = documentRoot.startsWith("/") || documentRoot.startsWith("\\") ? documentRoot.substring(1) : documentRoot;
		tescf.setDocumentRoot(new File(documentRoot));
		return tescf;
	}

	public boolean isPass(HttpServletRequest request) {
		String method = request.getMethod();
		LOG.info("http url:{}, request method:{}", request.getRequestURL(), method);
		return "options".equalsIgnoreCase(method);
	}

	@Bean
	public FilterRegistrationBean CorsFilter() {
		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		final CorsConfiguration config = new CorsConfiguration();
		config.setAllowCredentials(true);
		if (origins != null) {
			for (String origin : origins) {
				config.addAllowedOrigin(origin);
			}
		}
		config.addAllowedHeader("*");
		config.addAllowedMethod("*");
		source.registerCorsConfiguration("/**", config);
		final CorsProcessor processor = new DefaultCorsProcessor();
		FilterRegistrationBean bean = new FilterRegistrationBean(new CorsFilter(source) {
			@Override
			protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
					throws ServletException, IOException {
				if (CorsUtils.isCorsRequest(request) && isPass(request)) {
					super.doFilterInternal(request, response, filterChain);
				} else {
					processor.processRequest(config, request, response);
					filterChain.doFilter(request, response);
				}
			}
		});
		bean.setOrder(0);
		return bean;
	}
}
