package com.walmart.mobile.checkout.utils;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.taglibs.standard.lang.jstl.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;

import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;

public class PropertyUtils extends PropertyPlaceholderConfigurer {
	private static Map<String, String> propertyMap = new HashMap<>();
	private static final Logger LOG = LoggerFactory.getLogger(PropertyUtils.class);

	private static Set<String> encryptSet;
	static {
		encryptSet = new HashSet<>();
		encryptSet.add("mongo.password");
		encryptSet.add("dag.password");
		encryptSet.add("user.dag.password");
		encryptSet.add("delivery.dag.password");
		encryptSet.add("activemq.password");
		encryptSet.add("weixin.certPassword");
		encryptSet.add("weixin.h5.certPassword");
	}

	public static Integer getConfigIntegerValue(String name) {
		String value = getConfigValue(name);
		if (StringUtils.isNotEmpty(name)) {
			return Integer.parseInt(value);
		}
		return 0;
	}

	public static String getConfigValue(String name) {
		String value = propertyMap.get(name);
		if (StringUtils.isEmpty(value)) {
			LOG.warn("", new ParseException("Property [" + name + "] is not set"));
		}
		return value;
	}

	@Override
	protected void convertProperties(Properties props) {
		try {
			AESUtils.setKey(props.getProperty("encrypt.seed"));
		} catch (GlobalErrorInfoException e) {
			LOG.error("AESUtils error :", e);
		}

		propertyMap = new HashMap<>();
		for (Object key : props.keySet()) {
			String value = props.getProperty(key.toString());
			if (encryptSet.contains(key.toString().trim())) {
				value = AESUtils.decode(value);
			}
			propertyMap.put(key.toString(), value);
		}
		super.convertProperties(props);
	}

	@Override
	protected String convertProperty(String propertyName, String propertyValue) {
		String result = super.convertProperty(propertyName, propertyValue);
		if (encryptSet.contains(propertyName.trim())) {
			result = AESUtils.decode(propertyValue);
		}
		return result;
	}
}
