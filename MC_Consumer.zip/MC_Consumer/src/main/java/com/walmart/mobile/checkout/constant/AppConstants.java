package com.walmart.mobile.checkout.constant;

/**
 * 应用需要的常量,除String的类型以外都尽量使用基本数据类型,而不要使用封装类.
 * 
 * 
 * @author kchen15
 * 
 */
public class AppConstants {
	/** upc格式化代码 */
	public static final String UPC_ID_FORMAT = "%012d";

	/** -------------------- des加密工具类 -------------------- */
	/** 字符集 */
	public static final String UTF_8 = "UTF-8";
	/** des算法的加密种子 */
	public static final String DES_DEFAULT_SEED = "ISD.Jenkins@email.wal-mart.com/cn";
	/** 加密算法 */
	public static final String DES = "DES";

	public static final String SHA1PRNG = "SHA1PRNG";
	/** -------------------- 重试常量 -------------------- */
	/** 异常重试次数 */
	public static final int EXP_RETRY = 5;
	/** 基础时间 */
	public static final long BASE_TIMTE = 3 * 100000L; 
	/** 基础倍数 */
	public static final long BASE_MULTIPLES = 2L;
	/** 基础被减数 */
	public static final long BASE_SUB = 2L;
	/** 最大延迟时间6小时 */
	public static final long MAX_DELAY_TIME = (2 << 10) * BASE_TIMTE;

	/** 延迟发送其他另外队列的时间 */
	public static final long OTHER_QUEUE_DELAY_TIMTE = 200 * BASE_TIMTE;

	/** 删除ES的数据 */
	public static final long DELETE_IN_ELASTIC = 2L;

	/** 新增或者更新ES的数据 */
	public static final long ADD_OR_UPDATE_IN_ELASTIC = 1L;

	public static final String MONGODB_USER_NAME = "mongodbUserName";

	public static final String MONGODB_NAME = "mongodbName";

	public static final String MONGODB_PASS_WORD = "mongodbPassword";

	
	public static final String SYS_APP_KEY ="RECORD_SALE";
	
	public static final String RECORD_SALE_VERSION ="1.0.0";
	
	public static final String RECORD_SALE_FORMAT ="JSON";
	
	public static final String RECORD_SALE_APPSECUERT ="mobileCK";
	
}
