package com.walmart.mobile.checkout.service;

import java.security.NoSuchAlgorithmException;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.bean.QueryOrderParamter;
import com.walmart.mobile.checkout.constant.AppConstants;
import com.walmart.mobile.checkout.exception.ApplicationException;
import com.walmart.mobile.checkout.utils.SHA512;

@Service("invoiceService")
public class InvoiceService {

	private static final Logger LOG = LoggerFactory.getLogger(InvoiceService.class);

	private static final String NEED_REPLACE_APPLYKEY = "#####@@@#####";

	private static final String TC_NUMBER_NULL = "#TC_NUMBER#";

	
	private static final String INVOICE_SUCCESS_CODE = "0";

	private static final String INVOICE_HAS_SEND_CODE = "-1";
	@Autowired
	RestTemplate restTemplate;

	@Value("${invoice.customerNo}")
	private String customerNo;

	@Value("${invoice.applykey.url}")
	private String applyKeyUrl;

	@Value("${invoice.applyBill.url}")
	private String applyBillUrl;
	
	@Value("${order.status.url}")
	private String orderStatusUrl;

	public void processInvoice(String invoiceMessage) throws Exception {

		JSONObject jsonObject = JSON.parseObject(invoiceMessage);
		String requestData = jsonObject.getString("requestData");
		JSONObject requestDataJson = JSON.parseObject(requestData);
		
	    String	invoiceMessageTcNumber = repalceTcNumber(invoiceMessage, requestDataJson);
		
		JSONArray userArrayJson = requestDataJson.getJSONArray("user"); // jsonobject对象取得some对应的jsonarray数组
		JSONObject userObject = userArrayJson.getJSONObject(0);
		String userId = userObject.getString("userId");
		String mobilePhone = userObject.getString("mobilePhone");

		MultiValueMap<String, String> map = getInvoiceApplyKey(userId, mobilePhone);
		String result = sendMessage(map, applyKeyUrl);
		LOG.info("  applyKey result : {} ", result);

		JSONObject applyKeyObject = JSON.parseObject(result);
		String header = applyKeyObject.getString("header");
		JSONObject jsonHeader = JSON.parseObject(header);
		String code = jsonHeader.getString("code");
		if (INVOICE_SUCCESS_CODE.equals(code)) {
			String body = applyKeyObject.getString("body");
			JSONObject bodyHeader = JSON.parseObject(body);
			String applyKey = bodyHeader.getString("appKey");
			LOG.info(" applyKey : {}", applyKey);

			// 开始发送发票信息
			String invoiceJson = repalceApplyKey(invoiceMessageTcNumber, applyKey);
			LOG.info("send invoice info :{} ", invoiceJson);
			String invoiceResult = sendInvoiceInfoMessage(invoiceJson, applyBillUrl);
			LOG.info("invoiceResult : {}", invoiceResult);

			JSONObject invoiceResultObject = JSON.parseObject(invoiceResult);
			String invoiceResultHeader = invoiceResultObject.getString("header");
			JSONObject invoiceResultString = JSON.parseObject(invoiceResultHeader);
			String invoiceResultCode = invoiceResultString.getString("code");
			if (INVOICE_HAS_SEND_CODE.equals(invoiceResultCode)) {
				LOG.info("invoice has send");
			} else if (INVOICE_SUCCESS_CODE.equals(invoiceResultCode)) {
				LOG.info("invoice send success");
			} else {
				throw new ApplicationException("invoice created fail", -1);
			}
		} else {
			LOG.info("  applyKey fail , reason : {}", jsonHeader.getString("message"));
			throw new ApplicationException("applyKey fail", -1);
		}

	}

	private MultiValueMap<String, String> getInvoiceApplyKey(String userId, String mobilePhone) {
		LOG.info("send applykey info");
		MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
		map.add("customerNo", customerNo);
		map.add("userName", "mobilecheckout");
		map.add("platformNo", userId);
		map.add("tel", mobilePhone);

		return map;
	}

	private String sendMessage(MultiValueMap<String, String> map, String url) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		return restTemplate.postForObject(url, map, String.class);
	}

	private String sendInvoiceInfoMessage(String message, String url) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		HttpEntity<String> entity = new HttpEntity<>(message, headers);
		return restTemplate.postForObject(url, entity, String.class);
	}

	private String repalceApplyKey(String invoiceMessage, String applyKey) {
		return invoiceMessage.replaceAll(NEED_REPLACE_APPLYKEY, applyKey);
	}
	
	private String repalceTcNumber(String invoiceMessage , JSONObject requestDataJson ) throws ApplicationException{
		if(invoiceMessage.indexOf(TC_NUMBER_NULL) != -1){
			JSONArray mainArrayJson = requestDataJson.getJSONArray("main"); 
			JSONObject mainObject = mainArrayJson.getJSONObject(0);
			String realOrderId = mainObject.getString("remark");
			
			String queryOrderResult = getOrderInfo(realOrderId);
			LOG.info("order queryOrderResult {}  ", queryOrderResult);
			JSONObject orderStatusResult = JSON.parseObject(queryOrderResult);
			String code = orderStatusResult.getString("code");

			if ("0".endsWith(code)) {
				String orderInformation = orderStatusResult.getString("result");
				JSONObject orderInformationObject = JSON.parseObject(orderInformation);
				Integer status = orderInformationObject.getInteger("status");
				String tcNumber = orderInformationObject.getString("tcNumber");
				
				LOG.info("order query result code:{} , order status :{} , tcNumber : {} ", code, status, tcNumber);
				if(StringUtils.isBlank(tcNumber)||TC_NUMBER_NULL.equals(tcNumber)){
					throw new ApplicationException("tcnumber is empty , orderId is "+realOrderId);
				}
				return invoiceMessage.replaceAll(TC_NUMBER_NULL, tcNumber);
			}else{
				throw new ApplicationException("query tcnumber fail, orderId is "+realOrderId);
			}
		}
		return invoiceMessage ;
	}
	
	private String getOrderInfo(String orderId) throws ApplicationException {

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		QueryOrderParamter queryOrderParamter = new QueryOrderParamter();
		Date date = new Date();
		queryOrderParamter.setOrderId(orderId);
		queryOrderParamter.setAppKey(AppConstants.SYS_APP_KEY);
		queryOrderParamter.setFormat(AppConstants.RECORD_SALE_FORMAT);
		queryOrderParamter.setVersion(AppConstants.RECORD_SALE_VERSION);
		queryOrderParamter.setTimeStamp(date);

		StringBuilder sb = new StringBuilder();
		String signString = sb.append(AppConstants.SYS_APP_KEY).append(AppConstants.RECORD_SALE_VERSION)
				.append(AppConstants.RECORD_SALE_FORMAT).append(date).append(orderId)
				.append(AppConstants.RECORD_SALE_APPSECUERT).toString();

		String checkSign = StringUtils.EMPTY;

		try {
			checkSign = SHA512.hashValue(signString);
		} catch (NoSuchAlgorithmException e) {
			LOG.error("can't build checkSum", e);
			throw new ApplicationException("build checkSum  fail");
		}

		LOG.info("orderId : {} ,  checkSign :{}  ", orderId, checkSign);

		queryOrderParamter.setSign(checkSign);

		HttpEntity<String> queryOrderParamterEntity = new HttpEntity<>(JSON.toJSONString(queryOrderParamter), headers);
		return restTemplate.postForObject(orderStatusUrl, queryOrderParamterEntity, String.class);

	}

	
}
