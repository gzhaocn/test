package com.walmart.mobile.checkout.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSON;
import com.walmart.mobile.checkout.utils.wechat.WXPay;
import com.walmart.mobile.checkout.utils.wechat.business.WechatRefundQueryResultListener;
import com.walmart.mobile.checkout.utils.wechat.refund.query.protocol.RefundQueryReqData;

@Service("wechatRefundQueryService")
public class WechatRefundQueryService {

	
	@Autowired
	RestTemplate restTemplate;

	@Value("${refund.url}")
	private String refundUrl;
	

	public void processWechatQueryRefund(String wechatRefundMessage) throws Exception {
		
		RefundQueryReqData	refundQueryReqData =	JSON.parseObject(wechatRefundMessage, RefundQueryReqData.class);
		WechatRefundQueryResultListener resultListener = new WechatRefundQueryResultListener();
		WXPay.doRefundQueryBusiness(refundQueryReqData, resultListener,  restTemplate , refundUrl);
		
		
	}

}
