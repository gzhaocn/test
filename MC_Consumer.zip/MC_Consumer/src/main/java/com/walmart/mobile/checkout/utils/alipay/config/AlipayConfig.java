package com.walmart.mobile.checkout.utils.alipay.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.walmart.mobile.checkout.utils.PropertyUtils;

public class AlipayConfig {
	
	public static String partner;

	public static String seller;

	public static String privateKey;
	public static String publicKey;

	public static String aliPublicKey;

	public static String inputCharset;

	public static String signType;

	public static String httpsURL;
	private static final Logger LOG = LoggerFactory.getLogger(AlipayConfig.class);

	
	static {
		try {
			AlipayConfig.partner = PropertyUtils.getConfigValue("alipay.partner");
			AlipayConfig.seller = PropertyUtils.getConfigValue("alipay.seller");
			AlipayConfig.privateKey = PropertyUtils.getConfigValue("alipay.private_key");
			AlipayConfig.publicKey = PropertyUtils.getConfigValue("alipay.public_key");
			AlipayConfig.aliPublicKey = PropertyUtils.getConfigValue("alipay.ali_public_key");
			AlipayConfig.inputCharset = PropertyUtils.getConfigValue("alipay.input_charset");
			AlipayConfig.signType = PropertyUtils.getConfigValue("alipay.sign_type");
			AlipayConfig.httpsURL = PropertyUtils.getConfigValue("alipay.HTTPS_URL");
	} catch (Exception e) {
		LOG.error("initAlipayConfig error ", e);
	}
	}
}
