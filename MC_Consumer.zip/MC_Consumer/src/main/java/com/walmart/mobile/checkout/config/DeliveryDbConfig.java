package com.walmart.mobile.checkout.config;

import java.io.IOException;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.mybatis.spring.SqlSessionFactoryBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import com.alibaba.druid.pool.DruidDataSource;
import com.walmart.mobile.checkout.constant.GlobalErrorInfoEnum;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoException;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoRuntimeException;
import com.walmart.mobile.checkout.utils.PropertyUtils;

@Configuration
public class DeliveryDbConfig {
	@Value("${delivery.dag.username}")
	private String username;

	@Value("${delivery.dag.password}")
	private String password;

	@Value("${delivery.dag.url}")
	private String url;

	@Bean(name = "deliveryDataSource")
	public DataSource deliveryDataSource() throws GlobalErrorInfoException {
		DruidDataSource ds = new DruidDataSource();
		ds.setDriverClassName(PropertyUtils.getConfigValue("dag.class"));
		ds.setUrl(url);
		ds.setUsername(username);
		ds.setPassword(password);
		ds.setInitialSize(Integer.valueOf(PropertyUtils.getConfigValue("dag.initialSize")));
		ds.setMaxActive(Integer.valueOf(PropertyUtils.getConfigValue("dag.maxActive")));
		ds.setMaxWait(Integer.valueOf(PropertyUtils.getConfigValue("dag.maxWait")));
		ds.setRemoveAbandonedTimeout(Integer.valueOf(PropertyUtils.getConfigValue("dag.removeAbandonedTimeoutMillis")));
		ds.setRemoveAbandoned(Boolean.valueOf(PropertyUtils.getConfigValue("dag.removeAbandoned")));
		ds.setLogAbandoned(Boolean.valueOf(PropertyUtils.getConfigValue("dag.logAbandoned")));
		try {
			ds.setFilters(PropertyUtils.getConfigValue("dag.filter"));
		} catch (SQLException e) {
			throw new GlobalErrorInfoException(GlobalErrorInfoEnum.DRUID_LOAD_FILTER, e);
		}
		return ds;
	}

	public Resource[] getXmlResource() {
		String packageSearchPath = "classpath*:deliveryMapper/**/*.xml";
		Resource[] resources = null;
		try {
			resources = new PathMatchingResourcePatternResolver().getResources(packageSearchPath);
		} catch (IOException e) {
			throw new GlobalErrorInfoRuntimeException(GlobalErrorInfoEnum.RESOURCE_NOT_EXIST, e);
		}
		return resources;
	}

	@Bean(name = "deliverySqlServerSessionFactory")
	public SqlSessionFactoryBean deliverySqlServerSessionFactory() throws GlobalErrorInfoException {
		SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
		bean.setDataSource(deliveryDataSource());
		bean.setMapperLocations(getXmlResource());
		return bean;
	}

	@Bean(name = "deliverySqlServerTransactionManager")
	public DataSourceTransactionManager deliverySqlServerTransactionManager() throws GlobalErrorInfoException {
		return new DataSourceTransactionManager(deliveryDataSource());
	}
}
