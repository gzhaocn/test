
package com.walmart.mobile.checkout.utils.ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for anonymous complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="report2DESResult" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "report2DESResult" })
@XmlRootElement(name = "report2DESResponse")
public class Report2DESResponse {

	protected String report2DESResult;

	/**
	 * Gets the value of the report2DESResult property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getReport2DESResult() {
		return report2DESResult;
	}

	/**
	 * Sets the value of the report2DESResult property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setReport2DESResult(String value) {
		this.report2DESResult = value;
	}

}
