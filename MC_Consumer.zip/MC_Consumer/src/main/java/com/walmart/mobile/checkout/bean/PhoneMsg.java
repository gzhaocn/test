package com.walmart.mobile.checkout.bean;

public class PhoneMsg {
	

	/** 通常情况使用 **/
	String mobilePhone;
	/** 用于银商同步修改电话的时候用，放新的时候号码，mobilePhone 用于储存旧的手机号码 **/
	String newMobilePhone;
	String msg;
	
	
	public PhoneMsg() {
		super();
	}

	public PhoneMsg(String mobilePhone, String msg) {
		super();
		this.mobilePhone = mobilePhone;
		this.msg = msg;
	}
	
	public PhoneMsg(String mobilePhone, String newMobilePhone, String msg) {
		super();
		this.mobilePhone = mobilePhone;
		this.newMobilePhone = newMobilePhone;
		this.msg = msg;
	}

	public String getNewMobilePhone() {
		return newMobilePhone;
	}
	public void setNewMobilePhone(String newMobilePhone) {
		this.newMobilePhone = newMobilePhone;
	}
	public String getMobilePhone() {
		return mobilePhone;
	}
	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}

	@Override
	public String toString() {
		return "PhoneMsg [mobilePhone=" + mobilePhone + ", newMobilePhone=" + newMobilePhone + ", msg=" + msg + "]";
	}
	
}
