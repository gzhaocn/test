package com.walmart.mobile.checkout.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service("unionpayRefundService")
public class UnionpayRefundService {

	private static final Logger LOG = LoggerFactory.getLogger(UnionpayRefundService.class);

	
	public void processUnionpayRefund(String unionpayRefundMessage) throws Exception {
		
	
	}

}
