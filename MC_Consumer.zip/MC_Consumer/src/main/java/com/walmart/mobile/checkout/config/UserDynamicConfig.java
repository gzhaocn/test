package com.walmart.mobile.checkout.config;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.mybatis.spring.SqlSessionFactoryBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONObject;
import com.walmart.mobile.checkout.constant.GlobalErrorInfoEnum;
import com.walmart.mobile.checkout.dag.DagHost;
import com.walmart.mobile.checkout.dag.HostData;
import com.walmart.mobile.checkout.datasource.DynamicDataSource;
import com.walmart.mobile.checkout.exception.exceptionType.GlobalErrorInfoRuntimeException;

@Configuration
public class UserDynamicConfig {

	private static final Logger LOG = LoggerFactory.getLogger(UserDynamicConfig.class);

	@Value("${ddr.request.param}")
	private String ddrParam;

	@Value("${ddr.request.url}")
	private String ddrUrl;

	@Value("${check.user.url}")
	private String checkUserUrl;

	@Autowired
	private RestTemplate restTemplate;

	@Bean(name = "userDynamicDataSource")
	@Primary
	public DataSource userDynamicDataSource() {
		LOG.info("dynamic user datasource init.");
		DagHost.triggerUserDag(true);
		DynamicDataSource userDynamicDataSource = new DynamicDataSource();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<>(ddrParam, headers);
		String result = restTemplate.postForObject(ddrUrl, entity, String.class);
		DagHost.triggerUserDag(true);
		List<DagHost> dss = JSONObject.parseObject(result, HostData.class).getData();
		Map<Object, Object> dataSources = new HashMap<>(16);
		for (int i = 0; i < dss.size(); i++) {
			DagHost dh = dss.get(i);
			String key = dh.getDagId();
			dataSources.put(key, dh.getDataSource());
		}
		userDynamicDataSource.setTargetDataSources(dataSources);
		userDynamicDataSource.afterPropertiesSet();
		return userDynamicDataSource;
	}

	public Resource[] getXmlResource() {
		String packageSearchPath = "classpath*:userMapper/**/*.xml";
		Resource[] resources = null;
		try {
			resources = new PathMatchingResourcePatternResolver().getResources(packageSearchPath);
		} catch (IOException e) {
			throw new GlobalErrorInfoRuntimeException(GlobalErrorInfoEnum.RESOURCE_NOT_EXIST, e);
		}
		return resources;
	}

	@Bean(name = "userDynamicSqlServerSessionFactory")
	@Primary
	public SqlSessionFactoryBean userDynamicSqlServerSessionFactory() {
		SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
		bean.setDataSource(userDynamicDataSource());
		bean.setMapperLocations(getXmlResource());
		return bean;
	}

	@Bean(name = "userDynamicSqlServerTransactionManager")
	@Primary
	public DataSourceTransactionManager userDynamicSqlServerTransactionManager() {
		return new DataSourceTransactionManager(userDynamicDataSource());
	}
}
