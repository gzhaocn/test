package com.walmart.mobile.checkout.exception;

import com.walmart.mobile.checkout.constant.ExceptionConstants;

public class ApplicationRuntimeException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Integer code;

	public ApplicationRuntimeException(Throwable cause) {
		this(cause.getMessage(), cause);
	}

	public ApplicationRuntimeException(String msg, Throwable cause) {
		this(msg, ExceptionConstants.APP_EXP_DEFAULT_CODE, cause);
	}

	public ApplicationRuntimeException(String msg, Integer code, Throwable cause) {
		super(msg, cause);
		this.code = code;
	}

	public Integer getErrorCode() {
		return code;
	}
}
